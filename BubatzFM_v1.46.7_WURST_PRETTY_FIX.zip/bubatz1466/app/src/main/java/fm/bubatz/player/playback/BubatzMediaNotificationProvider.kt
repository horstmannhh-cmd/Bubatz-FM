package fm.bubatz.player.playback

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.annotation.OptIn
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession
import com.google.common.collect.ImmutableList
import fm.bubatz.player.MainActivity
import fm.bubatz.player.R

/**
 * v0.93 Samsung status-bar chip isolation test.
 *
 * v0.92 still started from Media3's generated notification and rebuilt it.  This
 * version deliberately creates a clean framework Notification.MediaStyle notification
 * from scratch and attaches the already-tested classic platform MediaSession token.
 * Playback itself, Media3 session, queue, crossfade and scrobbling stay untouched.
 */
@OptIn(UnstableApi::class)
class BubatzMediaNotificationProvider(
    private val context: Context,
    private val onMetadataSeen: ((MediaMetadata) -> Unit)? = null,
    private val platformSessionToken: (() -> android.media.session.MediaSession.Token?)? = null
) : MediaNotification.Provider {

    private val delegate = DefaultMediaNotificationProvider.Builder(context)
        .setChannelId("bubatz_media_playback")
        .setChannelName(R.string.app_name)
        .build()

    override fun createNotification(
        mediaSession: MediaSession,
        mediaButtonPreferences: ImmutableList<CommandButton>,
        actionFactory: MediaNotification.ActionFactory,
        onNotificationChangedCallback: MediaNotification.Provider.Callback
    ): MediaNotification {
        val metadata = mediaSession.player.mediaMetadata
        onMetadataSeen?.invoke(metadata)

        // Keep Media3's callback machinery alive for asynchronous metadata changes,
        // but always replace its result with our clean platform notification.
        val wrappedCallback = MediaNotification.Provider.Callback {
            onNotificationChangedCallback.onNotificationChanged(buildPlatformNotification(mediaSession))
        }
        delegate.createNotification(mediaSession, mediaButtonPreferences, actionFactory, wrappedCallback)

        return buildPlatformNotification(mediaSession)
    }

    override fun handleCustomCommand(session: MediaSession, action: String, extras: Bundle): Boolean =
        delegate.handleCustomCommand(session, action, extras)

    /**
     * v1.09: Media3 does not reliably ask a custom provider to rebuild the Samsung
     * live card at every dual-deck crossfade handoff. Force-publish the notification
     * from the CURRENT session metadata whenever PlaybackService observes a metadata
     * or item transition. Same ID, same MediaStyle/session token, only fresh content.
     */
    fun forceRefresh(mediaSession: MediaSession) {
        val mediaNotification = buildPlatformNotification(mediaSession)
        context.getSystemService(NotificationManager::class.java)
            ?.notify(mediaNotification.notificationId, mediaNotification.notification)
    }

    private fun buildPlatformNotification(mediaSession: MediaSession): MediaNotification {
        val player = mediaSession.player
        val metadata = player.mediaMetadata
        val title = metadata.title?.toString()?.trim().orEmpty().ifEmpty { "Bubatz FM" }
        val artist = metadata.artist?.toString()?.trim().orEmpty()
        val album = metadata.albumTitle?.toString()?.trim().orEmpty()

        fun serviceIntent(action: String, requestCode: Int): PendingIntent = PendingIntent.getService(
            context,
            requestCode,
            Intent(context, PlaybackService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openApp = PendingIntent.getActivity(
            context,
            9300,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val playPauseIcon = if (player.isPlaying) android.R.drawable.ic_media_pause
            else android.R.drawable.ic_media_play
        val playPauseLabel = if (player.isPlaying) "Pause" else "Play"

        val builder = Notification.Builder(context, "bubatz_media_playback")
            .setSmallIcon(R.drawable.bubatz_notification_pretty)
            .setContentIntent(openApp)
            .setCategory(Notification.CATEGORY_TRANSPORT)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setPriority(Notification.PRIORITY_HIGH)
            .setOnlyAlertOnce(false)
            .setOngoing(false)
            .setContentTitle(title)
            .setContentText(artist.ifEmpty { album })
            .setSubText(album.ifEmpty { null })
            .addAction(Notification.Action.Builder(
                android.R.drawable.ic_media_previous, "Zurück",
                serviceIntent(PlaybackService.ACTION_PREVIOUS, 9301)
            ).build())
            .addAction(Notification.Action.Builder(
                playPauseIcon, playPauseLabel,
                serviceIntent(PlaybackService.ACTION_PLAY_PAUSE, 9302)
            ).build())
            .addAction(Notification.Action.Builder(
                android.R.drawable.ic_media_next, "Weiter",
                serviceIntent(PlaybackService.ACTION_NEXT, 9303)
            ).build())

        // v1.34: Keep the system media card on the same artwork policy as the app UI.
        // If Media3 has embedded artwork, use it. Otherwise publish Bubatz.FM's
        // fallback artwork instead of leaving Samsung's media card without an image.
        val notificationArtwork = metadata.artworkData
            ?.takeIf { it.isNotEmpty() }
            ?.let { bytes ->
                runCatching { BitmapFactory.decodeByteArray(bytes, 0, bytes.size) }.getOrNull()
            }
            ?: BitmapFactory.decodeResource(context.resources, R.drawable.bubatz_app_icon_dark)

        notificationArtwork?.let(builder::setLargeIcon)

        platformSessionToken?.invoke()?.let { token ->
            builder.setStyle(
                Notification.MediaStyle()
                    .setMediaSession(token)
                    .setShowActionsInCompactView(0, 1, 2)
            )
        }

        val notification = builder.build().apply {
            flags = flags and Notification.FLAG_ONGOING_EVENT.inv()
            flags = flags or Notification.FLAG_NO_CLEAR
            flags = flags and Notification.FLAG_ONLY_ALERT_ONCE.inv()
        }
        return MediaNotification(1001, notification)
    }
}
