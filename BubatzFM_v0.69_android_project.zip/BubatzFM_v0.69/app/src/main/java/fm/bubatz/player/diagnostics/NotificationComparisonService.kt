package fm.bubatz.player.diagnostics

import android.app.Notification
import android.app.NotificationManager
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import fm.bubatz.player.CrashDiagnostics

class NotificationComparisonService : NotificationListenerService() {
    override fun onListenerConnected() { saveComparison() }
    override fun onNotificationPosted(sbn: StatusBarNotification?) { saveComparison() }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) { saveComparison() }

    private fun saveComparison() {
        runCatching {
            val notifications = activeNotifications ?: emptyArray()
            val interesting = notifications.filter { sbn ->
                sbn.packageName == packageName ||
                    sbn.packageName.contains("omnia", ignoreCase = true) ||
                    sbn.notification.extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.contains("Omnia", true) == true
            }
            val report = buildString {
                append("v0.69: Omnia ↔ Bubatz FM Tiefenvergleich\n")
                append("listenerConnected=true\n")
                append("aktive Benachrichtigungen=${notifications.size}\n")
                append("Treffer=${interesting.size}\n\n")
                if (interesting.isEmpty()) append("Keine Bubatz-/Omnia-Benachrichtigung gefunden. Omnia und Bubatz FM gleichzeitig abspielen bzw. geöffnet lassen und erneut aktualisieren.\n")
                interesting.forEachIndexed { i, sbn ->
                    if (i > 0) append("\n────────────\n")
                    append(describe(sbn))
                }
            }
            CrashDiagnostics(this).saveNotificationComparison(report)
        }.onFailure {
            CrashDiagnostics(this).saveNotificationComparison("v0.69 VERGLEICHSFEHLER\n${it::class.java.simpleName}: ${it.message}")
        }
    }

    private fun describe(sbn: StatusBarNotification): String {
        val n = sbn.notification
        val nm = getSystemService(NotificationManager::class.java)
        val channel = if (Build.VERSION.SDK_INT >= 26) n.channelId?.let { nm?.getNotificationChannel(it) } else null
        val promotedFlag = runCatching { Notification::class.java.getField("FLAG_PROMOTED_ONGOING").getInt(null) }.getOrNull()
        val promotable = runCatching { Notification::class.java.getMethod("hasPromotableCharacteristics").invoke(n) as? Boolean }.getOrNull()
        return buildString {
            append("package=").append(sbn.packageName).append('\n')
            append("id=").append(sbn.id).append('\n')
            append("ongoing=").append((n.flags and Notification.FLAG_ONGOING_EVENT) != 0).append('\n')
            append("promotedFlag=").append(promotedFlag?.let { (n.flags and it) != 0 }).append('\n')
            append("promotable=").append(promotable).append('\n')
            append("category=").append(n.category).append('\n')
            append("group=").append(n.group).append('\n')
            append("channel=").append(if (Build.VERSION.SDK_INT >= 26) n.channelId else "n/a").append('\n')
            append("importance=").append(channel?.importance).append('\n')
            append("style=").append(n.extras?.getString("android.template")).append('\n')
            append("title=").append(n.extras?.getCharSequence(Notification.EXTRA_TITLE)).append('\n')
            append("text=").append(n.extras?.getCharSequence(Notification.EXTRA_TEXT)).append('\n')
            append("subText=").append(n.extras?.getCharSequence(Notification.EXTRA_SUB_TEXT)).append('\n')
            append("mediaSession=").append(n.extras?.containsKey("android.mediaSession")).append('\n')
            append("flags=0x").append(n.flags.toString(16)).append('\n')
        }
    }
}
