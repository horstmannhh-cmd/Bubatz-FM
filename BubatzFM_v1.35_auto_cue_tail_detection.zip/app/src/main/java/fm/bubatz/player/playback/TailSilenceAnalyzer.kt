package fm.bubatz.player.playback

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.sqrt

/**
 * Conservative tail analyser used by Bubatz.FM Auto-Cue.
 *
 * It decodes only the final few seconds of the file and reports the end of the
 * last clearly audible PCM buffer.  A cue point is returned only when there is
 * a meaningful trailing-silence tail; otherwise callers keep the proven legacy
 * transition behaviour unchanged.
 */
class TailSilenceAnalyzer(private val context: Context) {

    data class Result(
        val cueOutMs: Long,
        val trailingSilenceMs: Long
    )

    fun analyze(uri: Uri, declaredDurationMs: Long): Result? {
        if (declaredDurationMs <= MIN_DURATION_MS) return null

        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(context, uri, null)

            var audioTrack = -1
            var inputFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("audio/")) {
                    audioTrack = i
                    inputFormat = f
                    break
                }
            }
            if (audioTrack < 0 || inputFormat == null) return null

            val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: return null
            val formatDurationUs = if (inputFormat.containsKey(MediaFormat.KEY_DURATION)) {
                inputFormat.getLong(MediaFormat.KEY_DURATION)
            } else {
                declaredDurationMs * 1000L
            }
            val durationUs = formatDurationUs.takeIf { it > 0L } ?: (declaredDurationMs * 1000L)
            val analysisStartUs = (durationUs - ANALYZE_TAIL_US).coerceAtLeast(0L)

            extractor.selectTrack(audioTrack)
            extractor.seekTo(analysisStartUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(inputFormat, null, null, 0)
            codec.start()

            val info = MediaCodec.BufferInfo()
            var inputEnded = false
            var outputEnded = false
            var outputFormat = inputFormat
            var lastAudibleEndUs = -1L
            var decodedAnyTail = false
            var safety = 0

            while (!outputEnded && safety++ < 20_000) {
                if (!inputEnded) {
                    val inputIndex = codec.dequeueInputBuffer(TIMEOUT_US)
                    if (inputIndex >= 0) {
                        val input = codec.getInputBuffer(inputIndex) ?: continue
                        input.clear()
                        val sampleTime = extractor.sampleTime
                        if (sampleTime < 0L) {
                            codec.queueInputBuffer(
                                inputIndex, 0, 0, 0L,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                            inputEnded = true
                        } else {
                            val size = extractor.readSampleData(input, 0)
                            if (size < 0) {
                                codec.queueInputBuffer(
                                    inputIndex, 0, 0, 0L,
                                    MediaCodec.BUFFER_FLAG_END_OF_STREAM
                                )
                                inputEnded = true
                            } else {
                                codec.queueInputBuffer(inputIndex, 0, size, sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                }

                val outputIndex = codec.dequeueOutputBuffer(info, TIMEOUT_US)
                when {
                    outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        outputFormat = codec.outputFormat
                    }
                    outputIndex >= 0 -> {
                        if (info.size > 0) {
                            val startUs = info.presentationTimeUs
                            if (startUs >= analysisStartUs - 1_000_000L) {
                                val out = codec.getOutputBuffer(outputIndex)
                                if (out != null) {
                                    out.position(info.offset)
                                    out.limit(info.offset + info.size)
                                    val stats = pcmStats(out.slice().order(ByteOrder.LITTLE_ENDIAN), outputFormat)
                                    if (stats != null) {
                                        decodedAnyTail = true
                                        val bufferDurationUs = stats.durationUs.coerceAtLeast(1L)
                                        if (stats.rms >= RMS_THRESHOLD || stats.peak >= PEAK_THRESHOLD) {
                                            lastAudibleEndUs = maxOf(
                                                lastAudibleEndUs,
                                                startUs + bufferDurationUs
                                            )
                                        }
                                    }
                                }
                            }
                        }
                        outputEnded = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        codec.releaseOutputBuffer(outputIndex, false)
                    }
                }
            }

            if (!decodedAnyTail || lastAudibleEndUs < 0L) return null

            val naturalEndMs = durationUs / 1000L
            val lastAudibleEndMs = (lastAudibleEndUs / 1000L).coerceAtMost(naturalEndMs)
            val trailingMs = naturalEndMs - lastAudibleEndMs

            // Be deliberately conservative. Tiny encoder padding is not a reason to
            // change a transition that is already known to be stable.
            if (trailingMs < MIN_TRAILING_SILENCE_MS || trailingMs > MAX_TRAILING_SILENCE_MS) {
                return null
            }

            return Result(
                cueOutMs = (lastAudibleEndMs + SAFETY_TAIL_MS).coerceAtMost(naturalEndMs - 1L),
                trailingSilenceMs = trailingMs
            )
        } catch (_: Throwable) {
            return null
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }

    private data class PcmStats(val rms: Double, val peak: Double, val durationUs: Long)

    private fun pcmStats(buffer: java.nio.ByteBuffer, format: MediaFormat): PcmStats? {
        val sampleRate = format.getIntegerOrNull(MediaFormat.KEY_SAMPLE_RATE) ?: return null
        val channels = format.getIntegerOrNull(MediaFormat.KEY_CHANNEL_COUNT) ?: return null
        if (sampleRate <= 0 || channels <= 0) return null

        val encoding = format.getIntegerOrNull(MediaFormat.KEY_PCM_ENCODING)
            ?: AudioFormat.ENCODING_PCM_16BIT

        var sumSquares = 0.0
        var peak = 0.0
        var samples = 0L
        val bytesPerSample: Int

        when (encoding) {
            AudioFormat.ENCODING_PCM_FLOAT -> {
                bytesPerSample = 4
                while (buffer.remaining() >= 4) {
                    val v = buffer.float.toDouble().coerceIn(-1.0, 1.0)
                    val a = kotlin.math.abs(v)
                    sumSquares += v * v
                    if (a > peak) peak = a
                    samples++
                }
            }
            AudioFormat.ENCODING_PCM_8BIT -> {
                bytesPerSample = 1
                while (buffer.hasRemaining()) {
                    val unsigned = buffer.get().toInt() and 0xff
                    val v = (unsigned - 128) / 128.0
                    val a = kotlin.math.abs(v)
                    sumSquares += v * v
                    if (a > peak) peak = a
                    samples++
                }
            }
            else -> {
                bytesPerSample = 2
                while (buffer.remaining() >= 2) {
                    val v = buffer.short.toDouble() / 32768.0
                    val a = kotlin.math.abs(v)
                    sumSquares += v * v
                    if (a > peak) peak = a
                    samples++
                }
            }
        }

        if (samples <= 0L) return null
        val frames = samples.toDouble() / channels.toDouble()
        val durationUs = (frames * 1_000_000.0 / sampleRate.toDouble()).toLong()
        return PcmStats(
            rms = sqrt(sumSquares / samples.toDouble()),
            peak = peak,
            durationUs = durationUs
        )
    }

    private fun MediaFormat.getIntegerOrNull(key: String): Int? =
        if (containsKey(key)) runCatching { getInteger(key) }.getOrNull() else null

    companion object {
        private const val ANALYZE_TAIL_US = 12_000_000L
        private const val TIMEOUT_US = 10_000L
        private const val MIN_DURATION_MS = 20_000L
        private const val MIN_TRAILING_SILENCE_MS = 300L
        private const val MAX_TRAILING_SILENCE_MS = 10_000L
        private const val SAFETY_TAIL_MS = 35L
        private const val RMS_THRESHOLD = 0.006
        private const val PEAK_THRESHOLD = 0.020
    }
}
