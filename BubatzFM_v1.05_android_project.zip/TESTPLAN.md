# v1.05 – Samsung-Laufschrift / Live-Benachrichtigung

1. Bubatz starten und einen Titel mit bekanntem Interpret abspielen.
2. Benachrichtigungsleiste herunterziehen: große Live-Benachrichtigung muss **Titel** und darunter **Interpret** zeigen, ohne doppelten Interpret im Titel.
3. Benachrichtigungsleiste schließen bzw. in eine App/Home wechseln: die kleine Statusleisten-Laufschrift neben der Uhr soll **Titel – Interpret** durchlaufen.
4. Vor/Zurück und Play/Pause kurz prüfen; Verhalten muss unverändert bleiben.

# v0.99 Bluetooth Auto-Start Wiederholungstest

1. Bluetooth Auto-Start in Bubatz aktivieren.
2. Bluetooth-Lautsprecher verbinden: Bubatz muss automatisch spielen.
3. Lautsprecher ausschalten/trennen. Die Bubatz-Medienkarte soll nach kurzer Zeit verschwinden.
4. Lautsprecher erneut verbinden: Bubatz muss wieder automatisch spielen.
5. Schritte 3–4 mindestens dreimal wiederholen, auch einmal zügig innerhalb von 10 Sekunden.
6. Kontrollieren, dass Shuffle-History und Statusleisten-Laufschrift weiterhin funktionieren.

# v0.95 – Random-/History-Test

1. Nur Bubatz FM verwenden; Omnia muss für diesen Test nicht laufen.
2. Einen Titel A abspielen und zweimal „Weiter“ drücken, sodass A → B → C entsteht.
3. Einmal „Zurück“: Erwartet wird B.
4. Noch einmal „Zurück“: Erwartet wird A.
5. Einmal „Weiter“: Erwartet wird wieder exakt B, kein neu ausgewürfelter Titel.
6. Noch einmal „Weiter“: Erwartet wird wieder exakt C.
7. Erst beim nächsten „Weiter“ hinter C darf ein neuer Zufallstitel D gewählt werden.
8. Kurz prüfen, dass die in v0.93 gelöste Samsung-Laufschrift weiterhin erscheint.

# Bubatz FM v0.92 – Laufschrift-Test

1. v0.92 über die vorhandene Version installieren.
2. Omnia vollständig schließen bzw. dort keine Musik laufen lassen.
3. Nur in Bubatz FM einen Titel starten.
4. Bubatz im Vordergrund kurz spielen lassen und anschließend auf den Homescreen wechseln.
5. Oben links neben der Uhr prüfen, ob Samsungs kleine Titel-Laufschrift/der rote Medien-Chip nun den Bubatz-Titel zeigt.
6. Falls ja: einen Titel weiter springen und prüfen, ob sich der Text aktualisiert.
7. Falls nein: ein Screenshot der Statusleiste reicht.

Für diesen Test muss die Omnia-Bridge nicht geöffnet werden.

## v0.96 – persistente Shuffle-History
1. Nur Bubatz verwenden; Omnia aus lassen.
2. Titel A starten, zweimal Weiter: B, C.
3. Zweimal Zurück bis A.
4. Bubatz vollständig schließen und erneut öffnen.
5. Weiter muss B liefern; nochmal Weiter muss C liefern.
6. Erst hinter dem Ende der bekannten History darf ein neuer Zufallstitel gewählt werden.
7. Kontrollieren, dass die Samsung-Statusleisten-Laufschrift weiterhin erscheint.

## v0.98 – Bluetooth-Autostart
1. In Bubatz unter Einstellungen → Bluetooth Auto-Start prüfen, dass „Automatisch bei Bluetooth-Audio starten“ aktiviert ist.
2. Bubatz vollständig schließen und sicherstellen, dass keine Musik läuft.
3. Bluetooth-Lautsprecher einschalten bzw. die A2DP-Verbindung zum Telefon herstellen.
4. Erwartet: Bubatz startet selbstständig die Wiedergabe, ohne dass die App manuell geöffnet werden muss.
5. Bluetooth-Lautsprecher trennen, Bubatz stoppen/schließen und erneut verbinden; der Autostart muss erneut funktionieren.
6. Optionaler Negativtest: Eine reine Bluetooth-Verbindung ohne Medienprofil (z. B. Smartwatch) darf keinen Bubatz-Autostart auslösen.
7. Danach kurz Vor/Zurück testen und prüfen, dass die Samsung-Statusleisten-Laufschrift weiterhin erscheint.

## v1.00 Crossfade-Härtung
1. Zwei normale Musikstücke automatisch ineinander überblenden lassen; Übergang muss wie bisher funktionieren.
2. Während der letzten Sekunden vor bzw. während einer Überblendung einmal **Weiter** drücken. Es darf genau ein manueller Titelwechsel stattfinden; kein späteres Zurückspringen/Doppelwechsel.
3. Dasselbe einmal mit **Zurück** testen.
4. Während einer Überblendung **Pause** drücken. Wiedergabe muss sauber pausieren, ohne dass der vorbereitete Folgetitel später hörbar startet.
5. Optional Bluetooth-Lautsprecher während einer Überblendung ausschalten. Bubatz muss wie in v0.99 sauber stoppen; beim nächsten Verbinden wieder automatisch starten.

## v1.01 Last.fm
1. Einstellungen → Last.fm öffnen. Scrobbling zunächst AUS lassen: Wiedergabe darf keine Last.fm-Aktivität erzeugen.
2. API-Key + Shared Secret eintragen und speichern.
3. „Last.fm Account verbinden“ → Browser-Freigabe durchführen → zurück in Bubatz „Freigabe abgeschlossen“. Der Benutzername muss angezeigt werden.
4. Scrobbling EIN schalten und einen normalen Musiktitel starten. Auf Last.fm sollte „Now Playing“ erscheinen.
5. Einen Titel vor der Scrobble-Schwelle überspringen: Er darf nicht gescrobbelt werden.
6. Einen Titel mindestens 50 % bzw. 4 Minuten hören: Er muss genau einmal gescrobbelt werden.
7. Während Crossfade weiterhören: Jeder Musiktitel darf höchstens einmal erscheinen.
8. Scrobbling AUS schalten: Danach dürfen keine neuen Now-Playing-/Scrobble-Ereignisse entstehen.
9. Account trennen/wechseln und einen zweiten Last.fm-Account verbinden. Neue Scrobbles müssen dem neuen Account zugeordnet werden.
