# Bubatz FM v0.16

- Fix: Kotlin-Kompilierfehler in `PlaybackService.kt` behoben.
- `dualDeck.activePlayer` ist eine Property und wird jetzt korrekt ohne `()` verwendet.
- Enthält weiterhin die v0.15/v0.14-Anpassungen (JVM 17, 5000 ms Crossfade-Referenz, Bibliotheks-Persistenz/Startlogik/Bluetooth-Autostart-Basis).

# v0.15

- Build-Fix: Java- und Kotlin-JVM-Target einheitlich auf 17 gesetzt.
- Dadurch wird der GitHub-Actions-Fehler bei `:app:kspDebugKotlin` behoben.

# Bubatz FM v0.14

- Bluetooth-Autostart wartet nun zuverlässig auf die Initialisierung des Players.
- Play aus komplettem Leerlauf kann selbst einen Titel aus der Bubatz-FM-Bibliothek auswählen.
- Standard-Crossfade auf 5000 ms gesetzt.
- Bibliothek bleibt in Room gespeichert; Musik wird weiterhin nur aus explizit ausgewählten Ordnern importiert.
- Versionsanzeige auf 0.14 aktualisiert.
