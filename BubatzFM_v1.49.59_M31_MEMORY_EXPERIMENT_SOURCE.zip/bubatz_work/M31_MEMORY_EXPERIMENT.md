# M31 memory experiment (source-only, unbuilt)

Based on v1.49.59 STAGE10. APK 298 equivalence has NOT been established.

Changes:
- MainActivity artwork byte cache capped at 4 MiB (instead of 32 unlimited-size entries).
- UI embedded artwork decoded with subsampling and RGB_565 to reduce bitmap memory.
- PlaybackService platform media-card bitmap subsampled with RGB_565.

No changes to Bubatz.IQ, shuffle selection, history, scrobbling, library database, or scan state.
This is an experimental source project, not an installed/tested APK. Build and test separately before installing on M31; preserve existing app data and use matching application ID/signing key for in-place updates.
