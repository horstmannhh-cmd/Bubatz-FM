package fm.bubatz.player

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Debug
import android.os.PowerManager
import android.os.SystemClock
import java.text.DateFormat
import java.util.Date

/**
 * Lightweight, read-only heartbeat for the rare "charging + idle" process death.
 * It deliberately does not alter playback, scheduling, Bubatz.IQ or power-management state.
 */
class ChargingIdleDiagnostics(private val context: Context) {
    private val prefs = context.getSharedPreferences("charging_idle_diagnostics", Context.MODE_PRIVATE)

    fun record(
        playbackActive: Boolean,
        mediaId: String?,
        title: String?,
        positionMs: Long,
        durationMs: Long,
        crossfadeActive: Boolean,
        radioInsertActive: Boolean
    ) {
        val battery = context.getSystemService(BatteryManager::class.java)
        val power = context.getSystemService(PowerManager::class.java)
        val activity = context.getSystemService(ActivityManager::class.java)

        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val plugged = batteryIntent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val capacity = battery?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        val charging = battery?.isCharging ?: false
        val powerSource = when (plugged) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "WIRELESS"
            else -> if (plugged == 0) "NONE" else "OTHER($plugged)"
        }

        val processMemory = Debug.MemoryInfo()
        Debug.getMemoryInfo(processMemory)
        val systemMemory = ActivityManager.MemoryInfo().also { activity?.getMemoryInfo(it) }
        val runtime = Runtime.getRuntime()

        val text = buildString {
            append("Charging/Idle heartbeat\n")
            append("Zeit: ").append(DateFormat.getDateTimeInstance().format(Date())).append('\n')
            append("elapsedRealtimeMs=").append(SystemClock.elapsedRealtime()).append('\n')
            append("charging=").append(charging).append('\n')
            append("batteryStatus=").append(status).append('\n')
            append("batteryPercent=").append(capacity).append('\n')
            append("powerSource=").append(powerSource).append('\n')
            append("interactive=").append(power?.isInteractive).append('\n')
            append("deviceIdleMode=").append(power?.isDeviceIdleMode).append('\n')
            append("powerSaveMode=").append(power?.isPowerSaveMode).append('\n')
            append("playbackActive=").append(playbackActive).append('\n')
            append("mediaId=").append(mediaId).append('\n')
            append("title=").append(title).append('\n')
            append("positionMs=").append(positionMs).append('\n')
            append("durationMs=").append(durationMs).append('\n')
            append("crossfadeActive=").append(crossfadeActive).append('\n')
            append("radioInsertActive=").append(radioInsertActive).append('\n')
            append("processPssMB=").append(processMemory.totalPss / 1024).append('\n')
            append("processPrivateDirtyMB=").append(processMemory.totalPrivateDirty / 1024).append('\n')
            append("javaHeapUsedMB=").append((runtime.totalMemory() - runtime.freeMemory()) / 1048576).append('\n')
            append("javaHeapMaxMB=").append(runtime.maxMemory() / 1048576).append('\n')
            append("systemAvailMemMB=").append(systemMemory.availMem / 1048576).append('\n')
            append("systemLowMemory=").append(systemMemory.lowMemory).append('\n')
            append("systemThresholdMB=").append(systemMemory.threshold / 1048576)
        }
        // commit() is intentional: a SIGKILL must not leave the final heartbeat queued in memory.
        prefs.edit().putString("last_heartbeat", text.take(12000)).commit()
    }

    fun read(): String = prefs.getString(
        "last_heartbeat",
        "Noch kein Charging/Idle-Heartbeat protokolliert."
    ) ?: "Noch kein Charging/Idle-Heartbeat protokolliert."
}
