package fm.bubatz.player.playback

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.DefaultMediaNotificationProvider

@OptIn(UnstableApi::class)
class BubatzMediaNotificationProvider(
    context: Context
) : DefaultMediaNotificationProvider(context) {

    override fun getNotificationContentTitle(metadata: MediaMetadata): CharSequence {
        val title = metadata.title?.toString()?.trim().orEmpty()
        val artist = metadata.artist?.toString()?.trim().orEmpty()

        return when {
            title.isNotEmpty() && artist.isNotEmpty() -> "$title – $artist"
            title.isNotEmpty() -> title
            artist.isNotEmpty() -> artist
            else -> "Bubatz FM"
        }
    }

    override fun getNotificationContentText(metadata: MediaMetadata): CharSequence? {
        // Keep the large media card tidy: album remains secondary text when available.
        return metadata.albumTitle ?: metadata.artist
    }
}
