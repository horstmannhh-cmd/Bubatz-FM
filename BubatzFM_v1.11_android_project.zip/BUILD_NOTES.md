## v1.11.0

Crossfade-Architektur: Nach der Equal-Power-Überblendung wird der bereits laufende Incoming-ExoPlayer zum aktiven Player. Die MediaSession wechselt per `setPlayer()` auf einen neuen `BubatzSessionPlayer`-Wrapper desselben Decks. Dadurch entfällt der bisherige zweite Decode/Seek/Prepare-Handoff, der sporadische Mikro-Stolperer erzeugen konnte.

# Bubatz FM v0.92 – Build Notes

v0.92 ist ein isolierter Samsung-Statusleisten-Test. Die produktive Bubatz-Wiedergabe bleibt unverändert; geändert wird nur die Beziehung zwischen MediaStyle-Notification und einer Omnia-ähnlichen klassischen Android-MediaSession.

Version: 0.92.0 / Code 92
