# v1.47.7

- Samsung Now Bar: ursprünglichen Brokkoli aus dem alten Stand vor den Wurst-Icon-Korrekturen wiederhergestellt.
- Das historische Symbol wurde inhaltlich nicht neu gezeichnet, sondern nur proportional verkleinert und zentriert, damit es nicht abgeschnitten wird.
- Keine Änderungen an Bubatz.IQ, Playback, Crossfade, Auto-Cue oder Storage-Fix.

# v1.47.3
- Stabilität: Wiedergabe von SAF-Dateien der SD-Karte nutzt für `com.android.externalstorage.documents` einen lokal abgelösten Dateideskriptor.
- Ziel: Ein Neustart/Absturz des Android ExternalStorageProvider beim Stöbern in sehr großen Ordnern soll die laufende Bubatz.FM-Wiedergabe nicht mehr via `DEPENDENCY_DIED` mitreißen.
- Bubatz.IQ-/Shuffle-Logik, Crossfade, Auto-Cue und UI unverändert.

## 1.46.9
- Wurst: Brokkoli wieder deutlich größer, monochrom und ohne Funkwellen.
- Eigenes Vektor-Small-Icon aus der ursprünglichen Bubatz-Brokkoli-Silhouette; Android/Samsung kann es passend zur Schrift einfärben.
- Sicherheitsrand rechts und leichte Linksverschiebung gegen Clipping beibehalten.
- Keine Änderungen an Bubatz.IQ, Shuffle oder Playback.

## v1.46.1
- Fix: BuildConfig generation enabled so automatic version display compiles.
- Keeps fixed broccoli zone and independent centered program text from v1.46.0.

# Bubatz.FM v1.45.7 – Diagnose-Build

- Sichtbarer roter Marker **DIAGNOSE 1.45.7** direkt unter dem Logo.
- Dient ausschließlich dazu, zweifelsfrei zu prüfen, ob GitHub und Android wirklich den aktuellen Quellstand bauen/installieren.
- Bubatz.IQ, Audio, Radio, Last.fm und History-Logik gegenüber v1.45.6 unverändert.
- GitHub-Workflow auf v1.45.7 aktualisiert und mit expliziter Build-Identitätsprüfung versehen.

## 1.46.8
- Samsung Now-Bar/"Wurst" icon: restored the detailed Bubatz broccoli artwork without radio waves.
- The notification bitmap now lives in `drawable-xxxhdpi` as a real 24dp-equivalent (96px) small icon instead of an oversized density-less drawable, preventing the right-side clipping seen with the prettier raster icon.
- Kept generous transparent safe margins and the slight left bias that worked in 1.46.6.
- No changes to Bubatz.IQ, shuffle, playback, crossfade or Auto-Cue logic.

## 1.47.8
- Build/Installations-Fix: Debug-Signing explizit an den Debug-Build gebunden.
- GitHub-Workflow von veralteten 1.45.7-Prüfungen bereinigt und auf 1.47.8 aktualisiert.
- CI prüft die erzeugte APK jetzt zusätzlich mit `apksigner` und `aapt`.
- Brokkoli-Icon aus 1.47.7 unverändert übernommen.

## v1.47.9
- Now-Bar/Notification-Brokkoli: restores the original v1.45.9 Media3 small icon artwork.
- The original glyph is only uniformly scaled down and centered to add Samsung safety margins; no redraw or silhouette changes.

## v1.47.29
- JETZT-Symbol: Brokkoli deutlich verkleinert; Radiowellen bleiben unverändert.
- Icon-Zone und Textlayout bleiben unverändert, damit sich die Schriftposition nicht verschiebt.
- Keine Änderungen an Bubatz.IQ oder Wiedergabelogik.
