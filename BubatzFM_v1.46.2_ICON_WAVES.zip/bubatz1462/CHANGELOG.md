## v1.46.1
- Fix: BuildConfig generation enabled so automatic version display compiles.
- Keeps fixed broccoli zone and independent centered program text from v1.46.0.

# Bubatz.FM v1.45.7 – Diagnose-Build

- Sichtbarer roter Marker **DIAGNOSE 1.45.7** direkt unter dem Logo.
- Dient ausschließlich dazu, zweifelsfrei zu prüfen, ob GitHub und Android wirklich den aktuellen Quellstand bauen/installieren.
- Bubatz.IQ, Audio, Radio, Last.fm und History-Logik gegenüber v1.45.6 unverändert.
- GitHub-Workflow auf v1.45.7 aktualisiert und mit expliziter Build-Identitätsprüfung versehen.
