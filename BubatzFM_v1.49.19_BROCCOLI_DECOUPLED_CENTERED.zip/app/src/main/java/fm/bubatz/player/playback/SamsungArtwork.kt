package fm.bubatz.player.playback

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import fm.bubatz.player.R

internal object SamsungArtwork {
    private const val WIDTH = 1600
    private const val HEIGHT = 900
    private const val COVER = 760

    fun fallbackForLiveCard(context: Context): Bitmap? {
        val source = BitmapFactory.decodeResource(context.resources, R.drawable.bubatz_placeholder_cover)
            ?: return null
        val out = Bitmap.createBitmap(WIDTH, HEIGHT, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        // Neutral Bubatz dark-green field. Samsung may crop the wide bitmap, but the
        // complete square cover remains inside the central safe area.
        canvas.drawColor(Color.rgb(6, 27, 17))
        val left = (WIDTH - COVER) / 2f
        val top = (HEIGHT - COVER) / 2f
        val dst = android.graphics.RectF(left, top, left + COVER, top + COVER)
        canvas.drawBitmap(source, null, dst, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        return out
    }
}
