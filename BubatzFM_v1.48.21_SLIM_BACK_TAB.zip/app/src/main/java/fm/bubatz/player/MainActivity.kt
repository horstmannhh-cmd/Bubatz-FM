
package fm.bubatz.player

import androidx.room.withTransaction
import android.Manifest
import androidx.compose.ui.graphics.asImageBitmap
import android.media.MediaMetadataRetriever
import android.graphics.BitmapFactory
import android.content.Intent
import android.provider.Settings
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.zIndex
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.googlefonts.GoogleFont
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import fm.bubatz.player.bluetooth.BluetoothDeviceRepository
import fm.bubatz.player.data.RadioClipEntity
import fm.bubatz.player.data.RecentMusicItem
import fm.bubatz.player.data.TrackEntity
import fm.bubatz.player.library.LibraryScanner
import fm.bubatz.player.library.ScanDiagnostics
import fm.bubatz.player.diagnostics.OmniaBridge
import fm.bubatz.player.playback.PlaybackService
import fm.bubatz.player.playback.FlowCycleStore
import fm.bubatz.player.scrobble.LastFmAuthCoordinator
import fm.bubatz.player.scrobble.LastFmSessionStore
import fm.bubatz.player.settings.AppSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalTime

private val BubatzDark = Color(0xFF0F1A13)
private val BubatzGreen = Color(0xFF1F2E21)
private val BubatzMid = Color(0xFF375A36)
private val BubatzSage = Color(0xFF6A8A6A)
private val BubatzCream = Color(0xFFF2E9D2)
private val BubatzGold = Color(0xFFDCC9A1)

@OptIn(ExperimentalTextApi::class)
private val PlusJakartaProvider = GoogleFont.Provider(
    providerAuthority = "com.google.android.gms.fonts",
    providerPackage = "com.google.android.gms",
    certificates = R.array.com_google_android_gms_fonts_certs
)
@OptIn(ExperimentalTextApi::class)
private val PlusJakartaSans = FontFamily(
    androidx.compose.ui.text.googlefonts.Font(GoogleFont("Plus Jakarta Sans"), PlusJakartaProvider, FontWeight.Normal),
    androidx.compose.ui.text.googlefonts.Font(GoogleFont("Plus Jakarta Sans"), PlusJakartaProvider, FontWeight.Medium),
    androidx.compose.ui.text.googlefonts.Font(GoogleFont("Plus Jakarta Sans"), PlusJakartaProvider, FontWeight.SemiBold)
)

// Track metadata can come from the full international music library.
// Plus Jakarta Sans is kept for Latin text; for any other Unicode script we
// deliberately hand the whole field to Android's sans-serif family. Android's
// system font stack then selects the installed script font (for example CJK,
// Arabic, Devanagari, Tamil or Hangul) and avoids missing-glyph boxes.
private fun bubatzMetadataFont(text: String): FontFamily {
    val needsSystemScriptFallback = text.codePoints().toArray().any { codePoint ->
        if (!Character.isLetter(codePoint)) return@any false
        Character.UnicodeScript.of(codePoint) != Character.UnicodeScript.LATIN
    }
    return if (needsSystemScriptFallback) FontFamily.SansSerif else PlusJakartaSans
}

private fun bubatzTypography(): Typography {
    val t = Typography()
    return Typography(
        displayLarge = t.displayLarge.copy(fontFamily = PlusJakartaSans),
        displayMedium = t.displayMedium.copy(fontFamily = PlusJakartaSans),
        displaySmall = t.displaySmall.copy(fontFamily = PlusJakartaSans),
        headlineLarge = t.headlineLarge.copy(fontFamily = PlusJakartaSans),
        headlineMedium = t.headlineMedium.copy(fontFamily = PlusJakartaSans),
        headlineSmall = t.headlineSmall.copy(fontFamily = PlusJakartaSans),
        titleLarge = t.titleLarge.copy(fontFamily = PlusJakartaSans),
        titleMedium = t.titleMedium.copy(fontFamily = PlusJakartaSans),
        titleSmall = t.titleSmall.copy(fontFamily = PlusJakartaSans),
        bodyLarge = t.bodyLarge.copy(fontFamily = PlusJakartaSans),
        bodyMedium = t.bodyMedium.copy(fontFamily = PlusJakartaSans),
        bodySmall = t.bodySmall.copy(fontFamily = PlusJakartaSans),
        labelLarge = t.labelLarge.copy(fontFamily = PlusJakartaSans),
        labelMedium = t.labelMedium.copy(fontFamily = PlusJakartaSans),
        labelSmall = t.labelSmall.copy(fontFamily = PlusJakartaSans)
    )
}

private data class ProgramSlot(val name: String, val timeLabel: String, val endLabel: String)

private val BubatzDailyProgram = listOf(
    ProgramSlot("Der Nachtbus", "0–3 Uhr", "3 UHR"),
    ProgramSlot("Dunstabzug", "3–6 Uhr", "6 UHR"),
    ProgramSlot("Morgenglühen", "6–9 Uhr", "9 UHR"),
    ProgramSlot("Blütezeit", "9–12 Uhr", "12 UHR"),
    ProgramSlot("High Noon", "12–15 Uhr", "15 UHR"),
    ProgramSlot("Drehmoment", "15–18 Uhr", "18 UHR"),
    ProgramSlot("Klangsog", "18–21 Uhr", "21 UHR"),
    ProgramSlot("Sofaschwere", "21–0 Uhr", "MITTERNACHT")
)

private fun currentProgramSlot(now: LocalTime = LocalTime.now()): ProgramSlot = when (now.hour) {
    in 0..2 -> BubatzDailyProgram[0]
    in 3..5 -> BubatzDailyProgram[1]
    in 6..8 -> BubatzDailyProgram[2]
    in 9..11 -> BubatzDailyProgram[3]
    in 12..14 -> BubatzDailyProgram[4]
    in 15..17 -> BubatzDailyProgram[5]
    in 18..20 -> BubatzDailyProgram[6]
    else -> BubatzDailyProgram[7]
}

@Composable
private fun MiniBroccoliRadio(modifier: Modifier = Modifier) {
    // Keep the three source elements independent: large original waves,
    // a deliberately tiny broccoli "station dot", and tight spacing.
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.bubatz_wave_left),
            contentDescription = null,
            modifier = Modifier.size(width = 18.dp, height = 38.dp),
            contentScale = ContentScale.Fit,
            colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(BubatzSage)
        )
        Spacer(Modifier.width(0.dp))
        Image(
            painter = painterResource(id = R.drawable.bubatz_broccoli_mini),
            contentDescription = null,
            modifier = Modifier.size(14.dp),
            contentScale = ContentScale.Fit,
            colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(BubatzSage)
        )
        Spacer(Modifier.width(0.dp))
        Image(
            painter = painterResource(id = R.drawable.bubatz_wave_right),
            contentDescription = null,
            modifier = Modifier.size(width = 18.dp, height = 38.dp),
            contentScale = ContentScale.Fit,
            colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(BubatzSage)
        )
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 50)

        if (android.os.Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 51)

        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE), 52)
        }

        setContent {
            MaterialTheme(
                typography = bubatzTypography(),
                colorScheme = darkColorScheme(
                    primary = BubatzCream,
                    secondary = BubatzSage,
                    background = BubatzDark,
                    surface = BubatzGreen,
                    onPrimary = BubatzDark,
                    onBackground = BubatzCream,
                    onSurface = BubatzCream
                )
            ) {
                BubatzApp()
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 52 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startService(
                Intent(this, PlaybackService::class.java)
                    .setAction(PlaybackService.ACTION_REFRESH_PHONE_MONITOR)
            )
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun BubatzApp() {
        var tab by rememberSaveable { mutableIntStateOf(0) }
        var showProgram by rememberSaveable { mutableStateOf(false) }
        val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
        val scope = rememberCoroutineScope()

        fun navigateTo(target: Int) {
            tab = target
            scope.launch { drawerState.close() }
        }

        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(
                    drawerContainerColor = BubatzDark,
                    drawerContentColor = BubatzCream
                ) {
                    Box(Modifier.fillMaxSize()) {
                        Image(
                            painter = painterResource(R.drawable.bubatz_player_background),
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop,
                            alpha = 0.18f
                        )
                        Box(
                            Modifier
                                .fillMaxSize()
                                .background(BubatzDark.copy(alpha = 0.84f))
                        )
                        Column(Modifier.fillMaxSize()) {
                            Spacer(Modifier.height(24.dp))
                            Image(
                                painter = painterResource(R.drawable.bubatz_logo_player_cutout),
                                contentDescription = "Bubatz FM",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(66.dp)
                                    .padding(horizontal = 28.dp),
                                contentScale = ContentScale.Fit,
                                alpha = 0.90f
                            )
                            Spacer(Modifier.height(24.dp))

                            @Composable
                            fun DrawerEntry(
                                label: String,
                                icon: androidx.compose.ui.graphics.vector.ImageVector,
                                selected: Boolean,
                                onClick: () -> Unit
                            ) {
                                val shape = RoundedCornerShape(22.dp)
                                val border = if (selected) BorderStroke(1.dp, BubatzSage.copy(alpha = 0.72f)) else null
                                Row(
                                    modifier = Modifier
                                        .padding(horizontal = 18.dp, vertical = 5.dp)
                                        .fillMaxWidth()
                                        .height(62.dp)
                                        .then(
                                            if (selected) Modifier
                                                .background(BubatzMid.copy(alpha = 0.32f), shape)
                                                .then(Modifier.border(border!!, shape))
                                            else Modifier
                                        )
                                        .clickable(onClick = onClick)
                                        .padding(horizontal = 18.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(Modifier.size(14.dp), contentAlignment = Alignment.Center) {
                                        if (selected) {
                                            Box(
                                                Modifier
                                                    .size(8.dp)
                                                    .background(Color(0xFFA8F23A), CircleShape)
                                            )
                                        }
                                    }
                                    Spacer(Modifier.width(10.dp))
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = null,
                                        tint = if (selected) BubatzCream else BubatzSage,
                                        modifier = Modifier.size(25.dp)
                                    )
                                    Spacer(Modifier.width(18.dp))
                                    Text(
                                        text = label,
                                        color = if (selected) BubatzCream else BubatzSage,
                                        fontSize = 16.sp,
                                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium
                                    )
                                }
                            }

                            DrawerEntry("Player", Icons.Default.Radio, tab == 0) { navigateTo(0) }
                            DrawerEntry("Tagesprogramm", Icons.Default.Schedule, false) {
                                scope.launch { drawerState.close() }
                                showProgram = true
                            }
                            DrawerEntry("Zuletzt gehört", Icons.Default.History, tab == 2) { navigateTo(2) }
                            DrawerEntry("Einstellungen", Icons.Default.Settings, tab == 1) { navigateTo(1) }

                            Spacer(Modifier.weight(1f))
                            Text(
                                text = "Bubatz.FM · ALLES, AUSSER GEWÖHNLICH",
                                color = BubatzSage.copy(alpha = 0.62f),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium,
                                letterSpacing = 0.8.sp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 28.dp, vertical = 28.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        ) {
            Scaffold(containerColor = BubatzDark) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    Crossfade(targetState = tab, label = "main-tabs") { selected ->
                        when (selected) {
                            0 -> NowPlayingScreen(
                                modifier = Modifier.fillMaxSize(),
                                onShowProgram = { showProgram = true },
                                onOpenMenu = { scope.launch { drawerState.open() } }
                            )
                            1 -> SettingsScreen(Modifier.fillMaxSize())
                            else -> RecentHistoryScreen(Modifier.fillMaxSize())
                        }
                    }
                    if (tab != 0) {
                        // Schlanke Zurück-Leiste: große unsichtbare Touchfläche, optisch nur Linie + Chevron.
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterEnd)
                                .zIndex(10f)
                                .width(52.dp)
                                .height(64.dp)
                                .clickable { navigateTo(0) },
                            contentAlignment = Alignment.CenterEnd
                        ) {
                            Row(
                                modifier = Modifier.fillMaxHeight(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.End
                            ) {
                                Box(
                                    Modifier
                                        .width(3.dp)
                                        .height(48.dp)
                                        .background(
                                            color = Color(0xFF9BEA45),
                                            shape = RoundedCornerShape(2.dp)
                                        )
                                )
                                Spacer(Modifier.width(7.dp))
                                Icon(
                                    imageVector = Icons.Default.ChevronLeft,
                                    contentDescription = "Zurück zum Player",
                                    tint = BubatzCream,
                                    modifier = Modifier.size(26.dp)
                                )
                                Spacer(Modifier.width(4.dp))
                            }
                        }
                    }
                }
            }
        }

        if (showProgram) {
            ProgramScheduleSheet(onDismiss = { showProgram = false })
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun ProgramScheduleSheet(onDismiss: () -> Unit) {
        var programSlot by remember { mutableStateOf(currentProgramSlot()) }
        LaunchedEffect(Unit) {
            while (true) {
                programSlot = currentProgramSlot()
                delay(30_000L)
            }
        }
        ModalBottomSheet(
            onDismissRequest = onDismiss,
            containerColor = BubatzDark.copy(alpha = 0.96f),
            contentColor = BubatzCream,
            shape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp),
            dragHandle = { BottomSheetDefaults.DragHandle(color = BubatzSage.copy(alpha = 0.85f)) }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 22.dp)
                    .padding(bottom = 22.dp)
                    .navigationBarsPadding()
                    .verticalScroll(rememberScrollState())
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color.Transparent,
                        border = BorderStroke(1.5.dp, BubatzSage.copy(alpha = 0.9f)),
                        modifier = Modifier.size(34.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.DateRange, null, tint = BubatzSage, modifier = Modifier.size(19.dp))
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text = "Bubatz.FM · TAGESPROGRAMM",
                        color = BubatzCream,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(Modifier.height(14.dp))
                val currentIndex = BubatzDailyProgram.indexOfFirst { it.name == programSlot.name }.coerceAtLeast(0)
                val orderedProgram = BubatzDailyProgram.drop(currentIndex) + BubatzDailyProgram.take(currentIndex)
                orderedProgram.forEach { slot ->
                    val isCurrent = slot.name == programSlot.name
                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        shape = RoundedCornerShape(14.dp),
                        color = if (isCurrent) BubatzMid.copy(alpha = 0.22f) else Color.Transparent,
                        border = if (isCurrent) BorderStroke(1.dp, BubatzSage.copy(alpha = 0.9f)) else null
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = slot.timeLabel,
                                color = if (isCurrent) BubatzGold else BubatzSage,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.width(88.dp)
                            )
                            Text(
                                text = slot.name,
                                color = BubatzCream,
                                fontSize = 14.sp,
                                fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Medium,
                                modifier = Modifier.weight(1f)
                            )
                            if (isCurrent) {
                                Canvas(Modifier.size(16.dp)) {
                                    drawCircle(BubatzSage.copy(alpha = 0.18f), radius = size.minDimension * 0.48f)
                                    drawCircle(Color(0xFFA8F04A).copy(alpha = 0.35f), radius = size.minDimension * 0.32f)
                                    drawCircle(Color(0xFFA8F04A), radius = size.minDimension * 0.18f)
                                }
                                Spacer(Modifier.width(5.dp))
                                Text(
                                    text = "JETZT",
                                    color = BubatzGold,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.8.sp
                                )
                            }
                        }
                    }
                    if (!isCurrent) {
                        HorizontalDivider(color = BubatzSage.copy(alpha = 0.18f), thickness = 0.5.dp, modifier = Modifier.padding(horizontal = 10.dp))
                    }
                }
                Spacer(Modifier.height(14.dp))
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, BubatzSage.copy(alpha = 0.8f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = BubatzCream)
                ) { Text("Schließen", fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                Spacer(Modifier.height(6.dp))
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun NowPlayingScreen(
        modifier: Modifier = Modifier,
        onShowProgram: () -> Unit,
        onOpenMenu: () -> Unit
    ) {
        val db = (application as BubatzApplication).database
        val state by db.state().observe().collectAsState(initial = null)
        val omniaState by OmniaBridge.state.collectAsState()
        val scope = rememberCoroutineScope()
        var showTrackInfo by rememberSaveable { mutableStateOf(false) }
        var detailGenre by remember { mutableStateOf<String?>(null) }
        var detailYear by remember { mutableStateOf<String?>(null) }

        var track by remember { mutableStateOf<TrackEntity?>(null) }
        var clip by remember { mutableStateOf<RadioClipEntity?>(null) }

        // Bubatz.FM program schedule is purely visual: it follows the device clock
        // and never changes playback, Bubatz.IQ, radio scheduling or audio behavior.
        var programSlot by remember { mutableStateOf(currentProgramSlot()) }
        LaunchedEffect(Unit) {
            while (true) {
                programSlot = currentProgramSlot()
                delay(30_000L)
            }
        }

        LaunchedEffect(state?.currentMediaId) {
            val mediaId = state?.currentMediaId

            if (mediaId?.startsWith("track:") == true) {
                // Keep the previous track (and therefore its cover) visible until
                // the database lookup for the new track has completed.
                val id = mediaId.removePrefix("track:").toLongOrNull()
                val newTrack = id?.let {
                    withContext(Dispatchers.IO) { db.tracks().byId(it) }
                }
                if (newTrack != null) {
                    track = newTrack
                    clip = null
                }
            } else if (mediaId?.startsWith("radio:") == true) {
                val id = mediaId.removePrefix("radio:").toLongOrNull()
                val newClip = id?.let {
                    withContext(Dispatchers.IO) { db.clips().byId(it) }
                }
                if (newClip != null) {
                    clip = newClip
                    track = null
                }
            } else if (mediaId == null) {
                track = null
                clip = null
            }
        }

        var visualPosition by remember(state?.currentPositionMs) {
            mutableLongStateOf(state?.currentPositionMs ?: 0L)
        }
        var isSeeking by remember { mutableStateOf(false) }
        var seekPreviewPosition by remember { mutableLongStateOf(0L) }

        LaunchedEffect(state?.isPlaying, state?.currentPositionMs, state?.currentMediaId, isSeeking) {
            if (!isSeeking) {
                visualPosition = state?.currentPositionMs ?: 0L
                while (state?.isPlaying == true && !isSeeking) {
                    delay(500)
                    visualPosition += 500
                }
            }
        }

        // v0.91 source arbitration: never steal the UI from Bubatz while its own
        // playback is active. If Bubatz is paused/stopped and Omnia has a live
        // MediaSession, the normal player becomes an Omnia remote surface.
        val useOmnia = state?.isPlaying != true && omniaState.connected && omniaState.hasMetadata
        val isRadio = !useOmnia && clip != null
        val title = when {
            useOmnia -> omniaState.title.ifBlank { "Omnia" }
            isRadio -> clip?.name ?: "Bubatz FM"
            else -> track?.title ?: "Bubatz FM"
        }
        val artist = when {
            useOmnia -> omniaState.artist.ifBlank { "Omnia" }
            isRadio -> "RADIOEINSPIELER"
            else -> track?.artist ?: "Bereit für Musik"
        }
        val album = when {
            useOmnia -> omniaState.album
            isRadio -> "ON AIR"
            else -> track?.album.orEmpty()
        }
        val duration = if (useOmnia) {
            omniaState.durationMs
        } else {
            (state?.currentDurationMs ?: 0L).coerceAtLeast(track?.durationMs ?: clip?.durationMs ?: 0L)
        }

        Box(modifier = modifier.fillMaxSize().background(BubatzDark)) {
            Image(
                painter = painterResource(R.drawable.bubatz_player_background),
                contentDescription = null,
                modifier = Modifier.matchParentSize(),
                contentScale = ContentScale.Crop,
                alpha = 1.0f
            )
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 22.dp, vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(84.dp)
            ) {
                Image(
                    painter = painterResource(R.drawable.bubatz_logo_player_cutout),
                    contentDescription = "Bubatz FM",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit,
                    alignment = Alignment.Center
                )

                // Fixed header position: part of the scroll content, not a floating overlay.
                // The 48dp touch target stays accessible while only the three lines are visible.
                IconButton(
                    onClick = onOpenMenu,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .offset(x = (-18).dp, y = (-13).dp)
                        .size(48.dp)
                ) {
                    // Neon-tube hamburger: three bright cores with two soft glow layers.
                    // Kept as a Canvas inside the existing 48dp touch target so menu behavior
                    // and its fixed header position remain unchanged.
                    Canvas(modifier = Modifier.size(34.dp)) {
                        val neon = Color(0xFFBFFF18)
                        val x1 = size.width * 0.12f
                        val widths = listOf(0.76f, 0.57f, 0.40f) // long -> medium -> short, left aligned
                        val ys = listOf(size.height * 0.27f, size.height * 0.50f, size.height * 0.73f)
                        ys.zip(widths).forEach { (y, width) ->
                            val x2 = x1 + size.width * width
                            drawLine(neon.copy(alpha = 0.16f), Offset(x1, y), Offset(x2, y), strokeWidth = 12.dp.toPx(), cap = StrokeCap.Round)
                            drawLine(neon.copy(alpha = 0.34f), Offset(x1, y), Offset(x2, y), strokeWidth = 7.dp.toPx(), cap = StrokeCap.Round)
                            drawLine(neon, Offset(x1, y), Offset(x2, y), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
                            drawLine(Color(0xFFE9FFB8), Offset(x1, y), Offset(x2, y), strokeWidth = 1.dp.toPx(), cap = StrokeCap.Round)
                        }
                    }
                }
            }

            Spacer(Modifier.height(2.dp))


            // Compact on-air badge. Keep MiniBroccoliRadio itself untouched.
            // "JETZT:" is vertically centred with the icon; programme name and
            // end time form a left-aligned two-line block. The longest programme
            // name is the sizing stress test.
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.90f)
                    .height(52.dp)
                    .clickable { onShowProgram() },
                shape = RoundedCornerShape(20.dp),
                color = BubatzMid.copy(alpha = 0.31f),
                border = BorderStroke(1.dp, BubatzSage.copy(alpha = 0.55f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(end = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .width(56.dp)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.Center
                    ) {
                        MiniBroccoliRadio(Modifier.size(width = 54.dp, height = 42.dp).offset(x = 3.dp))
                    }

                    Spacer(Modifier.width(10.dp))

                    Text(
                        text = "JETZT:",
                        fontFamily = PlusJakartaSans,
                            color = BubatzSage.copy(alpha = 0.90f),
                        fontSize = 10.sp,
                        lineHeight = 11.sp,
                        fontWeight = FontWeight.Medium,
                        letterSpacing = 0.4.sp,
                        maxLines = 1,
                        softWrap = false
                    )

                    Spacer(Modifier.width(10.dp))

                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.Start,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = programSlot.name.uppercase(),
                            fontFamily = PlusJakartaSans,
                            color = BubatzCream.copy(alpha = 0.96f),
                            fontSize = when {
                                programSlot.name.length > 22 -> 10.sp
                                programSlot.name.length > 17 -> 11.5.sp
                                else -> 13.5.sp
                            },
                            lineHeight = when {
                                programSlot.name.length > 22 -> 11.sp
                                programSlot.name.length > 17 -> 12.5.sp
                                else -> 14.5.sp
                            },
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Start,
                            maxLines = 1,
                            softWrap = false
                        )
                        Text(
                            text = "BIS ${programSlot.endLabel}",
                            fontFamily = PlusJakartaSans,
                            color = BubatzSage.copy(alpha = 0.90f),
                            fontSize = 9.sp,
                            lineHeight = 10.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Start,
                            maxLines = 1,
                            softWrap = false
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Tagesprogramm öffnen",
                        tint = BubatzCream.copy(alpha = 0.72f),
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            Surface(
                modifier = Modifier.fillMaxWidth(0.90f).aspectRatio(1f),
                shape = RoundedCornerShape(26.dp),
                color = BubatzGreen,
                tonalElevation = 4.dp
            ) {
                if (isRadio || useOmnia) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Image(
                            painterResource(if (useOmnia) R.drawable.bubatz_app_icon_dark else R.drawable.bubatz_logo_main_dark),
                            if (useOmnia) "Omnia über Bubatz FM" else "Bubatz FM Einspieler",
                            Modifier.fillMaxSize().padding(if (useOmnia) 52.dp else 28.dp),
                            contentScale = ContentScale.Fit
                        )
                    }
                } else {
                    AlbumArtwork(
                        uri = track?.uri,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            if (useOmnia) {
                AssistChip(
                    onClick = {},
                    label = { Text("OMNIA · EXTERNE WIEDERGABE") },
                    colors = AssistChipDefaults.assistChipColors(
                        labelColor = BubatzCream,
                        containerColor = BubatzMid
                    )
                )
                Spacer(Modifier.height(10.dp))
            }

            if (isRadio) {
                AssistChip(
                    onClick = {},
                    label = { Text("● ON AIR · BUBATZ FM") },
                    colors = AssistChipDefaults.assistChipColors(
                        labelColor = BubatzCream,
                        containerColor = BubatzMid
                    )
                )
                Spacer(Modifier.height(10.dp))
            }

            Text(
                text = title,
                fontFamily = bubatzMetadataFont(title),
                color = BubatzCream,
                fontSize = 22.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(5.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = artist,
                    fontFamily = bubatzMetadataFont(artist),
                    color = if (isRadio) BubatzGold else BubatzSage,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                if (!isRadio) {
                    Spacer(Modifier.width(6.dp))
                    IconButton(onClick = { showTrackInfo = true }, modifier = Modifier.size(26.dp)) {
                        Icon(Icons.Default.Info, "Titelinformationen", tint = BubatzSage.copy(alpha = 0.92f), modifier = Modifier.size(18.dp))
                    }
                }
            }
            if (album.isNotBlank()) {
                Text(
                    text = album,
                    fontFamily = bubatzMetadataFont(album),
                    color = BubatzSage.copy(alpha = 0.85f),
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(Modifier.height(12.dp))

            val shownPosition = if (isSeeking) seekPreviewPosition else if (useOmnia) omniaState.positionMs else visualPosition
            val sliderValue = if (duration > 0L) {
                (shownPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
            } else 0f

            CompactSeekBar(
                value = sliderValue,
                enabled = duration > 0L && !isRadio,
                onValueChange = { value ->
                    if (duration > 0L) {
                        isSeeking = true
                        seekPreviewPosition = (duration * value.coerceIn(0f, 1f)).toLong()
                    }
                },
                onValueChangeFinished = {
                    if (isSeeking && duration > 0L) {
                        val target = seekPreviewPosition.coerceIn(0L, duration)
                        visualPosition = target
                        if (useOmnia) OmniaBridge.seekTo(target) else sendSeekAction(target)
                    }
                    isSeeking = false
                }
            )
            Spacer(Modifier.height(6.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(shownPosition), color = BubatzSage, fontSize = 11.sp)
                Text(formatTime(duration), color = BubatzSage, fontSize = 11.sp)
            }

            Spacer(Modifier.height(7.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SoftGlowControl {
                    IconButton(onClick = { if (useOmnia) OmniaBridge.previous() else sendPlaybackAction(PlaybackService.ACTION_PREVIOUS) }) {
                        Icon(Icons.Default.SkipPrevious, "Vorheriger Titel", tint = BubatzCream, modifier = Modifier.size(34.dp))
                    }
                }

                SoftGlowControl(glowRadius = 46.dp, glowAlpha = 0.11f) {
                    FilledIconButton(
                        onClick = { if (useOmnia) OmniaBridge.playPause() else sendPlaybackAction(PlaybackService.ACTION_PLAY_PAUSE) },
                        modifier = Modifier.size(72.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = BubatzCream,
                            contentColor = BubatzDark
                        )
                    ) {
                        Icon(
                            if ((useOmnia && omniaState.isPlaying) || (!useOmnia && state?.isPlaying == true)) Icons.Default.Pause else Icons.Default.PlayArrow,
                            if ((useOmnia && omniaState.isPlaying) || (!useOmnia && state?.isPlaying == true)) "Pause" else "Play",
                            modifier = Modifier.size(38.dp)
                        )
                    }
                }

                SoftGlowControl {
                    IconButton(onClick = { if (useOmnia) OmniaBridge.next() else sendPlaybackAction(PlaybackService.ACTION_NEXT) }) {
                        Icon(Icons.Default.SkipNext, "Nächster Titel", tint = BubatzCream, modifier = Modifier.size(34.dp))
                    }
                }
            }

            Spacer(Modifier.height(6.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Shuffle, null, tint = BubatzSage, modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(5.dp))
                Text("BUBATZ.IQ", color = BubatzSage, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(18.dp))
                Text("•", color = BubatzMid)
                Spacer(Modifier.width(18.dp))
                Text(if (useOmnia) "OMNIA BRIDGE" else "BUBATZ.FM", color = BubatzGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(10.dp))
            Text(
                "Bluetooth- & Lockscreen-Steuerung aktiv",
                color = BubatzSage.copy(alpha = 0.75f),
                fontSize = 10.sp
            )

            Spacer(Modifier.height(16.dp))
            Text(
                text = "Bubatz.FM · v${BuildConfig.VERSION_NAME}",
                color = BubatzSage.copy(alpha = 0.48f),
                fontSize = 9.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(12.dp))
            }

            if (showTrackInfo) {
                LaunchedEffect(track?.uri, showTrackInfo) {
                    if (showTrackInfo && !track?.uri.isNullOrBlank()) {
                        val extra = withContext(Dispatchers.IO) {
                            runCatching {
                                val r = MediaMetadataRetriever()
                                try {
                                    r.setDataSource(this@MainActivity, Uri.parse(track!!.uri))
                                    r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE) to r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR)
                                } finally { r.release() }
                            }.getOrNull()
                        }
                        detailGenre = extra?.first
                        detailYear = extra?.second
                    }
                }
                ModalBottomSheet(
                    onDismissRequest = { showTrackInfo = false },
                    containerColor = BubatzDark.copy(alpha = 0.96f),
                    contentColor = BubatzCream,
                    shape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp),
                    dragHandle = { BottomSheetDefaults.DragHandle(color = BubatzSage.copy(alpha = 0.85f)) }
                ) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = Color.Transparent,
                                border = BorderStroke(1.5.dp, BubatzSage.copy(alpha = 0.9f)),
                                modifier = Modifier.size(34.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Info, null, tint = BubatzSage, modifier = Modifier.size(20.dp))
                                }
                            }
                            Spacer(Modifier.width(12.dp))
                            Text("Titelinformationen", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Spacer(Modifier.height(16.dp))
                        if (!useOmnia && track != null) {
                            Surface(Modifier.size(142.dp), shape = RoundedCornerShape(18.dp), color = BubatzGreen) { AlbumArtwork(track?.uri, Modifier.fillMaxSize()) }
                            Spacer(Modifier.height(16.dp))
                        }
                        DetailInfoRow("Titel", title)
                        DetailInfoRow("Interpret", artist)
                        if (album.isNotBlank()) DetailInfoRow("Album", album)
                        detailGenre?.takeIf { it.isNotBlank() }?.let { DetailInfoRow("Genre", it) }
                        detailYear?.takeIf { it.isNotBlank() }?.let { DetailInfoRow("Jahr", it) }
                        if (duration > 0L) DetailInfoRow("Laufzeit", formatTime(duration))
                        Spacer(Modifier.height(18.dp))
                        OutlinedButton(
                            onClick = { showTrackInfo = false },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            border = BorderStroke(1.dp, BubatzSage.copy(alpha = 0.8f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = BubatzCream)
                        ) { Text("Schließen", fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                    }
                }
            }
        }


    }

    @Composable
    private fun DetailInfoRow(label: String, value: String) {
        Column(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
                Text(
                    label.uppercase(),
                    color = BubatzSage,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 1.1.sp,
                    modifier = Modifier.width(86.dp)
                )
                Text(
                    value,
                    fontFamily = bubatzMetadataFont(value),
                    color = BubatzCream,
                    fontSize = 14.sp,
                    modifier = Modifier.weight(1f)
                )
            }
            HorizontalDivider(color = BubatzSage.copy(alpha = 0.20f), thickness = 0.5.dp)
        }
    }

    @Composable
    private fun AlbumArtwork(uri: String?, modifier: Modifier = Modifier) {
        // Keep the previous cover visible until the next embedded cover is ready.
        // This prevents the broccoli placeholder from flashing during normal transitions.
        var artworkBytes by remember { mutableStateOf<ByteArray?>(null) }

        LaunchedEffect(uri) {
            if (uri.isNullOrBlank()) {
                artworkBytes = null
                return@LaunchedEffect
            }

            val loadedArtwork = withContext(Dispatchers.IO) {
                runCatching {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(this@MainActivity, Uri.parse(uri))
                        retriever.embeddedPicture
                    } finally {
                        retriever.release()
                    }
                }.getOrNull()
            }

            artworkBytes = loadedArtwork
        }

        val bitmap = remember(artworkBytes) {
            artworkBytes?.let { bytes ->
                runCatching {
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
                }.getOrNull()
            }
        }

        Box(modifier.background(BubatzGreen), contentAlignment = Alignment.Center) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap,
                    contentDescription = "Albumcover",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Image(
                    painterResource(R.drawable.bubatz_app_icon_dark),
                    "Bubatz FM",
                    Modifier.fillMaxSize().padding(52.dp),
                    contentScale = ContentScale.Fit
                )
            }
        }
    }

    @Composable
    private fun SoftGlowControl(
        glowRadius: Dp = 28.dp,
        glowAlpha: Float = 0.07f,
        content: @Composable () -> Unit
    ) {
        Box(contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(glowRadius * 2f)) {
                drawCircle(
                    color = BubatzCream.copy(alpha = glowAlpha),
                    radius = size.minDimension / 2f
                )
            }
            content()
        }
    }

    @Composable
    private fun CompactSeekBar(
        value: Float,
        enabled: Boolean,
        onValueChange: (Float) -> Unit,
        onValueChangeFinished: () -> Unit
    ) {
        val active = BubatzGold
        val inactive = BubatzMid
        val disabled = BubatzSage.copy(alpha = 0.45f)

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .height(24.dp)
                .then(
                    if (enabled) {
                        Modifier
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onTap = { offset ->
                                        val fraction = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                                        onValueChange(fraction)
                                        onValueChangeFinished()
                                    }
                                )
                            }
                            .pointerInput(Unit) {
                                detectHorizontalDragGestures(
                                    onDragStart = { offset ->
                                        val fraction = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                                        onValueChange(fraction)
                                    },
                                    onHorizontalDrag = { change, _ ->
                                        val fraction = (change.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                                        onValueChange(fraction)
                                        change.consume()
                                    },
                                    onDragEnd = onValueChangeFinished,
                                    onDragCancel = onValueChangeFinished
                                )
                            }
                    } else Modifier
                )
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val y = size.height / 2f
                val startX = 4.dp.toPx()
                val endX = size.width - 4.dp.toPx()
                val usable = (endX - startX).coerceAtLeast(0f)
                val thumbX = startX + usable * value.coerceIn(0f, 1f)
                val trackWidth = 3.dp.toPx()

                drawLine(
                    color = if (enabled) inactive else disabled,
                    start = Offset(startX, y),
                    end = Offset(endX, y),
                    strokeWidth = trackWidth,
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = if (enabled) active else disabled,
                    start = Offset(startX, y),
                    end = Offset(thumbX, y),
                    strokeWidth = trackWidth,
                    cap = StrokeCap.Round
                )
                if (enabled) {
                    drawCircle(
                        color = BubatzCream.copy(alpha = 0.06f),
                        radius = 12.dp.toPx(),
                        center = Offset(thumbX, y)
                    )
                    drawCircle(
                        color = BubatzCream.copy(alpha = 0.12f),
                        radius = 8.dp.toPx(),
                        center = Offset(thumbX, y)
                    )
                }
                drawCircle(
                    color = if (enabled) active else disabled,
                    radius = 5.dp.toPx(),
                    center = Offset(thumbX, y)
                )
            }
        }
    }

    @Composable
    private fun RecentHistoryScreen(modifier: Modifier = Modifier) {
        val db = (application as BubatzApplication).database
        val recent by db.history().observeRecentMusic(50).collectAsState(initial = emptyList())

        Box(modifier.fillMaxSize().background(BubatzDark)) {
            Image(
                painter = painterResource(R.drawable.bubatz_player_background),
                contentDescription = null,
                modifier = Modifier.matchParentSize(),
                contentScale = ContentScale.Crop,
                alpha = 0.72f
            )
            Box(Modifier.matchParentSize().background(BubatzDark.copy(alpha = 0.32f)))

            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp, vertical = 16.dp)
            ) {
                Image(
                    painter = painterResource(R.drawable.bubatz_logo_player_cutout),
                    contentDescription = "Bubatz FM",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp)
                        .padding(horizontal = 34.dp),
                    contentScale = ContentScale.Fit,
                    alpha = 0.92f
                )
                Spacer(Modifier.height(18.dp))
                Text("Wer war das gerade?", color = BubatzCream, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Die letzten 50 Musiktitel · Einspieler werden nicht aufgeführt",
                    color = BubatzSage,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
                Spacer(Modifier.height(16.dp))

                if (recent.isEmpty()) {
                    SettingsCard("Noch nichts gehört") {
                        Text("Sobald Bubatz.FM Musik abspielt, tauchen die zuletzt gehörten Titel hier auf.", color = BubatzSage, fontSize = 13.sp)
                    }
                } else {
                    recent.forEachIndexed { index, item ->
                        RecentHistoryRow(item, isLatest = index == 0)
                        Spacer(Modifier.height(7.dp))
                    }
                }
                Spacer(Modifier.height(88.dp))
            }
        }
    }

    @Composable
    private fun RecentHistoryRow(item: RecentMusicItem, isLatest: Boolean = false) {
        var artworkBytes by remember(item.trackId) { mutableStateOf<ByteArray?>(null) }
        LaunchedEffect(item.trackId, item.uri) {
            artworkBytes = withContext(Dispatchers.IO) {
                runCatching {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(this@MainActivity, Uri.parse(item.uri))
                        retriever.embeddedPicture
                    } finally {
                        retriever.release()
                    }
                }.getOrNull()
            }
        }
        val bitmap = remember(artworkBytes) {
            artworkBytes?.let { bytes ->
                runCatching { BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap() }.getOrNull()
            }
        }
        Card(
            onClick = { playTrackFromHistory(item.trackId) },
            colors = CardDefaults.cardColors(containerColor = BubatzGreen.copy(alpha = 0.72f)),
            border = BorderStroke(
                if (isLatest) 1.2.dp else 0.7.dp,
                if (isLatest) Color(0xFF9BEA45).copy(alpha = 0.82f) else BubatzSage.copy(alpha = 0.42f)
            ),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.padding(horizontal = 11.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                    modifier = Modifier.size(54.dp),
                    shape = RoundedCornerShape(10.dp),
                    color = BubatzMid
                ) {
                    if (bitmap != null) {
                        Image(bitmap = bitmap, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    } else {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.MusicNote, null, tint = BubatzCream.copy(alpha = 0.8f))
                        }
                    }
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        item.title,
                        fontFamily = bubatzMetadataFont(item.title),
                        color = BubatzCream,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        item.artist ?: "Unbekannter Interpret",
                        fontFamily = bubatzMetadataFont(item.artist ?: "Unbekannter Interpret"),
                        color = BubatzSage,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(formatHistoryTime(item.playedAt), color = BubatzSage.copy(alpha = 0.78f), fontSize = 11.sp)
                }
                Spacer(Modifier.width(8.dp))
                    Surface(
                        modifier = Modifier.size(40.dp),
                        shape = CircleShape,
                        color = BubatzDark.copy(alpha = 0.48f),
                        border = BorderStroke(0.8.dp, BubatzSage.copy(alpha = 0.55f))
                    ) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.PlayArrow,
                                "Erneut abspielen",
                                tint = BubatzCream,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
                if (isLatest) {
                    Box(
                        Modifier
                            .align(Alignment.CenterStart)
                            .offset(x = 2.dp)
                            .size(9.dp)
                            .background(Color(0xFF9BEA45), CircleShape)
                    )
                }
            }
        }
    }

    @Composable
    private fun SettingsScreen(modifier: Modifier = Modifier) {
        val db = (application as BubatzApplication).database
        val scope = rememberCoroutineScope()
        val settings = remember { AppSettings(this) }
        LaunchedEffect(Unit) { settings.ensureDurablePersistence() }

        val musicCount by db.tracks().observeCount().collectAsState(initial = 0)
        val clipCount by db.clips().observeCount().collectAsState(initial = 0)
        val autoBt by settings.autoBluetooth.collectAsState(initial = true)
        val autoBtAll by settings.autoBluetoothAllDevices.collectAsState(initial = true)
        val selectedBt by settings.autoBluetoothDeviceAddresses.collectAsState(initial = emptySet())
        val skipOnce by settings.autoBluetoothSkipOnce.collectAsState(initial = false)
        val crossfade by settings.crossfadeMs.collectAsState(initial = 6500)
        val radioEnabled by settings.radioEnabled.collectAsState(initial = true)
        val lastFmEnabled by settings.lastFmEnabled.collectAsState(initial = false)
        val doNotDisturbCalls by settings.doNotDisturbCalls.collectAsState(initial = false)

        val pairedDevices = remember { BluetoothDeviceRepository(this).pairedAudioDevices() }

        val lastFmStore = remember { LastFmSessionStore(this) }
        val lastFmAuth = remember { LastFmAuthCoordinator(this) }
        var lastFmUser by remember { mutableStateOf(lastFmStore.username) }
        var lastFmStatus by remember {
            mutableStateOf(if (lastFmUser != null) "Verbunden als $lastFmUser" else "Nicht verbunden")
        }
        var lastFmApiKey by remember { mutableStateOf(lastFmStore.apiKey.orEmpty()) }
        var lastFmSecret by remember { mutableStateOf(lastFmStore.sharedSecret.orEmpty()) }
        var lastFmHasApiCredentials by remember { mutableStateOf(lastFmStore.hasApiCredentials) }

        var status by remember { mutableStateOf(ScanDiagnostics(this).read()) }

        val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            uri ?: return@rememberLauncherForActivityResult
            persist(uri)
            scope.launch {
                status = "Musik wird eingelesen …"
                val result = LibraryScanner(this@MainActivity).scanMusicDetailed(uri)
                var stored = 0
                if (result.error == null) {
                    db.withTransaction {
                        // v1.07: a scan is a real folder sync. Anything that no longer
                        // exists in the selected tree is disabled, while existing rows
                        // keep metadata/playCount/history identity. New files are inserted.
                        db.tracks().disableAll()
                        result.tracks.chunked(500).forEachIndexed { index, chunk ->
                            val inserted = db.tracks().insertAll(chunk)
                            stored += inserted.count { it != -1L }
                            db.tracks().enableByUris(chunk.map { it.uri })
                            status = "Bibliothek wird abgeglichen … ${minOf((index + 1) * 500, result.tracks.size)}/${result.tracks.size}"
                            ScanDiagnostics(this@MainActivity).save(status)
                        }
                    }
                }
                val activeAfter = db.tracks().count()
                val s = result.stats
                status = buildString {
                    append("FERTIG / SYNC\n")
                    append("Ordner: ${s.directoriesVisited} · Dateien: ${s.filesVisited}\n")
                    append("Audio erkannt: ${s.audioRecognized}\n")
                    append("Aktiv in Bibliothek: $activeAfter · Neu: $stored\n")
                    append("Query-Fehler: ${s.queryErrors}")
                    result.error?.let { append("\nFehler: $it – bestehende Bibliothek unverändert") }
                }
                ScanDiagnostics(this@MainActivity).save(status)
            }
        }

        val clipPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            uri ?: return@rememberLauncherForActivityResult
            persist(uri)
            scope.launch {
                status = "Einspieler werden eingelesen …"
                val items = LibraryScanner(this@MainActivity).scanRadio(uri)
                db.withTransaction {
                    db.clips().disableAll()
                    items.chunked(500).forEach { chunk ->
                        db.clips().insertAll(chunk)
                        db.clips().enableByUris(chunk.map { it.uri })
                    }
                }
                status = "${items.size} Einspieler aktiv · Ordner abgeglichen"
            }
        }

        Box(
            modifier = modifier
                .fillMaxSize()
                .background(BubatzDark)
        ) {
            Image(
                painter = painterResource(R.drawable.bubatz_player_background),
                contentDescription = null,
                modifier = Modifier.matchParentSize(),
                contentScale = ContentScale.Crop,
                alpha = 0.34f
            )
            Box(Modifier.matchParentSize().background(BubatzDark.copy(alpha = 0.52f)))

            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp, vertical = 14.dp)
            ) {
            Image(
                painterResource(R.drawable.bubatz_logo_player_cutout),
                "Bubatz FM",
                Modifier.fillMaxWidth().height(70.dp),
                contentScale = ContentScale.Fit
            )
            Text(
                "Einstellungen",
                color = BubatzSage,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.align(Alignment.End)
            )
            Spacer(Modifier.height(12.dp))

            SettingsCard("Bitte nicht stören!") {
                SettingSwitch(
                    "Anrufe ignorieren und Musik weiterspielen",
                    doNotDisturbCalls
                ) { enabled ->
                    scope.launch { settings.setDoNotDisturbCalls(enabled) }
                }
                Text(
                    if (doNotDisturbCalls)
                        "Aktiv: Auch bei Telefonanrufen spielt Bubatz weiter."
                    else
                        "Standard: Eingehende und aktive Telefonanrufe pausieren Bubatz. Danach geht es nur weiter, wenn der Anruf die Pause ausgelöst hat. Benachrichtigungstöne bleiben ohne Einfluss.",
                    color = BubatzSage,
                    fontSize = 12.sp
                )
                if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                    Spacer(Modifier.height(8.dp))
                    Text("Telefonberechtigung fehlt – die Anrufpause kann sonst nicht funktionieren.", color = BubatzGold, fontSize = 11.sp)
                    OutlinedButton(onClick = {
                        requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE), 52)
                    }) { Text("Telefonberechtigung erlauben") }
                }
            }

            Spacer(Modifier.height(8.dp))

            SettingsCard("Bibliothek") {
                Text("$musicCount Musiktitel · $clipCount Einspieler", color = BubatzCream, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                Text(status, color = BubatzSage, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SettingsActionButton(
                        label = "Musikordner",
                        icon = Icons.Default.Folder,
                        onClick = { musicPicker.launch(null) },
                        modifier = Modifier.weight(1f)
                    )
                    SettingsActionButton(
                        label = "Einspieler",
                        icon = Icons.Default.Podcasts,
                        onClick = { clipPicker.launch(null) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            SettingsCard("Omnia Bridge · v0.91") {
                val omniaState by OmniaBridge.state.collectAsState()
                val listenerEnabled = remember {
                    val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
                    enabled.contains(packageName)
                }

                Text(
                    when {
                        !listenerEnabled -> "Benachrichtigungszugriff fehlt"
                        omniaState.connected -> "Omnia verbunden"
                        else -> "Omnia noch nicht im MediaSession-Stack gefunden"
                    },
                    color = if (omniaState.connected) BubatzSage else BubatzCream,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(8.dp))

                if (omniaState.connected) {
                    Text(
                        omniaState.title.ifBlank { "Titel unbekannt" },
                        color = BubatzCream,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (omniaState.artist.isNotBlank()) {
                        Text(omniaState.artist, fontFamily = bubatzMetadataFont(omniaState.artist), color = BubatzSage, fontSize = 13.sp)
                    }
                    if (omniaState.album.isNotBlank()) {
                        Text(omniaState.album, color = BubatzSage.copy(alpha = 0.85f), fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { OmniaBridge.previous() }) {
                            Icon(Icons.Default.SkipPrevious, "Omnia: vorheriger Titel", tint = BubatzCream)
                        }
                        FilledIconButton(onClick = { OmniaBridge.playPause() }) {
                            Icon(
                                if (omniaState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                "Omnia: Play/Pause"
                            )
                        }
                        IconButton(onClick = { OmniaBridge.next() }) {
                            Icon(Icons.Default.SkipNext, "Omnia: nächster Titel", tint = BubatzCream)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "MediaSession: ${omniaState.packageName} · Actions 0x${omniaState.actions.toString(16)}",
                        color = BubatzSage,
                        fontSize = 10.sp
                    )
                } else {
                    Text(
                        "Omnia starten und dort einen Titel abspielen. Bubatz übernimmt Metadaten und Standard-Steuerung direkt aus Omnias echter Android-MediaSession.",
                        color = BubatzSage,
                        fontSize = 11.sp
                    )
                }

                if (!listenerEnabled) {
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = {
                        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    }) { Text("Zugriff öffnen") }
                }
            }

            Spacer(Modifier.height(8.dp))

            SettingsCard("Wiedergabe-Diagnose") {
                var crashText by remember {
                    mutableStateOf(CrashDiagnostics(this@MainActivity).readLiveDiagnostic())
                }
                Text(
                    "v0.91 bindet Omnia erstmals in die normale Playeransicht ein. Bubatz behält Vorrang, solange die eigene Wiedergabe läuft; bei pausiertem Bubatz übernimmt eine verbundene Omnia-Session Anzeige und Transportsteuerung.",
                    color = BubatzCream,
                    fontSize = 11.sp
                )
                Spacer(Modifier.height(8.dp))
                Text(crashText, color = BubatzSage, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        crashText = CrashDiagnostics(this@MainActivity).readLiveDiagnostic()
                    }) {
                        Text("Aktualisieren")
                    }
                    OutlinedButton(onClick = {
                        CrashDiagnostics(this@MainActivity).clearLiveDiagnostic()
                        crashText = CrashDiagnostics(this@MainActivity).readLiveDiagnostic()
                    }) {
                        Text("Löschen")
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = {
                    sendPlaybackAction(PlaybackService.ACTION_AUDIO_PIPELINE_DIAGNOSTIC)
                    kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
                        kotlinx.coroutines.delay(250L)
                        crashText = CrashDiagnostics(this@MainActivity).readLiveDiagnostic()
                    }
                }) { Text("Audio-System prüfen") }
            }

            Spacer(Modifier.height(8.dp))

            SettingsCard("Omnia-Vergleichsdiagnose") {
                var comparisonText by remember {
                    mutableStateOf(CrashDiagnostics(this@MainActivity).readNotificationComparison())
                }
                val listenerEnabled = remember(comparisonText) {
                    val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
                    enabled.contains(packageName)
                }
                Text(
                    if (listenerEnabled) "Benachrichtigungszugriff: aktiv" else "Benachrichtigungszugriff: noch nicht aktiviert",
                    color = if (listenerEnabled) BubatzSage else BubatzCream, fontSize = 11.sp
                )
                Spacer(Modifier.height(6.dp))
                Text("v1.47.34 ergänzt den Omnia/Bubatz-Vergleich um ART/ALBUM_ART: Abmessungen, Speichergröße, Bitmap-Format und Artwork-URIs. Die Wiedergabe bleibt unverändert.", color = BubatzCream, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                Text(comparisonText, color = BubatzSage, fontSize = 10.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    }) { Text("Zugriff öffnen") }
                    OutlinedButton(onClick = {
                        comparisonText = CrashDiagnostics(this@MainActivity).readNotificationComparison()
                    }) { Text("Vergleich laden") }
                }

            }

            Spacer(Modifier.height(8.dp))

            SettingsCard("Android-Absturzdiagnose") {
                var systemCrashText by remember {
                    mutableStateOf(CrashDiagnostics(this@MainActivity).readSystemExitInfo())
                }
                Text(
                    systemCrashText,
                    color = BubatzSage,
                    fontSize = 10.sp
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = {
                    systemCrashText = CrashDiagnostics(this@MainActivity).readSystemExitInfo()
                }) {
                    Text("Systemdiagnose aktualisieren")
                }
            }

            Spacer(Modifier.height(8.dp))

            SettingsCard("Radioeinspieler") {
                SettingSwitch(
                    "Automatische Einspieler aktiv",
                    radioEnabled
                ) { enabled ->
                    scope.launch { settings.setRadioEnabled(enabled) }
                }
                Text(
                    "Bei aktivierter Funktion ungefähr alle 25–35 Minuten tatsächlich gehörter Musik. Pausen und Einspieler zählen nicht. Einspieler werden nie überblendet und nie gescrobbelt.",
                    color = BubatzSage,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { sendPlaybackAction(PlaybackService.ACTION_TEST_RADIO_INSERT) }) {
                    Text("Einspieler jetzt testen")
                }
            }

            Spacer(Modifier.height(12.dp))

            var showFlowResetDialog by remember { mutableStateOf(false) }
            SettingsCard("Bubatz.IQ") {
                Text(
                    "Abwechslungsreiche Wiedergabe mit stärkerer Künstlerdurchmischung und eigenem Bubatz.IQ-Zyklus.",
                    color = BubatzSage,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { showFlowResetDialog = true }) {
                    Text("Bubatz.IQ neu mischen")
                }
            }
            if (showFlowResetDialog) {
                AlertDialog(
                    onDismissRequest = { showFlowResetDialog = false },
                    title = { Text("Bubatz.IQ neu mischen?") },
                    text = { Text("Der aktuelle Bubatz.IQ-Zyklus beginnt von vorn. Hörhistorie, Playcounts und Last.fm bleiben vollständig erhalten.") },
                    confirmButton = {
                        TextButton(onClick = {
                            FlowCycleStore(this@MainActivity).newCycle()
                            showFlowResetDialog = false
                        }) { Text("Neu mischen") }
                    },
                    dismissButton = {
                        TextButton(onClick = { showFlowResetDialog = false }) { Text("Abbrechen") }
                    }
                )
            }

            Spacer(Modifier.height(8.dp))

            SettingsCard("Crossfade") {
                Text("${crossfade / 1000.0} Sekunden · nur Musik → Musik", color = BubatzSage, fontSize = 12.sp)
                Slider(
                    value = crossfade.toFloat(),
                    onValueChange = { value -> scope.launch { settings.setCrossfadeMs(value.toInt()) } },
                    valueRange = 0f..15000f,
                    steps = 14
                )
                Text("Einspieler werden niemals überblendet.", color = BubatzGold, fontSize = 12.sp)
            }

            Spacer(Modifier.height(8.dp))

            SettingsCard("Bluetooth Auto-Start") {
                SettingSwitch(
                    "Automatisch bei Bluetooth-Audio starten",
                    autoBt
                ) { scope.launch { settings.setAutoBluetooth(it) } }

                if (autoBt) {
                    SettingSwitch("Alle Bluetooth-Audiogeräte", autoBtAll) {
                        scope.launch { settings.setAutoBluetoothAllDevices(it) }
                    }

                    if (!autoBtAll) {
                        pairedDevices.forEach { device ->
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = device.address in selectedBt,
                                    onCheckedChange = { enabled ->
                                        scope.launch {
                                            settings.setAutoBluetoothDeviceEnabled(device.address, enabled)
                                        }
                                    }
                                )
                                Text(device.name, color = BubatzCream)
                            }
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { scope.launch { settings.suppressNextBluetoothAutoStart() } },
                        enabled = !skipOnce,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(42.dp),
                        shape = RoundedCornerShape(15.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                    ) {
                        Text(
                            if (skipOnce) "Nächster Auto-Start wird übersprungen"
                            else "Beim nächsten Verbinden still bleiben",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            SettingsCard("Last.fm · v1.01") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Scrobbling", color = BubatzCream, fontWeight = FontWeight.SemiBold)
                        Text(
                            if (lastFmEnabled) "Aktiv" else "Ausgeschaltet",
                            color = BubatzSage,
                            fontSize = 12.sp
                        )
                    }
                    BubatzSlimSwitch(
                        checked = lastFmEnabled,
                        onCheckedChange = { enabled ->
                            scope.launch { settings.setLastFmEnabled(enabled) }
                        }
                    )
                }

                Spacer(Modifier.height(8.dp))
                Text(lastFmStatus, color = BubatzSage, fontSize = 12.sp)
                Text(
                    "Account und Scrobbling sind unabhängig: Du kannst den Account wechseln oder Scrobbling komplett abschalten.",
                    color = BubatzSage,
                    fontSize = 11.sp
                )

                if (!lastFmHasApiCredentials) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Für die Last.fm-API braucht Bubatz einmalig einen API-Key und Shared Secret. Sie werden verschlüsselt nur auf diesem Gerät gespeichert und nicht in das Projekt eingebaut.",
                        color = BubatzCream,
                        fontSize = 11.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = lastFmApiKey,
                        onValueChange = { lastFmApiKey = it },
                        label = { Text("Last.fm API-Key") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = lastFmSecret,
                        onValueChange = { lastFmSecret = it },
                        label = { Text("Shared Secret") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(
                        enabled = lastFmApiKey.isNotBlank() && lastFmSecret.isNotBlank(),
                        onClick = {
                            lastFmStore.saveApiCredentials(lastFmApiKey, lastFmSecret)
                            lastFmHasApiCredentials = true
                            lastFmStatus = "API-Zugang gespeichert · Account noch nicht verbunden"
                        }
                    ) { Text("API-Zugang speichern") }
                } else if (lastFmUser == null) {
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = {
                        scope.launch {
                            runCatching {
                                val url = lastFmAuth.beginAuthorization()
                                lastFmAuth.openAuthorization(url)
                                lastFmStatus = "Im Browser freigeben, danach hier bestätigen."
                            }.onFailure {
                                lastFmStatus = it.message ?: "Last.fm-Anmeldung fehlgeschlagen"
                            }
                        }
                    }) { Text("Last.fm Account verbinden") }

                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(onClick = {
                        scope.launch {
                            runCatching {
                                val session = lastFmAuth.finishAuthorization()
                                lastFmUser = session.username
                                lastFmStatus = "Verbunden als ${session.username}"
                            }.onFailure {
                                lastFmStatus = it.message ?: "Freigabe noch nicht abgeschlossen"
                            }
                        }
                    }) { Text("Freigabe abgeschlossen") }
                } else {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Verbunden als $lastFmUser",
                        color = BubatzCream,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(onClick = {
                        lastFmAuth.disconnect()
                        lastFmUser = null
                        lastFmStatus = "Nicht verbunden · API-Zugang bleibt gespeichert"
                    }) { Text("Account trennen / wechseln") }
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                "Bubatz.FM · v${BuildConfig.VERSION_NAME}",
                color = BubatzSage,
                fontSize = 11.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(24.dp))
            }
        }
    }

    @Composable
    private fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
        Card(
            colors = CardDefaults.cardColors(containerColor = BubatzGreen.copy(alpha = 0.62f)),
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, BubatzSage.copy(alpha = 0.56f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp).fillMaxWidth()) {
                Text(title, color = BubatzCream, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                Spacer(Modifier.height(6.dp))
                content()
            }
        }
    }

    @Composable
    private fun SettingsActionButton(
        label: String,
        icon: androidx.compose.ui.graphics.vector.ImageVector,
        onClick: () -> Unit,
        modifier: Modifier = Modifier
    ) {
        OutlinedButton(
            onClick = onClick,
            modifier = modifier.height(46.dp),
            shape = RoundedCornerShape(15.dp),
            border = BorderStroke(1.dp, Color(0xFF8BDD4B).copy(alpha = 0.82f)),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = BubatzCream),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
        ) {
            Icon(icon, null, tint = Color(0xFFA4E65C), modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                label,
                fontWeight = FontWeight.Medium,
                fontSize = 12.sp,
                maxLines = 1,
                softWrap = false
            )
        }
    }

    @Composable
    private fun BubatzSlimSwitch(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
        val track = if (checked) Color(0xFF8BDD4B).copy(alpha = 0.20f) else BubatzDark.copy(alpha = 0.38f)
        val border = if (checked) Color(0xFF9BE84E) else BubatzSage.copy(alpha = 0.55f)
        Box(
            modifier = Modifier
                .width(48.dp)
                .height(28.dp)
                .background(track, RoundedCornerShape(14.dp))
                .border(1.dp, border, RoundedCornerShape(14.dp))
                .clickable { onCheckedChange(!checked) }
                .padding(3.dp),
            contentAlignment = if (checked) Alignment.CenterEnd else Alignment.CenterStart
        ) {
            Box(
                Modifier
                    .size(20.dp)
                    .background(if (checked) BubatzCream else BubatzSage, CircleShape)
            )
        }
    }

    @Composable
    private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 40.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                label,
                color = BubatzCream,
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 18.dp),
                fontSize = 13.sp,
                lineHeight = 18.sp
            )
            Box(
                modifier = Modifier.width(48.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                BubatzSlimSwitch(checked = checked, onCheckedChange = onChange)
            }
        }
    }

    private fun sendPlaybackAction(action: String) {
        val i = Intent(this, PlaybackService::class.java).setAction(action)
        // The Activity is in the foreground, so a normal service start is enough.
        // Starting as a foreground service before a 40k-library initialization
        // finishes can trigger Android's foreground-service timeout.
        startService(i)
    }

    private fun sendSeekAction(positionMs: Long) {
        val i = Intent(this, PlaybackService::class.java)
            .setAction(PlaybackService.ACTION_SEEK)
            .putExtra(PlaybackService.EXTRA_SEEK_POSITION_MS, positionMs)
        startService(i)
    }

    private fun playTrackFromHistory(trackId: Long) {
        startService(
            Intent(this, PlaybackService::class.java)
                .setAction(PlaybackService.ACTION_PLAY_TRACK_ID)
                .putExtra(PlaybackService.EXTRA_TRACK_ID, trackId)
        )
    }

    private fun formatHistoryTime(timestamp: Long): String {
        val formatter = java.text.SimpleDateFormat("dd.MM. · HH:mm", java.util.Locale.getDefault())
        return formatter.format(java.util.Date(timestamp))
    }

    private fun persist(uri: Uri) {
        runCatching {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
    }

    private fun formatTime(ms: Long): String {
        if (ms <= 0) return "0:00"
        val total = ms / 1000
        val minutes = total / 60
        val seconds = total % 60
        return "$minutes:${seconds.toString().padStart(2, '0')}"
    }
}
