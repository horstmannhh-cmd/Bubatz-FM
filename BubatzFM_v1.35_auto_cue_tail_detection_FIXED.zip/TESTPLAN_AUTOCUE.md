# Bubatz.FM v1.35 Auto-Cue test

1. Listen normally to several music→music transitions. Compare fade-outs with v1.34.
2. Note titles with obvious long silence/fade at the end: the next song should enter later, after the audible outro, without waiting through dead air.
3. Note titles ending loudly right to the end: behaviour should remain the proven classic crossfade fallback.
4. Test at least two music→radio inserts. Speech must still start cleanly and the v1.32 radio→music end must remain stutter-free.
5. BOOMSTER: verify no display wake/pause/stutter at transitions.
6. Check Live notification artwork remains unchanged.
