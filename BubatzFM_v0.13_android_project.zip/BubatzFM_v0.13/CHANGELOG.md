# Bubatz FM – Changelog

## 0.13.0
- Fehler beim ersten Start über Play/Pause behoben.
- Wenn noch kein Titel aktiv ist, wählt Play jetzt automatisch den nächsten Shuffle-Titel und startet ihn.
- Sobald ein Titel geladen ist, bleibt das normale Play/Pause-Verhalten unverändert.
- Fix basiert direkt auf dem ersten echten Gerätetest mit 41.610 erkannten Titeln.
