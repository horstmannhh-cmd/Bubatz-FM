
package fm.bubatz.player.playback

import android.content.Intent
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import fm.bubatz.player.BubatzApplication
import fm.bubatz.player.data.PlayHistoryEntity
import fm.bubatz.player.data.PlaybackStateEntity
import fm.bubatz.player.playback.dual.DualDeckPlayer
import fm.bubatz.player.playback.dual.PlaybackCoordinator
import fm.bubatz.player.playback.session.BubatzSessionPlayer
import fm.bubatz.player.radio.RadioScheduler
import fm.bubatz.player.scrobble.PlaybackScrobbleTracker
import fm.bubatz.player.scrobble.LastFmApi
import fm.bubatz.player.scrobble.LastFmConfig
import fm.bubatz.player.scrobble.LastFmScrobbleSender
import fm.bubatz.player.scrobble.LastFmSessionStore
import fm.bubatz.player.settings.AppSettings
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

class PlaybackService : MediaSessionService() {
    companion object {
        const val ACTION_AUTO_PLAY = "fm.bubatz.player.AUTO_PLAY"
        const val ACTION_PLAY_PAUSE = "fm.bubatz.player.PLAY_PAUSE"
        const val ACTION_NEXT = "fm.bubatz.player.NEXT"
        const val ACTION_PREVIOUS = "fm.bubatz.player.PREVIOUS"
    }

    private lateinit var session: MediaSession
    private lateinit var dualDeck: DualDeckPlayer
    private val coordinator = PlaybackCoordinator()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private lateinit var shuffle: ShuffleManager
    private lateinit var scrobbleTracker: PlaybackScrobbleTracker
    private lateinit var settings: AppSettings
    private lateinit var lastFmStore: LastFmSessionStore
    private lateinit var lastFmSender: LastFmScrobbleSender
    private val lastFmApi = LastFmApi()

    private val radioScheduler = RadioScheduler()
    private var nextRadioAtMs = 0L
    private var currentStartedRealtimeMs: Long = 0L
    private var lastStartedMediaId: String? = null
    private var activePlayer: Player? = null
    private var sessionPlayer: BubatzSessionPlayer? = null
    private val sessionCallback = object : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .build()
        }
    }

    private var suppressHistoryForRestoredMediaId: String? = null
    private val externallyObservedPlayers = mutableSetOf<Int>()

    override fun onCreate() {
        super.onCreate()
        val db = (application as BubatzApplication).database
        shuffle = ShuffleManager(db)
        scrobbleTracker = PlaybackScrobbleTracker(db)
        settings = AppSettings(this)
        lastFmStore = LastFmSessionStore(this)
        lastFmSender = LastFmScrobbleSender(db, lastFmStore, lastFmApi)

        dualDeck = DualDeckPlayer(
            context = this,
            scope = scope,
            crossfadeMsProvider = { settings.crossfadeMs.first() },
            onActiveDeckChanged = { player ->
                activePlayer = player
                rebuildMediaSession(player)
            },
            onMediaStarted = { item -> handleMediaStarted(item) }
        )

        // A MediaSession must exist before a controller can bind, even while
        // the database-backed resume state is still loading.
        activePlayer = dualDeck.activePlayer
        rebuildMediaSession(dualDeck.activePlayer)

        scope.launch {
            val state = withContext(Dispatchers.IO) { db.state().get() }
            nextRadioAtMs = state?.nextRadioAtMs?.takeIf { it > 0L }
                ?: radioScheduler.nextDeadline()

            val restored = state?.currentMediaId?.let { mediaItemFromPersistentId(it) }
            val first = restored ?: nextPlayableItem() ?: return@launch
            val restorePosition = if (restored != null) state?.currentPositionMs ?: 0L else 0L

            if (restored != null && restorePosition > 0L) {
                suppressHistoryForRestoredMediaId = restored.mediaId
            }

            dualDeck.setInitial(
                item = first,
                startPositionMs = restorePosition,
                playWhenReady = false
            )

            val reservedNext = state?.upcomingMediaId?.let { mediaItemFromPersistentId(it) }
            if (reservedNext != null && reservedNext.mediaId != first.mediaId) {
                coordinator.setNext(reservedNext)
                dualDeck.scheduleNext(reservedNext)
            } else {
                scheduleUpcoming()
            }
        }

        scope.launch {
            while (isActive) {
                delay(1_000)
                val player = activePlayer ?: continue

                val listenedMs = if (currentStartedRealtimeMs > 0L) {
                    android.os.SystemClock.elapsedRealtime() - currentStartedRealtimeMs
                } else 0L
                scrobbleTracker.onProgress(listenedMs)
                if (listenedMs > 0L && listenedMs % 60_000L < 1_000L && LastFmConfig.configured) {
                    scope.launch { lastFmSender.flush() }
                }

                if (player.currentPosition % 5_000L < 1_000L) persistPosition()
            }
        }
    }

    private fun attachExternalControlListener(player: Player) {
        val identity = System.identityHashCode(player)
        if (!externallyObservedPlayers.add(identity)) return
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                scope.launch { persistPosition() }
            }
        })
    }

    private fun rebuildMediaSession(player: Player) {
        val facade = BubatzSessionPlayer(
            player = player,
            onNext = { scope.launch { skipNext() } },
            onPrevious = { scope.launch { handlePreviousRequest() } }
        )
        sessionPlayer = facade

        if (!::session.isInitialized) {
            session = MediaSession.Builder(this, facade)
                .setCallback(sessionCallback)
                .build()
        } else {
            session.setPlayer(facade)
        }
        attachExternalControlListener(player)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession = session

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_AUTO_PLAY -> dualDeck.play()
            ACTION_PLAY_PAUSE -> {
                val p = activePlayer
                if (p == null || p.currentMediaItem == null) {
                    scope.launch { startPlaybackIfIdle() }
                } else {
                    if (p.isPlaying) p.pause() else p.play()
                }
            }
            ACTION_NEXT -> scope.launch { skipNext() }
            ACTION_PREVIOUS -> scope.launch { handlePreviousRequest() }
        }
        return super.onStartCommand(intent, flags, startId)
    }

    private suspend fun handlePreviousRequest() {
        val p = activePlayer
        if (p != null && p.currentPosition > 5_000L) {
            dualDeck.seekTo(0L)
            persistPosition()
        } else {
            playPreviousFromHistory()
        }
    }

    private suspend fun startPlaybackIfIdle() {
        val current = activePlayer
        if (current != null && current.currentMediaItem != null) {
            current.play()
            return
        }

        val next = coordinator.peekNext()
        if (next != null) {
            dualDeck.setInitial(next, playWhenReady = true)
            activePlayer = dualDeck.activePlayer()
            rebuildMediaSession(activePlayer!!)
            persistPosition()
        }
    }

    private suspend fun skipNext() {
        val next = coordinator.peekNext() ?: nextPlayableItem()?.also { coordinator.setNext(it) } ?: return
        dualDeck.setInitial(next, 0L, playWhenReady = true)
    }

    private suspend fun playPreviousFromHistory() {
        val db = (application as BubatzApplication).database
        val current = activePlayer?.currentMediaItem?.mediaId
        val previous = withContext(Dispatchers.IO) {
            db.history().recent(20)
                .asSequence()
                .filter { it.type == "MUSIC" && it.trackId != null }
                .map { "track:${it.trackId}" }
                .firstOrNull { it != current }
        } ?: run {
            dualDeck.seekTo(0L)
            return
        }

        val item = mediaItemFromPersistentId(previous) ?: return
        coordinator.clear()
        dualDeck.setInitial(item, 0L, playWhenReady = true)
    }

    private suspend fun handleMediaStarted(item: MediaItem) {
        if (item.mediaId == lastStartedMediaId) return
        lastStartedMediaId = item.mediaId
        currentStartedRealtimeMs = android.os.SystemClock.elapsedRealtime()

        val duration = when {
            item.mediaId.startsWith("track:") -> {
                val id = item.mediaId.removePrefix("track:").toLongOrNull()
                id?.let { withContext(Dispatchers.IO) {
                    (application as BubatzApplication).database.tracks().byId(it)?.durationMs
                } } ?: 0L
            }
            item.mediaId.startsWith("radio:") -> {
                val id = item.mediaId.removePrefix("radio:").toLongOrNull()
                id?.let { withContext(Dispatchers.IO) {
                    (application as BubatzApplication).database.clips().byId(it)?.durationMs
                } } ?: 0L
            }
            else -> 0L
        }

        scrobbleTracker.onItemStarted(
            mediaId = item.mediaId,
            durationMs = duration,
            nowSeconds = System.currentTimeMillis() / 1000L
        )

        if (item.mediaId.startsWith("track:") && LastFmConfig.configured) {
            val key = lastFmStore.sessionKey
            val artist = item.mediaMetadata.artist?.toString().orEmpty()
            val title = item.mediaMetadata.title?.toString().orEmpty()
            if (key != null && artist.isNotBlank() && title.isNotBlank()) {
                scope.launch(Dispatchers.IO) {
                    runCatching {
                        lastFmApi.updateNowPlaying(
                            sessionKey = key,
                            artist = artist,
                            track = title,
                            album = item.mediaMetadata.albumTitle?.toString(),
                            durationSeconds = duration.takeIf { it > 0L }?.div(1000L)
                        )
                    }
                }
            }
        }

        if (suppressHistoryForRestoredMediaId == item.mediaId) {
            // Resuming the same partially-played item is not a new play.
            suppressHistoryForRestoredMediaId = null
        } else {
            recordStartedItem(item)
        }

        // The item that was scheduled has now become active.
        coordinator.consumeNext()
        persistPosition(currentMediaIdOverride = item.mediaId, upcomingMediaIdOverride = null)
        scheduleUpcoming()
    }

    private suspend fun scheduleUpcoming() {
        val next = nextPlayableItem() ?: return
        coordinator.setNext(next)
        persistPosition(upcomingMediaIdOverride = next.mediaId)
        dualDeck.scheduleNext(next)
    }

    /**
     * Radio scheduler is evaluated before selecting the next media item.
     * If due, exactly one radio insert is returned. The following item will
     * be music again because the deadline is immediately moved forward.
     */
    private suspend fun nextPlayableItem(): MediaItem? {
        val radioEnabled = settings.radioEnabled.first()
        if (radioEnabled && radioScheduler.isDue(nextRadioAtMs)) {
            val clip = withContext(Dispatchers.IO) { shuffle.nextRadioClip() }
            nextRadioAtMs = radioScheduler.nextDeadline()
            if (clip != null) {
                return MediaItem.Builder()
                    .setUri(clip.uri)
                    .setMediaId("radio:${clip.id}")
                    .setMediaMetadata(
                        MediaMetadata.Builder()
                            .setTitle(clip.name)
                            .setArtist("Bubatz FM")
                            .setAlbumTitle("Radioeinspieler")
                            .build()
                    )
                    .build()
            }
        }

        val t = withContext(Dispatchers.IO) { shuffle.nextTrack() } ?: return null
        return MediaItem.Builder()
            .setUri(t.uri)
            .setMediaId("track:${t.id}")
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(t.title)
                    .setArtist(t.artist)
                    .setAlbumTitle(t.album)
                    .setArtworkUri(Uri.parse(t.uri))
                    .build()
            )
            .build()
    }

    private suspend fun mediaItemFromPersistentId(mediaId: String): MediaItem? {
        val db = (application as BubatzApplication).database
        return withContext(Dispatchers.IO) {
            when {
                mediaId.startsWith("track:") -> {
                    val id = mediaId.removePrefix("track:").toLongOrNull() ?: return@withContext null
                    val t = db.tracks().byId(id) ?: return@withContext null
                    MediaItem.Builder()
                        .setUri(t.uri)
                        .setMediaId("track:${t.id}")
                        .setMediaMetadata(
                            MediaMetadata.Builder()
                                .setTitle(t.title)
                                .setArtist(t.artist)
                                .setAlbumTitle(t.album)
                                .setArtworkUri(Uri.parse(t.uri))
                                .build()
                        )
                        .build()
                }
                mediaId.startsWith("radio:") -> {
                    val id = mediaId.removePrefix("radio:").toLongOrNull() ?: return@withContext null
                    val clip = db.clips().byId(id) ?: return@withContext null
                    MediaItem.Builder()
                        .setUri(clip.uri)
                        .setMediaId("radio:${clip.id}")
                        .setMediaMetadata(
                            MediaMetadata.Builder()
                                .setTitle(clip.name)
                                .setArtist("Bubatz FM")
                                .setAlbumTitle("Radioeinspieler")
                                .build()
                        )
                        .build()
                }
                else -> null
            }
        }
    }

    private suspend fun recordStartedItem(item: MediaItem) {
        val db = (application as BubatzApplication).database
        val now = System.currentTimeMillis()
        withContext(Dispatchers.IO) {
            when {
                item.mediaId.startsWith("track:") -> {
                    val id = item.mediaId.removePrefix("track:").toLongOrNull() ?: return@withContext
                    db.tracks().markPlayed(id, now)
                    db.history().insert(
                        PlayHistoryEntity(
                            type = "MUSIC",
                            trackId = id,
                            title = item.mediaMetadata.title?.toString() ?: "Unbekannter Titel"
                        )
                    )
                }
                item.mediaId.startsWith("radio:") -> {
                    val id = item.mediaId.removePrefix("radio:").toLongOrNull() ?: return@withContext
                    db.clips().markPlayed(id, now)
                    db.history().insert(
                        PlayHistoryEntity(
                            type = "RADIO",
                            clipId = id,
                            title = item.mediaMetadata.title?.toString()
                                ?: "Bubatz FM Einspieler"
                        )
                    )
                }
            }
        }
    }

    private suspend fun persistPosition(
        currentMediaIdOverride: String? = null,
        upcomingMediaIdOverride: String? = coordinator.peekNext()?.mediaId
    ) {
        val player = activePlayer ?: return
        val db = (application as BubatzApplication).database
        val currentMediaId = currentMediaIdOverride ?: player.currentMediaItem?.mediaId
        val currentTrackId = currentMediaId
            ?.takeIf { it.startsWith("track:") }
            ?.removePrefix("track:")
            ?.toLongOrNull()

        withContext(Dispatchers.IO) {
            val old = db.state().get() ?: PlaybackStateEntity()
            db.state().put(
                old.copy(
                    currentTrackId = currentTrackId,
                    currentMediaId = currentMediaId,
                    upcomingMediaId = upcomingMediaIdOverride,
                    currentPositionMs = player.currentPosition.coerceAtLeast(0L),
                    currentDurationMs = player.duration.coerceAtLeast(0L),
                    currentTitle = player.currentMediaItem?.mediaMetadata?.title?.toString(),
                    currentArtist = player.currentMediaItem?.mediaMetadata?.artist?.toString(),
                    currentAlbum = player.currentMediaItem?.mediaMetadata?.albumTitle?.toString(),
                    isPlaying = player.isPlaying,
                    nextRadioAtMs = nextRadioAtMs
                )
            )
        }
    }

    override fun onDestroy() {
        runBlocking(Dispatchers.IO) {
            persistPosition()
        }
        scope.cancel()
        if (::session.isInitialized) session.release()
        dualDeck.release()
        super.onDestroy()
    }
}
