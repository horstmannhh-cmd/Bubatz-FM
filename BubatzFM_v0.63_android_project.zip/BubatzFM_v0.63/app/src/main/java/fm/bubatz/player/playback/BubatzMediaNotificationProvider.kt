package fm.bubatz.player.playback

import android.app.Notification
import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession
import com.google.common.collect.ImmutableList

@OptIn(UnstableApi::class)
class BubatzMediaNotificationProvider(
    private val appContext: Context,
    private val onMetadataSeen: ((MediaMetadata) -> Unit)? = null
) : DefaultMediaNotificationProvider(appContext) {

    override fun getNotificationContentTitle(metadata: MediaMetadata): CharSequence {
        onMetadataSeen?.invoke(metadata)
        val title = metadata.title?.toString()?.trim().orEmpty()
        val artist = metadata.artist?.toString()?.trim().orEmpty()
        return when {
            title.isNotEmpty() && artist.isNotEmpty() -> "$title – $artist"
            title.isNotEmpty() -> title
            artist.isNotEmpty() -> artist
            else -> "Bubatz FM"
        }
    }

    override fun getNotificationContentText(metadata: MediaMetadata): CharSequence? {
        return metadata.albumTitle ?: metadata.artist
    }

    override fun createNotification(
        mediaSession: MediaSession,
        mediaButtonPreferences: ImmutableList<CommandButton>,
        actionFactory: MediaNotification.ActionFactory,
        onNotificationChangedCallback: MediaNotification.Provider.Callback
    ): MediaNotification {
        val wrappedCallback = MediaNotification.Provider.Callback { updated ->
            onNotificationChangedCallback.onNotificationChanged(alignWithOmnia(updated))
        }

        val base = super.createNotification(
            mediaSession,
            mediaButtonPreferences,
            actionFactory,
            wrappedCallback
        )
        return alignWithOmnia(base)
    }

    private fun alignWithOmnia(source: MediaNotification): MediaNotification {
        val rebuilt = Notification.Builder
            .recoverBuilder(appContext, source.notification)
            .setOngoing(true)
            .setGroup(null)
            .setCategory(Notification.CATEGORY_TRANSPORT)
            .build()
            .apply {
                flags = flags or Notification.FLAG_ONGOING_EVENT
            }

        return MediaNotification(source.notificationId, rebuilt)
    }
}
