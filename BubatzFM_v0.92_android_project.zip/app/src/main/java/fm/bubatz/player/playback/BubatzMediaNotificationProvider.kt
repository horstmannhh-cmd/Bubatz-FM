package fm.bubatz.player.playback

import android.app.Notification
import android.content.Context
import android.os.Bundle
import androidx.annotation.OptIn
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession
import com.google.common.collect.ImmutableList
import fm.bubatz.player.R

/**
 * v0.64:
 * DefaultMediaNotificationProvider.createNotification() is final and cannot be
 * overridden. We therefore implement MediaNotification.Provider and delegate to
 * Media3, then adjust the returned notification BEFORE MediaSessionService posts it.
 */
@OptIn(UnstableApi::class)
class BubatzMediaNotificationProvider(
    private val context: Context,
    private val onMetadataSeen: ((MediaMetadata) -> Unit)? = null,
    private val platformSessionToken: (() -> android.media.session.MediaSession.Token?)? = null
) : MediaNotification.Provider {

    private val delegate: DefaultMediaNotificationProvider =
        DefaultMediaNotificationProvider.Builder(context)
            .setChannelId("bubatz_media_playback")
            .setChannelName(R.string.app_name)
            .build()
            .apply {
                setSmallIcon(R.drawable.media3_notification_small_icon)
            }

    override fun createNotification(
        mediaSession: MediaSession,
        mediaButtonPreferences: ImmutableList<CommandButton>,
        actionFactory: MediaNotification.ActionFactory,
        onNotificationChangedCallback: MediaNotification.Provider.Callback
    ): MediaNotification {
        onMetadataSeen?.invoke(mediaSession.player.mediaMetadata)

        val wrappedCallback = MediaNotification.Provider.Callback { updated ->
            onNotificationChangedCallback.onNotificationChanged(
                alignWithOmnia(updated, mediaSession.player.mediaMetadata)
            )
        }

        val base = delegate.createNotification(
            mediaSession,
            mediaButtonPreferences,
            actionFactory,
            wrappedCallback
        )

        return alignWithOmnia(base, mediaSession.player.mediaMetadata)
    }


    override fun handleCustomCommand(
        session: MediaSession,
        action: String,
        extras: Bundle
    ): Boolean {
        return delegate.handleCustomCommand(session, action, extras)
    }

    private fun alignWithOmnia(
        source: MediaNotification,
        metadata: MediaMetadata
    ): MediaNotification {
        val title = metadata.title?.toString()?.trim().orEmpty()
        val artist = metadata.artist?.toString()?.trim().orEmpty()
        val album = metadata.albumTitle?.toString()?.trim().orEmpty()

        val notificationTitle = title.ifEmpty { artist.ifEmpty { "Bubatz FM" } }

        val builder = Notification.Builder
            .recoverBuilder(context, source.notification)
            .setOngoing(false)
            .setGroup(null)
            .setCategory(Notification.CATEGORY_TRANSPORT)
            .setPriority(Notification.PRIORITY_HIGH)
            .setContentTitle(notificationTitle)
            .setContentText(artist.ifEmpty { album })
            .setSubText(album.ifEmpty { null })

        // v0.92: Samsung status-bar chip experiment.  The live Omnia comparison
        // consistently reports a classic platform MediaSession with actions 0xF37.
        // Associate Bubatz's real MediaStyle notification with our matching platform
        // session token instead of Media3's translated action surface.  The existing
        // notification actions/PendingIntents remain untouched.
        platformSessionToken?.invoke()?.let { token ->
            builder.setStyle(
                Notification.MediaStyle()
                    .setMediaSession(token)
                    .setShowActionsInCompactView(0, 1, 2)
            )
        }

        val rebuilt = builder.build()
            .apply {
                flags = flags and Notification.FLAG_ONGOING_EVENT.inv()
                flags = flags or Notification.FLAG_NO_CLEAR
                flags = flags and Notification.FLAG_ONLY_ALERT_ONCE.inv()
            }

        return MediaNotification(source.notificationId, rebuilt)
    }
}
