package fm.bubatz.player.library

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import fm.bubatz.player.data.RadioClipEntity
import fm.bubatz.player.data.TrackEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LibraryScanner(private val context: Context) {
    private val audioExt = setOf("mp3", "flac", "m4a", "aac", "ogg", "opus", "wav", "wma")

    suspend fun scanMusic(treeUri: Uri): List<TrackEntity> = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext emptyList()
        sequenceFiles(root).mapNotNull { file ->
            val ext = file.name?.substringAfterLast('.', "")?.lowercase()
            if (ext !in audioExt) return@mapNotNull null
            readTrack(file.uri, file.name ?: "Unbekannt")
        }.toList()
    }

    suspend fun scanRadio(treeUri: Uri): List<RadioClipEntity> = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext emptyList()
        sequenceFiles(root).mapNotNull { file ->
            val ext = file.name?.substringAfterLast('.', "")?.lowercase()
            if (ext !in audioExt) return@mapNotNull null
            val meta = metadata(file.uri)
            RadioClipEntity(
                uri = file.uri.toString(),
                name = meta.title ?: file.name?.substringBeforeLast('.') ?: "Einspieler",
                durationMs = meta.duration
            )
        }.toList()
    }

    private fun sequenceFiles(dir: DocumentFile): Sequence<DocumentFile> = sequence {
        for (child in dir.listFiles()) {
            if (child.isDirectory) yieldAll(sequenceFiles(child)) else if (child.isFile) yield(child)
        }
    }

    private fun readTrack(uri: Uri, fallback: String): TrackEntity? = runCatching {
        val m = metadata(uri)
        TrackEntity(
            uri = uri.toString(),
            title = m.title ?: fallback.substringBeforeLast('.'),
            artist = m.artist,
            album = m.album,
            durationMs = m.duration
        )
    }.getOrNull()

    private data class Meta(val title: String?, val artist: String?, val album: String?, val duration: Long)

    private fun metadata(uri: Uri): Meta {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(context, uri)
            Meta(
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            )
        } finally { r.release() }
    }
}
