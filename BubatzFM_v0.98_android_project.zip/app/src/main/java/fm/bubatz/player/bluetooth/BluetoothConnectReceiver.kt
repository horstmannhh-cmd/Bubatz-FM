package fm.bubatz.player.bluetooth

import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import fm.bubatz.player.playback.PlaybackService
import fm.bubatz.player.settings.AppSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * v0.98: starts Bubatz only for a real Bluetooth A2DP media connection.
 *
 * We deliberately ignore generic ACL connections. Watches, keyboards and other
 * Bluetooth devices may establish ACL links as well, and should never make music
 * start by themselves. A2DP STATE_CONNECTED is the actual media-output signal.
 */
class BluetoothConnectReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED) return
        if (intent.getIntExtra(BluetoothProfile.EXTRA_STATE, -1) != BluetoothProfile.STATE_CONNECTED) return

        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val device: BluetoothDevice? =
                    if (Build.VERSION.SDK_INT >= 33) {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    }

                val address = runCatching { device?.address }.getOrNull()
                if (!AppSettings(context).shouldAutoStartFor(address)) return@launch

                val service = Intent(context, PlaybackService::class.java)
                    .setAction(PlaybackService.ACTION_AUTO_PLAY)
                ContextCompat.startForegroundService(context, service)
            } finally {
                pending.finish()
            }
        }
    }
}
