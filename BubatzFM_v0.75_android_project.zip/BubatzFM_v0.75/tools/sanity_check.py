from pathlib import Path
import sys, xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]

# v0.32 is intentionally a minimal playback diagnostic build.
# Only validate the minimum project structure needed to compile/run this test.
required = [
    root / "app/src/main/AndroidManifest.xml",
    root / "app/src/main/java/fm/bubatz/player/MainActivity.kt",
    root / "app/src/main/java/fm/bubatz/player/playback/PlaybackService.kt",
    root / "app/src/main/java/fm/bubatz/player/data/Dao.kt",
]

errors = [f"Missing required file: {p.relative_to(root)}" for p in required if not p.exists()]

manifest = root / "app/src/main/AndroidManifest.xml"
if manifest.exists():
    try:
        ET.parse(manifest)
    except Exception as e:
        errors.append(f"AndroidManifest.xml invalid: {e}")

service = root / "app/src/main/java/fm/bubatz/player/playback/PlaybackService.kt"
if service.exists():
    text = service.read_text()
    if "MediaSession.Builder(this, player)" not in text:
        errors.append("Minimal MediaSession not found.")
    if "ExoPlayer.Builder(this).build()" not in text:
        errors.append("Minimal ExoPlayer not found.")

manifest_text = manifest.read_text() if manifest.exists() else ""
if "android.permission.FOREGROUND_SERVICE" not in manifest_text:
    errors.append("FOREGROUND_SERVICE permission missing.")
if "android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" not in manifest_text:
    errors.append("FOREGROUND_SERVICE_MEDIA_PLAYBACK permission missing.")
if "androidx.media3.session.MediaSessionService" not in manifest_text:
    errors.append("MediaSessionService intent-filter missing.")
if 'android:foregroundServiceType="mediaPlayback"' not in manifest_text:
    errors.append("PlaybackService foregroundServiceType=mediaPlayback missing.")

service_text = service.read_text() if service.exists() else ""
if "addSession(session)" not in service_text:
    errors.append("MediaSession is not explicitly registered with MediaSessionService.")
if "super.onStartCommand(intent, flags, startId)" not in service_text:
    errors.append("PlaybackService does not call MediaSessionService.onStartCommand().")

service_text = service.read_text() if service.exists() else ""
if "SESSION_COMMAND_PREVIOUS" not in service_text or "SESSION_COMMAND_NEXT" not in service_text:
    errors.append("Custom system-media previous/next commands missing.")
if "setMediaButtonPreferences(mediaButtonPreferences())" not in service_text:
    errors.append("Media button preferences are not configured.")
if "onCustomCommand(" not in service_text:
    errors.append("Custom media command callback missing.")

service_text = service.read_text() if service.exists() else ""
if "standbyPlayer" not in service_text:
    errors.append("Crossfade standby player missing.")
if "FadeEnvelope.gains" not in service_text:
    errors.append("Equal-power fade envelope missing.")
if "player.setMediaItem(nextItem, firstHandoffPosition)" not in service_text:
    errors.append("Session-safe crossfade handoff missing.")
if "session.setPlayer" in service_text:
    errors.append("Unsafe MediaSession player swapping detected.")

if errors:
    print("SANITY CHECK FAILED")
    for e in errors:
        print("-", e)
    sys.exit(1)

print("SANITY CHECK OK - v0.58 cover handoff without transient null track")
