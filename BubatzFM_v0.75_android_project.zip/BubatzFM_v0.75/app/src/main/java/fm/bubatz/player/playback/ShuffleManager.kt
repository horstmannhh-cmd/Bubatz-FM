package fm.bubatz.player.playback

import fm.bubatz.player.data.BubatzDatabase
import fm.bubatz.player.data.RadioClipEntity
import fm.bubatz.player.data.TrackEntity

/**
 * Persistent fair shuffle for very large libraries.
 *
 * Tracks with the lowest playCount are chosen first. A track is incremented
 * when it actually becomes the active item, so every track gets one turn
 * before previously played tracks become eligible again.
 *
 * This avoids constructing a 40k-row shuffle queue when playback starts.
 */
class ShuffleManager(private val db: BubatzDatabase) {
    suspend fun nextTrack(excludeId: Long? = null): TrackEntity? =
        db.tracks().randomLeastPlayed(excludeId)

    suspend fun nextRadioClip(excludeId: Long? = null): RadioClipEntity? =
        db.clips().randomLeastPlayed(excludeId)
}
