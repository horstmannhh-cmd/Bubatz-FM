package fm.bubatz.player

import android.app.Application
import fm.bubatz.player.data.BubatzDatabase

class BubatzApplication : Application() {
    val database: BubatzDatabase by lazy { BubatzDatabase.create(this) }

    override fun onCreate() {
        super.onCreate()

        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            runCatching {
                CrashDiagnostics(this).save(
                    label = "UNCAUGHT EXCEPTION auf Thread ${thread.name}",
                    throwable = throwable
                )
            }
            previous?.uncaughtException(thread, throwable)
        }
    }
}
