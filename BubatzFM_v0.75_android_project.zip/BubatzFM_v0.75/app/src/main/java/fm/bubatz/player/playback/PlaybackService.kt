package fm.bubatz.player.playback

import android.content.Intent
import android.os.Build
import android.app.PendingIntent
import android.app.NotificationManager
import android.app.NotificationChannel
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.Futures
import androidx.media3.session.SessionResult
import androidx.media3.session.SessionCommand
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.common.util.UnstableApi
import androidx.annotation.OptIn
import android.os.Bundle
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import fm.bubatz.player.BubatzApplication
import fm.bubatz.player.CrashDiagnostics
import fm.bubatz.player.data.PlaybackStateEntity
import fm.bubatz.player.data.PlayHistoryEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.collectLatest
import fm.bubatz.player.playback.crossfade.FadeEnvelope
import fm.bubatz.player.settings.AppSettings
import fm.bubatz.player.data.TrackEntity

@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {

    companion object {
        const val ACTION_AUTO_PLAY = "fm.bubatz.player.AUTO_PLAY"
        const val ACTION_PLAY_PAUSE = "fm.bubatz.player.PLAY_PAUSE"
        const val ACTION_NEXT = "fm.bubatz.player.NEXT"
        const val ACTION_PREVIOUS = "fm.bubatz.player.PREVIOUS"
        const val ACTION_SEEK = "fm.bubatz.player.SEEK"
        const val EXTRA_SEEK_POSITION_MS = "seek_position_ms"

        private const val SESSION_COMMAND_PREVIOUS = "fm.bubatz.player.session.PREVIOUS"
        private const val SESSION_COMMAND_NEXT = "fm.bubatz.player.session.NEXT"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private lateinit var player: ExoPlayer
    private lateinit var standbyPlayer: ExoPlayer
    private lateinit var session: MediaSession
    private lateinit var shuffle: ShuffleManager
    private lateinit var diagnostics: CrashDiagnostics
    private lateinit var db: fm.bubatz.player.data.BubatzDatabase
    private lateinit var settings: AppSettings

    private var currentTrackId: Long? = null
    private var startedCurrentTrack = false

    // Navigation history for familiar Previous/Next behavior:
    // A → B → C, Previous => B, Next => C (not a fresh random title).
    private val backStack = ArrayDeque<Long>()
    private val forwardStack = ArrayDeque<Long>()

    private var restoreJob: Job? = null
    private var positionPersistJob: Job? = null
    private var crossfadeMonitorJob: Job? = null
    private var crossfadeJob: Job? = null
    private var settingsJob: Job? = null

    private var configuredCrossfadeMs = 5_000
    private var crossfadeInProgress = false
    private var pendingCrossfadeTrack: TrackEntity? = null
    private var pendingCrossfadeItem: MediaItem? = null

    private val previousSessionCommand =
        SessionCommand(SESSION_COMMAND_PREVIOUS, Bundle.EMPTY)
    private val nextSessionCommand =
        SessionCommand(SESSION_COMMAND_NEXT, Bundle.EMPTY)

    private val sessionCallback = object : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val defaultResult = super.onConnect(session, controller)
            val sessionCommands = defaultResult.availableSessionCommands
                .buildUpon()
                .add(previousSessionCommand)
                .add(nextSessionCommand)
                .build()

            return MediaSession.ConnectionResult.accept(
                sessionCommands,
                defaultResult.availablePlayerCommands
            )
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle
        ): ListenableFuture<SessionResult> {
            when (customCommand.customAction) {
                SESSION_COMMAND_PREVIOUS -> {
                    scope.launch {
                        restoreJob?.join()
                        playPreviousInternal()
                    }
                }

                SESSION_COMMAND_NEXT -> {
                    scope.launch {
                        restoreJob?.join()
                        playNextInternal()
                    }
                }

                else -> {
                    return super.onCustomCommand(
                        session,
                        controller,
                        customCommand,
                        args
                    )
                }
            }

            return Futures.immediateFuture(
                SessionResult(SessionResult.RESULT_SUCCESS)
            )
        }
    }

    private fun mediaButtonPreferences(): List<CommandButton> =
        listOf(
            CommandButton.Builder(CommandButton.ICON_PREVIOUS)
                .setDisplayName("Zurück")
                .setSessionCommand(previousSessionCommand)
                .setSlots(CommandButton.SLOT_BACK)
                .build(),
            CommandButton.Builder(CommandButton.ICON_NEXT)
                .setDisplayName("Weiter")
                .setSessionCommand(nextSessionCommand)
                .setSlots(CommandButton.SLOT_FORWARD)
                .build()
        )

    override fun onCreate() {
        super.onCreate()

        diagnostics = CrashDiagnostics(this)
        db = (application as BubatzApplication).database
        shuffle = ShuffleManager(db)
        settings = AppSettings(this)


        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                "bubatz_media_playback",
                "Bubatz FM Wiedergabe",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Laufende Medienwiedergabe"
                setSound(null, null)
                enableVibration(false)
                setShowBadge(false)
            }
            nm?.createNotificationChannel(channel)
        }

        // v0.57: One UI's compact live-media surface appears to use the actual
        // media-notification content title rather than MediaMetadata.displayTitle.
        // Supply "Titel – Interpret" directly through the Media3 provider.
        player = ExoPlayer.Builder(this).build()
        standbyPlayer = ExoPlayer.Builder(this).build().apply {
            volume = 0f
            addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    diagnostics.save(
                        "v0.45: Standby STATE=$playbackState",
                        extra = "mediaId=${currentMediaItem?.mediaId}"
                    )
                }

                override fun onPlayerError(error: PlaybackException) {
                    diagnostics.save(
                        "v0.45 STANDBY EXOPLAYER ERROR",
                        error,
                        "mediaId=${currentMediaItem?.mediaId}\nuri=${currentMediaItem?.localConfiguration?.uri}"
                    )
                }
            })
        }

        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                diagnostics.save(
                    "v0.45 EXOPLAYER ERROR",
                    error,
                    "mediaId=${player.currentMediaItem?.mediaId}\nuri=${player.currentMediaItem?.localConfiguration?.uri}"
                )
            }

            override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                diagnostics.save(
                    "v0.57: MediaSession-Metadaten",
                    extra = buildString {
                        append("mediaId=").append(player.currentMediaItem?.mediaId).append('\n')
                        append("title=").append(mediaMetadata.title).append('\n')
                        append("displayTitle=").append(mediaMetadata.displayTitle).append('\n')
                        append("artist=").append(mediaMetadata.artist).append('\n')
                        append("album=").append(mediaMetadata.albumTitle).append('\n')
                        append("artworkUri=").append(mediaMetadata.artworkUri)
                    }
                )
                logSamsungLiveNotificationDiagnostics()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                scope.launch {
                    if (isPlaying && !startedCurrentTrack) {
                        startedCurrentTrack = true
                        currentTrackId?.let { id ->
                            val item = player.currentMediaItem
                            withContext(Dispatchers.IO) {
                                db.tracks().markPlayed(id, System.currentTimeMillis())
                                db.history().insert(
                                    PlayHistoryEntity(
                                        type = "MUSIC",
                                        trackId = id,
                                        title = item?.mediaMetadata?.title?.toString() ?: "Unbekannt"
                                    )
                                )
                            }
                        }

                        // v0.45: successor is prepared immediately rather than only
                        // a few seconds before the fade. SAF/SD-card preparation can
                        // occasionally take longer than expected.
                        if (configuredCrossfadeMs > 0 && pendingCrossfadeTrack == null) {
                            prepareCrossfadeSuccessor()
                        }
                    }
                    persistState()
                }
                if (isPlaying) logSamsungLiveNotificationDiagnostics()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                scope.launch {
                    persistState()
                    if (playbackState == Player.STATE_ENDED && !crossfadeInProgress) {
                        abortCrossfade()
                        playNextInternal()
                    }
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                startedCurrentTrack = false
                currentTrackId = mediaItem?.mediaId
                    ?.takeIf { it.startsWith("track:") }
                    ?.removePrefix("track:")
                    ?.toLongOrNull()
                scope.launch { persistState() }
            }
        })

                setMediaNotificationProvider(
            BubatzMediaNotificationProvider(
                context = this,
                onMetadataSeen = { metadata ->
                    diagnostics.save(
                        "v0.72: Notification-Metadaten",
                        extra = "title=${metadata.title}\\nartist=${metadata.artist}\\nalbum=${metadata.albumTitle}"
                    )
                }
            )
        )

session = MediaSession.Builder(this, player)
            .setCallback(sessionCallback)
            .setMediaButtonPreferences(mediaButtonPreferences())
            .build()

        // Critical for MediaSessionService's own notification/foreground handling.
        // Our Activity drives playback via explicit service intents and therefore no
        // MediaController necessarily connects first. Register the session ourselves.
        addSession(session)
        logSamsungLiveNotificationDiagnostics()

        restoreJob = scope.launch {
            restorePersistedPlayback()
        }

        positionPersistJob = scope.launch {
            while (true) {
                delay(2_000L)
                if (player.currentMediaItem != null) {
                    persistState()
                }
            }
        }

        settingsJob = scope.launch {
            settings.crossfadeMs.collectLatest { value ->
                configuredCrossfadeMs = value.coerceIn(0, 15_000)
            }
        }

        crossfadeMonitorJob = scope.launch {
            while (true) {
                delay(250L)
                monitorAutomaticCrossfade()
            }
        }

        diagnostics.save("v0.45 Service erstellt – sicherer Musik→Musik-Crossfade aktiv")
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession = session

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // MediaSessionService marks this method @CallSuper. Calling it here allows
        // Media3 to process its own service/media-notification lifecycle correctly.
        super.onStartCommand(intent, flags, startId)

        when (intent?.action) {
            ACTION_AUTO_PLAY -> {
                scope.launch {
                    restoreJob?.join()
                    if (player.currentMediaItem == null) {
                        playNextInternal()
                    } else {
                        player.play()
                    }
                }
                return START_STICKY
            }

            ACTION_PLAY_PAUSE -> {
                scope.launch {
                    restoreJob?.join()
                    if (player.currentMediaItem == null) {
                        playNextInternal()
                    } else if (player.isPlaying) {
                        abortCrossfade()
                        player.pause()
                    } else {
                        player.play()
                    }
                }
                return START_STICKY
            }

            ACTION_NEXT -> {
                scope.launch {
                    restoreJob?.join()
                    playNextInternal()
                }
                return START_STICKY
            }

            ACTION_PREVIOUS -> {
                scope.launch {
                    restoreJob?.join()
                    playPreviousInternal()
                }
                return START_STICKY
            }

            ACTION_SEEK -> {
                scope.launch {
                    restoreJob?.join()
                    val requested = intent.getLongExtra(EXTRA_SEEK_POSITION_MS, -1L)
                    if (requested >= 0L && player.currentMediaItem != null) {
                        abortCrossfade()
                        val duration = player.duration.takeIf { it > 0L }
                        val target = if (duration != null) {
                            requested.coerceIn(0L, duration)
                        } else {
                            requested.coerceAtLeast(0L)
                        }
                        player.seekTo(target)
                        persistState()
                        diagnostics.save(
                            "v0.45: Seek",
                            extra = "positionMs=$target"
                        )
                    }
                }
                return START_STICKY
            }
        }

        return START_STICKY
    }

    private suspend fun monitorAutomaticCrossfade() {
        if (configuredCrossfadeMs <= 0) return
        if (crossfadeInProgress) return
        if (!player.isPlaying) return
        if (player.currentMediaItem == null) return

        val duration = player.duration
        val position = player.currentPosition
        if (duration <= 0L || position < 0L) return

        val remaining = duration - position
        val fadeMs = configuredCrossfadeMs.toLong()
        if (remaining <= 0L) return

        // Retry preparation if the early preload was not available yet.
        if (pendingCrossfadeTrack == null && remaining <= 20_000L) {
            prepareCrossfadeSuccessor()
        }

        if (
            pendingCrossfadeItem != null &&
            remaining <= fadeMs &&
            standbyPlayer.playbackState == Player.STATE_READY
        ) {
            diagnostics.save(
                "v0.45: Fade-Schwelle erreicht",
                extra = "remainingMs=$remaining\nfadeMs=$fadeMs\nstandbyState=${standbyPlayer.playbackState}"
            )
            startAutomaticCrossfade()
        }
    }

    private suspend fun prepareCrossfadeSuccessor() {
        if (pendingCrossfadeTrack != null || crossfadeInProgress) return

        try {
            val next = withContext(Dispatchers.IO) {
                shuffle.nextTrack(currentTrackId)
            } ?: return

            val item = mediaItemForTrack(next)

            standbyPlayer.stop()
            standbyPlayer.clearMediaItems()
            standbyPlayer.volume = 0f
            standbyPlayer.setMediaItem(item)
            standbyPlayer.prepare()
            standbyPlayer.playWhenReady = false

            pendingCrossfadeTrack = next
            pendingCrossfadeItem = item

            diagnostics.save(
                "v0.45: Crossfade-Nachfolger vorbereitet",
                extra = "id=${next.id}\ntitel=${next.title}"
            )
        } catch (t: Throwable) {
            diagnostics.save("v0.45 EXCEPTION beim Crossfade-Preload", t)
            abortCrossfade()
        }
    }

    private fun startAutomaticCrossfade() {
        if (crossfadeInProgress) return

        val nextTrack = pendingCrossfadeTrack ?: return
        val nextItem = pendingCrossfadeItem ?: return
        val oldTrackId = currentTrackId
        val fadeMs = configuredCrossfadeMs.coerceAtLeast(1).toLong()

        crossfadeInProgress = true
        crossfadeJob?.cancel()
        crossfadeJob = scope.launch {
            try {
                standbyPlayer.volume = 0f
                standbyPlayer.play()

                diagnostics.save(
                    "v0.45: Crossfade gestartet",
                    extra = "dauerMs=$fadeMs\nvon=$oldTrackId\nzu=${nextTrack.id}"
                )

                val startedAt = android.os.SystemClock.elapsedRealtime()

                while (true) {
                    val elapsed =
                        android.os.SystemClock.elapsedRealtime() - startedAt
                    val progress =
                        (elapsed.toFloat() / fadeMs.toFloat()).coerceIn(0f, 1f)
                    val gains = FadeEnvelope.gains(progress)

                    player.volume = gains.outgoing
                    standbyPlayer.volume = gains.incoming

                    if (progress >= 1f) break
                    delay(50L)
                }

                // The MediaSession remains permanently attached to the known-good
                // primary ExoPlayer. Instead of swapping session players (the old
                // crash path), copy the already-playing successor back to primary
                // at the position reached during the fade.
                // Keep standby playing while the session-bound primary player
                // loads the same successor muted. v0.45 paused standby first,
                // creating the audible gap during prepare().
                val firstHandoffPosition =
                    standbyPlayer.currentPosition.coerceAtLeast(0L)

                oldTrackId?.let { oldId ->
                    if (oldId != nextTrack.id) backStack.addLast(oldId)
                }
                forwardStack.clear()

                currentTrackId = nextTrack.id
                startedCurrentTrack = false

                player.volume = 0f
                player.setMediaItem(nextItem, firstHandoffPosition)
                player.prepare()

                val readyDeadline =
                    android.os.SystemClock.elapsedRealtime() + 3_000L

                while (
                    player.playbackState != Player.STATE_READY &&
                    android.os.SystemClock.elapsedRealtime() < readyDeadline
                ) {
                    delay(20L)
                }

                if (player.playbackState != Player.STATE_READY) {
                    throw IllegalStateException(
                        "Hauptplayer wurde beim Crossfade-Handoff nicht rechtzeitig READY"
                    )
                }

                // Standby has continued meanwhile, so align again immediately
                // before the primary player starts.
                val alignedPosition =
                    standbyPlayer.currentPosition.coerceAtLeast(0L)
                player.seekTo(alignedPosition)
                player.play()

                // v0.57: keep standby at FULL volume until the primary player is
                // actually rendering. v0.57 started fading standby immediately
                // after play(), which can be a few audio-buffer milliseconds before
                // real output begins and creates the tiny audible dip.
                standbyPlayer.volume = 1f
                player.volume = 0f

                val audibleDeadline =
                    android.os.SystemClock.elapsedRealtime() + 1_500L
                var primaryStarted = false
                var lastPosition = player.currentPosition

                while (android.os.SystemClock.elapsedRealtime() < audibleDeadline) {
                    delay(20L)
                    val nowPosition = player.currentPosition
                    if (player.isPlaying && nowPosition > lastPosition) {
                        primaryStarted = true
                        break
                    }
                    lastPosition = nowPosition
                }

                if (!primaryStarted) {
                    throw IllegalStateException(
                        "Hauptplayer hat beim Crossfade-Handoff keine laufende Audioausgabe bestätigt"
                    )
                }

                // Give the audio sink two tiny buffer cycles while standby is still
                // fully audible, then perform the internal transfer.
                delay(60L)

                val handoffMs = 220L
                val handoffStarted =
                    android.os.SystemClock.elapsedRealtime()

                while (true) {
                    val elapsed =
                        android.os.SystemClock.elapsedRealtime() - handoffStarted
                    val p =
                        (elapsed.toFloat() / handoffMs.toFloat()).coerceIn(0f, 1f)

                    standbyPlayer.volume = 1f - p
                    player.volume = p

                    if (p >= 1f) break
                    delay(15L)
                }

                player.volume = 1f
                standbyPlayer.pause()
                standbyPlayer.stop()
                standbyPlayer.clearMediaItems()
                standbyPlayer.volume = 0f

                diagnostics.save(
                    "v0.45: Crossfade + nahtloser Handoff abgeschlossen",
                    extra = "titel=${nextTrack.title}\nstartHandoffMs=$firstHandoffPosition\nalignedMs=$alignedPosition"
                )

                pendingCrossfadeTrack = null
                pendingCrossfadeItem = null
                crossfadeInProgress = false

                delay(500L)
                if (configuredCrossfadeMs > 0) {
                    prepareCrossfadeSuccessor()
                }
            } catch (t: Throwable) {
                diagnostics.save("v0.45 EXCEPTION im Crossfade", t)
                abortCrossfade()
            }
        }
    }

    private fun abortCrossfade() {
        crossfadeJob?.cancel()
        crossfadeJob = null
        crossfadeInProgress = false
        pendingCrossfadeTrack = null
        pendingCrossfadeItem = null

        if (::player.isInitialized) {
            player.volume = 1f
        }
        if (::standbyPlayer.isInitialized) {
            runCatching { standbyPlayer.pause() }
            runCatching { standbyPlayer.stop() }
            runCatching { standbyPlayer.clearMediaItems() }
            standbyPlayer.volume = 0f
        }
    }

    private fun logSamsungLiveNotificationDiagnostics() {
        runCatching {
            val nm = getSystemService(NotificationManager::class.java)

            val canPostPromoted = runCatching {
                val method = NotificationManager::class.java
                    .getMethod("canPostPromotedNotifications")
                method.invoke(nm) as? Boolean
            }.getOrNull()

            val notificationClass = android.app.Notification::class.java
            val builderClass = android.app.Notification.Builder::class.java

            val hasPromotableMethodPresent = notificationClass.methods.any {
                it.name == "hasPromotableCharacteristics" && it.parameterCount == 0
            }

            val requestPromotedMethodPresent = builderClass.methods.any {
                it.name == "setRequestPromotedOngoing" && it.parameterTypes.size == 1
            }

            val promotedFlagValue = runCatching {
                notificationClass.getField("FLAG_PROMOTED_ONGOING").getInt(null)
            }.getOrNull()

            val active = if (Build.VERSION.SDK_INT >= 23) {
                nm?.activeNotifications?.joinToString(separator = "\n") { sbn ->
                    val n = sbn.notification

                    val promotedFlagSet = promotedFlagValue?.let { flag ->
                        (n.flags and flag) != 0
                    }

                    val promotable = runCatching {
                        val method = notificationClass
                            .getMethod("hasPromotableCharacteristics")
                        method.invoke(n) as? Boolean
                    }.getOrNull()

                    buildString {
                        append("id=").append(sbn.id)
                        append(",ongoing=").append(
                            (n.flags and android.app.Notification.FLAG_ONGOING_EVENT) != 0
                        )
                        append(",flags=0x").append(n.flags.toString(16))
                        append(",noClear=").append(
                            (n.flags and android.app.Notification.FLAG_NO_CLEAR) != 0
                        )
                        append(",onlyAlertOnce=").append(
                            (n.flags and android.app.Notification.FLAG_ONLY_ALERT_ONCE) != 0
                        )
                        append(",foregroundService=").append(
                            (n.flags and android.app.Notification.FLAG_FOREGROUND_SERVICE) != 0
                        )
                        append(",promotedFlag=").append(promotedFlagSet)
                        append(",promotable=").append(promotable)
                        append(",category=").append(n.category)
                        append(",group=").append(n.group)
                        append(",channel=").append(
                            if (Build.VERSION.SDK_INT >= 26) n.channelId else "n/a"
                        )
                        append(",style=").append(n.extras?.getString("android.template"))
                        append(",title=").append(n.extras?.getCharSequence("android.title"))
                        append(",text=").append(n.extras?.getCharSequence("android.text"))
                        append(",mediaSession=").append(
                            n.extras?.containsKey("android.mediaSession")
                        )
                    }
                }
            } else {
                "activeNotifications unsupported"
            }

            val channelInfo = if (Build.VERSION.SDK_INT >= 26) {
                nm?.notificationChannels?.joinToString(separator = "\n") { ch ->
                    "channel=${ch.id},name=${ch.name},importance=${ch.importance},badge=${ch.canShowBadge()},sound=${ch.sound}"
                }
            } else {
                "channels unsupported"
            }

            val liveReport = buildString {
                    append("v0.72: Samsung-/Android-16-Live-Diagnose").append('\n')
                    append("sdk=").append(Build.VERSION.SDK_INT).append('\n')
                    append("manufacturer=").append(Build.MANUFACTURER).append('\n')
                    append("model=").append(Build.MODEL).append('\n')
                    append("notificationsEnabled=").append(nm?.areNotificationsEnabled()).append('\n')
                    append("sessionActive=").append(::session.isInitialized && session.player.currentMediaItem != null).append('\n')
                    append("playerIsPlaying=").append(::player.isInitialized && player.isPlaying).append('\n')
                    append("playerState=").append(if (::player.isInitialized) player.playbackState else -1).append('\n')
                    append("mediaId=").append(if (::player.isInitialized) player.currentMediaItem?.mediaId else null).append('\n')

                    val sessionTokenText = runCatching {
                        if (::session.isInitialized) {
                            val token = session.token
                            "package=${token.packageName},uid=${token.uid},type=${token.type},serviceName=${token.serviceName}"
                        } else {
                            "session-not-initialized"
                        }
                    }.getOrElse { "error:${it::class.java.simpleName}:${it.message}" }

                    val availableCommandsText = runCatching {
                        if (::session.isInitialized) {
                            session.player.availableCommands.toString()
                        } else "session-not-initialized"
                    }.getOrElse { "error:${it::class.java.simpleName}:${it.message}" }

                    val serviceInfoText = runCatching {
                        val component = android.content.ComponentName(this@PlaybackService, PlaybackService::class.java)
                        val info = if (Build.VERSION.SDK_INT >= 33) {
                            packageManager.getServiceInfo(
                                component,
                                android.content.pm.PackageManager.ComponentInfoFlags.of(
                                    android.content.pm.PackageManager.GET_META_DATA.toLong()
                                )
                            )
                        } else {
                            @Suppress("DEPRECATION")
                            packageManager.getServiceInfo(component, android.content.pm.PackageManager.GET_META_DATA)
                        }
                        buildString {
                            append("name=").append(info.name)
                            append(",permission=").append(info.permission)
                            if (Build.VERSION.SDK_INT >= 29) {
                                append(",foregroundServiceType=").append(info.foregroundServiceType)
                            }
                            append(",exported=").append(info.exported)
                            append(",enabled=").append(info.enabled)
                        }
                    }.getOrElse { "error:${it::class.java.simpleName}:${it.message}" }

                    append("sessionToken=").append(sessionTokenText).append('\n')
                    append("availableCommands=").append(availableCommandsText).append('\n')
                    append("playbackSuppressionReason=").append(
                        if (::player.isInitialized) player.playbackSuppressionReason else -1
                    ).append('\n')
                    append("repeatMode=").append(if (::player.isInitialized) player.repeatMode else -1).append('\n')
                    append("shuffleModeEnabled=").append(
                        if (::player.isInitialized) player.shuffleModeEnabled else false
                    ).append('\n')
                    append("serviceInfo=").append(serviceInfoText).append('\n')
                    append("canPostPromotedNotifications=").append(canPostPromoted).append('\n')
                    append("hasPromotableCharacteristicsApi=").append(hasPromotableMethodPresent).append('\n')
                    append("setRequestPromotedOngoingApi=").append(requestPromotedMethodPresent).append('\n')
                    append("FLAG_PROMOTED_ONGOING=").append(promotedFlagValue).append('\n')
                    append("activeNotifications:\n").append(active).append('\n')
                    append("channels:\n").append(channelInfo)
                }
            diagnostics.saveLiveDiagnostic(liveReport)
        }.onFailure {
            diagnostics.saveLiveDiagnostic(
                "v0.72 LIVE-DIAGNOSE-FEHLER\n${it::class.java.simpleName}: ${it.message}"
            )
        }
    }

    private suspend fun restorePersistedPlayback() {
        try {
            val state = withContext(Dispatchers.IO) { db.state().get() }
            val trackId = state?.currentTrackId ?: return
            val track = withContext(Dispatchers.IO) { db.tracks().byId(trackId) }

            if (track == null) {
                diagnostics.save(
                    "v0.45: gespeicherter Titel nicht mehr vorhanden",
                    extra = "trackId=$trackId"
                )
                return
            }

            val item = mediaItemForTrack(track)
            val savedPosition = state.currentPositionMs
                .coerceAtLeast(0L)
                .let { pos ->
                    val knownDuration = track.durationMs.takeIf { it > 0L }
                        ?: state.currentDurationMs.takeIf { it > 0L }
                    if (knownDuration != null && pos >= knownDuration) 0L else pos
                }

            currentTrackId = track.id
            startedCurrentTrack = false

            player.setMediaItem(item, savedPosition)
            player.prepare()
            // Deliberately do not autoplay on ordinary app/service startup.
            player.playWhenReady = false

            diagnostics.save(
                "v0.45: letzter Titel wiederhergestellt",
                extra = "id=${track.id}\ntitel=${item.mediaMetadata.title}\npositionMs=$savedPosition"
            )
        } catch (t: Throwable) {
            diagnostics.save("v0.45 EXCEPTION bei Wiederherstellung", t)
        }
    }

    private suspend fun playNextInternal() {
        try {
            abortCrossfade()
            val oldCurrent = currentTrackId
            val usingForwardHistory = forwardStack.isNotEmpty()

            val next = if (usingForwardHistory) {
                val forwardId = forwardStack.removeLast()
                withContext(Dispatchers.IO) { db.tracks().byId(forwardId) }
            } else {
                withContext(Dispatchers.IO) {
                    shuffle.nextTrack(currentTrackId)
                }
            }

            if (next == null) {
                diagnostics.save("v0.45 FEHLER: kein nächster Titel gefunden")
                return
            }

            oldCurrent?.let { current ->
                if (current != next.id) {
                    backStack.addLast(current)
                }
            }

            // A genuinely new random branch discards old forward history.
            if (!usingForwardHistory) {
                forwardStack.clear()
            }

            val item = mediaItemForTrack(next)
            currentTrackId = next.id
            startedCurrentTrack = false

            diagnostics.save(
                "v0.45: nächster Titel gestartet",
                extra = "id=${next.id}\ntitel=${next.title}\nforwardHistory=$usingForwardHistory\nback=${backStack.size}\nforward=${forwardStack.size}"
            )

            player.setMediaItem(item)
            player.prepare()
            player.play()

            scope.launch {
                delay(500L)
                if (configuredCrossfadeMs > 0 && pendingCrossfadeTrack == null) {
                    prepareCrossfadeSuccessor()
                }
            }

        } catch (t: Throwable) {
            diagnostics.save("v0.45 EXCEPTION bei Next", t)
        }
    }

    private suspend fun playPreviousInternal() {
        try {
            abortCrossfade()
            // Standard behavior: after 5 seconds, Previous restarts current track.
            if (player.currentMediaItem != null && player.currentPosition > 5_000L) {
                player.seekTo(0L)
                if (!player.isPlaying) player.play()
                diagnostics.save("v0.45: Previous → aktueller Titel neu gestartet")
                return
            }

            val currentId = currentTrackId

            if (backStack.isEmpty()) {
                // Important: do NOT fall back into persistent DB history here.
                // Otherwise A → B → Previous(A) → Previous would jump back to B
                // and create a backwards loop.
                if (player.currentMediaItem != null) {
                    player.seekTo(0L)
                    if (!player.isPlaying) player.play()
                }
                diagnostics.save("v0.45: Previous → Anfang der aktuellen Navigationshistorie erreicht")
                return
            }

            val previousId = backStack.removeLast()

            val previous = withContext(Dispatchers.IO) {
                db.tracks().byId(previousId)
            }

            if (previous == null) {
                diagnostics.save("v0.45: Previous → History-Titel nicht mehr in DB")
                return
            }

            // Remember where we came from so Next returns there.
            currentId?.let { current ->
                if (current != previous.id) {
                    forwardStack.addLast(current)
                }
            }

            val item = mediaItemForTrack(previous)
            currentTrackId = previous.id
            startedCurrentTrack = false

            player.setMediaItem(item)
            player.prepare()
            player.play()

            scope.launch {
                delay(500L)
                if (configuredCrossfadeMs > 0 && pendingCrossfadeTrack == null) {
                    prepareCrossfadeSuccessor()
                }
            }

            diagnostics.save(
                "v0.45: vorheriger Titel gestartet",
                extra = "id=${previous.id}\ntitel=${previous.title}\nback=${backStack.size}\nforward=${forwardStack.size}"
            )
        } catch (t: Throwable) {
            diagnostics.save("v0.45 EXCEPTION bei Previous", t)
        }
    }

    private data class ResolvedTrack(
        val title: String,
        val artist: String?,
        val album: String?,
        val durationMs: Long
    )

    private suspend fun mediaItemForTrack(track: fm.bubatz.player.data.TrackEntity): MediaItem {
        val resolved = if (
            !track.artist.isNullOrBlank() &&
            !track.album.isNullOrBlank() &&
            track.durationMs > 0L
        ) {
            ResolvedTrack(track.title, track.artist, track.album, track.durationMs)
        } else {
            resolveTrackMetadata(track)
        }

        return MediaItem.Builder()
            .setUri(Uri.parse(track.uri))
            .setMediaId("track:${track.id}")
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(resolved.title)
                    .setDisplayTitle(
                        listOfNotNull(
                            resolved.title.takeIf { it.isNotBlank() },
                            resolved.artist?.takeIf { it.isNotBlank() }
                        ).joinToString(" – ")
                    )
                    .setArtist(resolved.artist)
                    .setAlbumTitle(resolved.album)
                    .build()
            )
            .build()
    }

    private suspend fun resolveTrackMetadata(
        track: fm.bubatz.player.data.TrackEntity
    ): ResolvedTrack = withContext(Dispatchers.IO) {
        val fallback = ResolvedTrack(
            title = track.title,
            artist = track.artist,
            album = track.album,
            durationMs = track.durationMs
        )

        val resolved = runCatching {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(this@PlaybackService, Uri.parse(track.uri))

                val title = retriever
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                    ?.takeIf { it.isNotBlank() }
                    ?: track.title

                val artist = retriever
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                    ?.takeIf { it.isNotBlank() }
                    ?: track.artist

                val album = retriever
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
                    ?.takeIf { it.isNotBlank() }
                    ?: track.album

                val duration = retriever
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull()
                    ?.takeIf { it > 0L }
                    ?: track.durationMs

                ResolvedTrack(title, artist, album, duration)
            } finally {
                retriever.release()
            }
        }.getOrElse {
            diagnostics.save(
                "v0.45: Metadaten-Fallback",
                throwable = it,
                extra = "trackId=${track.id}\nuri=${track.uri}"
            )
            fallback
        }

        if (
            resolved.title != track.title ||
            resolved.artist != track.artist ||
            resolved.album != track.album ||
            resolved.durationMs != track.durationMs
        ) {
            runCatching {
                db.tracks().updateMetadata(
                    id = track.id,
                    title = resolved.title,
                    artist = resolved.artist,
                    album = resolved.album,
                    durationMs = resolved.durationMs
                )
            }
        }

        resolved
    }

    private suspend fun persistState() {
        val item = player.currentMediaItem
        val state = PlaybackStateEntity(
            currentTrackId = currentTrackId,
            currentMediaId = item?.mediaId,
            upcomingMediaId = null,
            currentPositionMs = player.currentPosition.coerceAtLeast(0L),
            currentDurationMs = if (player.duration > 0L) player.duration else 0L,
            currentTitle = item?.mediaMetadata?.title?.toString(),
            currentArtist = item?.mediaMetadata?.artist?.toString(),
            currentAlbum = item?.mediaMetadata?.albumTitle?.toString(),
            isPlaying = player.isPlaying,
            nextRadioAtMs = 0L
        )
        withContext(Dispatchers.IO) {
            db.state().put(state)
        }
    }

    override fun onDestroy() {
        if (::player.isInitialized && player.currentMediaItem != null) {
            scope.launch { persistState() }
        }
        positionPersistJob?.cancel()
        restoreJob?.cancel()
        crossfadeMonitorJob?.cancel()
        crossfadeJob?.cancel()
        settingsJob?.cancel()
        runCatching { session.release() }
        runCatching { player.release() }
        runCatching { standbyPlayer.release() }
        scope.cancel()
        super.onDestroy()
    }
}
