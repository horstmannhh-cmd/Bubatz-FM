
package fm.bubatz.player

import android.Manifest
import androidx.compose.ui.graphics.asImageBitmap
import android.media.MediaMetadataRetriever
import android.graphics.BitmapFactory
import android.content.Intent
import android.provider.Settings
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import fm.bubatz.player.bluetooth.BluetoothDeviceRepository
import fm.bubatz.player.data.RadioClipEntity
import fm.bubatz.player.data.TrackEntity
import fm.bubatz.player.library.LibraryScanner
import fm.bubatz.player.library.ScanDiagnostics
import fm.bubatz.player.playback.PlaybackService
import fm.bubatz.player.scrobble.LastFmAuthCoordinator
import fm.bubatz.player.scrobble.LastFmConfig
import fm.bubatz.player.scrobble.LastFmSessionStore
import fm.bubatz.player.settings.AppSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val BubatzDark = Color(0xFF0F1A13)
private val BubatzGreen = Color(0xFF1F2E21)
private val BubatzMid = Color(0xFF375A36)
private val BubatzSage = Color(0xFF6A8A6A)
private val BubatzCream = Color(0xFFF2E9D2)
private val BubatzGold = Color(0xFFDCC9A1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 50)

        if (android.os.Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 51)

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = BubatzCream,
                    secondary = BubatzSage,
                    background = BubatzDark,
                    surface = BubatzGreen,
                    onPrimary = BubatzDark,
                    onBackground = BubatzCream,
                    onSurface = BubatzCream
                )
            ) {
                BubatzApp()
            }
        }
    }

    @Composable
    private fun BubatzApp() {
        var tab by rememberSaveable { mutableIntStateOf(0) }

        Scaffold(
            containerColor = BubatzDark,
            bottomBar = {
                NavigationBar(containerColor = BubatzGreen) {
                    NavigationBarItem(
                        selected = tab == 0,
                        onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.Radio, null) },
                        label = { Text("Player") }
                    )
                    NavigationBarItem(
                        selected = tab == 1,
                        onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.Settings, null) },
                        label = { Text("Einstellungen") }
                    )
                }
            }
        ) { padding ->
            Crossfade(targetState = tab, label = "main-tabs") { selected ->
                if (selected == 0) NowPlayingScreen(Modifier.padding(padding))
                else SettingsScreen(Modifier.padding(padding))
            }
        }
    }

    @Composable
    private fun NowPlayingScreen(modifier: Modifier = Modifier) {
        val db = (application as BubatzApplication).database
        val state by db.state().observe().collectAsState(initial = null)
        val scope = rememberCoroutineScope()

        var track by remember { mutableStateOf<TrackEntity?>(null) }
        var clip by remember { mutableStateOf<RadioClipEntity?>(null) }

        LaunchedEffect(state?.currentMediaId) {
            val mediaId = state?.currentMediaId

            if (mediaId?.startsWith("track:") == true) {
                // Keep the previous track (and therefore its cover) visible until
                // the database lookup for the new track has completed.
                val id = mediaId.removePrefix("track:").toLongOrNull()
                val newTrack = id?.let {
                    withContext(Dispatchers.IO) { db.tracks().byId(it) }
                }
                if (newTrack != null) {
                    track = newTrack
                    clip = null
                }
            } else if (mediaId?.startsWith("radio:") == true) {
                val id = mediaId.removePrefix("radio:").toLongOrNull()
                val newClip = id?.let {
                    withContext(Dispatchers.IO) { db.clips().byId(it) }
                }
                if (newClip != null) {
                    clip = newClip
                    track = null
                }
            } else if (mediaId == null) {
                track = null
                clip = null
            }
        }

        var visualPosition by remember(state?.currentPositionMs) {
            mutableLongStateOf(state?.currentPositionMs ?: 0L)
        }
        var isSeeking by remember { mutableStateOf(false) }
        var seekPreviewPosition by remember { mutableLongStateOf(0L) }

        LaunchedEffect(state?.isPlaying, state?.currentPositionMs, state?.currentMediaId, isSeeking) {
            if (!isSeeking) {
                visualPosition = state?.currentPositionMs ?: 0L
                while (state?.isPlaying == true && !isSeeking) {
                    delay(500)
                    visualPosition += 500
                }
            }
        }

        val isRadio = clip != null
        val title = clip?.name ?: track?.title ?: "Bubatz FM"
        val artist = if (isRadio) "RADIOEINSPIELER" else track?.artist ?: "Bereit für Musik"
        val album = if (isRadio) "ON AIR" else track?.album.orEmpty()
        val duration = (state?.currentDurationMs ?: 0L).coerceAtLeast(track?.durationMs ?: clip?.durationMs ?: 0L)

        Column(
            modifier
                .fillMaxSize()
                .background(BubatzDark)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.bubatz_logo_horizontal),
                contentDescription = "Bubatz FM",
                modifier = Modifier.fillMaxWidth().height(72.dp),
                contentScale = ContentScale.Fit
            )

            Spacer(Modifier.height(18.dp))

            Surface(
                modifier = Modifier.fillMaxWidth().aspectRatio(1f),
                shape = RoundedCornerShape(26.dp),
                color = BubatzGreen,
                tonalElevation = 4.dp
            ) {
                if (isRadio) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Image(
                            painterResource(R.drawable.bubatz_logo_main_dark),
                            "Bubatz FM Einspieler",
                            Modifier.fillMaxSize().padding(28.dp),
                            contentScale = ContentScale.Fit
                        )
                    }
                } else {
                    AlbumArtwork(
                        uri = track?.uri,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            if (isRadio) {
                AssistChip(
                    onClick = {},
                    label = { Text("● ON AIR · BUBATZ FM") },
                    colors = AssistChipDefaults.assistChipColors(
                        labelColor = BubatzCream,
                        containerColor = BubatzMid
                    )
                )
                Spacer(Modifier.height(10.dp))
            }

            Text(
                text = title,
                color = BubatzCream,
                fontSize = 25.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 2
            )
            Spacer(Modifier.height(5.dp))
            Text(
                text = artist,
                color = if (isRadio) BubatzGold else BubatzSage,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
            if (album.isNotBlank()) {
                Text(
                    text = album,
                    color = BubatzSage.copy(alpha = 0.85f),
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
            }

            Spacer(Modifier.height(20.dp))

            val shownPosition = if (isSeeking) seekPreviewPosition else visualPosition
            val sliderValue = if (duration > 0L) {
                (shownPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
            } else 0f

            CompactSeekBar(
                value = sliderValue,
                enabled = duration > 0L && !isRadio,
                onValueChange = { value ->
                    if (duration > 0L) {
                        isSeeking = true
                        seekPreviewPosition = (duration * value.coerceIn(0f, 1f)).toLong()
                    }
                },
                onValueChangeFinished = {
                    if (isSeeking && duration > 0L) {
                        val target = seekPreviewPosition.coerceIn(0L, duration)
                        visualPosition = target
                        sendSeekAction(target)
                    }
                    isSeeking = false
                }
            )
            Spacer(Modifier.height(6.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(shownPosition), color = BubatzSage, fontSize = 11.sp)
                Text(formatTime(duration), color = BubatzSage, fontSize = 11.sp)
            }

            Spacer(Modifier.height(14.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { sendPlaybackAction(PlaybackService.ACTION_PREVIOUS) }) {
                    Icon(Icons.Default.SkipPrevious, "Vorheriger Titel", tint = BubatzCream, modifier = Modifier.size(34.dp))
                }

                FilledIconButton(
                    onClick = { sendPlaybackAction(PlaybackService.ACTION_PLAY_PAUSE) },
                    modifier = Modifier.size(72.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = BubatzCream,
                        contentColor = BubatzDark
                    )
                ) {
                    Icon(
                        if (state?.isPlaying == true) Icons.Default.Pause else Icons.Default.PlayArrow,
                        if (state?.isPlaying == true) "Pause" else "Play",
                        modifier = Modifier.size(38.dp)
                    )
                }

                IconButton(onClick = { sendPlaybackAction(PlaybackService.ACTION_NEXT) }) {
                    Icon(Icons.Default.SkipNext, "Nächster Titel", tint = BubatzCream, modifier = Modifier.size(34.dp))
                }
            }

            Spacer(Modifier.height(10.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Shuffle, null, tint = BubatzSage, modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(6.dp))
                Text("RANDOM", color = BubatzSage, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(18.dp))
                Text("•", color = BubatzMid)
                Spacer(Modifier.width(18.dp))
                Text("BUBATZ.FM", color = BubatzGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(12.dp))
            Text(
                "Bluetooth- & Lockscreen-Steuerung aktiv",
                color = BubatzSage.copy(alpha = 0.75f),
                fontSize = 10.sp
            )

            Spacer(Modifier.height(24.dp))
        }
    }

    @Composable
    private fun AlbumArtwork(uri: String?, modifier: Modifier = Modifier) {
        // Keep the previous cover visible until the next embedded cover is ready.
        // This prevents the broccoli placeholder from flashing during normal transitions.
        var artworkBytes by remember { mutableStateOf<ByteArray?>(null) }

        LaunchedEffect(uri) {
            if (uri.isNullOrBlank()) {
                artworkBytes = null
                return@LaunchedEffect
            }

            val loadedArtwork = withContext(Dispatchers.IO) {
                runCatching {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(this@MainActivity, Uri.parse(uri))
                        retriever.embeddedPicture
                    } finally {
                        retriever.release()
                    }
                }.getOrNull()
            }

            artworkBytes = loadedArtwork
        }

        val bitmap = remember(artworkBytes) {
            artworkBytes?.let { bytes ->
                runCatching {
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
                }.getOrNull()
            }
        }

        Box(modifier.background(BubatzGreen), contentAlignment = Alignment.Center) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap,
                    contentDescription = "Albumcover",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Image(
                    painterResource(R.drawable.bubatz_app_icon_dark),
                    "Bubatz FM",
                    Modifier.fillMaxSize().padding(52.dp),
                    contentScale = ContentScale.Fit
                )
            }
        }
    }

    @Composable
    private fun CompactSeekBar(
        value: Float,
        enabled: Boolean,
        onValueChange: (Float) -> Unit,
        onValueChangeFinished: () -> Unit
    ) {
        val active = BubatzGold
        val inactive = BubatzMid
        val disabled = BubatzSage.copy(alpha = 0.45f)

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .height(24.dp)
                .then(
                    if (enabled) {
                        Modifier
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onTap = { offset ->
                                        val fraction = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                                        onValueChange(fraction)
                                        onValueChangeFinished()
                                    }
                                )
                            }
                            .pointerInput(Unit) {
                                detectHorizontalDragGestures(
                                    onDragStart = { offset ->
                                        val fraction = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                                        onValueChange(fraction)
                                    },
                                    onHorizontalDrag = { change, _ ->
                                        val fraction = (change.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                                        onValueChange(fraction)
                                        change.consume()
                                    },
                                    onDragEnd = onValueChangeFinished,
                                    onDragCancel = onValueChangeFinished
                                )
                            }
                    } else Modifier
                )
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val y = size.height / 2f
                val startX = 4.dp.toPx()
                val endX = size.width - 4.dp.toPx()
                val usable = (endX - startX).coerceAtLeast(0f)
                val thumbX = startX + usable * value.coerceIn(0f, 1f)
                val trackWidth = 4.dp.toPx()

                drawLine(
                    color = if (enabled) inactive else disabled,
                    start = Offset(startX, y),
                    end = Offset(endX, y),
                    strokeWidth = trackWidth,
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = if (enabled) active else disabled,
                    start = Offset(startX, y),
                    end = Offset(thumbX, y),
                    strokeWidth = trackWidth,
                    cap = StrokeCap.Round
                )
                drawCircle(
                    color = if (enabled) active else disabled,
                    radius = 6.dp.toPx(),
                    center = Offset(thumbX, y)
                )
            }
        }
    }

    @Composable
    private fun SettingsScreen(modifier: Modifier = Modifier) {
        val db = (application as BubatzApplication).database
        val scope = rememberCoroutineScope()
        val settings = remember { AppSettings(this) }

        val musicCount by db.tracks().observeCount().collectAsState(initial = 0)
        val clipCount by db.clips().observeCount().collectAsState(initial = 0)
        val autoBt by settings.autoBluetooth.collectAsState(initial = true)
        val autoBtAll by settings.autoBluetoothAllDevices.collectAsState(initial = true)
        val selectedBt by settings.autoBluetoothDeviceAddresses.collectAsState(initial = emptySet())
        val skipOnce by settings.autoBluetoothSkipOnce.collectAsState(initial = false)
        val crossfade by settings.crossfadeMs.collectAsState(initial = 6500)
        val radioEnabled by settings.radioEnabled.collectAsState(initial = true)

        val pairedDevices = remember { BluetoothDeviceRepository(this).pairedAudioDevices() }

        val lastFmStore = remember { LastFmSessionStore(this) }
        val lastFmAuth = remember { LastFmAuthCoordinator(this) }
        var lastFmUser by remember { mutableStateOf(lastFmStore.username) }
        var lastFmStatus by remember {
            mutableStateOf(if (lastFmUser != null) "Verbunden als $lastFmUser" else "Nicht verbunden")
        }

        var status by remember { mutableStateOf(ScanDiagnostics(this).read()) }

        val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            uri ?: return@rememberLauncherForActivityResult
            persist(uri)
            scope.launch {
                status = "Musik wird eingelesen …"
                val result = LibraryScanner(this@MainActivity).scanMusicDetailed(uri)
                var stored = 0
                result.tracks.chunked(1000).forEachIndexed { index, chunk ->
                    val inserted = db.tracks().insertAll(chunk)
                    stored += inserted.count { it != -1L }
                    status = "Bibliothek wird gespeichert … ${minOf((index + 1) * 1000, result.tracks.size)}/${result.tracks.size}"
                    ScanDiagnostics(this@MainActivity).save(status)
                }
                val s = result.stats
                status = buildString {
                    append("FERTIG / DB\n")
                    append("Ordner: ${s.directoriesVisited} · Dateien: ${s.filesVisited}\n")
                    append("Audio erkannt: ${s.audioRecognized}\n")
                    append("In Bibliothek neu: $stored\n")
                    append("Query-Fehler: ${s.queryErrors}")
                    result.error?.let { append("\nFehler: $it") }
                }
                ScanDiagnostics(this@MainActivity).save(status)
            }
        }

        val clipPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            uri ?: return@rememberLauncherForActivityResult
            persist(uri)
            scope.launch {
                status = "Einspieler werden eingelesen …"
                val items = LibraryScanner(this@MainActivity).scanRadio(uri)
                db.clips().insertAll(items)
                status = "${items.size} Einspieler geprüft"
            }
        }

        Column(
            modifier
                .fillMaxSize()
                .background(BubatzDark)
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            Image(
                painterResource(R.drawable.bubatz_logo_horizontal),
                "Bubatz FM",
                Modifier.fillMaxWidth().height(62.dp),
                contentScale = ContentScale.Fit
            )
            Spacer(Modifier.height(16.dp))

            SettingsCard("Bibliothek") {
                Text("$musicCount Musiktitel · $clipCount Einspieler", color = BubatzCream)
                Text(status, color = BubatzSage, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { musicPicker.launch(null) }) { Text("Musikordner") }
                    Button(onClick = { clipPicker.launch(null) }) { Text("Einspieler") }
                }
            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Wiedergabe-Diagnose") {
                var crashText by remember {
                    mutableStateOf(CrashDiagnostics(this@MainActivity).readLiveDiagnostic())
                }
                Text(
                    "v0.57 zeigt die Samsung-/Android-16-Live-Diagnose separat an, damit normale Wiedergabe-Logs sie nicht mehr überschreiben.",
                    color = BubatzCream,
                    fontSize = 11.sp
                )
                Spacer(Modifier.height(8.dp))
                Text(crashText, color = BubatzSage, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        crashText = CrashDiagnostics(this@MainActivity).readLiveDiagnostic()
                    }) {
                        Text("Aktualisieren")
                    }
                    OutlinedButton(onClick = {
                        CrashDiagnostics(this@MainActivity).clearLiveDiagnostic()
                        crashText = CrashDiagnostics(this@MainActivity).readLiveDiagnostic()
                    }) {
                        Text("Löschen")
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Omnia-Vergleichsdiagnose") {
                var comparisonText by remember {
                    mutableStateOf(CrashDiagnostics(this@MainActivity).readNotificationComparison())
                }
                val listenerEnabled = remember(comparisonText) {
                    val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
                    enabled.contains(packageName)
                }
                Text(
                    if (listenerEnabled) "Benachrichtigungszugriff: aktiv" else "Benachrichtigungszugriff: noch nicht aktiviert",
                    color = if (listenerEnabled) BubatzSage else BubatzCream, fontSize = 11.sp
                )
                Spacer(Modifier.height(6.dp))
                Text("Omnia und Bubatz FM können damit direkt anhand ihrer laufenden Media-Benachrichtigungen verglichen werden.", color = BubatzCream, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                Text(comparisonText, color = BubatzSage, fontSize = 10.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    }) { Text("Zugriff öffnen") }
                    OutlinedButton(onClick = {
                        comparisonText = CrashDiagnostics(this@MainActivity).readNotificationComparison()
                    }) { Text("Vergleich laden") }
                }
            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Android-Absturzdiagnose") {
                var systemCrashText by remember {
                    mutableStateOf(CrashDiagnostics(this@MainActivity).readSystemExitInfo())
                }
                Text(
                    systemCrashText,
                    color = BubatzSage,
                    fontSize = 10.sp
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = {
                    systemCrashText = CrashDiagnostics(this@MainActivity).readSystemExitInfo()
                }) {
                    Text("Systemdiagnose aktualisieren")
                }
            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Radioeinspieler") {
                SettingSwitch(
                    "Automatische Einspieler aktiv",
                    radioEnabled
                ) { enabled ->
                    scope.launch { settings.setRadioEnabled(enabled) }
                }
                Text(
                    "Bei aktivierter Funktion ungefähr alle 25–35 Minuten. Einspieler werden nie überblendet und nie gescrobbelt.",
                    color = BubatzSage,
                    fontSize = 12.sp
                )
            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Crossfade") {
                Text("${crossfade / 1000.0} Sekunden · nur Musik → Musik", color = BubatzSage, fontSize = 12.sp)
                Slider(
                    value = crossfade.toFloat(),
                    onValueChange = { value -> scope.launch { settings.setCrossfadeMs(value.toInt()) } },
                    valueRange = 0f..15000f,
                    steps = 14
                )
                Text("Einspieler werden niemals überblendet.", color = BubatzGold, fontSize = 12.sp)
            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Bluetooth Auto-Start") {
                SettingSwitch(
                    "Automatisch bei Bluetooth-Audio starten",
                    autoBt
                ) { scope.launch { settings.setAutoBluetooth(it) } }

                if (autoBt) {
                    SettingSwitch("Alle Bluetooth-Audiogeräte", autoBtAll) {
                        scope.launch { settings.setAutoBluetoothAllDevices(it) }
                    }

                    if (!autoBtAll) {
                        pairedDevices.forEach { device ->
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = device.address in selectedBt,
                                    onCheckedChange = { enabled ->
                                        scope.launch {
                                            settings.setAutoBluetoothDeviceEnabled(device.address, enabled)
                                        }
                                    }
                                )
                                Text(device.name, color = BubatzCream)
                            }
                        }
                    }

                    OutlinedButton(
                        onClick = { scope.launch { settings.suppressNextBluetoothAutoStart() } },
                        enabled = !skipOnce
                    ) {
                        Text(
                            if (skipOnce) "Nächster Auto-Start wird übersprungen"
                            else "Beim nächsten Verbinden still bleiben"
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Last.fm") {
                Text(lastFmStatus, color = BubatzSage, fontSize = 12.sp)

                if (!LastFmConfig.configured) {
                    Text(
                        "API-Key und Shared Secret müssen einmalig in LastFmConfig.kt eingetragen werden.",
                        color = BubatzCream,
                        fontSize = 12.sp
                    )
                } else if (lastFmUser == null) {
                    Button(onClick = {
                        scope.launch {
                            runCatching {
                                val url = lastFmAuth.beginAuthorization()
                                lastFmAuth.openAuthorization(url)
                                lastFmStatus = "Im Browser freigeben, danach hier bestätigen."
                            }.onFailure {
                                lastFmStatus = it.message ?: "Last.fm-Anmeldung fehlgeschlagen"
                            }
                        }
                    }) { Text("Last.fm verbinden") }

                    OutlinedButton(onClick = {
                        scope.launch {
                            runCatching {
                                val session = lastFmAuth.finishAuthorization()
                                lastFmUser = session.username
                                lastFmStatus = "Verbunden als ${session.username}"
                            }.onFailure {
                                lastFmStatus = it.message ?: "Freigabe noch nicht abgeschlossen"
                            }
                        }
                    }) { Text("Freigabe abgeschlossen") }
                } else {
                    OutlinedButton(onClick = {
                        lastFmAuth.disconnect()
                        lastFmUser = null
                        lastFmStatus = "Nicht verbunden"
                    }) { Text("Last.fm trennen") }
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                "Bubatz FM · Version 0.58 Cover-Handoff",
                color = BubatzSage,
                fontSize = 11.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(24.dp))
        }
    }

    @Composable
    private fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
        Card(
            colors = CardDefaults.cardColors(containerColor = BubatzGreen),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(18.dp).fillMaxWidth()) {
                Text(title, color = BubatzCream, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                Spacer(Modifier.height(8.dp))
                content()
            }
        }
    }

    @Composable
    private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = BubatzCream, modifier = Modifier.weight(1f), fontSize = 13.sp)
            Switch(checked = checked, onCheckedChange = onChange)
        }
    }

    private fun sendPlaybackAction(action: String) {
        val i = Intent(this, PlaybackService::class.java).setAction(action)
        // The Activity is in the foreground, so a normal service start is enough.
        // Starting as a foreground service before a 40k-library initialization
        // finishes can trigger Android's foreground-service timeout.
        startService(i)
    }

    private fun sendSeekAction(positionMs: Long) {
        val i = Intent(this, PlaybackService::class.java)
            .setAction(PlaybackService.ACTION_SEEK)
            .putExtra(PlaybackService.EXTRA_SEEK_POSITION_MS, positionMs)
        startService(i)
    }

    private fun persist(uri: Uri) {
        runCatching {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
    }

    private fun formatTime(ms: Long): String {
        if (ms <= 0) return "0:00"
        val total = ms / 1000
        val minutes = total / 60
        val seconds = total % 60
        return "$minutes:${seconds.toString().padStart(2, '0')}"
    }
}
