# v0.95 – Random-/History-Test

1. Nur Bubatz FM verwenden; Omnia muss für diesen Test nicht laufen.
2. Einen Titel A abspielen und zweimal „Weiter“ drücken, sodass A → B → C entsteht.
3. Einmal „Zurück“: Erwartet wird B.
4. Noch einmal „Zurück“: Erwartet wird A.
5. Einmal „Weiter“: Erwartet wird wieder exakt B, kein neu ausgewürfelter Titel.
6. Noch einmal „Weiter“: Erwartet wird wieder exakt C.
7. Erst beim nächsten „Weiter“ hinter C darf ein neuer Zufallstitel D gewählt werden.
8. Kurz prüfen, dass die in v0.93 gelöste Samsung-Laufschrift weiterhin erscheint.

# Bubatz FM v0.92 – Laufschrift-Test

1. v0.92 über die vorhandene Version installieren.
2. Omnia vollständig schließen bzw. dort keine Musik laufen lassen.
3. Nur in Bubatz FM einen Titel starten.
4. Bubatz im Vordergrund kurz spielen lassen und anschließend auf den Homescreen wechseln.
5. Oben links neben der Uhr prüfen, ob Samsungs kleine Titel-Laufschrift/der rote Medien-Chip nun den Bubatz-Titel zeigt.
6. Falls ja: einen Titel weiter springen und prüfen, ob sich der Text aktualisiert.
7. Falls nein: ein Screenshot der Statusleiste reicht.

Für diesen Test muss die Omnia-Bridge nicht geöffnet werden.

## v0.96 – persistente Shuffle-History
1. Nur Bubatz verwenden; Omnia aus lassen.
2. Titel A starten, zweimal Weiter: B, C.
3. Zweimal Zurück bis A.
4. Bubatz vollständig schließen und erneut öffnen.
5. Weiter muss B liefern; nochmal Weiter muss C liefern.
6. Erst hinter dem Ende der bekannten History darf ein neuer Zufallstitel gewählt werden.
7. Kontrollieren, dass die Samsung-Statusleisten-Laufschrift weiterhin erscheint.
