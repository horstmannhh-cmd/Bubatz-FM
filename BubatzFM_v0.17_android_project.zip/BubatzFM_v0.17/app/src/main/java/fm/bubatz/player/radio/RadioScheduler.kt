
package fm.bubatz.player.radio

import kotlin.random.Random

/**
 * Schedules a radio insert after a deliberately non-clockwork interval.
 * A due insert is consumed only when it actually starts.
 */
class RadioScheduler(
    private val minMinutes: Int = 25,
    private val maxMinutes: Int = 35
) {
    fun nextDeadline(nowMs: Long = System.currentTimeMillis()): Long {
        val minutes = Random.nextInt(minMinutes, maxMinutes + 1)
        return nowMs + minutes * 60_000L
    }

    fun isDue(deadlineMs: Long, nowMs: Long = System.currentTimeMillis()): Boolean =
        deadlineMs > 0L && nowMs >= deadlineMs
}
