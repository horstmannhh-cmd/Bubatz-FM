package fm.bubatz.player.library

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import fm.bubatz.player.data.RadioClipEntity
import fm.bubatz.player.data.TrackEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LibraryScanner(private val context: Context) {
    private val audioExt = setOf("mp3", "flac", "m4a", "aac", "ogg", "opus", "wav", "wma")

    suspend fun scanMusic(treeUri: Uri): List<TrackEntity> = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext emptyList()
        sequenceFiles(root).mapNotNull { file ->
            if (!isAudio(file)) return@mapNotNull null
            readTrack(file.uri, file.name ?: "Unbekannt")
        }.toList()
    }

    suspend fun scanRadio(treeUri: Uri): List<RadioClipEntity> = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext emptyList()
        sequenceFiles(root).mapNotNull { file ->
            if (!isAudio(file)) return@mapNotNull null
            val fallback = file.name?.substringBeforeLast('.') ?: "Einspieler"
            val meta = metadataOrNull(file.uri)
            RadioClipEntity(
                uri = file.uri.toString(),
                name = meta?.title ?: fallback,
                durationMs = meta?.duration ?: 0L
            )
        }.toList()
    }

    private fun isAudio(file: DocumentFile): Boolean {
        val ext = file.name?.substringAfterLast('.', "")?.lowercase()
        return ext in audioExt || file.type?.startsWith("audio/") == true
    }

    private fun sequenceFiles(dir: DocumentFile): Sequence<DocumentFile> = sequence {
        val children = runCatching { dir.listFiles() }.getOrDefault(emptyArray())
        for (child in children) {
            when {
                child.isDirectory -> yieldAll(sequenceFiles(child))
                child.isFile -> yield(child)
            }
        }
    }

    private fun readTrack(uri: Uri, fallback: String): TrackEntity {
        val m = metadataOrNull(uri)
        return TrackEntity(
            uri = uri.toString(),
            title = m?.title ?: fallback.substringBeforeLast('.'),
            artist = m?.artist,
            album = m?.album,
            durationMs = m?.duration ?: 0L
        )
    }

    private data class Meta(val title: String?, val artist: String?, val album: String?, val duration: Long)

    private fun metadataOrNull(uri: Uri): Meta? = runCatching {
        val r = MediaMetadataRetriever()
        try {
            val opened = runCatching {
                context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                    r.setDataSource(pfd.fileDescriptor)
                    true
                } ?: false
            }.getOrDefault(false)

            if (!opened) {
                r.setDataSource(context, uri)
            }

            Meta(
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            )
        } finally {
            r.release()
        }
    }.getOrNull()
}
