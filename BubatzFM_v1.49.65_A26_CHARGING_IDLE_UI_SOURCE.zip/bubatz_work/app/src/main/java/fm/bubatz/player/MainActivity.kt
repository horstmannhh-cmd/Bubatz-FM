
package fm.bubatz.player

import androidx.room.withTransaction
import android.Manifest
import androidx.compose.ui.graphics.asImageBitmap
import android.media.MediaMetadataRetriever
import android.graphics.BitmapFactory
import android.content.Intent
import android.content.res.Configuration
import android.content.ClipData
import android.provider.Settings
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.zIndex
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.googlefonts.GoogleFont
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import fm.bubatz.player.bluetooth.BluetoothDeviceRepository
import fm.bubatz.player.data.RadioClipEntity
import fm.bubatz.player.data.RecentMusicItem
import fm.bubatz.player.data.ArchiveSearch
import fm.bubatz.player.data.TrackEntity
import fm.bubatz.player.library.LibraryScanner
import fm.bubatz.player.library.ScanDiagnostics
import fm.bubatz.player.diagnostics.OmniaBridge
import fm.bubatz.player.playback.PlaybackService
import fm.bubatz.player.playback.FlowCycleStore
import fm.bubatz.player.scrobble.LastFmAuthCoordinator
import fm.bubatz.player.scrobble.LastFmSessionStore
import fm.bubatz.player.settings.AppSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalTime

private val BubatzDark = Color(0xFF0F1A13)
private val BubatzGreen = Color(0xFF1F2E21)
private val BubatzMid = Color(0xFF375A36)
private val BubatzSage = Color(0xFF6A8A6A)
private val BubatzRecentArtist = Color(0xFF7D9B7D)
private val BubatzCream = Color(0xFFF2E9D2)
private val BubatzGold = Color(0xFFDCC9A1)
private val BubatzPlayerSecondary = Color(0xFF86A986)
private val BubatzLime = Color(0xFF9BEA45)

@OptIn(ExperimentalTextApi::class)
private val PlusJakartaProvider = GoogleFont.Provider(
    providerAuthority = "com.google.android.gms.fonts",
    providerPackage = "com.google.android.gms",
    certificates = R.array.com_google_android_gms_fonts_certs
)
@OptIn(ExperimentalTextApi::class)
private val PlusJakartaSans = FontFamily(
    androidx.compose.ui.text.googlefonts.Font(GoogleFont("Plus Jakarta Sans"), PlusJakartaProvider, FontWeight.Normal),
    androidx.compose.ui.text.googlefonts.Font(GoogleFont("Plus Jakarta Sans"), PlusJakartaProvider, FontWeight.Medium),
    androidx.compose.ui.text.googlefonts.Font(GoogleFont("Plus Jakarta Sans"), PlusJakartaProvider, FontWeight.SemiBold)
)

// Track metadata can come from the full international music library.
// Plus Jakarta Sans is kept for Latin text; for any other Unicode script we
// deliberately hand the whole field to Android's sans-serif family. Android's
// system font stack then selects the installed script font (for example CJK,
// Arabic, Devanagari, Tamil or Hangul) and avoids missing-glyph boxes.
private fun bubatzMetadataFont(text: String): FontFamily {
    val needsSystemScriptFallback = text.codePoints().toArray().any { codePoint ->
        if (!Character.isLetter(codePoint)) return@any false
        Character.UnicodeScript.of(codePoint) != Character.UnicodeScript.LATIN
    }
    return if (needsSystemScriptFallback) FontFamily.SansSerif else PlusJakartaSans
}

private fun bubatzTypography(): Typography {
    val t = Typography()
    return Typography(
        displayLarge = t.displayLarge.copy(fontFamily = PlusJakartaSans),
        displayMedium = t.displayMedium.copy(fontFamily = PlusJakartaSans),
        displaySmall = t.displaySmall.copy(fontFamily = PlusJakartaSans),
        headlineLarge = t.headlineLarge.copy(fontFamily = PlusJakartaSans),
        headlineMedium = t.headlineMedium.copy(fontFamily = PlusJakartaSans),
        headlineSmall = t.headlineSmall.copy(fontFamily = PlusJakartaSans),
        titleLarge = t.titleLarge.copy(fontFamily = PlusJakartaSans),
        titleMedium = t.titleMedium.copy(fontFamily = PlusJakartaSans),
        titleSmall = t.titleSmall.copy(fontFamily = PlusJakartaSans),
        bodyLarge = t.bodyLarge.copy(fontFamily = PlusJakartaSans),
        bodyMedium = t.bodyMedium.copy(fontFamily = PlusJakartaSans),
        bodySmall = t.bodySmall.copy(fontFamily = PlusJakartaSans),
        labelLarge = t.labelLarge.copy(fontFamily = PlusJakartaSans),
        labelMedium = t.labelMedium.copy(fontFamily = PlusJakartaSans),
        labelSmall = t.labelSmall.copy(fontFamily = PlusJakartaSans)
    )
}

private data class ProgramSlot(val name: String, val timeLabel: String, val endLabel: String)

private val BubatzDailyProgram = listOf(
    ProgramSlot("Der Nachtbus", "0–3 Uhr", "3 UHR"),
    ProgramSlot("Dunstabzug", "3–6 Uhr", "6 UHR"),
    ProgramSlot("Zündfunk", "6–9 Uhr", "9 UHR"),
    ProgramSlot("Aufglühen", "9–12 Uhr", "12 UHR"),
    ProgramSlot("High Noon", "12–15 Uhr", "15 UHR"),
    ProgramSlot("Blütezeit", "15–18 Uhr", "18 UHR"),
    ProgramSlot("Drehmoment", "18–21 Uhr", "21 UHR"),
    ProgramSlot("Sofaschwere", "21–0 Uhr", "MITTERNACHT")
)

private fun currentProgramSlot(now: LocalTime = LocalTime.now()): ProgramSlot = when (now.hour) {
    in 0..2 -> BubatzDailyProgram[0]
    in 3..5 -> BubatzDailyProgram[1]
    in 6..8 -> BubatzDailyProgram[2]
    in 9..11 -> BubatzDailyProgram[3]
    in 12..14 -> BubatzDailyProgram[4]
    in 15..17 -> BubatzDailyProgram[5]
    in 18..20 -> BubatzDailyProgram[6]
    else -> BubatzDailyProgram[7]
}

@Composable
private fun MiniBroccoliRadio(modifier: Modifier = Modifier) {
    // Keep the three source elements independent: large original waves,
    // a deliberately tiny broccoli "station dot", and tight spacing.
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.bubatz_wave_left),
            contentDescription = null,
            modifier = Modifier.size(width = 18.dp, height = 38.dp),
            contentScale = ContentScale.Fit,
            colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(BubatzSage)
        )
        Spacer(Modifier.width(0.dp))
        Image(
            painter = painterResource(id = R.drawable.bubatz_broccoli_mini),
            contentDescription = null,
            modifier = Modifier.size(14.dp),
            contentScale = ContentScale.Fit,
            colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(BubatzSage)
        )
        Spacer(Modifier.width(0.dp))
        Image(
            painter = painterResource(id = R.drawable.bubatz_wave_right),
            contentDescription = null,
            modifier = Modifier.size(width = 18.dp, height = 38.dp),
            contentScale = ContentScale.Fit,
            colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(BubatzSage)
        )
    }
}

@Composable
private fun LandscapeMiniBroccoliRadio(modifier: Modifier = Modifier) {
    // Landscape uses the same visual grammar as portrait: the broccoli is only
    // the small station-dot between the radio waves, never the dominant glyph.
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.bubatz_wave_left),
            contentDescription = null,
            modifier = Modifier.size(width = 15.dp, height = 30.dp),
            contentScale = ContentScale.Fit,
            colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(BubatzSage)
        )
        Image(
            painter = painterResource(id = R.drawable.bubatz_broccoli_mini),
            contentDescription = null,
            modifier = Modifier.size(11.dp),
            contentScale = ContentScale.Fit,
            colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(BubatzSage)
        )
        Image(
            painter = painterResource(id = R.drawable.bubatz_wave_right),
            contentDescription = null,
            modifier = Modifier.size(width = 15.dp, height = 30.dp),
            contentScale = ContentScale.Fit,
            colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(BubatzSage)
        )
    }
}

class MainActivity : ComponentActivity() {
    private var widgetProgramRequest by mutableStateOf(false)
    // Small in-memory artwork cache: keeps already loaded covers available across
    // Compose navigation/recreation so the placeholder does not flash on return to Player.
    private val artworkCache = object : LinkedHashMap<String, ByteArray>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, ByteArray>?): Boolean = size > 32
    }

    @Synchronized
    private fun cachedArtwork(uri: String?): ByteArray? = uri?.let { artworkCache[it] }

    @Synchronized
    private fun cacheArtwork(uri: String, bytes: ByteArray?) {
        if (bytes != null) artworkCache[uri] = bytes
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        widgetProgramRequest = intent?.getBooleanExtra(BubatzWidgetProvider.EXTRA_OPEN_PROGRAM, false) == true
        // The widget navigation command is a one-shot event. Consume it immediately so
        // Activity recreation (e.g. portrait/landscape rotation) cannot reopen the sheet.
        if (widgetProgramRequest) {
            intent?.removeExtra(BubatzWidgetProvider.EXTRA_OPEN_PROGRAM)
        }

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 50)

        if (android.os.Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 51)

        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE), 52)
        }

        setContent {
            MaterialTheme(
                typography = bubatzTypography(),
                colorScheme = darkColorScheme(
                    primary = BubatzCream,
                    secondary = BubatzSage,
                    background = BubatzDark,
                    surface = BubatzGreen,
                    onPrimary = BubatzDark,
                    onBackground = BubatzCream,
                    onSurface = BubatzCream
                )
            ) {
                BubatzApp()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val openProgram = intent.getBooleanExtra(BubatzWidgetProvider.EXTRA_OPEN_PROGRAM, false)
        if (openProgram) {
            widgetProgramRequest = true
            intent.removeExtra(BubatzWidgetProvider.EXTRA_OPEN_PROGRAM)
        }
        setIntent(intent)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 52 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startService(
                Intent(this, PlaybackService::class.java)
                    .setAction(PlaybackService.ACTION_REFRESH_PHONE_MONITOR)
            )
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun BubatzApp() {
        var tab by rememberSaveable { mutableIntStateOf(0) }
        var showProgram by rememberSaveable { mutableStateOf(false) }
        LaunchedEffect(widgetProgramRequest) {
            if (widgetProgramRequest) {
                showProgram = true
                widgetProgramRequest = false
            }
        }
        val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
        val scope = rememberCoroutineScope()

        fun navigateTo(target: Int) {
            tab = target
            scope.launch { drawerState.close() }
        }

        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(
                    drawerContainerColor = BubatzDark,
                    drawerContentColor = BubatzCream
                ) {
                    Box(Modifier.fillMaxSize()) {
                        Image(
                            painter = painterResource(R.drawable.bubatz_player_background),
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop,
                            alpha = 0.18f
                        )
                        Box(
                            Modifier
                                .fillMaxSize()
                                .background(BubatzDark.copy(alpha = 0.84f))
                        )
                        Column(Modifier.fillMaxSize()) {
                            Spacer(Modifier.height(24.dp))
                            Image(
                                painter = painterResource(R.drawable.bubatz_logo_player_cutout),
                                contentDescription = "Bubatz FM",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(66.dp)
                                    .padding(horizontal = 28.dp),
                                contentScale = ContentScale.Fit,
                                alpha = 0.90f
                            )
                            Spacer(Modifier.height(24.dp))

                            @Composable
                            fun DrawerEntry(
                                label: String,
                                icon: androidx.compose.ui.graphics.vector.ImageVector,
                                selected: Boolean,
                                onClick: () -> Unit
                            ) {
                                val shape = RoundedCornerShape(22.dp)
                                val border = if (selected) BorderStroke(1.dp, BubatzSage.copy(alpha = 0.72f)) else null
                                Row(
                                    modifier = Modifier
                                        .padding(horizontal = 18.dp, vertical = 5.dp)
                                        .fillMaxWidth()
                                        .height(62.dp)
                                        .then(
                                            if (selected) Modifier
                                                .background(BubatzMid.copy(alpha = 0.32f), shape)
                                                .then(Modifier.border(border!!, shape))
                                            else Modifier
                                        )
                                        .clickable(onClick = onClick)
                                        .padding(horizontal = 18.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(Modifier.size(14.dp), contentAlignment = Alignment.Center) {
                                        if (selected) {
                                            Box(
                                                Modifier
                                                    .size(8.dp)
                                                    .background(Color(0xFFA8F23A), CircleShape)
                                            )
                                        }
                                    }
                                    Spacer(Modifier.width(10.dp))
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = null,
                                        tint = if (selected) BubatzCream else BubatzSage,
                                        modifier = Modifier.size(25.dp)
                                    )
                                    Spacer(Modifier.width(18.dp))
                                    Text(
                                        text = label,
                                        color = if (selected) BubatzCream else BubatzSage,
                                        fontSize = 16.sp,
                                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium
                                    )
                                }
                            }

                            DrawerEntry("Player", Icons.Default.Radio, tab == 0) { navigateTo(0) }
                            DrawerEntry("Wirkungsprofil", Icons.Default.Schedule, false) {
                                scope.launch { drawerState.close() }
                                showProgram = true
                            }
                            DrawerEntry("Zuletzt gehört", Icons.Default.History, tab == 2) { navigateTo(2) }
                            DrawerEntry("Archiv", Icons.Default.LibraryMusic, tab == 3) { navigateTo(3) }
                            DrawerEntry("Einstellungen", Icons.Default.Settings, tab == 1) { navigateTo(1) }

                            Spacer(Modifier.weight(1f))
                            Text(
                                text = "Bubatz.FM · ALLES, AUSSER GEWÖHNLICH",
                                color = BubatzSage.copy(alpha = 0.62f),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium,
                                letterSpacing = 0.8.sp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 28.dp, vertical = 28.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        ) {
            Scaffold(containerColor = BubatzDark) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    Crossfade(targetState = tab, label = "main-tabs") { selected ->
                        when (selected) {
                            0 -> NowPlayingScreen(
                                modifier = Modifier.fillMaxSize(),
                                onShowProgram = { showProgram = true },
                                onOpenMenu = { scope.launch { drawerState.open() } }
                            )
                            1 -> SettingsScreen(Modifier.fillMaxSize())
                            2 -> RecentHistoryScreen(Modifier.fillMaxSize())
                            else -> LibraryScreen(Modifier.fillMaxSize())
                        }
                    }
                    if (tab != 0) {
                        // Keep the same Bubatz.FM burger navigation available on all main pages.
                        // No separate back control: one navigation language everywhere.
                        IconButton(
                            onClick = { scope.launch { drawerState.open() } },
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(top = 15.dp, start = 4.dp)
                                .zIndex(10f)
                                .size(48.dp)
                        ) {
                            Canvas(modifier = Modifier.size(36.dp)) {
                                val neon = Color(0xFFBFFF18)
                                val x1 = size.width * 0.12f
                                val widths = listOf(0.76f, 0.57f, 0.40f)
                                val ys = listOf(size.height * 0.27f, size.height * 0.50f, size.height * 0.73f)
                                ys.zip(widths).forEach { (y, width) ->
                                    val x2 = x1 + size.width * width
                                    drawLine(neon.copy(alpha = 0.16f), Offset(x1, y), Offset(x2, y), strokeWidth = 12.dp.toPx(), cap = StrokeCap.Round)
                                    drawLine(neon.copy(alpha = 0.34f), Offset(x1, y), Offset(x2, y), strokeWidth = 7.dp.toPx(), cap = StrokeCap.Round)
                                    drawLine(neon, Offset(x1, y), Offset(x2, y), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
                                    drawLine(Color(0xFFE9FFB8), Offset(x1, y), Offset(x2, y), strokeWidth = 1.dp.toPx(), cap = StrokeCap.Round)
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showProgram) {
            ProgramScheduleSheet(onDismiss = { showProgram = false })
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun ProgramScheduleSheet(onDismiss: () -> Unit) {
        var programSlot by remember { mutableStateOf(currentProgramSlot()) }
        LaunchedEffect(Unit) {
            while (true) {
                programSlot = currentProgramSlot()
                delay(30_000L)
            }
        }
        val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
        ModalBottomSheet(
            onDismissRequest = onDismiss,
            containerColor = BubatzDark.copy(alpha = 0.96f),
            contentColor = BubatzCream,
            shape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp),
            dragHandle = { BottomSheetDefaults.DragHandle(color = BubatzSage.copy(alpha = 0.85f)) }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 22.dp)
                    .padding(bottom = 22.dp)
                    .navigationBarsPadding()
                    .then(if (isLandscape) Modifier.heightIn(max = 300.dp) else Modifier)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color.Transparent,
                        border = BorderStroke(1.5.dp, BubatzSage.copy(alpha = 0.9f)),
                        modifier = Modifier.size(34.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.DateRange, null, tint = BubatzSage, modifier = Modifier.size(19.dp))
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text = "WIRKUNGSPROFIL",
                        color = BubatzCream,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 0.6.sp,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Den Tag in vollen Zügen genießen.",
                    color = BubatzSage.copy(alpha = 0.88f),
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.height(14.dp))
                val currentIndex = BubatzDailyProgram.indexOfFirst { it.name == programSlot.name }.coerceAtLeast(0)
                val orderedProgram = BubatzDailyProgram.drop(currentIndex) + BubatzDailyProgram.take(currentIndex)
                if (isLandscape) {
                    orderedProgram.chunked(2).forEach { pair ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            pair.forEach { slot ->
                                val isCurrent = slot.name == programSlot.name
                                Surface(
                                    modifier = Modifier.weight(1f).padding(vertical = 2.dp),
                                    shape = RoundedCornerShape(14.dp),
                                    color = if (isCurrent) BubatzMid.copy(alpha = 0.22f) else Color.Transparent,
                                    border = if (isCurrent) BorderStroke(1.dp, BubatzSage.copy(alpha = 0.9f)) else BorderStroke(0.5.dp, BubatzSage.copy(alpha = 0.14f))
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(slot.timeLabel, color = if (isCurrent) BubatzGold else BubatzSage, fontSize = 10.sp, fontWeight = FontWeight.Medium, modifier = Modifier.width(66.dp))
                                        Text(slot.name, color = BubatzCream, fontSize = 12.sp, fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                        if (isCurrent) {
                                            Canvas(Modifier.size(13.dp)) {
                                                drawCircle(BubatzSage.copy(alpha = 0.18f), radius = size.minDimension * 0.48f)
                                                drawCircle(Color(0xFFA8F04A), radius = size.minDimension * 0.18f)
                                            }
                                            Spacer(Modifier.width(4.dp))
                                            Text("JETZT", color = BubatzGold, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.6.sp)
                                        }
                                    }
                                }
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                } else {
                    orderedProgram.forEach { slot ->
                        val isCurrent = slot.name == programSlot.name
                        Surface(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                            shape = RoundedCornerShape(14.dp),
                            color = if (isCurrent) BubatzMid.copy(alpha = 0.22f) else Color.Transparent,
                            border = if (isCurrent) BorderStroke(1.dp, BubatzSage.copy(alpha = 0.9f)) else null
                        ) {
                            Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(slot.timeLabel, color = if (isCurrent) BubatzGold else BubatzSage, fontSize = 12.sp, fontWeight = FontWeight.Medium, style = LocalTextStyle.current.copy(fontFeatureSettings = "tnum"), modifier = Modifier.width(92.dp))
                                Text(slot.name, color = BubatzCream, fontSize = 14.sp, fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Medium, modifier = Modifier.weight(1f))
                                if (isCurrent) {
                                    Canvas(Modifier.size(16.dp)) {
                                        drawCircle(BubatzSage.copy(alpha = 0.18f), radius = size.minDimension * 0.48f)
                                        drawCircle(Color(0xFFA8F04A).copy(alpha = 0.35f), radius = size.minDimension * 0.32f)
                                        drawCircle(Color(0xFFA8F04A), radius = size.minDimension * 0.18f)
                                    }
                                    Spacer(Modifier.width(5.dp))
                                    Text("JETZT", color = BubatzGold, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
                                }
                            }
                        }
                        if (!isCurrent) HorizontalDivider(color = BubatzSage.copy(alpha = 0.18f), thickness = 0.5.dp, modifier = Modifier.padding(horizontal = 10.dp))
                    }
                }
                Spacer(Modifier.height(14.dp))
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, BubatzSage.copy(alpha = 0.8f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = BubatzCream)
                ) { Text("Schließen", fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                Spacer(Modifier.height(6.dp))
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun NowPlayingScreen(
        modifier: Modifier = Modifier,
        onShowProgram: () -> Unit,
        onOpenMenu: () -> Unit
    ) {
        val db = (application as BubatzApplication).database
        val state by db.state().observe().collectAsState(initial = null)
        val omniaState by OmniaBridge.state.collectAsState()
        val scope = rememberCoroutineScope()
        var showTrackInfo by rememberSaveable { mutableStateOf(false) }
        var detailGenre by remember { mutableStateOf<String?>(null) }
        var detailYear by remember { mutableStateOf<String?>(null) }
        var artistBrowserName by rememberSaveable { mutableStateOf<String?>(null) }
        var albumBrowserName by rememberSaveable { mutableStateOf<String?>(null) }
        var browserReturnToTrackInfo by rememberSaveable { mutableStateOf(false) }

        var track by remember { mutableStateOf<TrackEntity?>(null) }
        var clip by remember { mutableStateOf<RadioClipEntity?>(null) }

        // Bubatz.FM program schedule is purely visual: it follows the device clock
        // and never changes playback, Bubatz.IQ, radio scheduling or audio behavior.
        var programSlot by remember { mutableStateOf(currentProgramSlot()) }
        LaunchedEffect(Unit) {
            while (true) {
                programSlot = currentProgramSlot()
                delay(30_000L)
            }
        }

        LaunchedEffect(state?.currentMediaId) {
            val mediaId = state?.currentMediaId

            if (mediaId?.startsWith("track:") == true) {
                // Keep the previous track (and therefore its cover) visible until
                // the database lookup for the new track has completed.
                val id = mediaId.removePrefix("track:").toLongOrNull()
                val newTrack = id?.let {
                    withContext(Dispatchers.IO) { db.tracks().byId(it) }
                }
                if (newTrack != null) {
                    track = newTrack
                    clip = null
                }
            } else if (mediaId?.startsWith("radio:") == true) {
                val id = mediaId.removePrefix("radio:").toLongOrNull()
                val newClip = id?.let {
                    withContext(Dispatchers.IO) { db.clips().byId(it) }
                }
                if (newClip != null) {
                    clip = newClip
                    track = null
                }
            } else if (mediaId == null) {
                track = null
                clip = null
            }
        }

        var visualPosition by remember(state?.currentPositionMs) {
            mutableLongStateOf(state?.currentPositionMs ?: 0L)
        }
        var isSeeking by remember { mutableStateOf(false) }
        var seekPreviewPosition by remember { mutableLongStateOf(0L) }

        LaunchedEffect(state?.isPlaying, state?.currentPositionMs, state?.currentMediaId, isSeeking) {
            if (!isSeeking) {
                visualPosition = state?.currentPositionMs ?: 0L
                while (state?.isPlaying == true && !isSeeking) {
                    delay(500)
                    visualPosition += 500
                }
            }
        }

        // v0.91 source arbitration: never steal the UI from Bubatz while its own
        // playback is active. If Bubatz is paused/stopped and Omnia has a live
        // MediaSession, the normal player becomes an Omnia remote surface.
        val useOmnia = state?.isPlaying != true && omniaState.connected && omniaState.hasMetadata
        val isRadio = !useOmnia && clip != null
        val title = when {
            useOmnia -> omniaState.title.ifBlank { "Omnia" }
            isRadio -> clip?.name ?: "Bubatz FM"
            else -> track?.title ?: "Bubatz FM"
        }
        val artist = when {
            useOmnia -> omniaState.artist.ifBlank { "Omnia" }
            isRadio -> "RADIOEINSPIELER"
            else -> track?.artist ?: "Bereit für Musik"
        }
        val album = when {
            useOmnia -> omniaState.album
            isRadio -> "ON AIR"
            else -> track?.album.orEmpty()
        }
        val duration = if (useOmnia) {
            omniaState.durationMs
        } else {
            (state?.currentDurationMs ?: 0L).coerceAtLeast(track?.durationMs ?: clip?.durationMs ?: 0L)
        }

        Box(modifier = modifier.fillMaxSize().background(BubatzDark)) {
            val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
            Image(
                painter = painterResource(R.drawable.bubatz_player_background),
                contentDescription = null,
                modifier = Modifier.matchParentSize(),
                // Portrait keeps the proven crop. In landscape show the whole broccoli
                // texture instead of zooming deeply into the portrait source artwork.
                contentScale = ContentScale.Crop,
                alpha = 1.0f
            )
            if (isLandscape) {
                LandscapeNowPlayingContent(
                    track = track,
                    isRadio = isRadio,
                    useOmnia = useOmnia,
                    title = title,
                    artist = artist,
                    album = album,
                    programSlot = programSlot,
                    duration = duration,
                    shownPosition = if (isSeeking) seekPreviewPosition else if (useOmnia) omniaState.positionMs else visualPosition,
                    isPlaying = if (useOmnia) omniaState.isPlaying else state?.isPlaying == true,
                    onOpenMenu = onOpenMenu,
                    onShowProgram = onShowProgram,
                    onInfo = { showTrackInfo = true },
                    onArtist = { if (!isRadio && artist.isNotBlank()) artistBrowserName = artist },
                    onHistoryArtist = { artistBrowserName = it },
                    onHistoryAlbum = { albumBrowserName = it },
                    onSeek = { target ->
                        visualPosition = target
                        if (useOmnia) OmniaBridge.seekTo(target) else sendSeekAction(target)
                    },
                    onPrevious = { if (useOmnia) OmniaBridge.previous() else sendPlaybackAction(PlaybackService.ACTION_PREVIOUS) },
                    onPlayPause = { if (useOmnia) OmniaBridge.playPause() else sendPlaybackAction(PlaybackService.ACTION_PLAY_PAUSE) },
                    onNext = { if (useOmnia) OmniaBridge.next() else sendPlaybackAction(PlaybackService.ACTION_NEXT) }
                )
            } else Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 22.dp, vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(84.dp)
            ) {
                Image(
                    painter = painterResource(R.drawable.bubatz_logo_player_cutout),
                    contentDescription = "Bubatz FM",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit,
                    alignment = Alignment.Center
                )

                // Fixed header position: part of the scroll content, not a floating overlay.
                // The 48dp touch target stays accessible while only the three lines are visible.
                IconButton(
                    onClick = onOpenMenu,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .offset(x = (-18).dp, y = (-13).dp)
                        .size(48.dp)
                ) {
                    // Neon-tube hamburger: three bright cores with two soft glow layers.
                    // Kept as a Canvas inside the existing 48dp touch target so menu behavior
                    // and its fixed header position remain unchanged.
                    Canvas(modifier = Modifier.size(36.dp)) {
                        val neon = Color(0xFFBFFF18)
                        val x1 = size.width * 0.12f
                        val widths = listOf(0.76f, 0.57f, 0.40f) // long -> medium -> short, left aligned
                        val ys = listOf(size.height * 0.27f, size.height * 0.50f, size.height * 0.73f)
                        ys.zip(widths).forEach { (y, width) ->
                            val x2 = x1 + size.width * width
                            drawLine(neon.copy(alpha = 0.16f), Offset(x1, y), Offset(x2, y), strokeWidth = 12.dp.toPx(), cap = StrokeCap.Round)
                            drawLine(neon.copy(alpha = 0.34f), Offset(x1, y), Offset(x2, y), strokeWidth = 7.dp.toPx(), cap = StrokeCap.Round)
                            drawLine(neon, Offset(x1, y), Offset(x2, y), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
                            drawLine(Color(0xFFE9FFB8), Offset(x1, y), Offset(x2, y), strokeWidth = 1.dp.toPx(), cap = StrokeCap.Round)
                        }
                    }
                }
            }

            Spacer(Modifier.height(2.dp))


            // Compact hybrid on-air badge: proven v1.48.23 geometry with the
            // stronger v1.48.24 colour treatment. MiniBroccoliRadio stays untouched.
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.90f)
                    .height(52.dp)
                    .clickable { onShowProgram() },
                shape = RoundedCornerShape(20.dp),
                color = BubatzMid.copy(alpha = 0.27f),
                border = BorderStroke(1.dp, BubatzLime.copy(alpha = 0.88f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(end = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .width(56.dp)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.Center
                    ) {
                        MiniBroccoliRadio(Modifier.size(width = 54.dp, height = 42.dp).offset(x = 3.dp))
                    }

                    Spacer(Modifier.width(10.dp))

                    Text(
                        text = "JETZT:",
                        fontFamily = PlusJakartaSans,
                        color = BubatzLime.copy(alpha = 0.96f),
                        fontSize = 10.sp,
                        lineHeight = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 0.4.sp,
                        maxLines = 1,
                        softWrap = false
                    )

                    Spacer(Modifier.width(10.dp))

                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.Start,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = programSlot.name.uppercase(),
                            fontFamily = PlusJakartaSans,
                            color = BubatzCream.copy(alpha = 0.96f),
                            fontSize = when {
                                programSlot.name.length > 22 -> 10.sp
                                programSlot.name.length > 17 -> 11.5.sp
                                else -> 13.5.sp
                            },
                            lineHeight = when {
                                programSlot.name.length > 22 -> 11.sp
                                programSlot.name.length > 17 -> 12.5.sp
                                else -> 14.5.sp
                            },
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Start,
                            maxLines = 1,
                            softWrap = false
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = null,
                                tint = BubatzCream.copy(alpha = 0.90f),
                                modifier = Modifier.size(11.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(
                                text = "BIS ${programSlot.endLabel}",
                                fontFamily = PlusJakartaSans,
                                color = BubatzCream.copy(alpha = 0.90f),
                                fontSize = 9.sp,
                                lineHeight = 10.sp,
                                fontWeight = FontWeight.Medium,
                                textAlign = TextAlign.Start,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Wirkungsprofil öffnen",
                        tint = BubatzCream.copy(alpha = 0.78f),
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            Surface(
                modifier = Modifier.fillMaxWidth(0.90f).aspectRatio(1f),
                shape = RoundedCornerShape(26.dp),
                color = BubatzGreen,
                tonalElevation = 4.dp
            ) {
                if (isRadio || useOmnia) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Image(
                            painterResource(if (useOmnia) R.drawable.bubatz_app_icon_dark else R.drawable.bubatz_placeholder_cover),
                            if (useOmnia) "Omnia über Bubatz FM" else "Bubatz FM Einspieler",
                            Modifier.fillMaxSize().padding(if (useOmnia) 52.dp else 0.dp),
                            contentScale = ContentScale.Fit
                        )
                    }
                } else {
                    AlbumArtwork(
                        uri = track?.uri,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            if (useOmnia) {
                AssistChip(
                    onClick = {},
                    label = { Text("OMNIA · EXTERNE WIEDERGABE") },
                    colors = AssistChipDefaults.assistChipColors(
                        labelColor = BubatzCream,
                        containerColor = BubatzMid
                    )
                )
                Spacer(Modifier.height(10.dp))
            }

            if (isRadio) {
                AssistChip(
                    onClick = {},
                    label = { Text("● ON AIR · BUBATZ FM") },
                    colors = AssistChipDefaults.assistChipColors(
                        labelColor = BubatzCream,
                        containerColor = BubatzMid
                    )
                )
                Spacer(Modifier.height(10.dp))
            }

            Text(
                text = title,
                fontFamily = bubatzMetadataFont(title),
                color = BubatzCream,
                fontSize = 22.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(5.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = artist,
                    fontFamily = bubatzMetadataFont(artist),
                    color = if (isRadio) BubatzGold else BubatzPlayerSecondary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false).then(if (!isRadio && artist.isNotBlank()) Modifier.clickable { artistBrowserName = artist } else Modifier)
                )
                if (!isRadio) {
                    Spacer(Modifier.width(6.dp))
                    IconButton(onClick = { showTrackInfo = true }, modifier = Modifier.size(26.dp)) {
                        Icon(Icons.Default.Info, "Inhaltsstoffe", tint = BubatzPlayerSecondary, modifier = Modifier.size(18.dp))
                    }
                }
            }
            if (album.isNotBlank()) {
                Text(
                    text = album,
                    fontFamily = bubatzMetadataFont(album),
                    color = BubatzPlayerSecondary.copy(alpha = 0.96f),
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(Modifier.height(12.dp))

            val shownPosition = if (isSeeking) seekPreviewPosition else if (useOmnia) omniaState.positionMs else visualPosition
            val sliderValue = if (duration > 0L) {
                (shownPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
            } else 0f

            CompactSeekBar(
                value = sliderValue,
                enabled = duration > 0L && !isRadio,
                onValueChange = { value ->
                    if (duration > 0L) {
                        isSeeking = true
                        seekPreviewPosition = (duration * value.coerceIn(0f, 1f)).toLong()
                    }
                },
                onValueChangeFinished = {
                    if (isSeeking && duration > 0L) {
                        val target = seekPreviewPosition.coerceIn(0L, duration)
                        visualPosition = target
                        if (useOmnia) OmniaBridge.seekTo(target) else sendSeekAction(target)
                    }
                    isSeeking = false
                }
            )
            Spacer(Modifier.height(6.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(shownPosition), color = BubatzPlayerSecondary, fontSize = 11.sp)
                Text(formatTime(duration), color = BubatzPlayerSecondary, fontSize = 11.sp)
            }

            Spacer(Modifier.height(7.dp))

            Row(
                Modifier
                    .fillMaxWidth()
                    .offset(y = (-10).dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SoftGlowControl {
                    IconButton(onClick = { if (useOmnia) OmniaBridge.previous() else sendPlaybackAction(PlaybackService.ACTION_PREVIOUS) }) {
                        Icon(Icons.Default.SkipPrevious, "Vorheriger Titel", tint = BubatzCream, modifier = Modifier.size(36.dp))
                    }
                }

                SoftGlowControl(glowRadius = 46.dp, glowAlpha = 0.11f) {
                    FilledIconButton(
                        onClick = { if (useOmnia) OmniaBridge.playPause() else sendPlaybackAction(PlaybackService.ACTION_PLAY_PAUSE) },
                        modifier = Modifier.size(72.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = BubatzCream,
                            contentColor = BubatzDark
                        )
                    ) {
                        Icon(
                            if ((useOmnia && omniaState.isPlaying) || (!useOmnia && state?.isPlaying == true)) Icons.Default.Pause else Icons.Default.PlayArrow,
                            if ((useOmnia && omniaState.isPlaying) || (!useOmnia && state?.isPlaying == true)) "Pause" else "Play",
                            modifier = Modifier.size(38.dp)
                        )
                    }
                }

                SoftGlowControl {
                    IconButton(onClick = { if (useOmnia) OmniaBridge.next() else sendPlaybackAction(PlaybackService.ACTION_NEXT) }) {
                        Icon(Icons.Default.SkipNext, "Nächster Titel", tint = BubatzCream, modifier = Modifier.size(36.dp))
                    }
                }
            }

            Spacer(Modifier.height(6.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val iqGlowTransition = rememberInfiniteTransition(label = "bubatzIqGlow")
                val iqGlowStrength by iqGlowTransition.animateFloat(
                    initialValue = 0.28f,
                    targetValue = 0.92f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(durationMillis = 4800, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "bubatzIqGlowStrength"
                )
                // The mark itself brightens as well as casting light. This keeps the
                // effect logo-like (VAIO / illuminated Apple), never button-like.
                val iqCoreColor = androidx.compose.ui.graphics.lerp(
                    BubatzSage,
                    Color(0xFFD6FF9A),
                    iqGlowStrength * 0.72f
                )
                Row(
                    Modifier.padding(horizontal = 5.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Pure logo-style glow: no plate, border or button background.
                    // Only the shuffle glyph and BUBATZ.IQ lettering breathe very gently.
                    Box(contentAlignment = Alignment.Center) {
                        // Two blurred copies create a real contour halo around the glyph.
                        // The sharp core stays on top, so it reads as internally illuminated.
                        Icon(
                            Icons.Default.Shuffle,
                            null,
                            tint = BubatzLime,
                            modifier = Modifier
                                .size(22.dp)
                                .graphicsLayer {
                                    alpha = 0.10f + iqGlowStrength * 0.18f
                                    renderEffect = BlurEffect(13f, 13f, TileMode.Decal)
                                }
                        )
                        Icon(
                            Icons.Default.Shuffle,
                            null,
                            tint = BubatzLime,
                            modifier = Modifier
                                .size(20.dp)
                                .graphicsLayer {
                                    alpha = 0.16f + iqGlowStrength * 0.24f
                                    renderEffect = BlurEffect(6f, 6f, TileMode.Decal)
                                }
                        )
                        Icon(
                            Icons.Default.Shuffle,
                            null,
                            tint = iqCoreColor,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                    Spacer(Modifier.width(5.dp))
                    Box(contentAlignment = Alignment.CenterStart) {
                        // Broad, soft outer light. It breathes; there is never a plate behind it.
                        Text(
                            "BUBATZ.IQ",
                            color = Color.Transparent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            style = androidx.compose.ui.text.TextStyle(
                                shadow = androidx.compose.ui.graphics.Shadow(
                                    color = BubatzLime.copy(alpha = 0.12f + iqGlowStrength * 0.24f),
                                    offset = androidx.compose.ui.geometry.Offset.Zero,
                                    blurRadius = 24f
                                )
                            )
                        )
                        // Tight inner halo keeps the light attached to the letter contours.
                        Text(
                            "BUBATZ.IQ",
                            color = iqCoreColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            style = androidx.compose.ui.text.TextStyle(
                                shadow = androidx.compose.ui.graphics.Shadow(
                                    color = BubatzLime.copy(alpha = 0.34f + iqGlowStrength * 0.56f),
                                    offset = androidx.compose.ui.geometry.Offset.Zero,
                                    blurRadius = 10f
                                )
                            )
                        )
                    }
                }
                Spacer(Modifier.width(18.dp))
                Text("•", color = BubatzMid)
                Spacer(Modifier.width(18.dp))
                Text(if (useOmnia) "OMNIA BRIDGE" else "BUBATZ.FM", color = BubatzGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(10.dp))
            Text(
                "Bluetooth- & Lockscreen-Steuerung aktiv",
                color = BubatzSage.copy(alpha = 0.75f),
                fontSize = 10.sp
            )

            Spacer(Modifier.height(16.dp))
            Text(
                text = "Bubatz.FM · v${BuildConfig.VERSION_NAME}",
                color = BubatzSage.copy(alpha = 0.48f),
                fontSize = 9.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(12.dp))
            }

            if (showTrackInfo) {
                LaunchedEffect(track?.uri, showTrackInfo) {
                    if (showTrackInfo && !track?.uri.isNullOrBlank()) {
                        val extra = withContext(Dispatchers.IO) {
                            runCatching {
                                val r = MediaMetadataRetriever()
                                try {
                                    r.setDataSource(this@MainActivity, Uri.parse(track!!.uri))
                                    r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE) to r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR)
                                } finally { r.release() }
                            }.getOrNull()
                        }
                        detailGenre = extra?.first
                        detailYear = extra?.second
                    }
                }
                val infoLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
                ModalBottomSheet(
                    onDismissRequest = { showTrackInfo = false },
                    containerColor = BubatzDark.copy(alpha = 0.96f),
                    contentColor = BubatzCream,
                    shape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp),
                    dragHandle = { BottomSheetDefaults.DragHandle(color = BubatzSage.copy(alpha = 0.85f)) }
                ) {
                    if (infoLandscape) {
                        LandscapeTrackInfoContent(
                            title = title,
                            artist = artist,
                            album = album,
                            uri = track?.uri,
                            genre = detailGenre,
                            year = detailYear,
                            durationMs = duration,
                            onArtist = if (artist.isNotBlank()) ({ browserReturnToTrackInfo = true; showTrackInfo = false; artistBrowserName = artist }) else null,
                            onAlbum = if (album.isNotBlank()) ({ browserReturnToTrackInfo = true; showTrackInfo = false; albumBrowserName = album }) else null,
                            onDismiss = { showTrackInfo = false }
                        )
                    } else {
                        Column(
                            Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Surface(shape = RoundedCornerShape(50), color = Color.Transparent, border = BorderStroke(1.5.dp, BubatzSage.copy(alpha = 0.9f)), modifier = Modifier.size(34.dp)) {
                                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Info, null, tint = BubatzSage, modifier = Modifier.size(20.dp)) }
                                }
                                Spacer(Modifier.width(12.dp))
                                Text("Inhaltsstoffe", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Spacer(Modifier.height(16.dp))
                            if (!useOmnia && track != null) {
                                Box(Modifier.fillMaxWidth().height(166.dp), contentAlignment = Alignment.Center) {
                                    Surface(Modifier.size(166.dp), shape = RoundedCornerShape(18.dp), color = BubatzGreen) { AlbumArtwork(track?.uri, Modifier.fillMaxSize()) }
                                    Box(Modifier.align(Alignment.CenterEnd).padding(end = 8.dp)) { ShareTrackIcon(title = title, artist = artist, uri = track?.uri) }
                                }
                                Spacer(Modifier.height(16.dp))
                            }
                            DetailInfoRow("Titel", title)
                            DetailInfoRow("Interpret", artist, onClick = if (artist.isNotBlank()) ({ browserReturnToTrackInfo = true; showTrackInfo = false; artistBrowserName = artist }) else null)
                            if (album.isNotBlank()) DetailInfoRow("Album", album, onClick = { browserReturnToTrackInfo = true; showTrackInfo = false; albumBrowserName = album })
                            detailGenre?.takeIf { it.isNotBlank() }?.let { DetailInfoRow("Genre", it) }
                            detailYear?.takeIf { it.isNotBlank() }?.let { DetailInfoRow("Jahr", it) }
                            if (duration > 0L) DetailInfoRow("Laufzeit", formatTime(duration))
                            Spacer(Modifier.height(18.dp))
                            OutlinedButton(onClick = { showTrackInfo = false }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, BubatzSage.copy(alpha = 0.8f)), colors = ButtonDefaults.outlinedButtonColors(contentColor = BubatzCream)) { Text("Schließen", fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                            Spacer(Modifier.height(12.dp))
                            Text("Musik teilen. Gute Vibes weitergeben. 🥦", color = BubatzSage.copy(alpha = 0.72f), fontSize = 11.sp)
                        }
                    }
                }
            }
            artistBrowserName?.let { selectedArtist ->
                ArtistLibrarySheet(
                    artist = selectedArtist,
                    onDismiss = {
                        // Sheet gesture / outside tap always closes the complete info stack.
                        artistBrowserName = null
                        albumBrowserName = null
                        browserReturnToTrackInfo = false
                        showTrackInfo = false
                    },
                    onAlbumSelected = { albumName -> albumBrowserName = albumName },
                    backLabel = if (browserReturnToTrackInfo) "← Zurück zu den Inhaltsstoffen" else null,
                    onBack = if (browserReturnToTrackInfo) ({
                        artistBrowserName = null
                        browserReturnToTrackInfo = false
                        showTrackInfo = true
                    }) else null
                )
            }
            albumBrowserName?.let { selectedAlbum ->
                AlbumLibrarySheetByName(
                    album = selectedAlbum,
                    onDismiss = {
                        // Sheet gesture / outside tap always closes the complete info stack.
                        albumBrowserName = null
                        artistBrowserName = null
                        browserReturnToTrackInfo = false
                        showTrackInfo = false
                    },
                    onBackToArtist = when {
                        artistBrowserName != null -> ({ albumBrowserName = null })
                        browserReturnToTrackInfo -> ({ albumBrowserName = null; browserReturnToTrackInfo = false; showTrackInfo = true })
                        else -> null
                    },
                    backLabel = if (artistBrowserName != null) "← Zurück zum Künstler" else if (browserReturnToTrackInfo) "← Zurück zu den Inhaltsstoffen" else null
                )
            }
        }


    }

    private fun shareTrackText(title: String, artist: String) {
        val cleanArtist = artist.ifBlank { "Unbekannter Interpret" }
        val text = "Ich höre gerade „$title“ von $cleanArtist auf Bubatz.FM 🥦"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(intent, "Titel teilen"))
    }

    private fun shareTrackFile(uriString: String, title: String, artist: String, includeText: Boolean = false) {
        val uri = Uri.parse(uriString)
        val mime = contentResolver.getType(uri) ?: when {
            uriString.endsWith(".m4a", true) -> "audio/mp4"
            uriString.endsWith(".mp3", true) -> "audio/mpeg"
            else -> "audio/*"
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            if (includeText) {
                putExtra(Intent.EXTRA_TEXT, "Ich höre gerade „$title“ von ${artist.ifBlank { "Unbekannter Interpret" }} auf Bubatz.FM 🥦")
            }
            clipData = ClipData.newRawUri(title, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, if (includeText) "Datei + Text teilen" else "Audiodatei teilen"))
    }

    @Composable
    private fun ShareTrackIcon(title: String, artist: String, uri: String?) {
        var showShareChoice by remember { mutableStateOf(false) }
        Surface(
            shape = CircleShape,
            color = BubatzDark.copy(alpha = 0.55f),
            border = BorderStroke(1.dp, BubatzLime.copy(alpha = 0.72f)),
            modifier = Modifier.size(46.dp).clickable { showShareChoice = true }
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Share, "Teilen", tint = BubatzLime, modifier = Modifier.size(21.dp))
            }
        }
        if (showShareChoice) {
            AlertDialog(
                onDismissRequest = { showShareChoice = false },
                containerColor = BubatzDark,
                titleContentColor = BubatzCream,
                textContentColor = BubatzPlayerSecondary,
                title = { Text("Titel teilen") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Wie Vibes verbreiten?", color = BubatzPlayerSecondary)
                        Button(
                            onClick = {
                                showShareChoice = false
                                shareTrackText(title, artist)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BubatzLime, contentColor = BubatzDark)
                        ) { Text("Titelinformationen teilen", fontWeight = FontWeight.SemiBold) }
                        if (!uri.isNullOrBlank()) {
                            OutlinedButton(
                                onClick = {
                                    showShareChoice = false
                                    shareTrackFile(uri, title, artist, includeText = false)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.dp, BubatzSage.copy(alpha = .62f)),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = BubatzCream)
                            ) { Text("Audiodatei teilen") }
                        }
                        Text(
                            "Musik teilen. Gute Vibes weitergeben. 🥦",
                            color = BubatzSage.copy(alpha = 0.72f), fontSize = 11.sp,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { showShareChoice = false }) {
                        Text("Abbrechen", color = BubatzPlayerSecondary)
                    }
                }
            )
        }
    }

    @Composable
    private fun DetailInfoRow(label: String, value: String, onClick: (() -> Unit)? = null) {
        Column(Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)) {
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
                Text(
                    label.uppercase(),
                    color = BubatzSage,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 1.1.sp,
                    modifier = Modifier.width(86.dp)
                )
                Text(
                    value,
                    fontFamily = bubatzMetadataFont(value),
                    color = BubatzCream,
                    fontSize = 14.sp,
                    lineHeight = 16.sp,
                    modifier = Modifier.weight(1f)
                )
                if (onClick != null) Icon(Icons.Default.ChevronRight, "Interpret ansehen", tint = BubatzLime, modifier = Modifier.size(18.dp))
            }
            HorizontalDivider(color = BubatzSage.copy(alpha = 0.20f), thickness = 0.5.dp)
        }
    }

    @Composable
    private fun LandscapeTrackInfoContent(
        title: String,
        artist: String,
        album: String?,
        uri: String?,
        genre: String?,
        year: String?,
        durationMs: Long,
        onArtist: (() -> Unit)?,
        onAlbum: (() -> Unit)?,
        onDismiss: () -> Unit
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 2.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = Color.Transparent, border = BorderStroke(1.5.dp, BubatzSage.copy(alpha = 0.9f)), modifier = Modifier.size(32.dp)) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Info, null, tint = BubatzSage, modifier = Modifier.size(19.dp)) }
                }
                Spacer(Modifier.width(10.dp))
                Text("Inhaltsstoffe", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onDismiss) { Text("Schließen", color = BubatzPlayerSecondary, fontSize = 12.sp) }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.Top) {
                Box(Modifier.width(150.dp).height(150.dp), contentAlignment = Alignment.Center) {
                    Surface(Modifier.size(142.dp), shape = RoundedCornerShape(16.dp), color = BubatzGreen) { AlbumArtwork(uri, Modifier.fillMaxSize()) }
                    Box(Modifier.align(Alignment.BottomEnd)) { ShareTrackIcon(title = title, artist = artist, uri = uri) }
                }
                Column(Modifier.weight(1f)) {
                    DetailInfoRow("Titel", title)
                    DetailInfoRow("Interpret", artist, onClick = onArtist)
                    album?.takeIf { it.isNotBlank() }?.let { DetailInfoRow("Album", it, onClick = onAlbum) }
                    genre?.takeIf { it.isNotBlank() }?.let { DetailInfoRow("Genre", it) }
                    year?.takeIf { it.isNotBlank() }?.let { DetailInfoRow("Jahr", it) }
                    if (durationMs > 0L) DetailInfoRow("Laufzeit", formatTime(durationMs))
                }
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun ArtistLibrarySheet(artist: String, onDismiss: () -> Unit, onAlbumSelected: (String) -> Unit = {}, backLabel: String? = null, onBack: (() -> Unit)? = null) {
        val db = (application as BubatzApplication).database
        var tracks by remember(artist) { mutableStateOf<List<TrackEntity>>(emptyList()) }
        var loading by remember(artist) { mutableStateOf(true) }
        LaunchedEffect(artist) {
            loading = true
            tracks = withContext(Dispatchers.IO) { db.tracks().tracksByArtist(artist) }
            loading = false
        }
        val albums = remember(tracks) {
            tracks.groupBy { it.album?.trim()?.takeIf { name -> name.isNotBlank() } ?: "Unbekanntes Album" }
                .toList()
                // Jahresdaten werden erst nach dem IQ-Test zentral erschlossen. Bis dahin stabil alphabetisch.
                .sortedBy { it.first.lowercase() }
        }
        val songs = remember(tracks) { tracks.sortedBy { it.title.lowercase() } }
        val totalDuration = remember(tracks) { tracks.sumOf { it.durationMs.coerceAtLeast(0L) } }
        ModalBottomSheet(
            onDismissRequest = onDismiss,
            containerColor = BubatzDark.copy(alpha = 0.98f),
            contentColor = BubatzCream,
            shape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp),
            dragHandle = { BottomSheetDefaults.DragHandle(color = BubatzSage.copy(alpha = 0.85f)) }
        ) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp).padding(bottom = 24.dp).navigationBarsPadding()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = CircleShape, color = Color.Transparent, border = BorderStroke(1.5.dp, BubatzSage.copy(alpha = 0.9f)), modifier = Modifier.size(34.dp)) {
                        Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = BubatzSage, modifier = Modifier.size(20.dp)) }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(artist, fontFamily = bubatzMetadataFont(artist), fontSize = 19.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (!loading) Text("${tracks.size} Titel · ${formatTime(totalDuration)} Gesamtlaufzeit", color = BubatzSage, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("Nur Ansicht · keine Wiedergabe", color = BubatzLime.copy(alpha = 0.88f), fontSize = 11.sp)
                Spacer(Modifier.height(12.dp))
                Column(Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState())) {
                    if (loading) {
                        Box(Modifier.fillMaxWidth().padding(30.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = BubatzLime, modifier = Modifier.size(28.dp)) }
                    } else if (tracks.isEmpty()) {
                        Text("Keine Titel für diesen Interpreten gefunden.", color = BubatzSage, fontSize = 13.sp, modifier = Modifier.padding(vertical = 20.dp))
                    } else {
                        Text("ALBEN", color = BubatzCream, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
                        Spacer(Modifier.height(8.dp))
                        // Albums deliberately use a two-column visual grid so they read as a
                        // separate browse layer from the compact alphabetical song list below.
                        albums.chunked(2).forEach { albumRow ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                                albumRow.forEachIndexed { index, (albumName, albumTracks) ->
                                    Column(Modifier.weight(1f).padding(end = if (index == 0) 6.dp else 0.dp)) {
                                        AlbumArtwork(albumTracks.firstOrNull()?.uri, Modifier.fillMaxWidth().aspectRatio(1f).clickable { onAlbumSelected(albumName) })
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            albumName,
                                            fontFamily = bubatzMetadataFont(albumName),
                                            color = BubatzCream,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.height(38.dp)
                                        )
                                        Text(
                                            "${albumTracks.size} ${if (albumTracks.size == 1) "Titel" else "Titel"}",
                                            color = BubatzSage.copy(alpha = 0.82f),
                                            fontSize = 9.5.sp,
                                            maxLines = 1
                                        )
                                    }
                                    if (index == 0 && albumRow.size > 1) Spacer(Modifier.width(6.dp))
                                }
                                if (albumRow.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                        HorizontalDivider(color = BubatzSage.copy(alpha = 0.25f), thickness = 0.5.dp, modifier = Modifier.padding(vertical = 10.dp))
                        Text("LIEDER", color = BubatzCream, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
                        Spacer(Modifier.height(5.dp))
                        songs.forEach { t ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                // Read-only visual album cue: useful when the same song title exists
                                // as different recordings/releases. No click handler, no playback path.
                                AlbumArtwork(t.uri, Modifier.size(38.dp))
                                Spacer(Modifier.width(9.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        t.title,
                                        fontFamily = bubatzMetadataFont(t.title),
                                        color = BubatzCream.copy(alpha = 0.94f),
                                        fontSize = 13.sp
                                    )
                                    val songAlbum = t.album?.trim()?.takeIf { it.isNotBlank() } ?: "Unbekanntes Album"
                                    Text(
                                        songAlbum,
                                        fontFamily = bubatzMetadataFont(songAlbum),
                                        color = BubatzSage.copy(alpha = 0.78f),
                                        fontSize = 10.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Spacer(Modifier.width(8.dp))
                                if (t.durationMs > 0L) Text(formatTime(t.durationMs), color = BubatzSage, fontSize = 11.sp)
                            }
                            HorizontalDivider(color = BubatzSage.copy(alpha = 0.12f), thickness = 0.5.dp)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = onBack ?: onDismiss, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, BubatzSage.copy(alpha = 0.8f)), colors = ButtonDefaults.outlinedButtonColors(contentColor = BubatzCream)) {
                    Text(backLabel ?: "Schließen", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }

    @Composable
    private fun AlbumArtwork(uri: String?, modifier: Modifier = Modifier) {
        // Keep the previous cover visible until the next embedded cover is ready.
        // This prevents the broccoli placeholder from flashing during normal transitions.
        var artworkBytes by remember { mutableStateOf(cachedArtwork(uri)) }

        LaunchedEffect(uri) {
            if (uri.isNullOrBlank()) {
                artworkBytes = null
                return@LaunchedEffect
            }

            // If this cover was already decoded during this Activity lifetime, keep it
            // immediately visible and avoid a placeholder frame while navigating back.
            cachedArtwork(uri)?.let {
                artworkBytes = it
                return@LaunchedEffect
            }

            val loadedArtwork = withContext(Dispatchers.IO) {
                runCatching {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(this@MainActivity, Uri.parse(uri))
                        retriever.embeddedPicture
                    } finally {
                        retriever.release()
                    }
                }.getOrNull()
            }

            cacheArtwork(uri, loadedArtwork)
            artworkBytes = loadedArtwork
        }

        val bitmap = remember(artworkBytes) {
            artworkBytes?.let { bytes ->
                runCatching {
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
                }.getOrNull()
            }
        }

        Box(modifier.background(BubatzGreen), contentAlignment = Alignment.Center) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap,
                    contentDescription = "Albumcover",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Image(
                    painterResource(R.drawable.bubatz_placeholder_cover),
                    "Bubatz FM",
                    Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
        }
    }

    @Composable
    private fun SoftGlowControl(
        glowRadius: Dp = 28.dp,
        glowAlpha: Float = 0.07f,
        content: @Composable () -> Unit
    ) {
        Box(contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(glowRadius * 2f)) {
                drawCircle(
                    color = BubatzCream.copy(alpha = glowAlpha),
                    radius = size.minDimension / 2f
                )
            }
            content()
        }
    }

    @Composable
    private fun CompactSeekBar(
        value: Float,
        enabled: Boolean,
        onValueChange: (Float) -> Unit,
        onValueChangeFinished: () -> Unit
    ) {
        val active = BubatzGold
        val inactive = BubatzMid.copy(alpha = 0.92f)
        val disabled = BubatzPlayerSecondary.copy(alpha = 0.52f)

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .height(24.dp)
                .then(
                    if (enabled) {
                        Modifier
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onTap = { offset ->
                                        val fraction = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                                        onValueChange(fraction)
                                        onValueChangeFinished()
                                    }
                                )
                            }
                            .pointerInput(Unit) {
                                detectHorizontalDragGestures(
                                    onDragStart = { offset ->
                                        val fraction = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                                        onValueChange(fraction)
                                    },
                                    onHorizontalDrag = { change, _ ->
                                        val fraction = (change.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                                        onValueChange(fraction)
                                        change.consume()
                                    },
                                    onDragEnd = onValueChangeFinished,
                                    onDragCancel = onValueChangeFinished
                                )
                            }
                    } else Modifier
                )
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val y = size.height / 2f
                val startX = 4.dp.toPx()
                val endX = size.width - 4.dp.toPx()
                val usable = (endX - startX).coerceAtLeast(0f)
                val thumbX = startX + usable * value.coerceIn(0f, 1f)
                val trackWidth = 3.dp.toPx()

                drawLine(
                    color = if (enabled) inactive else disabled,
                    start = Offset(startX, y),
                    end = Offset(endX, y),
                    strokeWidth = trackWidth,
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = if (enabled) active else disabled,
                    start = Offset(startX, y),
                    end = Offset(thumbX, y),
                    strokeWidth = trackWidth,
                    cap = StrokeCap.Round
                )
                if (enabled) {
                    drawCircle(
                        color = BubatzCream.copy(alpha = 0.10f),
                        radius = 14.dp.toPx(),
                        center = Offset(thumbX, y)
                    )
                    drawCircle(
                        color = BubatzCream.copy(alpha = 0.20f),
                        radius = 10.dp.toPx(),
                        center = Offset(thumbX, y)
                    )
                }
                drawCircle(
                    color = if (enabled) active else disabled,
                    radius = 8.dp.toPx(),
                    center = Offset(thumbX, y)
                )
            }
        }
    }

    private data class LibraryArtistEntry(val name: String, val count: Int)
    private data class LibraryAlbumEntry(val name: String, val count: Int, val searchText: String, val coverUri: String?)

    @Composable
    private fun LibraryScreen(modifier: Modifier = Modifier) {
        val db = (application as BubatzApplication).database
        val scope = rememberCoroutineScope()
        var artists by remember { mutableStateOf<List<LibraryArtistEntry>>(emptyList()) }
        var albums by remember { mutableStateOf<List<LibraryAlbumEntry>>(emptyList()) }
        var titleTracks by remember { mutableStateOf<List<TrackEntity>>(emptyList()) }
        var titleTotal by remember { mutableIntStateOf(0) }
        var titleLoading by remember { mutableStateOf(false) }
        var titlePage by remember { mutableIntStateOf(0) }
        var titleRawLoaded by remember { mutableIntStateOf(0) }
        var loading by remember { mutableStateOf(true) }
        var query by rememberSaveable { mutableStateOf("") }
        var mode by rememberSaveable { mutableStateOf("Künstler") }
        var selectedArtist by remember { mutableStateOf<String?>(null) }
        var selectedAlbum by remember { mutableStateOf<String?>(null) }
        var selectedTitleTrack by remember { mutableStateOf<TrackEntity?>(null) }
        // Room invalidates this observable whenever the tracks table changes, including
        // metadata updates. Debounce avoids rebuilding groupings for every scanned file.
        var archiveRevision by remember { mutableIntStateOf(0) }
        LaunchedEffect(db) {
            db.tracks().observeCount().debounce(2500).collect {
                archiveRevision++
            }
        }

        // Only compact SQL groupings live in memory. Titles are fetched in bounded pages.
        // Refresh after a completed scan or a burst of metadata updates while this
        // screen is open; reopening also starts a fresh Room observation.
        LaunchedEffect(archiveRevision) {
            loading = true
            val artistRows = withContext(Dispatchers.IO) { db.tracks().archiveArtists() }
            val albumRows = withContext(Dispatchers.IO) { db.tracks().archiveAlbums() }
            artists = artistRows.map { LibraryArtistEntry(it.name, it.trackCount) }
            albums = albumRows.map { LibraryAlbumEntry(it.name, it.trackCount, it.searchText, it.coverUri) }
            loading = false
        }
        val q = query.trim().lowercase()
        val terms = remember(q) { q.split(Regex("\\s+")).filter { it.isNotBlank() } }
        val visibleArtists = remember(artists, terms) { if (terms.isEmpty()) artists else artists.filter { e -> terms.all { it in e.name.lowercase() } } }
        val visibleAlbums = remember(albums, terms) { if (terms.isEmpty()) albums else albums.filter { e -> terms.all { it in e.searchText } } }
        // The SQL term narrows the search; the in-memory filter retains multiword AND semantics.
        LaunchedEffect(mode, q, archiveRevision) {
            if (mode != "Titel") return@LaunchedEffect
            titleLoading = true
            titleTracks = emptyList()
            titlePage = 0
            titleRawLoaded = 0
            titleTotal = withContext(Dispatchers.IO) { db.tracks().archiveSearchTitleCount(ArchiveSearch.count(terms)) }
            val page = withContext(Dispatchers.IO) { db.tracks().archiveSearchTitlePage(ArchiveSearch.titles(terms, 100, 0)) }
            titleRawLoaded = page.size
            titleTracks = page
            titleLoading = false
        }
        val visibleTitles = titleTracks

        Box(modifier.fillMaxSize().background(BubatzDark)) {
            Image(painterResource(R.drawable.bubatz_player_background), null, Modifier.matchParentSize(), contentScale = ContentScale.Crop, alpha = 0.72f)
            Box(Modifier.matchParentSize().background(BubatzDark.copy(alpha = 0.32f)))
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 16.dp)) {
                Image(painterResource(R.drawable.bubatz_logo_player_cutout), "Bubatz FM", Modifier.fillMaxWidth().height(70.dp).padding(horizontal = 34.dp), contentScale = ContentScale.Fit, alpha = 0.92f)
                Spacer(Modifier.height(14.dp))
                Text("Archiv", color = BubatzCream, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("Nur Ansicht · keine Wiedergabe", color = BubatzLime.copy(alpha = 0.88f), fontSize = 11.sp)
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth()) {
                    listOf("Künstler", "Alben", "Titel").forEach { label ->
                        val active = mode == label
                        Surface(Modifier.weight(1f).clickable { mode = label }, shape = RoundedCornerShape(16.dp), color = if (active) BubatzMid else BubatzGreen.copy(alpha=.72f), border = BorderStroke(1.dp, if (active) BubatzLime.copy(alpha=.65f) else BubatzSage.copy(alpha=.35f))) {
                            Text(label, Modifier.padding(vertical=10.dp), color=if(active) BubatzCream else BubatzSage, textAlign=TextAlign.Center, fontWeight=FontWeight.Medium)
                        }
                        if (label != "Titel") Spacer(Modifier.width(8.dp))
                    }
                }
                Spacer(Modifier.height(18.dp))
                OutlinedTextField(value=query, onValueChange={query=it}, modifier=Modifier.fillMaxWidth(), singleLine=true, leadingIcon={ Icon(Icons.Default.Search, null, tint=BubatzSage) }, placeholder={ Text(when(mode) { "Künstler" -> "Künstler suchen …"; "Alben" -> "Album oder Interpret suchen …"; else -> "Titel, Interpret oder Album suchen …" }, color=BubatzSage) }, colors=OutlinedTextFieldDefaults.colors(focusedTextColor=BubatzCream, unfocusedTextColor=BubatzCream, focusedBorderColor=BubatzLime, unfocusedBorderColor=BubatzSage.copy(alpha=.55f), cursorColor=BubatzLime), shape=RoundedCornerShape(16.dp))
                Spacer(Modifier.height(10.dp))
                if (loading) Box(Modifier.fillMaxWidth().padding(30.dp), contentAlignment=Alignment.Center) { CircularProgressIndicator(color=BubatzLime) }
                else LazyColumn(Modifier.weight(1f), contentPadding=PaddingValues(bottom=80.dp)) {
                    if (mode == "Künstler") {
                        itemsIndexed(visibleArtists, key={ _, entry -> "artist:"+entry.name.lowercase() }) { index, entry ->
                            val section = entry.name.firstOrNull()?.uppercaseChar()?.takeIf { it in 'A'..'Z' }?.toString() ?: "#"
                            val previousSection = visibleArtists.getOrNull(index - 1)?.name?.firstOrNull()?.uppercaseChar()?.takeIf { it in 'A'..'Z' }?.toString() ?: if (index > 0) "#" else null
                            if (index == 0 || section != previousSection) {
                                Text(section, color=BubatzLime.copy(alpha=.82f), fontSize=12.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(start=4.dp, top=12.dp, bottom=4.dp))
                            }
                            LibraryBrowseRow(entry.name, entry.count) { selectedArtist=entry.name }
                        }
                    } else if (mode == "Alben") {
                        items(visibleAlbums, key={"album:"+it.name.lowercase()}) { entry ->
                            LibraryAlbumBrowseRow(entry) { selectedAlbum=entry.name }
                        }
                    } else {
                        item {
                            Text("$titleTotal Titel insgesamt", color=BubatzSage, fontSize=11.sp, modifier=Modifier.padding(start=4.dp, top=6.dp, bottom=6.dp))
                        }
                        if (visibleTitles.isEmpty()) item { Text("Kein Titel gefunden", color=BubatzSage, fontSize=13.sp, modifier=Modifier.padding(18.dp)) }
                        items(visibleTitles, key={"title:"+it.id}) { entry ->
                            LibraryTrackBrowseRow(entry) { selectedTitleTrack = entry }
                        }
                        if (titleRawLoaded < titleTotal && !titleLoading) item {
                            OutlinedButton(onClick = {
                                titleLoading = true
                                scope.launch {
                                    val next = titlePage + 1
                                    val page = withContext(Dispatchers.IO) { db.tracks().archiveSearchTitlePage(ArchiveSearch.titles(terms, 100, next * 100)) }
                                    titleTracks = titleTracks + page
                                    titlePage = next
                                    titleRawLoaded += page.size
                                    titleLoading = false
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text("Weitere Titel laden") }
                        }
                    }
                }
            }
            selectedTitleTrack?.let { t ->
                LibraryTrackInfoSheet(
                    track = t,
                    onDismiss = { selectedTitleTrack = null },
                    onArtist = { selectedArtist = t.artist?.takeIf { it.isNotBlank() } },
                    onAlbum = { selectedAlbum = t.album?.takeIf { it.isNotBlank() } }
                )
            }
            // Keep the previous sheet composed underneath the next one. This preserves search,
            // artist and scroll state while drilling down and back up through the read-only archive.
            selectedArtist?.let { ArtistLibrarySheet(it, { selectedArtist=null }, { albumName -> selectedAlbum=albumName }, backLabel = if (selectedTitleTrack != null) "← Zurück zur Titelsuche" else null) }
            selectedAlbum?.let { albumName ->
                AlbumLibrarySheetByName(
                    album = albumName,
                    onDismiss = { selectedAlbum=null },
                    onBackToArtist = if (selectedArtist != null || selectedTitleTrack != null) ({ selectedAlbum=null }) else null,
                    backLabel = when { selectedArtist != null -> "← Zurück zum Künstler"; selectedTitleTrack != null -> "← Zurück zur Titelsuche"; else -> null }
                )
            }
        }
    }

    @Composable
    private fun LibraryTrackBrowseRow(track: TrackEntity, onClick: () -> Unit) {
        Row(Modifier.fillMaxWidth().clickable(onClick=onClick).padding(horizontal=4.dp, vertical=8.dp), verticalAlignment=Alignment.CenterVertically) {
            AlbumArtwork(track.uri, Modifier.size(46.dp))
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(track.title, fontFamily=bubatzMetadataFont(track.title), color=BubatzCream, fontSize=14.sp, fontWeight=FontWeight.SemiBold, maxLines=2, overflow=TextOverflow.Ellipsis)
                Text(track.artist?.takeIf { it.isNotBlank() } ?: "Unbekannter Interpret", color=BubatzSage, fontSize=11.sp, maxLines=1, overflow=TextOverflow.Ellipsis)
                track.album?.takeIf { it.isNotBlank() }?.let { Text(it, color=BubatzSage.copy(alpha=.78f), fontSize=10.sp, maxLines=1, overflow=TextOverflow.Ellipsis) }
            }
            Icon(Icons.Default.ChevronRight, null, tint=BubatzCream.copy(alpha=.68f), modifier=Modifier.size(20.dp))
        }
        HorizontalDivider(color=BubatzSage.copy(alpha=.12f), thickness=.5.dp)
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun LibraryTrackInfoSheet(track: TrackEntity, onDismiss: () -> Unit, onArtist: () -> Unit, onAlbum: () -> Unit) {
        var genre by remember(track.uri) { mutableStateOf<String?>(null) }
        var year by remember(track.uri) { mutableStateOf<String?>(null) }
        LaunchedEffect(track.uri) {
            val extra = withContext(Dispatchers.IO) { runCatching {
                val r=MediaMetadataRetriever(); try { r.setDataSource(this@MainActivity, Uri.parse(track.uri)); r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE) to r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR) } finally { r.release() }
            }.getOrNull() }
            genre=extra?.first; year=extra?.second
        }
        ModalBottomSheet(onDismissRequest=onDismiss, containerColor=BubatzDark.copy(alpha=.98f), contentColor=BubatzCream, shape=RoundedCornerShape(topStart=30.dp, topEnd=30.dp), dragHandle={BottomSheetDefaults.DragHandle(color=BubatzSage.copy(alpha=.85f))}) {
            Column(Modifier.fillMaxWidth().fillMaxHeight(0.90f).padding(horizontal=22.dp).padding(bottom=24.dp).navigationBarsPadding()) {
                Row(verticalAlignment=Alignment.CenterVertically) { Surface(shape=CircleShape,color=Color.Transparent,border=BorderStroke(1.5.dp,BubatzSage.copy(alpha=.9f)),modifier=Modifier.size(34.dp)){Box(contentAlignment=Alignment.Center){Icon(Icons.Default.Info,null,tint=BubatzSage,modifier=Modifier.size(20.dp))}}; Spacer(Modifier.width(12.dp)); Text("Inhaltsstoffe",fontSize=19.sp,fontWeight=FontWeight.SemiBold) }
                Spacer(Modifier.height(14.dp)); Row { AlbumArtwork(track.uri, Modifier.size(112.dp)); Spacer(Modifier.width(16.dp)); Column(Modifier.weight(1f)) { DetailInfoRow("Titel",track.title); DetailInfoRow("Interpret",track.artist.orEmpty(), onClick=if(!track.artist.isNullOrBlank()) onArtist else null); track.album?.takeIf{it.isNotBlank()}?.let{DetailInfoRow("Album",it,onClick=onAlbum)} } }
                genre?.takeIf{it.isNotBlank()}?.let{DetailInfoRow("Genre",it)}; year?.takeIf{it.isNotBlank()}?.let{DetailInfoRow("Jahr",it)}; if(track.durationMs>0) DetailInfoRow("Laufzeit",formatTime(track.durationMs))
                Spacer(Modifier.height(14.dp)); OutlinedButton(onClick=onDismiss, modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(18.dp), border=BorderStroke(1.dp,BubatzSage.copy(alpha=.8f)), colors=ButtonDefaults.outlinedButtonColors(contentColor=BubatzCream)){Text("← Zurück zur Titelsuche")}
            }
        }
    }

    @Composable
    private fun LibraryAlbumBrowseRow(entry: LibraryAlbumEntry, onClick: () -> Unit) {
        Surface(Modifier.fillMaxWidth().padding(vertical=4.dp).clickable(onClick=onClick), shape=RoundedCornerShape(16.dp), color=BubatzGreen.copy(alpha=.72f), border=BorderStroke(.7.dp,BubatzSage.copy(alpha=.4f))) {
            Row(Modifier.padding(10.dp), verticalAlignment=Alignment.CenterVertically) {
                Surface(Modifier.size(52.dp), shape=RoundedCornerShape(10.dp), color=BubatzGreen) {
                    LibraryAlbumThumbnail(entry.coverUri)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(entry.name, color=BubatzCream, fontSize=15.sp, fontWeight=FontWeight.SemiBold)
                    Text("${entry.count} Titel", color=BubatzSage, fontSize=11.sp)
                }
                Icon(Icons.Default.ChevronRight, null, tint=BubatzCream.copy(alpha=.75f))
            }
        }
    }

    @Composable
    private fun LibraryAlbumThumbnail(uri: String?) {
        // LazyColumn only composes visible rows, so artwork extraction happens only for
        // albums currently on screen. The shared Activity cache makes revisits instant.
        var artworkBytes by remember(uri) { mutableStateOf(cachedArtwork(uri)) }
        LaunchedEffect(uri) {
            if (uri.isNullOrBlank()) return@LaunchedEffect
            cachedArtwork(uri)?.let { artworkBytes = it; return@LaunchedEffect }
            val loaded = withContext(Dispatchers.IO) {
                runCatching {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(this@MainActivity, Uri.parse(uri))
                        retriever.embeddedPicture
                    } finally { retriever.release() }
                }.getOrNull()
            }
            cacheArtwork(uri, loaded)
            artworkBytes = loaded
        }
        val bitmap = remember(artworkBytes) {
            artworkBytes?.let { bytes -> runCatching { BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap() }.getOrNull() }
        }
        Box(Modifier.fillMaxSize().background(BubatzGreen), contentAlignment=Alignment.Center) {
            if (bitmap != null) Image(bitmap=bitmap, contentDescription="Albumcover", modifier=Modifier.fillMaxSize(), contentScale=ContentScale.Crop)
            else Image(painterResource(R.drawable.bubatz_placeholder_mini), "Bubatz FM", Modifier.fillMaxSize().padding(9.dp), contentScale=ContentScale.Fit)
        }
    }

    @Composable
    private fun LibraryBrowseRow(name: String, count: Int, onClick: () -> Unit) {
        Column(Modifier.fillMaxWidth().clickable(onClick=onClick)) {
            Row(Modifier.fillMaxWidth().padding(horizontal=4.dp, vertical=11.dp), verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(name, color=BubatzCream, fontSize=15.sp, fontWeight=FontWeight.SemiBold)
                    Spacer(Modifier.height(2.dp))
                    Text("$count Titel", color=BubatzSage.copy(alpha=.92f), fontSize=11.sp)
                }
                Icon(Icons.Default.ChevronRight, null, tint=BubatzCream.copy(alpha=.68f), modifier=Modifier.size(22.dp))
            }
            Box(Modifier.fillMaxWidth().padding(start=4.dp, end=4.dp).height(.5.dp).background(BubatzSage.copy(alpha=.18f)))
        }
    }

    private data class AlbumTagOrder(val track: TrackEntity, val discNumber: Int?, val trackNumber: Int?, val fileName: String)

    private fun sortAlbumTracksByTags(tracks: List<TrackEntity>): List<TrackEntity> {
        if (tracks.size < 2) return tracks
        fun leadingNumber(raw: String?): Int? = raw?.trim()?.substringBefore('/')?.trim()?.takeWhile { it.isDigit() }?.takeIf { it.isNotEmpty() }?.toIntOrNull()
        val tagged = tracks.map { track ->
            var disc: Int? = null
            var number: Int? = null
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(this, Uri.parse(track.uri))
                disc = leadingNumber(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DISC_NUMBER))
                number = leadingNumber(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CD_TRACK_NUMBER))
            } catch (_: Exception) {
                // Bad or unsupported metadata must never break the read-only library.
            } finally {
                try { retriever.release() } catch (_: Exception) {}
            }
            AlbumTagOrder(track, disc, number, Uri.parse(track.uri).lastPathSegment.orEmpty())
        }
        val hasDiscTags = tagged.any { it.discNumber != null }
        return tagged.sortedWith(compareBy<AlbumTagOrder>(
            { if (hasDiscTags && it.discNumber == null) 1 else 0 },
            { it.discNumber ?: 1 },
            { if (it.trackNumber == null) 1 else 0 },
            { it.trackNumber ?: Int.MAX_VALUE },
            { if (it.trackNumber == null) it.track.title.lowercase() else "" },
            { it.fileName.lowercase() }
        )).map { it.track }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun AlbumLibrarySheetByName(album: String, onDismiss: () -> Unit, onBackToArtist: (() -> Unit)? = null, backLabel: String? = null) {
        val db = (application as BubatzApplication).database
        var tracks by remember(album) { mutableStateOf<List<TrackEntity>>(emptyList()) }
        var loading by remember(album) { mutableStateOf(true) }
        LaunchedEffect(album) {
            loading = true
            tracks = withContext(Dispatchers.IO) { sortAlbumTracksByTags(db.tracks().tracksByAlbum(album)) }
            loading = false
        }
        if (loading) {
            ModalBottomSheet(onDismissRequest=onDismiss, containerColor=BubatzDark.copy(alpha=.98f), contentColor=BubatzCream) {
                Box(Modifier.fillMaxWidth().padding(42.dp), contentAlignment=Alignment.Center) { CircularProgressIndicator(color=BubatzLime) }
            }
        } else AlbumLibrarySheet(album, tracks, onDismiss, onBackToArtist, backLabel)
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun AlbumLibrarySheet(album: String, tracks: List<TrackEntity>, onDismiss: () -> Unit, onBackToArtist: (() -> Unit)? = null, backLabel: String? = null) {
        val songs = remember(tracks) { tracks }
        val total = remember(tracks) { tracks.sumOf { it.durationMs.coerceAtLeast(0L) } }
        val albumArtist = tracks.mapNotNull { it.albumArtist?.trim()?.takeIf(String::isNotBlank) }.distinct().singleOrNull()
            ?: if (tracks.mapNotNull { it.artist }.distinctBy { it.lowercase() }.size > 1) "Various Artists" else tracks.firstOrNull()?.artist
        ModalBottomSheet(onDismissRequest=onDismiss, containerColor=BubatzDark.copy(alpha=.98f), contentColor=BubatzCream, shape=RoundedCornerShape(topStart=30.dp, topEnd=30.dp), dragHandle={BottomSheetDefaults.DragHandle(color=BubatzSage.copy(alpha=.85f))}) {
            Column(Modifier.fillMaxWidth().padding(horizontal=22.dp).padding(bottom=24.dp).navigationBarsPadding()) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    AlbumArtwork(tracks.firstOrNull()?.uri, Modifier.size(82.dp)); Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) { Text(album, fontFamily=bubatzMetadataFont(album), fontSize=19.sp, fontWeight=FontWeight.SemiBold); albumArtist?.let { Text(it, color=BubatzSage, fontSize=12.sp) }; Text("${tracks.size} Titel · ${formatTime(total)} Gesamtlaufzeit", color=BubatzSage, fontSize=11.sp) }
                }
                Spacer(Modifier.height(8.dp)); Text("Nur Ansicht · keine Wiedergabe", color=BubatzLime.copy(alpha=.88f), fontSize=11.sp); Spacer(Modifier.height(10.dp))
                Column(Modifier.fillMaxWidth().weight(1f, fill = false).verticalScroll(rememberScrollState())) { songs.forEachIndexed { index,t ->
                    Row(Modifier.fillMaxWidth().padding(vertical=7.dp), verticalAlignment=Alignment.CenterVertically) { Text((index+1).toString().padStart(2,'0'), color=BubatzSage, fontSize=11.sp, modifier=Modifier.width(28.dp)); Column(Modifier.weight(1f)) { Text(t.title, color=BubatzCream, fontSize=13.sp); Text(t.artist ?: "Unbekannter Interpret", color=BubatzSage, fontSize=10.sp) }; if(t.durationMs>0) Text(formatTime(t.durationMs), color=BubatzSage, fontSize=11.sp) }; HorizontalDivider(color=BubatzSage.copy(alpha=.12f), thickness=.5.dp) } }
                Spacer(Modifier.height(12.dp)); OutlinedButton(onClick=onBackToArtist ?: onDismiss, modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(18.dp), border=BorderStroke(1.dp,BubatzSage.copy(alpha=.8f)), colors=ButtonDefaults.outlinedButtonColors(contentColor=BubatzCream)) { Text(backLabel ?: if (onBackToArtist != null) "← Zurück zum Künstler" else "Schließen") }
            }
        }
    }

    @Composable
    private fun LandscapeNowPlayingContent(
        track: TrackEntity?,
        isRadio: Boolean,
        useOmnia: Boolean,
        title: String,
        artist: String,
        album: String,
        programSlot: ProgramSlot,
        duration: Long,
        shownPosition: Long,
        isPlaying: Boolean,
        onOpenMenu: () -> Unit,
        onShowProgram: () -> Unit,
        onInfo: () -> Unit,
        onArtist: () -> Unit,
        onHistoryArtist: (String) -> Unit,
        onHistoryAlbum: (String) -> Unit,
        onSeek: (Long) -> Unit,
        onPrevious: () -> Unit,
        onPlayPause: () -> Unit,
        onNext: () -> Unit
    ) {
        val db = (application as BubatzApplication).database
        val recent by db.history().observeRecentMusic(8).collectAsState(initial = emptyList())
        var landscapeHistoryInfo by remember { mutableStateOf<RecentMusicItem?>(null) }
        var seekValue by remember(shownPosition, duration) { mutableFloatStateOf(if (duration > 0L) (shownPosition.toFloat() / duration).coerceIn(0f, 1f) else 0f) }

        Row(
            Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Left: artwork. Same artwork pipeline as portrait, only rearranged.
            Column(Modifier.weight(0.92f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth().height(82.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onOpenMenu,
                        modifier = Modifier.size(52.dp).offset(x = (-26).dp, y = (-28).dp)
                    ) {
                        Icon(Icons.Default.Menu, "Menü", tint = BubatzLime, modifier = Modifier.size(34.dp))
                    }
                    Image(
                        painterResource(R.drawable.bubatz_logo_landscape_stacked),
                        "Bubatz FM",
                        Modifier.weight(1f).fillMaxHeight().padding(end = 4.dp),
                        contentScale = ContentScale.Fit
                    )
                }
                Spacer(Modifier.height(3.dp))
                Surface(
                    modifier = Modifier.weight(1f).aspectRatio(1f),
                    shape = RoundedCornerShape(22.dp), color = BubatzGreen, tonalElevation = 4.dp
                ) {
                    if (isRadio || useOmnia) {
                        Image(painterResource(if (useOmnia) R.drawable.bubatz_app_icon_dark else R.drawable.bubatz_placeholder_cover), null, Modifier.fillMaxSize().padding(if (useOmnia) 36.dp else 0.dp), contentScale = ContentScale.Fit)
                    } else AlbumArtwork(track?.uri, Modifier.fillMaxSize())
                }
            }

            // Centre: current programme, metadata and the familiar transport controls.
            Column(Modifier.weight(1.15f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Surface(
                    modifier = Modifier.fillMaxWidth().height(56.dp).clickable { onShowProgram() },
                    shape = RoundedCornerShape(18.dp),
                    color = BubatzDark.copy(alpha = .82f),
                    border = BorderStroke(1.dp, BubatzLime.copy(alpha = .78f))
                ) {
                    // Keep the landscape live box as one rigid structure: symbol | JETZT: |
                    // two-line programme block | chevron.  Do not position the three texts
                    // independently; that caused the programme/time block to drift vertically.
                    Row(
                        Modifier.fillMaxSize().padding(horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        LandscapeMiniBroccoliRadio(Modifier.width(47.dp).fillMaxHeight())
                        Spacer(Modifier.width(4.dp))
                        Box(Modifier.width(39.dp).fillMaxHeight(), contentAlignment = Alignment.CenterStart) {
                            Text("JETZT:", fontFamily = PlusJakartaSans, color = BubatzLime.copy(alpha = 0.96f), fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Spacer(Modifier.width(1.dp))
                        Column(
                            Modifier.weight(1f).padding(start = 3.dp),
                            verticalArrangement = Arrangement.spacedBy((-4).dp),
                            horizontalAlignment = Alignment.Start
                        ) {
                            Text(
                                programSlot.name.uppercase(), fontFamily = PlusJakartaSans, color = BubatzCream.copy(alpha = 0.96f), fontSize = 13.5.sp,
                                modifier = Modifier.offset(y = 2.dp),
                                fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            Row(Modifier.offset(y = (-2).dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Schedule, null, tint = BubatzCream.copy(alpha = 0.90f), modifier = Modifier.size(11.dp))
                                Spacer(Modifier.width(3.dp))
                                Text("BIS ${programSlot.endLabel}", fontFamily = PlusJakartaSans, color = BubatzCream.copy(alpha = 0.90f), fontSize = 10.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                            }
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = BubatzCream.copy(alpha=.75f), modifier = Modifier.size(21.dp))
                    }
                }
                Spacer(Modifier.height(9.dp))
                Text(title, fontFamily = bubatzMetadataFont(title), color = BubatzCream, fontSize = 21.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(3.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                    Text(artist, fontFamily = bubatzMetadataFont(artist), color = if (isRadio) BubatzGold else BubatzPlayerSecondary, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = if (!isRadio) Modifier.clickable { onArtist() } else Modifier)
                    if (!isRadio) { Spacer(Modifier.width(5.dp)); IconButton(onClick = onInfo, modifier = Modifier.size(24.dp)) { Icon(Icons.Default.Info, "Inhaltsstoffe", tint = BubatzPlayerSecondary, modifier = Modifier.size(17.dp)) } }
                }
                if (album.isNotBlank()) Text(album, color = BubatzPlayerSecondary.copy(alpha=.96f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(6.dp))
                CompactSeekBar(
                    value = seekValue,
                    enabled = duration > 0L && !isRadio,
                    onValueChange = { seekValue = it.coerceIn(0f, 1f) },
                    onValueChangeFinished = {
                        if (duration > 0L && !isRadio) {
                            onSeek((duration * seekValue).toLong().coerceIn(0L, duration))
                        }
                    }
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(formatTime((duration * seekValue).toLong()), color = BubatzPlayerSecondary, fontSize = 10.sp)
                    Text(formatTime(duration), color = BubatzPlayerSecondary, fontSize = 10.sp)
                }
                Spacer(Modifier.height(2.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    SoftGlowControl { IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, "Vorheriger Titel", tint = BubatzCream, modifier = Modifier.size(31.dp)) } }
                    SoftGlowControl(glowRadius = 40.dp, glowAlpha = .11f) { FilledIconButton(onClick = onPlayPause, modifier = Modifier.size(62.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor=BubatzCream, contentColor=BubatzDark)) { Icon(if(isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, if(isPlaying) "Pause" else "Play", modifier=Modifier.size(34.dp)) } }
                    SoftGlowControl { IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "Nächster Titel", tint = BubatzCream, modifier = Modifier.size(31.dp)) } }
                }
                Spacer(Modifier.height(2.dp))
                val landscapeIqTransition = rememberInfiniteTransition(label = "landscapeBubatzIqGlow")
                val landscapeIqGlow by landscapeIqTransition.animateFloat(
                    initialValue = 0.28f,
                    targetValue = 0.92f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(durationMillis = 4800, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "landscapeBubatzIqGlowStrength"
                )
                val landscapeIqCore = androidx.compose.ui.graphics.lerp(
                    BubatzSage, Color(0xFFD6FF9A), landscapeIqGlow * 0.72f
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Shuffle, null, tint = BubatzLime, modifier = Modifier.size(22.dp).graphicsLayer {
                            alpha = 0.14f + landscapeIqGlow * 0.24f
                            renderEffect = BlurEffect(13f, 13f, TileMode.Decal)
                        })
                        Icon(Icons.Default.Shuffle, null, tint = BubatzLime, modifier = Modifier.size(20.dp).graphicsLayer {
                            alpha = 0.22f + landscapeIqGlow * 0.30f
                            renderEffect = BlurEffect(6f, 6f, TileMode.Decal)
                        })
                        Icon(Icons.Default.Shuffle, null, tint = landscapeIqCore, modifier = Modifier.size(17.dp))
                    }
                    Spacer(Modifier.width(5.dp))
                    Box(contentAlignment = Alignment.CenterStart) {
                        Text(
                            "BUBATZ.IQ", color = Color.Transparent, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                            style = androidx.compose.ui.text.TextStyle(shadow = androidx.compose.ui.graphics.Shadow(
                                color = BubatzLime.copy(alpha = 0.18f + landscapeIqGlow * 0.32f),
                                offset = androidx.compose.ui.geometry.Offset.Zero, blurRadius = 24f
                            ))
                        )
                        Text(
                            "BUBATZ.IQ", color = landscapeIqCore, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                            style = androidx.compose.ui.text.TextStyle(shadow = androidx.compose.ui.graphics.Shadow(
                                color = BubatzLime.copy(alpha = 0.42f + landscapeIqGlow * 0.58f),
                                offset = androidx.compose.ui.geometry.Offset.Zero, blurRadius = 10f
                            ))
                        )
                    }
                }
            }

            // Right: compact read-only glance at the latest music titles.
            Column(Modifier.weight(.88f).fillMaxHeight().padding(start = 8.dp, top = 8.dp)) {
                Text("Zuletzt gehört", color=BubatzCream, fontSize=17.sp, fontWeight=FontWeight.SemiBold)
                Text("Tippe auf einen Titel für Infos", color=BubatzSage, fontSize=9.sp)
                Spacer(Modifier.height(8.dp))
                if (recent.isEmpty()) Text("Noch nichts gehört", color=BubatzSage, fontSize=12.sp)
                else recent.take(5).forEachIndexed { index, item ->
                    Row(
                        Modifier.fillMaxWidth().clickable { landscapeHistoryInfo = item }.padding(vertical=6.dp),
                        verticalAlignment=Alignment.CenterVertically
                    ) {
                        Surface(Modifier.size(38.dp), shape=RoundedCornerShape(7.dp), color=BubatzGreen) { HistoryMiniArtwork(item.uri, Modifier.fillMaxSize()) }
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.title, color=BubatzCream, fontSize=11.sp, fontWeight=FontWeight.Medium, maxLines=1, overflow=TextOverflow.Ellipsis)
                            Text(item.artist ?: "Unbekannter Interpret", color=BubatzRecentArtist, fontSize=9.sp, maxLines=1, overflow=TextOverflow.Ellipsis)
                        }
                        IconButton(onClick = { landscapeHistoryInfo = item }, modifier = Modifier.size(26.dp)) {
                            Icon(Icons.Default.Info, "Inhaltsstoffe", tint = BubatzSage.copy(alpha=.88f), modifier = Modifier.size(15.dp))
                        }
                    }
                    if(index < minOf(4,recent.size-1)) HorizontalDivider(color=BubatzSage.copy(alpha=.13f), thickness=.5.dp)
                }
            }
        }
        landscapeHistoryInfo?.let { selected ->
            HistoryTrackInfoSheet(
                selected,
                onDismiss = { landscapeHistoryInfo = null },
                onArtist = { onHistoryArtist(it); landscapeHistoryInfo = null },
                onAlbum = { onHistoryAlbum(it); landscapeHistoryInfo = null }
            )
        }
    }

    @Composable
    private fun HistoryMiniArtwork(uri: String, modifier: Modifier = Modifier) {
        var bytes by remember(uri) { mutableStateOf(cachedArtwork(uri)) }
        LaunchedEffect(uri) {
            if (bytes == null) {
                bytes = withContext(Dispatchers.IO) {
                    runCatching {
                        val retriever = MediaMetadataRetriever()
                        try {
                            retriever.setDataSource(this@MainActivity, Uri.parse(uri))
                            retriever.embeddedPicture
                        } finally { retriever.release() }
                    }.getOrNull()
                }
                cacheArtwork(uri, bytes)
            }
        }
        Box(modifier.background(BubatzGreen), contentAlignment=Alignment.Center) {
            val b = bytes
            if (b != null) {
                val bmp = remember(b) { BitmapFactory.decodeByteArray(b,0,b.size)?.asImageBitmap() }
                if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale=ContentScale.Crop)
            } else Image(painterResource(R.drawable.bubatz_app_icon_dark), null, Modifier.fillMaxSize().padding(7.dp), contentScale=ContentScale.Fit)
        }
    }

    @Composable
    private fun RecentHistoryScreen(modifier: Modifier = Modifier) {
        val db = (application as BubatzApplication).database
        val recent by db.history().observeRecentMusic(50).collectAsState(initial = emptyList())
        var infoItem by remember { mutableStateOf<RecentMusicItem?>(null) }
        var artistBrowserName by rememberSaveable { mutableStateOf<String?>(null) }
        var albumBrowserName by rememberSaveable { mutableStateOf<String?>(null) }

        Box(modifier.fillMaxSize().background(BubatzDark)) {
            Image(
                painter = painterResource(R.drawable.bubatz_player_background),
                contentDescription = null,
                modifier = Modifier.matchParentSize(),
                contentScale = ContentScale.Crop,
                alpha = 0.72f
            )
            Box(Modifier.matchParentSize().background(BubatzDark.copy(alpha = 0.32f)))

            // Lazy rendering is important here: the old scroll Column composed all 50 rows at
            // once and started up to 50 MediaMetadataRetriever jobs when the drawer entry was tapped.
            // Only visible rows now request artwork, keeping navigation responsive.
            val historyListState = rememberLazyListState()
            LazyColumn(
                state = historyListState,
                modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 88.dp)
            ) {
                item {
                    Image(
                        painter = painterResource(R.drawable.bubatz_logo_player_cutout),
                        contentDescription = "Bubatz FM",
                        modifier = Modifier.fillMaxWidth().height(70.dp).padding(horizontal = 34.dp),
                        contentScale = ContentScale.Fit, alpha = 0.92f
                    )
                    Spacer(Modifier.height(18.dp))
                    Text("Wer war das gerade?", color = BubatzCream, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text("Die letzten 50 Musiktitel · Einspieler werden nicht aufgeführt", color = BubatzSage, fontSize = 13.sp, lineHeight = 18.sp)
                    Spacer(Modifier.height(16.dp))
                }
                if (recent.isEmpty()) {
                    item { SettingsCard("Noch nichts gehört") { Text("Sobald Bubatz.FM Musik abspielt, tauchen die zuletzt gehörten Titel hier auf.", color = BubatzSage, fontSize = 13.sp) } }
                } else {
                    itemsIndexed(recent, key = { _, item -> item.historyId }) { index, item ->
                        RecentHistoryRow(item, isLatest = index == 0, allowArtworkLoad = !historyListState.isScrollInProgress, onInfo = { infoItem = item })
                        Spacer(Modifier.height(7.dp))
                    }
                }
            }

            infoItem?.let { selected ->
                HistoryTrackInfoSheet(selected, onDismiss = { infoItem = null }, onArtist = { artistBrowserName = it; infoItem = null }, onAlbum = { albumBrowserName = it; infoItem = null })
            }
            artistBrowserName?.let { selectedArtist ->
                ArtistLibrarySheet(selectedArtist, { artistBrowserName = null }, { albumName -> albumBrowserName = albumName })
            }
            albumBrowserName?.let { selectedAlbum ->
                AlbumLibrarySheetByName(
                    album = selectedAlbum,
                    onDismiss = { albumBrowserName = null },
                    onBackToArtist = if (artistBrowserName != null) ({ albumBrowserName = null }) else null
                )
            }
        }
    }

    @Composable
    private fun RecentHistoryRow(item: RecentMusicItem, isLatest: Boolean = false, allowArtworkLoad: Boolean = true, onInfo: () -> Unit) {
        var artworkBytes by remember(item.trackId) { mutableStateOf(cachedArtwork(item.uri)) }
        LaunchedEffect(item.trackId, item.uri, allowArtworkLoad) {
            cachedArtwork(item.uri)?.let { artworkBytes = it; return@LaunchedEffect }
            if (!allowArtworkLoad) return@LaunchedEffect
            artworkBytes = withContext(Dispatchers.IO) {
                runCatching {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(this@MainActivity, Uri.parse(item.uri))
                        retriever.embeddedPicture
                    } finally {
                        retriever.release()
                    }
                }.getOrNull()
            }
            cacheArtwork(item.uri, artworkBytes)
        }
        val bitmap = remember(artworkBytes) {
            artworkBytes?.let { bytes ->
                runCatching { BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap() }.getOrNull()
            }
        }
        Card(
            onClick = { playTrackFromHistory(item.trackId) },
            colors = CardDefaults.cardColors(containerColor = BubatzGreen.copy(alpha = 0.72f)),
            border = BorderStroke(
                if (isLatest) 1.2.dp else 0.7.dp,
                if (isLatest) Color(0xFF9BEA45).copy(alpha = 0.82f) else BubatzSage.copy(alpha = 0.42f)
            ),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.padding(horizontal = 11.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Fester Statusbereich: alle Cover bleiben exakt in einer Flucht.
                    Box(Modifier.width(12.dp), contentAlignment = Alignment.CenterStart) {
                        if (isLatest) {
                            Box(Modifier.size(9.dp).background(Color(0xFF9BEA45), CircleShape))
                        }
                    }
                    Spacer(Modifier.width(5.dp))
                    Surface(
                    modifier = Modifier.size(54.dp),
                    shape = RoundedCornerShape(10.dp),
                    color = BubatzMid
                ) {
                    if (bitmap != null) {
                        Image(bitmap = bitmap, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    } else {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Image(
                                painter = painterResource(R.drawable.bubatz_placeholder_mini),
                                contentDescription = null,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize().padding(7.dp)
                            )
                        }
                    }
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        item.title,
                        fontFamily = bubatzMetadataFont(item.title),
                        color = BubatzCream,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        item.artist ?: "Unbekannter Interpret",
                        fontFamily = bubatzMetadataFont(item.artist ?: "Unbekannter Interpret"),
                        color = BubatzRecentArtist,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(formatHistoryTime(item.playedAt), color = BubatzSage.copy(alpha = 0.78f), fontSize = 11.sp)
                }
                Spacer(Modifier.width(6.dp))
                    IconButton(
                        onClick = onInfo,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Surface(
                            modifier = Modifier.size(28.dp),
                            shape = CircleShape,
                            color = BubatzDark.copy(alpha = 0.34f),
                            border = BorderStroke(0.8.dp, BubatzSage.copy(alpha = 0.60f))
                        ) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Info, "Inhaltsstoffe", tint = BubatzCream.copy(alpha = 0.92f), modifier = Modifier.size(17.dp))
                            }
                        }
                    }
                    Spacer(Modifier.width(4.dp))
                    Surface(
                        modifier = Modifier.size(40.dp),
                        shape = CircleShape,
                        color = BubatzDark.copy(alpha = 0.48f),
                        border = BorderStroke(0.8.dp, BubatzSage.copy(alpha = 0.55f))
                    ) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.PlayArrow,
                                "Erneut abspielen",
                                tint = BubatzCream,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun HistoryTrackInfoSheet(item: RecentMusicItem, onDismiss: () -> Unit, onArtist: (String) -> Unit, onAlbum: (String) -> Unit) {
        var genre by remember(item.trackId) { mutableStateOf<String?>(null) }
        var year by remember(item.trackId) { mutableStateOf<String?>(null) }
        var durationMs by remember(item.trackId) { mutableLongStateOf(0L) }
        LaunchedEffect(item.trackId, item.uri) {
            val extra = withContext(Dispatchers.IO) {
                runCatching {
                    val r = MediaMetadataRetriever()
                    try {
                        r.setDataSource(this@MainActivity, Uri.parse(item.uri))
                        Triple(
                            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE),
                            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR),
                            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                        )
                    } finally { r.release() }
                }.getOrNull()
            }
            genre = extra?.first
            year = extra?.second
            durationMs = extra?.third ?: 0L
        }
        val infoLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
        ModalBottomSheet(
            onDismissRequest = onDismiss,
            containerColor = BubatzDark.copy(alpha = 0.96f),
            contentColor = BubatzCream,
            shape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp),
            dragHandle = { BottomSheetDefaults.DragHandle(color = BubatzSage.copy(alpha = 0.85f)) }
        ) {
            if (infoLandscape) {
                LandscapeTrackInfoContent(
                    title = item.title,
                    artist = item.artist ?: "Unbekannter Interpret",
                    album = item.album,
                    uri = item.uri,
                    genre = genre,
                    year = year,
                    durationMs = durationMs,
                    onArtist = item.artist?.takeIf { it.isNotBlank() }?.let { artistName -> { onArtist(artistName) } },
                    onAlbum = item.album?.takeIf { it.isNotBlank() }?.let { albumName -> { onAlbum(albumName) } },
                    onDismiss = onDismiss
                )
            } else {
                Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = CircleShape, color = Color.Transparent, border = BorderStroke(1.5.dp, BubatzSage.copy(alpha = 0.9f)), modifier = Modifier.size(34.dp)) {
                            Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Info, null, tint = BubatzSage, modifier = Modifier.size(20.dp)) }
                        }
                        Spacer(Modifier.width(12.dp))
                        Text("Inhaltsstoffe", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.height(16.dp))
                    Box(Modifier.fillMaxWidth().height(166.dp), contentAlignment = Alignment.Center) {
                        Surface(Modifier.size(166.dp), shape = RoundedCornerShape(18.dp), color = BubatzGreen) { AlbumArtwork(item.uri, Modifier.fillMaxSize()) }
                        Box(Modifier.align(Alignment.CenterEnd).padding(end = 8.dp)) { ShareTrackIcon(title = item.title, artist = item.artist ?: "Unbekannter Interpret", uri = item.uri) }
                    }
                    Spacer(Modifier.height(16.dp))
                    DetailInfoRow("Titel", item.title)
                    DetailInfoRow("Interpret", item.artist ?: "Unbekannter Interpret", onClick = item.artist?.takeIf { it.isNotBlank() }?.let { artistName -> { onArtist(artistName) } })
                    item.album?.takeIf { it.isNotBlank() }?.let { albumName -> DetailInfoRow("Album", albumName, onClick = { onAlbum(albumName) }) }
                    genre?.takeIf { it.isNotBlank() }?.let { DetailInfoRow("Genre", it) }
                    year?.takeIf { it.isNotBlank() }?.let { DetailInfoRow("Jahr", it) }
                    if (durationMs > 0L) DetailInfoRow("Laufzeit", formatTime(durationMs))
                    Spacer(Modifier.height(18.dp))
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, BubatzSage.copy(alpha = 0.8f)), colors = ButtonDefaults.outlinedButtonColors(contentColor = BubatzCream)) { Text("Schließen", fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                    Spacer(Modifier.height(12.dp))
                    Text("Musik teilen. Gute Vibes weitergeben. 🥦", color = BubatzSage.copy(alpha = 0.72f), fontSize = 11.sp)
                }
            }
        }
    }

    @Composable
    private fun SettingsScreen(modifier: Modifier = Modifier) {
        val db = (application as BubatzApplication).database
        val scope = rememberCoroutineScope()
        val settings = remember { AppSettings(this) }
        LaunchedEffect(Unit) { settings.ensureDurablePersistence() }

        val musicCount by db.tracks().observeCount().collectAsState(initial = 0)
        val clipCount by db.clips().observeCount().collectAsState(initial = 0)
        val autoBt by settings.autoBluetooth.collectAsState(initial = true)
        val autoBtAll by settings.autoBluetoothAllDevices.collectAsState(initial = true)
        val selectedBt by settings.autoBluetoothDeviceAddresses.collectAsState(initial = emptySet())
        val skipOnce by settings.autoBluetoothSkipOnce.collectAsState(initial = false)
        val crossfade by settings.crossfadeMs.collectAsState(initial = 6500)
        val radioEnabled by settings.radioEnabled.collectAsState(initial = true)
        val lastFmEnabled by settings.lastFmEnabled.collectAsState(initial = false)
        val doNotDisturbCalls by settings.doNotDisturbCalls.collectAsState(initial = false)

        val pairedDevices = remember { BluetoothDeviceRepository(this).pairedAudioDevices() }

        val lastFmStore = remember { LastFmSessionStore(this) }
        val lastFmAuth = remember { LastFmAuthCoordinator(this) }
        var lastFmUser by remember { mutableStateOf(lastFmStore.username) }
        var lastFmStatus by remember {
            mutableStateOf(if (lastFmUser != null) "Verbunden als $lastFmUser" else "Nicht verbunden")
        }
        var lastFmApiKey by remember { mutableStateOf(lastFmStore.apiKey.orEmpty()) }
        var lastFmSecret by remember { mutableStateOf(lastFmStore.sharedSecret.orEmpty()) }
        var lastFmHasApiCredentials by remember { mutableStateOf(lastFmStore.hasApiCredentials) }
        var developerLabOpen by remember { mutableStateOf(false) }

        var status by remember { mutableStateOf(ScanDiagnostics(this).read()) }

        val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            uri ?: return@rememberLauncherForActivityResult
            persist(uri)
            status = "Bibliotheksscan läuft im Vordergrunddienst. Fortschritt in der Benachrichtigung."
            ScanDiagnostics(this@MainActivity).save(status)
            androidx.core.content.ContextCompat.startForegroundService(
                this@MainActivity,
                Intent(this@MainActivity, fm.bubatz.player.library.LibraryScanService::class.java)
                    .setAction(fm.bubatz.player.library.LibraryScanService.ACTION_SCAN)
                    .putExtra(fm.bubatz.player.library.LibraryScanService.EXTRA_TREE_URI, uri.toString())
            )
        }

        val clipPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            uri ?: return@rememberLauncherForActivityResult
            persist(uri)
            scope.launch {
                status = "Einspieler werden eingelesen …"
                val items = LibraryScanner(this@MainActivity).scanRadio(uri)
                db.withTransaction {
                    db.clips().disableAll()
                    items.chunked(500).forEach { chunk ->
                        db.clips().insertAll(chunk)
                        db.clips().enableByUris(chunk.map { it.uri })
                    }
                }
                status = "${items.size} Einspieler aktiv · Ordner abgeglichen"
            }
        }

        Box(
            modifier = modifier
                .fillMaxSize()
                .background(BubatzDark)
        ) {
            Image(
                painter = painterResource(R.drawable.bubatz_player_background),
                contentDescription = null,
                modifier = Modifier.matchParentSize(),
                contentScale = ContentScale.Crop,
                alpha = 0.34f
            )
            Box(Modifier.matchParentSize().background(BubatzDark.copy(alpha = 0.52f)))

            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp, vertical = 14.dp)
            ) {
            Image(
                painterResource(R.drawable.bubatz_logo_player_cutout),
                "Bubatz FM",
                Modifier.fillMaxWidth().height(70.dp),
                contentScale = ContentScale.Fit
            )
            Text(
                "Einstellungen",
                color = BubatzSage,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.align(Alignment.End)
            )
            Spacer(Modifier.height(12.dp))

            SettingsCard("Bitte nicht stören!") {
                SettingSwitch(
                    "Anrufe ignorieren und Musik weiterspielen",
                    doNotDisturbCalls
                ) { enabled ->
                    scope.launch { settings.setDoNotDisturbCalls(enabled) }
                }
                Text(
                    if (doNotDisturbCalls)
                        "Aktiv: Auch bei Telefonanrufen spielt Bubatz weiter."
                    else
                        "Standard: Eingehende und aktive Telefonanrufe pausieren Bubatz. Danach geht es nur weiter, wenn der Anruf die Pause ausgelöst hat. Benachrichtigungstöne bleiben ohne Einfluss.",
                    color = BubatzSage,
                    fontSize = 12.sp
                )
                if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                    Spacer(Modifier.height(8.dp))
                    Text("Telefonberechtigung fehlt – die Anrufpause kann sonst nicht funktionieren.", color = BubatzGold, fontSize = 11.sp)
                    OutlinedButton(onClick = {
                        requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE), 52)
                    }) { Text("Telefonberechtigung erlauben") }
                }
            }

            Spacer(Modifier.height(8.dp))

            SettingsCard("Bluetooth Auto-Start") {
                SettingSwitch(
                    "Automatisch bei Bluetooth-Audio starten",
                    autoBt
                ) { scope.launch { settings.setAutoBluetooth(it) } }

                if (autoBt) {
                    SettingSwitch("Alle Bluetooth-Audiogeräte", autoBtAll) {
                        scope.launch { settings.setAutoBluetoothAllDevices(it) }
                    }

                    if (!autoBtAll) {
                        pairedDevices.forEach { device ->
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = device.address in selectedBt,
                                    onCheckedChange = { enabled ->
                                        scope.launch {
                                            settings.setAutoBluetoothDeviceEnabled(device.address, enabled)
                                        }
                                    }
                                )
                                Text(device.name, color = BubatzCream)
                            }
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { scope.launch { settings.suppressNextBluetoothAutoStart() } },
                        enabled = !skipOnce,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(42.dp),
                        shape = RoundedCornerShape(15.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                    ) {
                        Text(
                            if (skipOnce) "Nächster Auto-Start wird übersprungen"
                            else "Beim nächsten Verbinden still bleiben",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            SettingsCard("Crossfade") {
                Text("${crossfade / 1000.0} Sekunden · nur Musik → Musik", color = BubatzSage, fontSize = 12.sp)
                Slider(
                    value = crossfade.toFloat(),
                    onValueChange = { value -> scope.launch { settings.setCrossfadeMs(value.toInt()) } },
                    valueRange = 0f..15000f,
                    steps = 14
                )
                Text("Einspieler werden niemals überblendet.", color = BubatzGold, fontSize = 12.sp)
            }

            Spacer(Modifier.height(8.dp))

            SettingsCard("Radioeinspieler") {
                SettingSwitch(
                    "Automatische Einspieler aktiv",
                    radioEnabled
                ) { enabled ->
                    scope.launch { settings.setRadioEnabled(enabled) }
                }
                Text(
                    "Bei aktivierter Funktion ungefähr alle 25–35 Minuten tatsächlich gehörter Musik. Pausen und Einspieler zählen nicht. Einspieler werden nie überblendet und nie gescrobbelt.",
                    color = BubatzSage,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { sendPlaybackAction(PlaybackService.ACTION_TEST_RADIO_INSERT) }) {
                    Text("Einspieler jetzt testen")
                }
            }

            Spacer(Modifier.height(8.dp))

            Spacer(Modifier.height(8.dp))

            SettingsCard("Bibliothek") {
                Text("$musicCount Musiktitel · $clipCount Einspieler", color = BubatzCream, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                Text(status, color = BubatzSage, fontSize = 12.sp)
                val scanPrefs = remember { getSharedPreferences("library_scan_state", MODE_PRIVATE) }
                val savedPhase = scanPrefs.getString("phase", "").orEmpty()
                if (savedPhase in setOf("metadata", "timed_out_metadata", "metadata_error")) {
                    OutlinedButton(onClick = {
                        status = "Metadatenprüfung wird fortgesetzt …"
                        androidx.core.content.ContextCompat.startForegroundService(
                            this@MainActivity,
                            Intent(this@MainActivity, fm.bubatz.player.library.LibraryScanService::class.java)
                                .setAction(fm.bubatz.player.library.LibraryScanService.ACTION_RESUME_METADATA)
                        )
                    }) { Text("Metadaten fortsetzen") }
                } else if (savedPhase == "timed_out_enumerating") {
                    Text("Ordnerscan unterbrochen: Bitte Musikordner erneut auswählen.", color = BubatzSage, fontSize = 12.sp)
                }
                if (savedPhase == "complete") {
                    OutlinedButton(onClick = {
                        status = "Fehlerhafte Metadaten werden erneut geprüft …"
                        androidx.core.content.ContextCompat.startForegroundService(
                            this@MainActivity,
                            Intent(this@MainActivity, fm.bubatz.player.library.LibraryScanService::class.java)
                                .setAction(fm.bubatz.player.library.LibraryScanService.ACTION_RETRY_FAILED)
                        )
                    }) { Text("Fehlerhafte Dateien erneut prüfen") }
                }

                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SettingsActionButton(
                        label = "Musikordner",
                        icon = Icons.Default.Folder,
                        onClick = { musicPicker.launch(null) },
                        modifier = Modifier.weight(1f)
                    )
                    SettingsActionButton(
                        label = "Einspieler",
                        icon = Icons.Default.Podcasts,
                        onClick = { clipPicker.launch(null) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            Spacer(Modifier.height(8.dp))

            var showFlowResetDialog by remember { mutableStateOf(false) }
            SettingsCard("Bubatz.IQ") {
                Text(
                    "Abwechslungsreiche Wiedergabe mit stärkerer Künstlerdurchmischung und eigenem Bubatz.IQ-Zyklus.",
                    color = BubatzSage,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { showFlowResetDialog = true }) {
                    Text("Bubatz.IQ neu mischen")
                }
            }
            if (showFlowResetDialog) {
                AlertDialog(
                    onDismissRequest = { showFlowResetDialog = false },
                    title = { Text("Bubatz.IQ neu mischen?") },
                    text = { Text("Der aktuelle Bubatz.IQ-Zyklus beginnt von vorn. Hörhistorie, Playcounts und Last.fm bleiben vollständig erhalten.") },
                    confirmButton = {
                        TextButton(onClick = {
                            FlowCycleStore(this@MainActivity).newCycle()
                            showFlowResetDialog = false
                        }) { Text("Neu mischen") }
                    },
                    dismissButton = {
                        TextButton(onClick = { showFlowResetDialog = false }) { Text("Abbrechen") }
                    }
                )
            }

            Spacer(Modifier.height(8.dp))

            SettingsCard("Last.fm · v1.01") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Scrobbling", color = BubatzCream, fontWeight = FontWeight.SemiBold)
                        Text(
                            if (lastFmEnabled) "Aktiv" else "Ausgeschaltet",
                            color = BubatzSage,
                            fontSize = 12.sp
                        )
                    }
                    BubatzSlimSwitch(
                        checked = lastFmEnabled,
                        onCheckedChange = { enabled ->
                            scope.launch { settings.setLastFmEnabled(enabled) }
                        }
                    )
                }

                Spacer(Modifier.height(8.dp))
                Text(lastFmStatus, color = BubatzSage, fontSize = 12.sp)
                Text(
                    "Account und Scrobbling sind unabhängig: Du kannst den Account wechseln oder Scrobbling komplett abschalten.",
                    color = BubatzSage,
                    fontSize = 11.sp
                )

                if (!lastFmHasApiCredentials) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Für die Last.fm-API braucht Bubatz einmalig einen API-Key und Shared Secret. Sie werden verschlüsselt nur auf diesem Gerät gespeichert und nicht in das Projekt eingebaut.",
                        color = BubatzCream,
                        fontSize = 11.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = lastFmApiKey,
                        onValueChange = { lastFmApiKey = it },
                        label = { Text("Last.fm API-Key") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = lastFmSecret,
                        onValueChange = { lastFmSecret = it },
                        label = { Text("Shared Secret") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(
                        enabled = lastFmApiKey.isNotBlank() && lastFmSecret.isNotBlank(),
                        onClick = {
                            lastFmStore.saveApiCredentials(lastFmApiKey, lastFmSecret)
                            lastFmHasApiCredentials = true
                            lastFmStatus = "API-Zugang gespeichert · Account noch nicht verbunden"
                        }
                    ) { Text("API-Zugang speichern") }
                } else if (lastFmUser == null) {
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = {
                        scope.launch {
                            runCatching {
                                val url = lastFmAuth.beginAuthorization()
                                lastFmAuth.openAuthorization(url)
                                lastFmStatus = "Im Browser freigeben, danach hier bestätigen."
                            }.onFailure {
                                lastFmStatus = it.message ?: "Last.fm-Anmeldung fehlgeschlagen"
                            }
                        }
                    }) { Text("Last.fm Account verbinden") }

                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(onClick = {
                        scope.launch {
                            runCatching {
                                val session = lastFmAuth.finishAuthorization()
                                lastFmUser = session.username
                                lastFmStatus = "Verbunden als ${session.username}"
                            }.onFailure {
                                lastFmStatus = it.message ?: "Freigabe noch nicht abgeschlossen"
                            }
                        }
                    }) { Text("Freigabe abgeschlossen") }
                } else {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Verbunden als $lastFmUser",
                        color = BubatzCream,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(onClick = {
                        lastFmAuth.disconnect()
                        lastFmUser = null
                        lastFmStatus = "Nicht verbunden · API-Zugang bleibt gespeichert"
                    }) { Text("Account trennen / wechseln") }
                }
            }

            Spacer(Modifier.height(8.dp))

            SettingsCard("Entwicklerlabor") {
                Text(
                    "Omnia · Wiedergabe-Diagnose · Vergleich · Android-System",
                    color = BubatzSage,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { developerLabOpen = !developerLabOpen },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (developerLabOpen) "Entwicklerlabor schließen" else "Entwicklerlabor öffnen")
                }
            }

            if (developerLabOpen) {
            SettingsCard("Omnia Bridge · v0.91") {
                    val omniaState by OmniaBridge.state.collectAsState()
                    val listenerEnabled = remember {
                        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
                        enabled.contains(packageName)
                    }
    
                    Text(
                        when {
                            !listenerEnabled -> "Benachrichtigungszugriff fehlt"
                            omniaState.connected -> "Omnia verbunden"
                            else -> "Omnia noch nicht im MediaSession-Stack gefunden"
                        },
                        color = if (omniaState.connected) BubatzSage else BubatzCream,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(8.dp))
    
                    if (omniaState.connected) {
                        Text(
                            omniaState.title.ifBlank { "Titel unbekannt" },
                            color = BubatzCream,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (omniaState.artist.isNotBlank()) {
                            Text(omniaState.artist, fontFamily = bubatzMetadataFont(omniaState.artist), color = BubatzSage, fontSize = 13.sp)
                        }
                        if (omniaState.album.isNotBlank()) {
                            Text(omniaState.album, color = BubatzSage.copy(alpha = 0.85f), fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { OmniaBridge.previous() }) {
                                Icon(Icons.Default.SkipPrevious, "Omnia: vorheriger Titel", tint = BubatzCream)
                            }
                            FilledIconButton(onClick = { OmniaBridge.playPause() }) {
                                Icon(
                                    if (omniaState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    "Omnia: Play/Pause"
                                )
                            }
                            IconButton(onClick = { OmniaBridge.next() }) {
                                Icon(Icons.Default.SkipNext, "Omnia: nächster Titel", tint = BubatzCream)
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "MediaSession: ${omniaState.packageName} · Actions 0x${omniaState.actions.toString(16)}",
                            color = BubatzSage,
                            fontSize = 10.sp
                        )
                    } else {
                        Text(
                            "Omnia starten und dort einen Titel abspielen. Bubatz übernimmt Metadaten und Standard-Steuerung direkt aus Omnias echter Android-MediaSession.",
                            color = BubatzSage,
                            fontSize = 11.sp
                        )
                    }
    
                    if (!listenerEnabled) {
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = {
                            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                        }) { Text("Zugriff öffnen") }
                    }
                }
    
                Spacer(Modifier.height(8.dp))

                SettingsCard("Wiedergabe-Diagnose") {
                    var crashText by remember {
                        mutableStateOf(CrashDiagnostics(this@MainActivity).readLiveDiagnostic())
                    }
                    Text(
                        "v0.91 bindet Omnia erstmals in die normale Playeransicht ein. Bubatz behält Vorrang, solange die eigene Wiedergabe läuft; bei pausiertem Bubatz übernimmt eine verbundene Omnia-Session Anzeige und Transportsteuerung.",
                        color = BubatzCream,
                        fontSize = 11.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(crashText, color = BubatzSage, fontSize = 11.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            crashText = CrashDiagnostics(this@MainActivity).readLiveDiagnostic()
                        }) {
                            Text("Aktualisieren")
                        }
                        OutlinedButton(onClick = {
                            CrashDiagnostics(this@MainActivity).clearLiveDiagnostic()
                            crashText = CrashDiagnostics(this@MainActivity).readLiveDiagnostic()
                        }) {
                            Text("Löschen")
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = {
                        sendPlaybackAction(PlaybackService.ACTION_AUDIO_PIPELINE_DIAGNOSTIC)
                        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
                            kotlinx.coroutines.delay(250L)
                            crashText = CrashDiagnostics(this@MainActivity).readLiveDiagnostic()
                        }
                    }) { Text("Audio-System prüfen") }
                }
    
                Spacer(Modifier.height(8.dp))

                SettingsCard("Omnia-Vergleichsdiagnose") {
                    var comparisonText by remember {
                        mutableStateOf(CrashDiagnostics(this@MainActivity).readNotificationComparison())
                    }
                    val listenerEnabled = remember(comparisonText) {
                        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
                        enabled.contains(packageName)
                    }
                    Text(
                        if (listenerEnabled) "Benachrichtigungszugriff: aktiv" else "Benachrichtigungszugriff: noch nicht aktiviert",
                        color = if (listenerEnabled) BubatzSage else BubatzCream, fontSize = 11.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    Text("v1.47.34 ergänzt den Omnia/Bubatz-Vergleich um ART/ALBUM_ART: Abmessungen, Speichergröße, Bitmap-Format und Artwork-URIs. Die Wiedergabe bleibt unverändert.", color = BubatzCream, fontSize = 11.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(comparisonText, color = BubatzSage, fontSize = 10.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                        }) { Text("Zugriff öffnen") }
                        OutlinedButton(onClick = {
                            comparisonText = CrashDiagnostics(this@MainActivity).readNotificationComparison()
                        }) { Text("Vergleich laden") }
                    }
    
                }
    
                Spacer(Modifier.height(8.dp))

                SettingsCard("Android-Absturzdiagnose") {
                    var systemCrashText by remember {
                        mutableStateOf(CrashDiagnostics(this@MainActivity).readSystemExitInfo())
                    }
                    Text(
                        systemCrashText,
                        color = BubatzSage,
                        fontSize = 10.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = {
                        systemCrashText = CrashDiagnostics(this@MainActivity).readSystemExitInfo()
                    }) {
                        Text("Systemdiagnose aktualisieren")
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Charging/Idle – letzter Heartbeat", color = BubatzCream, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))
                    var chargingIdleText by remember {
                        mutableStateOf(ChargingIdleDiagnostics(this@MainActivity).read())
                    }
                    Text(chargingIdleText, color = BubatzSage, fontSize = 10.sp)
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = {
                        chargingIdleText = ChargingIdleDiagnostics(this@MainActivity).read()
                    }) {
                        Text("Heartbeat aktualisieren")
                    }
                    Spacer(Modifier.height(12.dp))
                    var heartbeatHistoryText by remember { mutableStateOf("") }
                    OutlinedButton(onClick = {
                        heartbeatHistoryText = ChargingIdleDiagnostics(this@MainActivity).readHistory()
                    }) {
                        Text("Heartbeat-Verlauf laden (bis zu 90 Minuten)")
                    }
                    if (heartbeatHistoryText.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        androidx.compose.foundation.text.selection.SelectionContainer {
                            Text(heartbeatHistoryText, color = BubatzSage, fontSize = 10.sp)
                        }
                    }
                }
    
                }

            Spacer(Modifier.height(16.dp))
            Text(
                "Bubatz.FM · v${BuildConfig.VERSION_NAME}",
                color = BubatzSage,
                fontSize = 11.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(24.dp))
            }
        }
    }

    @Composable
    private fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
        Card(
            colors = CardDefaults.cardColors(containerColor = BubatzGreen.copy(alpha = 0.62f)),
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, BubatzSage.copy(alpha = 0.56f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp).fillMaxWidth()) {
                Text(title, color = BubatzCream, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                Spacer(Modifier.height(6.dp))
                content()
            }
        }
    }

    @Composable
    private fun SettingsActionButton(
        label: String,
        icon: androidx.compose.ui.graphics.vector.ImageVector,
        onClick: () -> Unit,
        modifier: Modifier = Modifier
    ) {
        OutlinedButton(
            onClick = onClick,
            modifier = modifier.height(46.dp),
            shape = RoundedCornerShape(15.dp),
            border = BorderStroke(1.dp, Color(0xFF8BDD4B).copy(alpha = 0.82f)),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = BubatzCream),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
        ) {
            Icon(icon, null, tint = Color(0xFFA4E65C), modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                label,
                fontWeight = FontWeight.Medium,
                fontSize = 12.sp,
                maxLines = 1,
                softWrap = false
            )
        }
    }

    @Composable
    private fun BubatzSlimSwitch(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
        val track = if (checked) Color(0xFF8BDD4B).copy(alpha = 0.20f) else BubatzDark.copy(alpha = 0.38f)
        val border = if (checked) Color(0xFF9BE84E) else BubatzSage.copy(alpha = 0.55f)
        Box(
            modifier = Modifier
                .width(48.dp)
                .height(28.dp)
                .background(track, RoundedCornerShape(14.dp))
                .border(1.dp, border, RoundedCornerShape(14.dp))
                .clickable { onCheckedChange(!checked) }
                .padding(3.dp),
            contentAlignment = if (checked) Alignment.CenterEnd else Alignment.CenterStart
        ) {
            Box(
                Modifier
                    .size(20.dp)
                    .background(if (checked) BubatzCream else BubatzSage, CircleShape)
            )
        }
    }

    @Composable
    private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 40.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                label,
                color = BubatzCream,
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 18.dp),
                fontSize = 13.sp,
                lineHeight = 18.sp
            )
            Box(
                modifier = Modifier.width(48.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                BubatzSlimSwitch(checked = checked, onCheckedChange = onChange)
            }
        }
    }

    private fun sendPlaybackAction(action: String) {
        val i = Intent(this, PlaybackService::class.java).setAction(action)
        // The Activity is in the foreground, so a normal service start is enough.
        // Starting as a foreground service before a 40k-library initialization
        // finishes can trigger Android's foreground-service timeout.
        startService(i)
    }

    private fun sendSeekAction(positionMs: Long) {
        val i = Intent(this, PlaybackService::class.java)
            .setAction(PlaybackService.ACTION_SEEK)
            .putExtra(PlaybackService.EXTRA_SEEK_POSITION_MS, positionMs)
        startService(i)
    }

    private fun playTrackFromHistory(trackId: Long) {
        startService(
            Intent(this, PlaybackService::class.java)
                .setAction(PlaybackService.ACTION_PLAY_TRACK_ID)
                .putExtra(PlaybackService.EXTRA_TRACK_ID, trackId)
        )
    }

    private fun formatHistoryTime(timestamp: Long): String {
        val formatter = java.text.SimpleDateFormat("dd.MM. · HH:mm", java.util.Locale.getDefault())
        return formatter.format(java.util.Date(timestamp))
    }

    private fun persist(uri: Uri) {
        runCatching {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
    }

    private fun formatTime(ms: Long): String {
        if (ms <= 0) return "0:00"
        val total = ms / 1000
        val minutes = total / 60
        val seconds = total % 60
        return "$minutes:${seconds.toString().padStart(2, '0')}"
    }
}
