package fm.bubatz.player.playback

import android.content.Intent
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import fm.bubatz.player.BubatzApplication
import fm.bubatz.player.CrashDiagnostics
import fm.bubatz.player.data.PlaybackStateEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PlaybackService : MediaSessionService() {

    companion object {
        const val ACTION_AUTO_PLAY = "fm.bubatz.player.AUTO_PLAY"
        const val ACTION_PLAY_PAUSE = "fm.bubatz.player.PLAY_PAUSE"
        const val ACTION_NEXT = "fm.bubatz.player.NEXT"
        const val ACTION_PREVIOUS = "fm.bubatz.player.PREVIOUS"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private lateinit var player: ExoPlayer
    private lateinit var session: MediaSession
    private lateinit var shuffle: ShuffleManager
    private lateinit var diagnostics: CrashDiagnostics

    private var currentTrackId: Long? = null
    private var startedCurrentTrack = false

    override fun onCreate() {
        super.onCreate()

        diagnostics = CrashDiagnostics(this)
        val db = (application as BubatzApplication).database
        shuffle = ShuffleManager(db)

        player = ExoPlayer.Builder(this).build()

        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                diagnostics.save(
                    "v0.31 EXOPLAYER ERROR",
                    error,
                    "mediaId=${player.currentMediaItem?.mediaId}\nuri=${player.currentMediaItem?.localConfiguration?.uri}"
                )
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                scope.launch {
                    if (isPlaying && !startedCurrentTrack) {
                        startedCurrentTrack = true
                        currentTrackId?.let { id ->
                            withContext(Dispatchers.IO) {
                                db.tracks().markPlayed(id, System.currentTimeMillis())
                            }
                        }
                    }
                    persistState()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                scope.launch {
                    persistState()
                    if (playbackState == Player.STATE_ENDED) {
                        playNextInternal()
                    }
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                startedCurrentTrack = false
                currentTrackId = mediaItem?.mediaId
                    ?.takeIf { it.startsWith("track:") }
                    ?.removePrefix("track:")
                    ?.toLongOrNull()
                scope.launch { persistState() }
            }
        })

        session = MediaSession.Builder(this, player).build()

        diagnostics.save("v0.31 Service erstellt – Minimalplayer bereit")
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession = session

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_AUTO_PLAY -> {
                scope.launch {
                    if (player.currentMediaItem == null) {
                        playNextInternal()
                    } else {
                        player.play()
                    }
                }
                return START_STICKY
            }

            ACTION_PLAY_PAUSE -> {
                scope.launch {
                    if (player.currentMediaItem == null) {
                        playNextInternal()
                    } else if (player.isPlaying) {
                        player.pause()
                    } else {
                        player.play()
                    }
                }
                return START_STICKY
            }

            ACTION_NEXT -> {
                scope.launch { playNextInternal() }
                return START_STICKY
            }

            ACTION_PREVIOUS -> {
                if (player.currentPosition > 5_000L) {
                    player.seekTo(0L)
                } else {
                    player.seekTo(0L)
                }
                return START_STICKY
            }
        }

        return super.onStartCommand(intent, flags, startId)
    }

    private suspend fun playNextInternal() {
        try {
            diagnostics.save("v0.31: wähle nächsten Titel")

            val next = withContext(Dispatchers.IO) {
                shuffle.nextTrack(currentTrackId)
            }

            if (next == null) {
                diagnostics.save("v0.31 FEHLER: kein Titel gefunden")
                return
            }

            val item = MediaItem.Builder()
                .setUri(Uri.parse(next.uri))
                .setMediaId("track:${next.id}")
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(next.title)
                        .setArtist(next.artist)
                        .setAlbumTitle(next.album)
                        .build()
                )
                .build()

            currentTrackId = next.id
            startedCurrentTrack = false

            diagnostics.save(
                "v0.31: Titel geladen",
                extra = "id=${next.id}\ntitel=${next.title}\nuri=${next.uri}"
            )

            player.setMediaItem(item)
            player.prepare()
            player.play()

            diagnostics.save("v0.31: play() auf Minimalplayer aufgerufen")

        } catch (t: Throwable) {
            diagnostics.save("v0.31 EXCEPTION beim Start", t)
        }
    }

    private suspend fun persistState() {
        val db = (application as BubatzApplication).database
        val item = player.currentMediaItem
        val state = PlaybackStateEntity(
            currentTrackId = currentTrackId,
            currentMediaId = item?.mediaId,
            upcomingMediaId = null,
            currentPositionMs = player.currentPosition.coerceAtLeast(0L),
            currentDurationMs = if (player.duration > 0L) player.duration else 0L,
            currentTitle = item?.mediaMetadata?.title?.toString(),
            currentArtist = item?.mediaMetadata?.artist?.toString(),
            currentAlbum = item?.mediaMetadata?.albumTitle?.toString(),
            isPlaying = player.isPlaying,
            nextRadioAtMs = 0L
        )
        withContext(Dispatchers.IO) {
            db.state().put(state)
        }
    }

    override fun onDestroy() {
        runCatching { session.release() }
        runCatching { player.release() }
        scope.cancel()
        super.onDestroy()
    }
}
