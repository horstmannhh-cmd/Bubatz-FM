## 1.46.9
- Wurst: Brokkoli wieder deutlich größer, monochrom und ohne Funkwellen.
- Eigenes Vektor-Small-Icon aus der ursprünglichen Bubatz-Brokkoli-Silhouette; Android/Samsung kann es passend zur Schrift einfärben.
- Sicherheitsrand rechts und leichte Linksverschiebung gegen Clipping beibehalten.
- Keine Änderungen an Bubatz.IQ, Shuffle oder Playback.

## v1.46.1
- Fix: BuildConfig generation enabled so automatic version display compiles.
- Keeps fixed broccoli zone and independent centered program text from v1.46.0.

# Bubatz.FM v1.45.7 – Diagnose-Build

- Sichtbarer roter Marker **DIAGNOSE 1.45.7** direkt unter dem Logo.
- Dient ausschließlich dazu, zweifelsfrei zu prüfen, ob GitHub und Android wirklich den aktuellen Quellstand bauen/installieren.
- Bubatz.IQ, Audio, Radio, Last.fm und History-Logik gegenüber v1.45.6 unverändert.
- GitHub-Workflow auf v1.45.7 aktualisiert und mit expliziter Build-Identitätsprüfung versehen.

## 1.46.8
- Samsung Now-Bar/"Wurst" icon: restored the detailed Bubatz broccoli artwork without radio waves.
- The notification bitmap now lives in `drawable-xxxhdpi` as a real 24dp-equivalent (96px) small icon instead of an oversized density-less drawable, preventing the right-side clipping seen with the prettier raster icon.
- Kept generous transparent safe margins and the slight left bias that worked in 1.46.6.
- No changes to Bubatz.IQ, shuffle, playback, crossfade or Auto-Cue logic.
