package fm.bubatz.player.library

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.DocumentsContract
import fm.bubatz.player.data.RadioClipEntity
import fm.bubatz.player.data.TrackEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LibraryScanner(private val context: Context) {
    private val audioExt = setOf("mp3", "flac", "m4a", "aac", "ogg", "opus", "wav", "wma")
    private val diagnostics = ScanDiagnostics(context)

    data class ScanStats(
        var directoriesVisited: Int = 0,
        var filesVisited: Int = 0,
        var audioRecognized: Int = 0,
        var metadataRead: Int = 0,
        var metadataFailed: Int = 0,
        var queryErrors: Int = 0
    )

    data class MusicScanResult(
        val tracks: List<TrackEntity>,
        val stats: ScanStats,
        val error: String? = null
    )

    suspend fun scanMusicDetailed(treeUri: Uri): MusicScanResult = withContext(Dispatchers.IO) {
        val stats = ScanStats()
        val found = mutableListOf<Pair<Uri, String>>()

        diagnostics.save("START\nURI: $treeUri")

        val rootId = runCatching { DocumentsContract.getTreeDocumentId(treeUri) }
            .getOrElse {
                val msg = "FEHLER Tree-ID: ${it::class.java.simpleName}: ${it.message}"
                diagnostics.save(msg)
                return@withContext MusicScanResult(emptyList(), stats, msg)
            }

        diagnostics.save("Tree-ID OK\n$rootId")

        val rootDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)

        try {
            enumerate(
                treeUri = treeUri,
                documentUri = rootDocUri,
                stats = stats,
                found = found
            )
        } catch (t: Throwable) {
            val msg = "FEHLER Scan: ${t::class.java.simpleName}: ${t.message}"
            diagnostics.save(report(stats, found.size, msg))
            return@withContext MusicScanResult(emptyList(), stats, msg)
        }

        diagnostics.save(report(stats, found.size, "Enumeration fertig; Metadaten folgen"))

        val tracks = ArrayList<TrackEntity>(found.size)
        found.forEachIndexed { index, (uri, name) ->
            val meta = metadataOrNull(uri)
            if (meta != null) stats.metadataRead++ else stats.metadataFailed++
            tracks += TrackEntity(
                uri = uri.toString(),
                title = meta?.title ?: name.substringBeforeLast('.'),
                artist = meta?.artist,
                album = meta?.album,
                durationMs = meta?.duration ?: 0L
            )
            if ((index + 1) % 250 == 0) {
                diagnostics.save(report(stats, found.size, "Metadaten ${index + 1}/${found.size}"))
            }
        }

        diagnostics.save(report(stats, found.size, "Scan fertig"))
        MusicScanResult(tracks, stats, null)
    }

    suspend fun scanMusic(treeUri: Uri): List<TrackEntity> = scanMusicDetailed(treeUri).tracks

    suspend fun scanRadio(treeUri: Uri): List<RadioClipEntity> = withContext(Dispatchers.IO) {
        val result = mutableListOf<RadioClipEntity>()
        val stats = ScanStats()
        val found = mutableListOf<Pair<Uri, String>>()
        val rootId = runCatching { DocumentsContract.getTreeDocumentId(treeUri) }.getOrNull()
            ?: return@withContext emptyList()
        val root = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
        enumerate(treeUri, root, stats, found)
        for ((uri, name) in found) {
            val meta = metadataOrNull(uri)
            result += RadioClipEntity(
                uri = uri.toString(),
                name = meta?.title ?: name.substringBeforeLast('.'),
                durationMs = meta?.duration ?: 0L
            )
        }
        result
    }

    private fun enumerate(
        treeUri: Uri,
        documentUri: Uri,
        stats: ScanStats,
        found: MutableList<Pair<Uri, String>>
    ) {
        stats.directoriesVisited++
        if (stats.directoriesVisited % 25 == 0) {
            diagnostics.save(report(stats, found.size, "Ordner werden durchsucht"))
        }

        val documentId = DocumentsContract.getDocumentId(documentUri)
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, documentId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )

        val cursor = try {
            context.contentResolver.query(childrenUri, projection, null, null, null)
        } catch (t: Throwable) {
            stats.queryErrors++
            diagnostics.save(report(stats, found.size, "Query-Fehler: ${t::class.java.simpleName}: ${t.message}"))
            return
        }

        if (cursor == null) {
            stats.queryErrors++
            diagnostics.save(report(stats, found.size, "Query lieferte null"))
            return
        }

        cursor.use { c ->
            val idIndex = c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameIndex = c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeIndex = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)

            while (c.moveToNext()) {
                val childId = if (idIndex >= 0) c.getString(idIndex) else null
                if (childId.isNullOrBlank()) continue
                val name = if (nameIndex >= 0) c.getString(nameIndex) ?: "Unbekannt" else "Unbekannt"
                val mime = if (mimeIndex >= 0) c.getString(mimeIndex) else null
                val childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childId)

                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    enumerate(treeUri, childUri, stats, found)
                } else {
                    stats.filesVisited++
                    val ext = name.substringAfterLast('.', "").lowercase()
                    if (ext in audioExt || mime?.startsWith("audio/") == true) {
                        stats.audioRecognized++
                        found += childUri to name
                    }
                    if (stats.filesVisited % 1000 == 0) {
                        diagnostics.save(report(stats, found.size, "Dateien werden gezählt"))
                    }
                }
            }
        }
    }

    private fun report(stats: ScanStats, found: Int, phase: String): String = buildString {
        append("$phase\n")
        append("Ordner: ${stats.directoriesVisited}\n")
        append("Dateien: ${stats.filesVisited}\n")
        append("Audio erkannt: ${stats.audioRecognized}\n")
        append("Audio gesammelt: $found\n")
        append("Metadaten OK: ${stats.metadataRead}\n")
        append("Metadaten Fehler: ${stats.metadataFailed}\n")
        append("Query-Fehler: ${stats.queryErrors}")
    }

    private data class Meta(
        val title: String?,
        val artist: String?,
        val album: String?,
        val duration: Long
    )

    private fun metadataOrNull(uri: Uri): Meta? = runCatching {
        val r = MediaMetadataRetriever()
        try {
            val opened = runCatching {
                context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                    r.setDataSource(pfd.fileDescriptor)
                    true
                } ?: false
            }.getOrDefault(false)
            if (!opened) r.setDataSource(context, uri)
            Meta(
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            )
        } finally {
            r.release()
        }
    }.getOrNull()
}
