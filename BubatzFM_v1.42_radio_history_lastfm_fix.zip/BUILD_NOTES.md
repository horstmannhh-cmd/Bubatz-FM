# v1.16 – Zuletzt gehört

- Basis: v1.13_fixed (Smartwatch-Artwork-Experimente 1.14/1.15 verworfen)
- Persistente Liste der letzten 50 Musiktitel
- Radioeinspieler werden nicht angezeigt
- Cover, Titel, Interpret und Zeitpunkt
- Antippen startet den Titel erneut
- Historie wird auf 200 interne Einträge begrenzt
- Keine Änderung an MediaSession/Notification/Crossfade/Last.fm/Bluetooth/Anruflogik

## v1.11.0

Crossfade-Architektur: Nach der Equal-Power-Überblendung wird der bereits laufende Incoming-ExoPlayer zum aktiven Player. Die MediaSession wechselt per `setPlayer()` auf einen neuen `BubatzSessionPlayer`-Wrapper desselben Decks. Dadurch entfällt der bisherige zweite Decode/Seek/Prepare-Handoff, der sporadische Mikro-Stolperer erzeugen konnte.

# Bubatz FM v0.92 – Build Notes

v0.92 ist ein isolierter Samsung-Statusleisten-Test. Die produktive Bubatz-Wiedergabe bleibt unverändert; geändert wird nur die Beziehung zwischen MediaStyle-Notification und einer Omnia-ähnlichen klassischen Android-MediaSession.

Version: 0.92.0 / Code 92

v1.12: Radioeinspieler-Shuffle-Bag persistent eingeführt und Samsung DISPLAY_TITLE wieder auf reinen Titel gesetzt. Kein Crossfade-Code geändert.

## v1.42.0
Gezielter Bookkeeping-Fix für den gapless Radio→Musik-MediaItem-Übergang: ExoPlayer bleibt dabei kontinuierlich `isPlaying=true`, daher feuert `onIsPlayingChanged(true)` nicht erneut. Der Übergang registriert den vorgepufferten Nachfolger nun direkt in History/Flow und startet Last.fm, ohne den Audio-Pfad anzufassen.
