package fm.bubatz.player.playback

import android.content.Context
import fm.bubatz.player.data.BubatzDatabase
import fm.bubatz.player.data.RadioClipEntity
import fm.bubatz.player.data.TrackEntity
import kotlin.math.max
import kotlin.random.Random

/** Bubatz Flow: persistent cycles plus artist/album-aware weighted shuffle. */
class ShuffleManager(private val db: BubatzDatabase, context: Context) {
    private val cycles = FlowCycleStore(context)

    suspend fun nextTrack(excludeId: Long? = null): TrackEntity? {
        var cycle = cycles.current()
        var candidates = db.tracks().flowCycleCandidates(cycle, excludeId, 64)
        // A fully heard Flow automatically opens a fresh pot. Manual reset uses the
        // same generation mechanism, so real play counts/history are never erased.
        if (candidates.isEmpty() && db.tracks().remainingInFlowCycle(cycle) == 0) {
            cycle = cycles.newCycle()
            candidates = db.tracks().flowCycleCandidates(cycle, excludeId, 64)
        }
        if (candidates.isEmpty()) return null
        if (candidates.size == 1) return candidates.first()

        val recent = db.tracks().recentlyPlayed(120)
        val artistRank = mutableMapOf<String, Int>()
        val albumRank = mutableMapOf<String, Int>()
        recent.forEachIndexed { index, track ->
            track.artist?.normalized()?.takeIf { it.isNotEmpty() }?.let { artistRank.putIfAbsent(it, index) }
            track.album?.normalized()?.takeIf { it.isNotEmpty() }?.let { albumRank.putIfAbsent(it, index) }
        }

        val weighted = candidates.map { track ->
            var weight = 1.0
            track.artist?.normalized()?.let { key ->
                artistRank[key]?.let { rank ->
                    weight *= when {
                        rank == 0 -> 0.005
                        rank < 3 -> 0.02
                        rank < 8 -> 0.07
                        rank < 15 -> 0.18
                        rank < 25 -> 0.38
                        rank < 35 -> 0.62
                        else -> 0.85
                    }
                }
            }
            // Album behaviour deliberately remains the proven v1.17 weighting.
            track.album?.normalized()?.let { key ->
                albumRank[key]?.let { rank ->
                    weight *= when {
                        rank < 3 -> 0.20
                        rank < 10 -> 0.45
                        else -> 0.80
                    }
                }
            }
            track to max(weight, 0.0001)
        }

        val total = weighted.sumOf { it.second }
        var pick = Random.nextDouble(total)
        for ((track, weight) in weighted) {
            pick -= weight
            if (pick <= 0.0) return track
        }
        return weighted.last().first
    }

    suspend fun markPlayed(id: Long, playedAt: Long) =
        db.tracks().markPlayed(id, playedAt, cycles.current())

    fun startNewCycle(): Long = cycles.newCycle()

    suspend fun nextRadioClip(excludeId: Long? = null): RadioClipEntity? =
        db.clips().randomLeastPlayed(excludeId)

    private fun String.normalized(): String = trim().lowercase()
}
