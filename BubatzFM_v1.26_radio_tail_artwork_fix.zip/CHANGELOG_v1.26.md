# Bubatz FM v1.26

- Radio-Hardcut wartet jetzt auf die tatsächlich beobachtete Trackgrenze statt auf eine berechnete Restzeit. Dadurch wird das Ende eines Einspielers nicht mehr zu früh abgeschnitten.
- Der erste Musiktitel nach einem Einspieler erhält sein eingebettetes Cover bereits beim MediaItem-Aufbau, damit Live-Benachrichtigung und Sperrbildschirm das Artwork sofort wieder anzeigen.
- Musik→Musik-Crossfade aus v1.24/v1.25 bleibt unverändert.
