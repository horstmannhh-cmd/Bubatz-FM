package fm.bubatz.player.playback

import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.TransferListener
import java.io.FileInputStream
import java.io.IOException
import kotlin.math.min

/**
 * v1.47.3 storage stability layer.
 *
 * Samsung's system file browser can restart com.android.externalstorage.documents
 * while it is enumerating very large folders. Media3's normal content:// path then
 * leaves active playback tied to that provider. If Android kills/restarts the provider,
 * Bubatz can be killed as a dependent process (DEPENDENCY_DIED).
 *
 * For ExternalStorageProvider document Uris we therefore open the file only briefly,
 * detach the returned Linux file descriptor, and let ExoPlayer read from that local
 * descriptor. After open() returns, the active audio stream no longer needs a live
 * ContentProvider connection. Other Uri types continue through Media3's normal source.
 */
@UnstableApi
class ResilientExternalStorageDataSourceFactory(
    context: Context
) : DataSource.Factory {
    private val appContext = context.applicationContext
    private val fallbackFactory = DefaultDataSource.Factory(appContext)

    override fun createDataSource(): DataSource =
        RoutingDataSource(appContext, fallbackFactory.createDataSource())
}

@UnstableApi
private class RoutingDataSource(
    private val context: Context,
    private val fallback: DataSource
) : DataSource {
    private val listeners = mutableListOf<TransferListener>()
    private var active: DataSource? = null

    override fun addTransferListener(transferListener: TransferListener) {
        listeners += transferListener
    }

    override fun open(dataSpec: DataSpec): Long {
        check(active == null) { "DataSource already open" }

        val useDetachedExternalStorage =
            dataSpec.uri.scheme == "content" &&
                dataSpec.uri.authority == "com.android.externalstorage.documents"

        if (useDetachedExternalStorage) {
            val detached = DetachedExternalStorageDataSource(context)
            listeners.forEach(detached::addTransferListener)
            try {
                val length = detached.open(dataSpec)
                active = detached
                return length
            } catch (_: Throwable) {
                // Keep compatibility with providers/files that cannot expose a seekable fd.
                runCatching { detached.close() }
            }
        }

        listeners.forEach(fallback::addTransferListener)
        active = fallback
        return fallback.open(dataSpec)
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int =
        active?.read(buffer, offset, length) ?: throw IOException("DataSource is not open")

    override fun getUri(): Uri? = active?.uri

    override fun getResponseHeaders(): Map<String, List<String>> =
        active?.responseHeaders ?: emptyMap()

    override fun close() {
        val source = active
        active = null
        source?.close()
    }
}

@UnstableApi
private class DetachedExternalStorageDataSource(
    private val context: Context
) : BaseDataSource(false) {
    private var currentUri: Uri? = null
    private var localPfd: ParcelFileDescriptor? = null
    private var input: FileInputStream? = null
    private var bytesRemaining: Long = C.LENGTH_UNSET.toLong()
    private var opened = false

    override fun open(dataSpec: DataSpec): Long {
        transferInitializing(dataSpec)
        currentUri = dataSpec.uri

        val providerPfd = context.contentResolver.openFileDescriptor(dataSpec.uri, "r")
            ?: throw IOException("Could not open ${dataSpec.uri}")

        try {
            // detachFd() transfers ownership away from the provider-returned PFD.
            // The adopted PFD below is local to this process and survives a provider restart.
            val rawFd = providerPfd.detachFd()
            localPfd = ParcelFileDescriptor.adoptFd(rawFd)
        } finally {
            runCatching { providerPfd.close() }
        }

        val stream = FileInputStream(localPfd!!.fileDescriptor)
        input = stream

        try {
            stream.channel.position(dataSpec.position)
        } catch (t: Throwable) {
            closeQuietly()
            throw IOException("External-storage file is not seekable", t)
        }

        val availableFromPosition = runCatching {
            val size = stream.channel.size()
            (size - dataSpec.position).coerceAtLeast(0L)
        }.getOrElse {
            val statSize = localPfd?.statSize ?: -1L
            if (statSize >= 0L) (statSize - dataSpec.position).coerceAtLeast(0L)
            else C.LENGTH_UNSET.toLong()
        }

        bytesRemaining = when {
            dataSpec.length != C.LENGTH_UNSET.toLong() -> dataSpec.length
            else -> availableFromPosition
        }

        opened = true
        transferStarted(dataSpec)
        return bytesRemaining
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (bytesRemaining == 0L) return C.RESULT_END_OF_INPUT

        val stream = input ?: throw IOException("DataSource is not open")
        val requested = if (bytesRemaining == C.LENGTH_UNSET.toLong()) {
            length
        } else {
            min(bytesRemaining, length.toLong()).toInt()
        }

        val read = stream.read(buffer, offset, requested)
        if (read == -1) return C.RESULT_END_OF_INPUT

        if (bytesRemaining != C.LENGTH_UNSET.toLong()) {
            bytesRemaining -= read.toLong()
        }
        bytesTransferred(read)
        return read
    }

    override fun getUri(): Uri? = currentUri

    override fun close() {
        closeQuietly()
        currentUri = null
        bytesRemaining = C.LENGTH_UNSET.toLong()
        if (opened) {
            opened = false
            transferEnded()
        }
    }

    private fun closeQuietly() {
        runCatching { input?.close() }
        input = null
        runCatching { localPfd?.close() }
        localPfd = null
    }
}
