package fm.bubatz.player

import fm.bubatz.player.playback.NavigationHistory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class NavigationHistoryTest {
    @Test
    fun previousAndNextReplayKnownHistoryBeforeCreatingNewBranch() {
        val history = NavigationHistory()
        history.reset(1L)
        history.appendNew(1L, 2L)
        history.appendNew(2L, 3L)

        assertEquals(2L, history.movePrevious())
        assertEquals(1L, history.movePrevious())
        assertNull(history.movePrevious())

        assertEquals(2L, history.moveNext())
        assertEquals(3L, history.moveNext())
        assertNull(history.moveNext())
    }

    @Test
    fun freshBranchOnlyReplacesForwardHistoryWhenExplicitlyAppended() {
        val history = NavigationHistory()
        history.reset(1L)
        history.appendNew(1L, 2L)
        history.appendNew(2L, 3L)
        assertEquals(2L, history.movePrevious())

        history.appendNew(2L, 4L)

        assertNull(history.moveNext())
        assertEquals(2L, history.movePrevious())
        assertEquals(4L, history.moveNext())
    }
}
