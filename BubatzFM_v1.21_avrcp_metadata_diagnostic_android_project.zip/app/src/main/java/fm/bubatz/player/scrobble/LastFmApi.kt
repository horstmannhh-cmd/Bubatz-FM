
package fm.bubatz.player.scrobble

import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.security.MessageDigest

data class LastFmSession(val username: String, val key: String)
data class LastFmResult(val ok: Boolean, val errorCode: Int? = null, val message: String? = null)

class LastFmApi(
    private val apiKey: String,
    private val sharedSecret: String,
    private val client: OkHttpClient = OkHttpClient()
) {
    private fun md5(value: String): String =
        MessageDigest.getInstance("MD5")
            .digest(value.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    private fun signature(params: Map<String, String>): String {
        val base = params
            .filterKeys { it != "format" && it != "callback" }
            .toSortedMap()
            .entries
            .joinToString("") { (k, v) -> "$k$v" } + sharedSecret
        return md5(base)
    }

    private fun signedParams(params: Map<String, String>): Map<String, String> {
        val base = params + ("api_key" to apiKey)
        return base + ("api_sig" to signature(base))
    }

    private fun post(params: Map<String, String>): JSONObject {
        check(apiKey.isNotBlank() && sharedSecret.isNotBlank()) { "Last.fm API-Zugang ist nicht konfiguriert." }
        val signed = signedParams(params)
        val body = FormBody.Builder(Charsets.UTF_8).apply {
            signed.forEach { (k, v) -> add(k, v) }
            add("format", "json")
        }.build()
        val request = Request.Builder()
            .url(LastFmConfig.API_ROOT)
            .post(body)
            .build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (raw.isBlank()) throw IllegalStateException("Empty Last.fm response")
            return JSONObject(raw)
        }
    }

    fun getToken(): String {
        val json = post(mapOf("method" to "auth.getToken"))
        if (json.has("error")) throw IllegalStateException(json.optString("message", "Last.fm error"))
        return json.getString("token")
    }

    fun authorizationUrl(token: String): String =
        "${LastFmConfig.AUTH_ROOT}?api_key=$apiKey&token=$token"

    fun getSession(token: String): LastFmSession {
        val json = post(mapOf("method" to "auth.getSession", "token" to token))
        if (json.has("error")) throw IllegalStateException(json.optString("message", "Last.fm error"))
        val session = json.getJSONObject("session")
        return LastFmSession(session.getString("name"), session.getString("key"))
    }

    fun updateNowPlaying(
        sessionKey: String,
        artist: String,
        track: String,
        album: String?,
        durationSeconds: Long?
    ): LastFmResult {
        val p = mutableMapOf(
            "method" to "track.updateNowPlaying",
            "sk" to sessionKey,
            "artist" to artist,
            "track" to track
        )
        if (!album.isNullOrBlank()) p["album"] = album
        if (durationSeconds != null && durationSeconds > 0) p["duration"] = durationSeconds.toString()
        return parseResult(post(p))
    }

    fun scrobbleBatch(
        sessionKey: String,
        rows: List<ScrobblePayload>
    ): LastFmResult {
        if (rows.isEmpty()) return LastFmResult(true)
        require(rows.size <= 50)

        val p = mutableMapOf(
            "method" to "track.scrobble",
            "sk" to sessionKey
        )
        rows.forEachIndexed { i, row ->
            p["artist[$i]"] = row.artist
            p["track[$i]"] = row.track
            p["timestamp[$i]"] = row.timestampSeconds.toString()
            if (!row.album.isNullOrBlank()) p["album[$i]"] = row.album
        }
        return parseResult(post(p))
    }

    private fun parseResult(json: JSONObject): LastFmResult =
        if (json.has("error")) {
            LastFmResult(
                ok = false,
                errorCode = json.optInt("error"),
                message = json.optString("message")
            )
        } else LastFmResult(ok = true)
}

data class ScrobblePayload(
    val queueId: Long,
    val artist: String,
    val track: String,
    val album: String?,
    val timestampSeconds: Long
)
