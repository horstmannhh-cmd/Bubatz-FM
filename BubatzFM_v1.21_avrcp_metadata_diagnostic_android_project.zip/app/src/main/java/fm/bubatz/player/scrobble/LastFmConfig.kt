package fm.bubatz.player.scrobble

/**
 * Last.fm endpoint configuration.
 *
 * v1.01 deliberately does not embed an account or API credentials in the
 * source tree. API key/shared secret are entered once in the app and stored
 * encrypted on-device; the Last.fm user account is then authorized via the
 * normal browser flow and can be changed independently.
 */
object LastFmConfig {
    const val API_ROOT = "https://ws.audioscrobbler.com/2.0/"
    const val AUTH_ROOT = "https://www.last.fm/api/auth/"
}
