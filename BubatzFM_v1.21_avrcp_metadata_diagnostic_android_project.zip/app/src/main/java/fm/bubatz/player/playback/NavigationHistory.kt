package fm.bubatz.player.playback

/**
 * Deterministic navigation history for shuffle playback.
 *
 * Example: A -> B -> C, previous -> B, previous -> A,
 * next -> B, next -> C. A fresh random track is only appended
 * when the cursor is already at the end of the known history.
 */
class NavigationHistory {
    private val items = mutableListOf<Long>()
    private var index = -1

    fun reset(currentId: Long? = null) {
        items.clear()
        index = -1
        currentId?.let {
            items += it
            index = 0
        }
    }

    fun ensureCurrent(currentId: Long?) {
        val id = currentId ?: return
        if (index in items.indices && items[index] == id) return

        val existing = items.indexOfLast { it == id }
        if (existing >= 0) {
            index = existing
            return
        }

        if (index < items.lastIndex) {
            items.subList(index + 1, items.size).clear()
        }
        items += id
        index = items.lastIndex
    }

    fun peekNext(): Long? =
        if (index >= 0 && index < items.lastIndex) items[index + 1] else null

    fun moveNext(): Long? {
        val next = peekNext() ?: return null
        index += 1
        return next
    }

    /** v1.07: remove the known forward item when its file disappeared. */
    fun discardNext(): Long? {
        if (index < 0 || index >= items.lastIndex) return null
        return items.removeAt(index + 1)
    }

    fun movePrevious(): Long? {
        if (index <= 0 || items.isEmpty()) return null
        index -= 1
        return items[index]
    }

    /**
     * Appends a genuinely new shuffle branch after the current item.
     * Any old forward branch is discarded.
     */
    fun appendNew(currentId: Long?, nextId: Long) {
        ensureCurrent(currentId)

        if (index < items.lastIndex) {
            items.subList(index + 1, items.size).clear()
        }

        if (index in items.indices && items[index] == nextId) return
        items += nextId
        index = items.lastIndex
    }

    /**
     * Called when an already prepared automatic successor becomes active.
     * If it is the known forward item, advance into history. Otherwise it
     * starts a fresh branch.
     */
    fun acceptSuccessor(currentId: Long?, nextId: Long) {
        ensureCurrent(currentId)
        if (peekNext() == nextId) {
            index += 1
        } else {
            appendNew(currentId, nextId)
        }
    }

    fun snapshot(): Pair<List<Long>, Int> = items.toList() to index

    fun restore(savedItems: List<Long>, savedIndex: Int, currentId: Long?): Boolean {
        if (savedItems.isEmpty() || savedIndex !in savedItems.indices) return false
        if (currentId != null && savedItems[savedIndex] != currentId) return false
        items.clear()
        items.addAll(savedItems)
        index = savedIndex
        return true
    }

    fun size(): Int = items.size
    fun position(): Int = index
}
