package fm.bubatz.player.bluetooth

import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import fm.bubatz.player.playback.PlaybackService
import fm.bubatz.player.settings.AppSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * v0.99: handles the complete Bluetooth A2DP lifecycle.
 *
 * CONNECTED starts Bubatz (subject to the user's policy). DISCONNECTED rearms
 * auto-start immediately and stops the playback service so Samsung/Android does
 * not keep a paused Bubatz media session around between speaker connections.
 * Generic ACL links are deliberately ignored.
 */
class BluetoothConnectReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED) return
        val state = intent.getIntExtra(BluetoothProfile.EXTRA_STATE, -1)
        if (state != BluetoothProfile.STATE_CONNECTED && state != BluetoothProfile.STATE_DISCONNECTED) return

        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val device: BluetoothDevice? =
                    if (Build.VERSION.SDK_INT >= 33) {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    }

                val address = runCatching { device?.address }.getOrNull()
                val settings = AppSettings(context)

                if (state == BluetoothProfile.STATE_DISCONNECTED) {
                    // A real A2DP disconnect marks the end of this auto-start cycle.
                    // Clear the debounce/latch so even a quick reconnect can start
                    // again, then remove the paused media session/notification.
                    settings.rearmBluetoothAutoStart(address)
                    context.stopService(Intent(context, PlaybackService::class.java))
                    return@launch
                }

                if (!settings.shouldAutoStartFor(address)) return@launch

                val service = Intent(context, PlaybackService::class.java)
                    .setAction(PlaybackService.ACTION_AUTO_PLAY)
                ContextCompat.startForegroundService(context, service)
            } finally {
                pending.finish()
            }
        }
    }
}
