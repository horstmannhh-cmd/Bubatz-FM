
package fm.bubatz.player.scrobble

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class LastFmSessionStore(context: Context) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "lastfm_secure",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    var apiKey: String?
        get() = prefs.getString("api_key", null)
        set(value) = prefs.edit().apply {
            if (value == null) remove("api_key") else putString("api_key", value.trim())
        }.apply()

    var sharedSecret: String?
        get() = prefs.getString("shared_secret", null)
        set(value) = prefs.edit().apply {
            if (value == null) remove("shared_secret") else putString("shared_secret", value.trim())
        }.apply()

    val hasApiCredentials: Boolean
        get() = !apiKey.isNullOrBlank() && !sharedSecret.isNullOrBlank()

    fun saveApiCredentials(apiKey: String, sharedSecret: String) {
        prefs.edit()
            .putString("api_key", apiKey.trim())
            .putString("shared_secret", sharedSecret.trim())
            .apply()
    }

    var sessionKey: String?
        get() = prefs.getString("session_key", null)
        set(value) = prefs.edit().apply {
            if (value == null) remove("session_key") else putString("session_key", value)
        }.apply()

    var pendingToken: String?
        get() = prefs.getString("pending_token", null)
        set(value) = prefs.edit().apply {
            if (value == null) remove("pending_token") else putString("pending_token", value)
        }.apply()

    var username: String?
        get() = prefs.getString("username", null)
        set(value) = prefs.edit().apply {
            if (value == null) remove("username") else putString("username", value)
        }.apply()

    fun clearSession() {
        prefs.edit()
            .remove("session_key")
            .remove("pending_token")
            .remove("username")
            .apply()
    }

    fun clearAll() {
        prefs.edit().clear().apply()
    }
}
