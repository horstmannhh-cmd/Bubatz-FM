package fm.bubatz.player.radio

import android.content.Context
import fm.bubatz.player.data.BubatzDatabase
import fm.bubatz.player.data.RadioClipEntity

/**
 * Persistent shuffle-bag for radio inserts.
 *
 * Every enabled insert is played exactly once per cycle. When the bag is empty,
 * a completely new random order is generated. The last insert of the previous
 * cycle is never allowed to become the first insert of the next cycle when more
 * than one insert exists.
 *
 * The current order, cursor and pending selection survive process/app restarts.
 * Library changes are reconciled lazily before the next selection: removed clips
 * disappear, newly added clips join the remaining part of the current cycle.
 */
class RadioShuffleBag(
    context: Context,
    private val db: BubatzDatabase
) {
    private val prefs = context.getSharedPreferences("radio_shuffle_bag", Context.MODE_PRIVATE)

    suspend fun nextClip(): RadioClipEntity? {
        val enabledIds = db.clips().allEnabledIds()
        if (enabledIds.isEmpty()) {
            clear()
            return null
        }

        var order = readOrder()
        var position = prefs.getInt(KEY_POSITION, 0).coerceIn(0, order.size)
        var pendingId = prefs.getLong(KEY_PENDING_ID, -1L).takeIf { it >= 0L }
        val lastPlayedId = prefs.getLong(KEY_LAST_PLAYED_ID, -1L).takeIf { it >= 0L }

        val enabledSet = enabledIds.toSet()
        if (pendingId != null && pendingId !in enabledSet) pendingId = null

        if (order.isNotEmpty()) {
            val playedPrefix = order.take(position).filter { it in enabledSet }
            val futureExisting = order.drop(position).filter { it in enabledSet }
            val newIds = enabledIds.filter { it !in order.toSet() }

            val remainingPool = (futureExisting + newIds).distinct().toMutableList()
            val reconciledRemaining = mutableListOf<Long>()
            pendingId?.takeIf { it in remainingPool }?.let {
                reconciledRemaining += it
                remainingPool.remove(it)
            }
            remainingPool.shuffle()
            reconciledRemaining += remainingPool

            order = playedPrefix + reconciledRemaining
            position = playedPrefix.size
        }

        if (order.isEmpty() || position >= order.size) {
            order = newCycle(enabledIds, lastPlayedId)
            position = 0
            pendingId = null
        }

        if (pendingId == null) {
            pendingId = order.getOrNull(position)
            persist(order, position, pendingId, lastPlayedId)
        } else {
            persist(order, position, pendingId, lastPlayedId)
        }

        return pendingId?.let { db.clips().byIdEnabled(it) }
    }

    /** Advance the bag only when the selected insert really started playing. */
    fun confirmPlayed(clipId: Long) {
        val order = readOrder()
        var position = prefs.getInt(KEY_POSITION, 0).coerceIn(0, order.size)
        val pendingId = prefs.getLong(KEY_PENDING_ID, -1L).takeIf { it >= 0L }

        if (pendingId == clipId) {
            if (order.getOrNull(position) == clipId) {
                position += 1
            } else {
                val index = order.indexOf(clipId)
                if (index >= position) position = index + 1
            }
        }

        persist(order, position, null, clipId)
    }

    private fun newCycle(enabledIds: List<Long>, lastPlayedId: Long?): List<Long> {
        val order = enabledIds.distinct().shuffled().toMutableList()
        if (order.size > 1 && lastPlayedId != null && order.firstOrNull() == lastPlayedId) {
            val swapIndex = order.indexOfFirst { it != lastPlayedId }
            if (swapIndex > 0) {
                val tmp = order[0]
                order[0] = order[swapIndex]
                order[swapIndex] = tmp
            }
        }
        return order
    }

    private fun readOrder(): List<Long> = prefs.getString(KEY_ORDER, "")
        .orEmpty()
        .split(',')
        .mapNotNull { it.toLongOrNull() }

    private fun persist(order: List<Long>, position: Int, pendingId: Long?, lastPlayedId: Long?) {
        prefs.edit()
            .putString(KEY_ORDER, order.joinToString(","))
            .putInt(KEY_POSITION, position.coerceIn(0, order.size))
            .putLong(KEY_PENDING_ID, pendingId ?: -1L)
            .putLong(KEY_LAST_PLAYED_ID, lastPlayedId ?: -1L)
            .commit()
    }

    private fun clear() {
        prefs.edit().clear().commit()
    }

    companion object {
        private const val KEY_ORDER = "order"
        private const val KEY_POSITION = "position"
        private const val KEY_PENDING_ID = "pending_id"
        private const val KEY_LAST_PLAYED_ID = "last_played_id"
    }
}
