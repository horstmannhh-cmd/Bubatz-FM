package fm.bubatz.player.playback

import fm.bubatz.player.data.BubatzDatabase
import fm.bubatz.player.data.RadioClipEntity
import fm.bubatz.player.data.TrackEntity
import kotlin.math.max
import kotlin.random.Random

/**
 * Persistent fair + human-friendly shuffle for very large libraries.
 *
 * Fairness remains the hard rule: only tracks from the currently least-played
 * tier are eligible. From a random candidate window we then prefer artists and
 * albums that have not appeared recently. This keeps the result genuinely
 * random without the very human-unfriendly clusters produced by plain RANDOM().
 */
class ShuffleManager(private val db: BubatzDatabase) {
    suspend fun nextTrack(excludeId: Long? = null): TrackEntity? {
        val candidates = db.tracks().leastPlayedCandidates(excludeId, 64)
        if (candidates.isEmpty()) return null
        if (candidates.size == 1) return candidates.first()

        val recent = db.tracks().recentlyPlayed(80)
        val artistRank = mutableMapOf<String, Int>()
        val albumRank = mutableMapOf<String, Int>()
        recent.forEachIndexed { index, track ->
            track.artist?.normalized()?.takeIf { it.isNotEmpty() }?.let { artistRank.putIfAbsent(it, index) }
            track.album?.normalized()?.takeIf { it.isNotEmpty() }?.let { albumRank.putIfAbsent(it, index) }
        }

        // Weighted lottery, not a hard ban. A recently heard artist can still
        // occur if the library/cycle leaves few alternatives, but is strongly
        // disfavoured. Unknown metadata stays neutral.
        val weighted = candidates.map { track ->
            var weight = 1.0
            track.artist?.normalized()?.let { key ->
                artistRank[key]?.let { rank ->
                    weight *= when {
                        rank == 0 -> 0.01
                        rank < 3 -> 0.04
                        rank < 8 -> 0.12
                        rank < 20 -> 0.35
                        else -> 0.75
                    }
                }
            }
            track.album?.normalized()?.let { key ->
                albumRank[key]?.let { rank ->
                    weight *= when {
                        rank < 3 -> 0.20
                        rank < 10 -> 0.45
                        else -> 0.80
                    }
                }
            }
            track to max(weight, 0.0001)
        }

        val total = weighted.sumOf { it.second }
        var pick = Random.nextDouble(total)
        for ((track, weight) in weighted) {
            pick -= weight
            if (pick <= 0.0) return track
        }
        return weighted.last().first
    }

    suspend fun nextRadioClip(excludeId: Long? = null): RadioClipEntity? =
        db.clips().randomLeastPlayed(excludeId)

    private fun String.normalized(): String = trim().lowercase()
}
