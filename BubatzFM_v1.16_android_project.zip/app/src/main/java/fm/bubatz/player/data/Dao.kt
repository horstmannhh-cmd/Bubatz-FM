package fm.bubatz.player.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TrackDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(items: List<TrackEntity>): List<Long>

    @Query("SELECT COUNT(*) FROM tracks WHERE enabled = 1")
    fun observeCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM tracks WHERE enabled = 1")
    suspend fun count(): Int

    @Query("SELECT id FROM tracks WHERE enabled = 1 ORDER BY id")
    suspend fun allEnabledIds(): List<Long>

    @Query("SELECT * FROM tracks WHERE id = :id")
    suspend fun byId(id: Long): TrackEntity?

    @Query("SELECT * FROM tracks WHERE id = :id AND enabled = 1")
    suspend fun byIdEnabled(id: Long): TrackEntity?

    @Query("UPDATE tracks SET enabled = 0")
    suspend fun disableAll()

    @Query("UPDATE tracks SET enabled = 1 WHERE uri IN (:uris)")
    suspend fun enableByUris(uris: List<String>)

    @Query("""
        SELECT * FROM tracks
        WHERE enabled = 1
          AND playCount = (SELECT MIN(playCount) FROM tracks WHERE enabled = 1)
          AND (:excludeId IS NULL OR id != :excludeId)
        ORDER BY RANDOM()
        LIMIT 1
    """)
    suspend fun randomLeastPlayed(excludeId: Long? = null): TrackEntity?

    @Query("UPDATE tracks SET lastPlayed=:playedAt, playCount=playCount+1 WHERE id=:id")
    suspend fun markPlayed(id: Long, playedAt: Long)

    @Query("""
        UPDATE tracks
        SET title = :title,
            artist = :artist,
            album = :album,
            durationMs = :durationMs
        WHERE id = :id
    """)
    suspend fun updateMetadata(
        id: Long,
        title: String,
        artist: String?,
        album: String?,
        durationMs: Long
    )
}

@Dao
interface RadioClipDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(items: List<RadioClipEntity>): List<Long>

    @Query("SELECT COUNT(*) FROM radio_clips WHERE enabled=1")
    fun observeCount(): Flow<Int>

    @Query("SELECT id FROM radio_clips WHERE enabled = 1 ORDER BY id")
    suspend fun allEnabledIds(): List<Long>

    @Query("SELECT * FROM radio_clips WHERE id=:id")
    suspend fun byId(id: Long): RadioClipEntity?

    @Query("SELECT * FROM radio_clips WHERE id=:id AND enabled = 1")
    suspend fun byIdEnabled(id: Long): RadioClipEntity?

    @Query("UPDATE radio_clips SET enabled = 0")
    suspend fun disableAll()

    @Query("UPDATE radio_clips SET enabled = 1 WHERE uri IN (:uris)")
    suspend fun enableByUris(uris: List<String>)

    @Query("""
        SELECT * FROM radio_clips
        WHERE enabled = 1
          AND playCount = (SELECT MIN(playCount) FROM radio_clips WHERE enabled = 1)
          AND (:excludeId IS NULL OR id != :excludeId)
        ORDER BY RANDOM()
        LIMIT 1
    """)
    suspend fun randomLeastPlayed(excludeId: Long? = null): RadioClipEntity?

    @Query("UPDATE radio_clips SET lastPlayed=:playedAt, playCount=playCount+1 WHERE id=:id")
    suspend fun markPlayed(id: Long, playedAt: Long)
}

@Dao
interface ShuffleDao {
    @Query("DELETE FROM shuffle_queue") suspend fun clearTracks()
    @Insert suspend fun insertTracks(items: List<ShuffleQueueEntity>)
    @Query("SELECT trackId FROM shuffle_queue WHERE cycle=:cycle AND position=:position LIMIT 1")
    suspend fun trackAt(cycle: Long, position: Int): Long?

    @Query("DELETE FROM radio_shuffle_queue") suspend fun clearClips()
    @Insert suspend fun insertClips(items: List<RadioShuffleQueueEntity>)
    @Query("SELECT clipId FROM radio_shuffle_queue WHERE cycle=:cycle AND position=:position LIMIT 1")
    suspend fun clipAt(cycle: Long, position: Int): Long?
}

@Dao
interface StateDao {
    @Query("SELECT * FROM playback_state WHERE `key`='main' LIMIT 1")
    suspend fun get(): PlaybackStateEntity?

    @Query("SELECT * FROM playback_state WHERE `key`='main' LIMIT 1")
    fun observe(): Flow<PlaybackStateEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(state: PlaybackStateEntity)
}



@Dao
interface ScrobbleQueueDao {
    @Insert
    suspend fun enqueue(item: ScrobbleQueueEntity): Long

    @Query("SELECT * FROM scrobble_queue WHERE submitted = 0 ORDER BY startedAtSeconds ASC LIMIT :limit")
    suspend fun pending(limit: Int = 100): List<ScrobbleQueueEntity>

    @Query("UPDATE scrobble_queue SET submitted = 1 WHERE id = :id")
    suspend fun markSubmitted(id: Long)

    @Query("UPDATE scrobble_queue SET attempts = attempts + 1 WHERE id = :id")
    suspend fun markAttempt(id: Long)

    @Query("SELECT COUNT(*) FROM scrobble_queue WHERE submitted = 0")
    suspend fun pendingCount(): Int
}

@Dao
interface HistoryDao {
    @Insert
    suspend fun insert(item: PlayHistoryEntity)

    @Query("SELECT * FROM play_history ORDER BY playedAt DESC LIMIT :limit")
    suspend fun recent(limit: Int = 100): List<PlayHistoryEntity>

    @Query("""
        SELECT h.id AS historyId, h.playedAt AS playedAt, t.id AS trackId,
               t.title AS title, t.artist AS artist, t.album AS album, t.uri AS uri
        FROM play_history h
        INNER JOIN tracks t ON t.id = h.trackId
        WHERE h.type = 'MUSIC' AND h.trackId IS NOT NULL
        ORDER BY h.playedAt DESC
        LIMIT :limit
    """)
    fun observeRecentMusic(limit: Int = 50): Flow<List<RecentMusicItem>>

    @Query("""
        DELETE FROM play_history
        WHERE id NOT IN (SELECT id FROM play_history ORDER BY playedAt DESC LIMIT :keep)
    """)
    suspend fun trimTo(keep: Int = 200)
}

@Database(
    entities = [
        TrackEntity::class, RadioClipEntity::class,
        ShuffleQueueEntity::class, RadioShuffleQueueEntity::class,
        PlaybackStateEntity::class, ScrobbleQueueEntity::class, PlayHistoryEntity::class
    ],
    version = 5,
    exportSchema = false
)
abstract class BubatzDatabase : RoomDatabase() {
    abstract fun tracks(): TrackDao
    abstract fun clips(): RadioClipDao
    abstract fun shuffle(): ShuffleDao
    abstract fun state(): StateDao
    abstract fun history(): HistoryDao
    abstract fun scrobbles(): ScrobbleQueueDao

    companion object {
        private val MIGRATION_4_5 = object : androidx.room.migration.Migration(4, 5) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE playback_state ADD COLUMN currentTitle TEXT")
                db.execSQL("ALTER TABLE playback_state ADD COLUMN currentArtist TEXT")
                db.execSQL("ALTER TABLE playback_state ADD COLUMN currentAlbum TEXT")
            }
        }

        private val MIGRATION_3_4 = object : androidx.room.migration.Migration(3, 4) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE playback_state ADD COLUMN currentDurationMs INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE playback_state ADD COLUMN isPlaying INTEGER NOT NULL DEFAULT 0")
            }
        }

        private val MIGRATION_2_3 = object : androidx.room.migration.Migration(2, 3) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE playback_state ADD COLUMN currentMediaId TEXT")
                db.execSQL("ALTER TABLE playback_state ADD COLUMN upcomingMediaId TEXT")
            }
        }

        fun create(context: android.content.Context): BubatzDatabase =
            Room.databaseBuilder(context, BubatzDatabase::class.java, "bubatz-fm.db")
                .addMigrations(MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5)
                .fallbackToDestructiveMigrationOnDowngrade()
                .build()
    }
}
