# Bubatz.FM 1.49.65 – A26

Basis: 1.49.64 A26 Heartbeat Diagnostic.

## Änderungen
- Charging/Idle-Härtung: ExoPlayer hält während aktiver lokaler Wiedergabe explizit einen lokalen WakeLock (`C.WAKE_MODE_LOCAL`); Manifest um `WAKE_LOCK` ergänzt. MediaSessionService bleibt `foregroundServiceType="mediaPlayback"` und `START_STICKY` unverändert.
- Album-/Inhaltsstoffe-Navigation: Album-Bottom-Sheet wird auf 90 % der verfügbaren Höhe begrenzt; die Titelliste nutzt den verbleibenden Raum als Scrollbereich. Der untere „Zurück zu den Inhaltsstoffen“-Button bleibt dadurch vollständig im sichtbaren Footer.
- Programmübersicht: „Gebrauchsanweisung“ heißt jetzt „Wirkungsprofil“.
- Subline ergänzt: „Den Tag in vollen Zügen genießen.“
- Heartbeat-Diagnostik aus 1.49.64 bleibt erhalten.

## Bewusst unverändert
- Bubatz.IQ / Weighted Shuffle / Künstlerabstände
- Bibliotheks- und Testdaten
- Crossfade-Logik
- Last.fm-Logik
- Audio-Pegel / AudioAttributes

Hinweis: Der SIGKILL beim Laden/Idle ist anhand der bisherigen Daten nicht abschließend auf eine einzelne Android-/Samsung-Komponente zurückführbar. Die WakeLock-Ergänzung ist eine gezielte Härtung für den beobachteten Screen-off/Charging-Idle-Fall; die Heartbeat-Historie bleibt zur Verifikation aktiv.
