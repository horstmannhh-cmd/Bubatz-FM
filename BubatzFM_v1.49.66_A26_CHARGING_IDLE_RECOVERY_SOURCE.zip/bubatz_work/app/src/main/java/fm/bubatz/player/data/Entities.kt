package fm.bubatz.player.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "tracks",
    indices = [Index(value = ["uri"], unique = true), Index("artist"), Index("album")]
)
data class TrackEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uri: String,
    val title: String,
    val artist: String?,
    val album: String?,
    val albumArtist: String? = null,
    val isCompilation: Boolean? = null,
    val durationMs: Long,
    val dateAdded: Long = System.currentTimeMillis(),
    val lastPlayed: Long? = null,
    val playCount: Int = 0,
    val flowCycle: Long = 0,
    val enabled: Boolean = true
)

// Metadata processing is independent of playback and the IQ deck.
// 1 = inspected (including genuinely absent tags); 2 = file read failed.
@Entity(tableName = "metadata_scan", indices = [Index("status")])
data class MetadataScanEntity(
    @PrimaryKey val trackId: Long,
    val status: Int,
    val inspectedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "radio_clips",
    indices = [Index(value = ["uri"], unique = true)]
)
data class RadioClipEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uri: String,
    val name: String,
    val category: String = "Allgemein",
    val durationMs: Long,
    val lastPlayed: Long? = null,
    val playCount: Int = 0,
    val enabled: Boolean = true
)

@Entity(tableName = "shuffle_queue")
data class ShuffleQueueEntity(
    @PrimaryKey val position: Int,
    val trackId: Long,
    val cycle: Long
)

@Entity(tableName = "radio_shuffle_queue")
data class RadioShuffleQueueEntity(
    @PrimaryKey val position: Int,
    val clipId: Long,
    val cycle: Long
)

@Entity(tableName = "playback_state")
data class PlaybackStateEntity(
    @PrimaryKey val key: String = "main",
    val shuffleCycle: Long = 0,
    val shufflePosition: Int = 0,
    val radioCycle: Long = 0,
    val radioPosition: Int = 0,
    val currentTrackId: Long? = null,
    val currentMediaId: String? = null,
    val upcomingMediaId: String? = null,
    val currentPositionMs: Long = 0,
    val currentDurationMs: Long = 0,
    val currentTitle: String? = null,
    val currentArtist: String? = null,
    val currentAlbum: String? = null,
    val isPlaying: Boolean = false,
    val nextRadioAtMs: Long = 0
)


data class RecentMusicItem(
    val historyId: Long,
    val playedAt: Long,
    val trackId: Long,
    val title: String,
    val artist: String?,
    val album: String?,
    val uri: String
)

@Entity(tableName = "scrobble_queue")
data class ScrobbleQueueEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val trackId: Long,
    val startedAtSeconds: Long,
    val attempts: Int = 0,
    val submitted: Boolean = false
)


@Entity(
    tableName = "play_history",
    indices = [Index("playedAt"), Index("trackId"), Index("clipId")]
)
data class PlayHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playedAt: Long = System.currentTimeMillis(),
    val type: String, // MUSIC or RADIO
    val trackId: Long? = null,
    val clipId: Long? = null,
    val title: String
)
