# Bubatz.FM 1.49.66 – A26 Charging/Idle Recovery

- START_STICKY recovery: after an Android process kill, playback resumes only if the last persisted state was actively playing.
- Normal app/service startup remains paused; no unintended autoplay on ordinary launch.
- A preselected crossfade successor is persisted immediately and restored without a second Bubatz.IQ selection.
- Existing charging/idle diagnostics remain enabled for verification.
- Wirkungsprofil heading enlarged from 13.5sp to 17sp.
- Bubatz.IQ selection logic itself is unchanged.
