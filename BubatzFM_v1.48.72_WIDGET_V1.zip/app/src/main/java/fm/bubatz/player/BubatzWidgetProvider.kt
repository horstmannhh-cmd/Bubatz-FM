package fm.bubatz.player

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.widget.RemoteViews
import fm.bubatz.player.data.BubatzDatabase
import fm.bubatz.player.playback.PlaybackService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalTime

class BubatzWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateAsync(context, manager, it) }
    }

    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager, appWidgetId: Int, newOptions: android.os.Bundle) {
        updateAsync(context, manager, appWidgetId)
    }

    companion object {
        const val EXTRA_OPEN_PROGRAM = "fm.bubatz.player.OPEN_PROGRAM"
        private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, BubatzWidgetProvider::class.java))
            ids.forEach { updateAsync(context.applicationContext, manager, it) }
        }

        private fun updateAsync(context: Context, manager: AppWidgetManager, id: Int) {
            scope.launch {
                val db = (context.applicationContext as BubatzApplication).database
                val state = db.state().get()
                val track = state?.currentTrackId?.let { db.tracks().byId(it) }
                val compact = manager.getAppWidgetOptions(id).getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250) < 250
                val layout = if (compact) R.layout.widget_bubatz_compact else R.layout.widget_bubatz_standard
                val views = RemoteViews(context.packageName, layout)

                val isRadio = state?.currentMediaId?.startsWith("radio:") == true
                val title = if (isRadio) (state?.currentTitle ?: "Einspieler") else (state?.currentTitle ?: track?.title ?: "Bubatz.FM")
                val artist = if (isRadio) "Bubatz.FM · Einspieler" else (state?.currentArtist ?: track?.artist ?: "Bereit für Musik")
                val program = currentProgramName()

                views.setTextViewText(R.id.widget_title, title)
                views.setTextViewText(R.id.widget_artist, artist)
                views.setTextViewText(R.id.widget_program, program)
                views.setImageViewResource(R.id.widget_play_pause, if (state?.isPlaying == true) R.drawable.ic_widget_pause else R.drawable.ic_widget_play)

                val art = if (!isRadio) track?.uri?.let { loadArtwork(context, it) } else null
                if (art != null) views.setImageViewBitmap(R.id.widget_cover, art)
                else views.setImageViewResource(R.id.widget_cover, if (isRadio) R.drawable.bubatz_placeholder_cover else R.drawable.bubatz_placeholder_cover)

                views.setOnClickPendingIntent(R.id.widget_cover, activityIntent(context, false, 8100 + id))
                views.setOnClickPendingIntent(R.id.widget_logo, activityIntent(context, false, 8200 + id))
                views.setOnClickPendingIntent(R.id.widget_program_area, activityIntent(context, true, 8300 + id))
                views.setOnClickPendingIntent(R.id.widget_program, activityIntent(context, true, 8350 + id))
                views.setOnClickPendingIntent(R.id.widget_previous, serviceIntent(context, PlaybackService.ACTION_PREVIOUS, 8400 + id))
                views.setOnClickPendingIntent(R.id.widget_play_pause, serviceIntent(context, PlaybackService.ACTION_PLAY_PAUSE, 8500 + id))
                views.setOnClickPendingIntent(R.id.widget_next, serviceIntent(context, PlaybackService.ACTION_NEXT, 8600 + id))
                manager.updateAppWidget(id, views)
            }
        }

        private fun activityIntent(context: Context, openProgram: Boolean, requestCode: Int): PendingIntent {
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                if (openProgram) putExtra(EXTRA_OPEN_PROGRAM, true)
            }
            return PendingIntent.getActivity(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        private fun serviceIntent(context: Context, action: String, requestCode: Int): PendingIntent {
            val intent = Intent(context, PlaybackService::class.java).setAction(action)
            return if (Build.VERSION.SDK_INT >= 26) PendingIntent.getForegroundService(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            else PendingIntent.getService(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        private fun currentProgramName(now: LocalTime = LocalTime.now()): String = when (now.hour) {
            in 0..2 -> "Der Nachtbus"; in 3..5 -> "Dunstabzug"; in 6..8 -> "Morgenglühen"; in 9..11 -> "Blütezeit"
            in 12..14 -> "High Noon"; in 15..17 -> "Drehmoment"; in 18..20 -> "Klangsog"; else -> "Sofaschwere"
        }

        private suspend fun loadArtwork(context: Context, uri: String): Bitmap? = withContext(Dispatchers.IO) {
            runCatching {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, Uri.parse(uri))
                    val bytes = retriever.embeddedPicture ?: return@runCatching null
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                    var sample = 1
                    while (bounds.outWidth / sample > 320 || bounds.outHeight / sample > 320) sample *= 2
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
                } finally { retriever.release() }
            }.getOrNull()
        }
    }
}
