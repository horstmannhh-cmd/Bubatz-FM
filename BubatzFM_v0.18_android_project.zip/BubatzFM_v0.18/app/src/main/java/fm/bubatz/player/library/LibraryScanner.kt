package fm.bubatz.player.library

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.DocumentsContract
import fm.bubatz.player.data.RadioClipEntity
import fm.bubatz.player.data.TrackEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LibraryScanner(private val context: Context) {
    private val audioExt = setOf("mp3", "flac", "m4a", "aac", "ogg", "opus", "wav", "wma")

    data class ScanStats(
        var directoriesVisited: Int = 0,
        var filesVisited: Int = 0,
        var audioRecognized: Int = 0,
        var metadataRead: Int = 0,
        var metadataFailed: Int = 0,
        var queryErrors: Int = 0
    )

    data class MusicScanResult(
        val tracks: List<TrackEntity>,
        val stats: ScanStats,
        val rootDocumentId: String?,
        val error: String? = null
    )

    suspend fun scanMusicDetailed(treeUri: Uri): MusicScanResult = withContext(Dispatchers.IO) {
        val stats = ScanStats()
        val tracks = mutableListOf<TrackEntity>()

        val rootId = runCatching { DocumentsContract.getTreeDocumentId(treeUri) }
            .getOrNull()

        if (rootId == null) {
            return@withContext MusicScanResult(
                tracks = emptyList(),
                stats = stats,
                rootDocumentId = null,
                error = "Tree-Document-ID konnte nicht gelesen werden."
            )
        }

        val rootDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)

        runCatching {
            scanDocumentTree(
                treeUri = treeUri,
                documentUri = rootDocUri,
                stats = stats,
                onAudio = { uri, name ->
                    val meta = metadataOrNull(uri)
                    if (meta != null) stats.metadataRead++ else stats.metadataFailed++
                    tracks += TrackEntity(
                        uri = uri.toString(),
                        title = meta?.title ?: name.substringBeforeLast('.'),
                        artist = meta?.artist,
                        album = meta?.album,
                        durationMs = meta?.duration ?: 0L
                    )
                }
            )
        }.onFailure {
            return@withContext MusicScanResult(
                tracks = tracks,
                stats = stats,
                rootDocumentId = rootId,
                error = "${it::class.java.simpleName}: ${it.message ?: "unbekannter Fehler"}"
            )
        }

        MusicScanResult(
            tracks = tracks,
            stats = stats,
            rootDocumentId = rootId
        )
    }

    suspend fun scanMusic(treeUri: Uri): List<TrackEntity> =
        scanMusicDetailed(treeUri).tracks

    suspend fun scanRadio(treeUri: Uri): List<RadioClipEntity> = withContext(Dispatchers.IO) {
        val result = mutableListOf<RadioClipEntity>()
        val stats = ScanStats()
        val rootId = runCatching { DocumentsContract.getTreeDocumentId(treeUri) }
            .getOrNull() ?: return@withContext emptyList()

        val rootDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
        runCatching {
            scanDocumentTree(
                treeUri = treeUri,
                documentUri = rootDocUri,
                stats = stats,
                onAudio = { uri, name ->
                    val meta = metadataOrNull(uri)
                    result += RadioClipEntity(
                        uri = uri.toString(),
                        name = meta?.title ?: name.substringBeforeLast('.'),
                        durationMs = meta?.duration ?: 0L
                    )
                }
            )
        }
        result
    }

    private fun scanDocumentTree(
        treeUri: Uri,
        documentUri: Uri,
        stats: ScanStats,
        onAudio: (Uri, String) -> Unit
    ) {
        stats.directoriesVisited++

        val documentId = DocumentsContract.getDocumentId(documentUri)
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, documentId)

        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )

        val cursor = try {
            context.contentResolver.query(childrenUri, projection, null, null, null)
        } catch (t: Throwable) {
            stats.queryErrors++
            return
        }

        if (cursor == null) {
            stats.queryErrors++
            return
        }

        cursor.use { c ->
            val idIndex = c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameIndex = c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeIndex = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)

            while (c.moveToNext()) {
                val childId = if (idIndex >= 0) c.getString(idIndex) else null
                if (childId.isNullOrBlank()) continue

                val name = if (nameIndex >= 0) c.getString(nameIndex) ?: "Unbekannt" else "Unbekannt"
                val mime = if (mimeIndex >= 0) c.getString(mimeIndex) else null
                val childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childId)

                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    scanDocumentTree(treeUri, childUri, stats, onAudio)
                } else {
                    stats.filesVisited++
                    if (isAudio(name, mime)) {
                        stats.audioRecognized++
                        onAudio(childUri, name)
                    }
                }
            }
        }
    }

    private fun isAudio(name: String, mime: String?): Boolean {
        val ext = name.substringAfterLast('.', "").lowercase()
        return ext in audioExt || mime?.startsWith("audio/") == true
    }

    private data class Meta(
        val title: String?,
        val artist: String?,
        val album: String?,
        val duration: Long
    )

    private fun metadataOrNull(uri: Uri): Meta? = runCatching {
        val retriever = MediaMetadataRetriever()
        try {
            val opened = runCatching {
                context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                    retriever.setDataSource(pfd.fileDescriptor)
                    true
                } ?: false
            }.getOrDefault(false)

            if (!opened) {
                retriever.setDataSource(context, uri)
            }

            Meta(
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE),
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST),
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM),
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull() ?: 0L
            )
        } finally {
            retriever.release()
        }
    }.getOrNull()
}
