# Bubatz FM v0.33

- Stabiler v0.32-Minimalplayer bleibt die Basis.
- Echte Wiedergabe-History ergänzt.
- „Zurück“: nach mehr als 5 Sekunden wird der aktuelle Titel neu gestartet; nahe am Titelanfang wird der vorherige Titel geladen.
- History wird erst geschrieben, wenn ein Titel tatsächlich zu spielen beginnt.
- Play/Pause, Next und Hintergrundwiedergabe bleiben unverändert.
- Noch kein Crossfade und noch keine Radioeinspieler in diesem Build.

# Bubatz FM v0.32

- Behebt die Auswahl des Diagnosebuilds durch den GitHub-Workflow: jetzt wieder rein numerische Versionsnummer.
- Sanity-Check ist für den Minimalplayer explizit auf die tatsächlich benötigten Komponenten reduziert.
- Der Minimalplayer selbst bleibt gegenüber v0.31 unverändert.

# Bubatz FM v0.31b

- Korrigiert ausschließlich die Build-Pipeline des Minimalplayer-Diagnosebuilds.
- Die drei alten Architekturprüfungen für DualDeck/Radio/Previous werden für diesen Diagnosebuild bewusst übersprungen.
- Der eigentliche Minimalplayer-Code aus v0.31 bleibt unverändert.

# Bubatz FM v0.31 Minimalplayer

- PlaybackService vollständig neu und minimal aufgebaut.
- Nur EIN ExoPlayer und EINE MediaSession.
- DualDeck, Crossfade, Radioeinspieler, Last.fm, History-Wrapper und Session-Fassade sind aus dem Wiedergabepfad entfernt.
- Play/Pause/Next funktionieren direkt über den neuen Minimalplayer.
- Titelwahl bleibt fair-random über playCount.
- Aktueller Titel und Wiedergabestatus werden weiter in der bestehenden Datenbank gespeichert.
- Bibliothek bleibt vollständig erhalten; kein erneutes Einlesen nötig.
- Ziel dieses Builds: erstmals echte hörbare Wiedergabe über den Service stabil herstellen.

# Bubatz FM v0.30 Activity-Isolation

- Play-Taste startet für diesen Test keinen PlaybackService.
- Ein zufälliger Titel wird in den App-Cache kopiert und direkt von einem ExoPlayer in MainActivity verarbeitet.
- MediaSessionService, DualDeck und Foreground-Service sind vollständig aus dem Testpfad entfernt.
- Wiedergabe bleibt stumm und läuft 3 Sekunden.
- Wenn v0.30 stabil ist, liegt die Crash-Ursache eindeutig im Service/MediaSession-Lebenszyklus.
- Bibliothek bleibt unverändert erhalten.

# Bubatz FM v0.29 Local-File-Isolation

- Prüft, ob der Crash vom SAF/content://-Datenpfad stammt.
- Ein zufälliger Titel wird zunächst über ContentResolver in den App-Cache kopiert.
- ExoPlayer erhält danach ausschließlich eine lokale file://-URI.
- Wiedergabe bleibt stumm; der Test läuft 3 Sekunden.
- Wenn v0.29 stabil bleibt, liegt die Ursache sehr wahrscheinlich im direkten content://-Playback.
- Bibliothek bleibt unverändert erhalten.

# Bubatz FM v0.28 Audio-Isolation

- Isoliert den Absturz direkt nach playWhenReady=true.
- Der Audio-Renderer wird vor dem Aktivieren der Wiedergabe vollständig deaktiviert.
- Wenn der Prozess damit stabil bleibt, liegt der Crash sehr wahrscheinlich im Audio-Renderer/Decoder/AudioSink/Audio-Fokus-Pfad.
- ExoPlayer-Fehler und Playback-State-Änderungen werden zusätzlich persistent protokolliert.
- Noch keine hörbare Wiedergabe; Bibliothek bleibt unverändert erhalten.

# Bubatz FM v0.27 Post-prepare-Diagnose

- Testet ausschließlich die Schritte nach erfolgreichem prepare().
- Prüft volume=0, playWhenReady=true, 1,5 s aktiven Zustand, play(), erneut 1,5 s, pause() und release().
- Audio bleibt stumm, damit wir nur den technischen Wiedergabestart untersuchen.
- Jede Stufe wird persistent protokolliert.
- Bibliothek bleibt erhalten; kein erneutes Einlesen nötig.

# Bubatz FM v0.26 Stufendiagnose

- Wiedergabestart in klar getrennte Diagnose-Stufen zerlegt.
- Jede erreichte Stufe wird dauerhaft gespeichert, bevor die nächste beginnt.
- Geprüft werden: Service-Befehl, Initialisierung, Zufallstitel, URI, Dateizugriff, ExoPlayer-Erzeugung, MediaItem-Erzeugung, setMediaItem() und prepare().
- In v0.26 wird absichtlich noch KEIN play() aufgerufen.
- Ziel: exakt feststellen, welche einzelne Media3-Operation den Prozess beendet.
- Bibliothek bleibt vollständig erhalten; kein erneutes Einlesen nötig.

# Bubatz FM v0.25 Systemdiagnose

- Liest Androids eigene `ApplicationExitInfo`-Historie aus.
- Zeigt, ob der letzte Prozessabbruch ein Java-Crash, Native-Crash, ANR, Service-/Initialisierungsfehler, OS-Kill oder anderer Grund war.
- Liest vorhandene System-Traces aus, wenn Android sie bereitstellt.
- Für diesen Test muss Play NICHT erneut gedrückt werden: zuerst den bereits aufgezeichneten Absturz aus v0.24 auslesen.
- Bibliothek bleibt unverändert erhalten.

# Bubatz FM v0.24 Service-Fix

- Wichtiger Fix im MediaSessionService-Lebenszyklus.
- Eigene Bubatz-FM-Intents (Play/Pause/Next/Previous/Bluetooth-Autostart) werden nicht mehr an `MediaSessionService.super.onStartCommand()` weitergereicht.
- Hintergrund: v0.23 zeigte, dass der URI-Preflight vollständig erfolgreich war und der Prozess erst danach abstürzte. Damit liegt der Verdacht stark auf der Weitergabe des benutzerdefinierten Intent an MediaSessionService.
- v0.24 bleibt zunächst Preflight-only: Play prüft die Datei, startet aber noch keine Audioausgabe.
- Bibliothek bleibt vollständig erhalten; kein erneutes Einlesen nötig.

# Bubatz FM v0.23 URI-Preflight

- Crash-Schleife behoben: gespeicherter Wiedergabestatus wird beim Start sicher zurückgesetzt, Bibliothek bleibt erhalten.
- Play startet in dieser Diagnoseversion absichtlich noch keine Audioausgabe.
- Stattdessen wird ein Zufallstitel gewählt und sein SAF-/Content-URI direkt auf Lesbarkeit geprüft.
- Diagnose zeigt Titel-ID, URI, Scheme, Authority, Dateizugriff und Dateilänge.
- Damit lässt sich eindeutig feststellen, ob der Absturz vor ExoPlayer an einem ungültigen/unerreichbaren Dokument-URI liegt.
- Bibliothek muss nicht neu eingelesen werden.

# Bubatz FM v0.22 Diagnose

- Wiedergabestart protokolliert jeden kritischen Schritt dauerhaft.
- Unbehandelte Java/Kotlin-Abstürze werden dauerhaft gespeichert.
- ExoPlayer-Fehler werden mit mediaId und URI gespeichert.
- MediaMetadataRetriever wurde vollständig aus dem ersten Wiedergabeweg entfernt.
- Eingebettete Albumcover-Abfrage vorübergehend deaktiviert, um native Metadaten-Crashes auszuschließen.
- Play wartet jetzt sicher auf abgeschlossene Service-Initialisierung.
- Diagnose ist in Einstellungen → Wiedergabe-Diagnose sichtbar.
- Bestehende Bibliothek bleibt kompatibel; kein erneutes Einlesen nötig.

# Bubatz FM v0.21

- Wiedergabestart für sehr große Bibliotheken grundlegend entschärft.
- Kein Aufbau einer 40.000+-Zeilen-Shuffle-Queue mehr beim ersten Play.
- Persistentes Fair-Shuffle über playCount: jeder Titel kommt einmal dran, bevor Wiederholungen möglich werden.
- Frische Bibliothek wählt erst beim tatsächlichen Play-Befehl einen Titel, nicht beim Service-Start.
- Manuelle Player-Steuerung startet keinen unnötigen Foreground-Service vor der Wiedergabe.
- SAF-Metadatenzugriff vereinfacht.
- Audio-Datei-URI wird nicht mehr fälschlich als Artwork-URI an Media3 übergeben.
- Ein Titel gilt erst als gespielt, wenn die Wiedergabe tatsächlich startet, nicht schon beim Vorladen.
- Bestehende 40.836-Titel-Datenbank bleibt kompatibel; kein erneutes Einlesen nötig.

# Bubatz FM v0.20

- Bibliotheksimport für sehr große Sammlungen umgebaut: zuerst schnelle Dateierfassung und DB-Speicherung, keine 40.000 Metadaten-Lesevorgänge mehr vor dem ersten Datenbankeintrag.
- Metadaten werden bei Wiedergabe eines Titels bei Bedarf gelesen.
- DB-Import erfolgt in 1000er-Blöcken.
- Radioeinspieler-Timer zählt jetzt ausschließlich tatsächlich abgespielte MUSIK-Zeit.
- Pause, App-Schließzeit und Einspieler zählen nicht mit.
- Restzeit bis zum nächsten Einspieler wird persistent gespeichert.
- Nach jedem tatsächlich gestarteten Einspieler wird ein neuer Zufallswert von 25–35 Minuten gezogen.

# Bubatz FM v0.19 Diagnose persistent

- Diagnose wird jetzt dauerhaft in SharedPreferences gespeichert.
- Selbst nach Prozess-Neustart oder Absturz bleibt der letzte Scan-Zwischenstand sichtbar.
- Fortschritt wird bereits während Ordner-/Datei-Zählung und Metadatenphase gespeichert.
- Damit lässt sich unterscheiden: Prozessneustart, SAF-Query-Problem, Audio-Erkennung oder Metadatenphase.

# Bubatz FM v0.18 Diagnose

- Ordnerscanner auf direkte Android DocumentsContract-Abfragen umgestellt.
- Rekursive SD-Karten-Suche ohne DocumentFile.listFiles().
- Diagnoseanzeige: besuchte Ordner, Dateien, erkannte Audiodateien, Metadaten-Erfolge/-Fehler, Datenbank-Einfügungen und Query-Fehler.
- Ziel: den 0-Titel-Fehler auf dem realen Gerät eindeutig lokalisieren.

# Bubatz FM v0.17

- Fix: Musikdateien werden nicht mehr verworfen, wenn Android auf der SD-Karte keine Metadaten über MediaMetadataRetriever liefert.
- Metadatenlesung versucht zuerst einen FileDescriptor und fällt bei Bedarf auf die URI-Methode zurück.
- Audioerkennung nutzt zusätzlich den MIME-Type.
- Versionsanzeige auf 0.17 aktualisiert.

# Bubatz FM v0.16

- Fix: Kotlin-Kompilierfehler in `PlaybackService.kt` behoben.
- `dualDeck.activePlayer` ist eine Property und wird jetzt korrekt ohne `()` verwendet.
- Enthält weiterhin die v0.15/v0.14-Anpassungen (JVM 17, 5000 ms Crossfade-Referenz, Bibliotheks-Persistenz/Startlogik/Bluetooth-Autostart-Basis).

# v0.15

- Build-Fix: Java- und Kotlin-JVM-Target einheitlich auf 17 gesetzt.
- Dadurch wird der GitHub-Actions-Fehler bei `:app:kspDebugKotlin` behoben.

# Bubatz FM v0.14

- Bluetooth-Autostart wartet nun zuverlässig auf die Initialisierung des Players.
- Play aus komplettem Leerlauf kann selbst einen Titel aus der Bubatz-FM-Bibliothek auswählen.
- Standard-Crossfade auf 5000 ms gesetzt.
- Bibliothek bleibt in Room gespeichert; Musik wird weiterhin nur aus explizit ausgewählten Ordnern importiert.
- Versionsanzeige auf 0.14 aktualisiert.
