package fm.bubatz.player.playback

import android.content.Intent
import android.os.Build
import android.app.PendingIntent
import android.app.NotificationManager
import android.app.NotificationChannel
import android.media.MediaMetadataRetriever
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.AudioManager
import android.Manifest
import android.content.pm.PackageManager
import android.telephony.TelephonyManager
import android.telephony.TelephonyCallback
import android.telephony.PhoneStateListener
import android.media.MediaMetadata as PlatformMediaMetadata
import android.media.session.MediaSession as PlatformMediaSession
import android.media.session.PlaybackState as PlatformPlaybackState
import android.net.Uri
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.Futures
import androidx.media3.session.SessionResult
import androidx.media3.session.SessionCommand
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.common.util.UnstableApi
import androidx.annotation.OptIn
import android.os.Bundle
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import fm.bubatz.player.BubatzApplication
import fm.bubatz.player.CrashDiagnostics
import fm.bubatz.player.ChargingIdleDiagnostics
import fm.bubatz.player.data.PlaybackStateEntity
import fm.bubatz.player.data.PlayHistoryEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.collectLatest
import fm.bubatz.player.playback.crossfade.FadeEnvelope
import fm.bubatz.player.settings.AppSettings
import fm.bubatz.player.data.TrackEntity
import fm.bubatz.player.playback.session.BubatzSessionPlayer
import fm.bubatz.player.scrobble.LastFmApi
import fm.bubatz.player.scrobble.LastFmScrobbleSender
import fm.bubatz.player.scrobble.LastFmSessionStore
import fm.bubatz.player.scrobble.PlaybackScrobbleTracker
import fm.bubatz.player.scrobble.FlushResult
import fm.bubatz.player.radio.RadioScheduler
import fm.bubatz.player.radio.RadioShuffleBag
import fm.bubatz.player.data.RadioClipEntity

@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {

    companion object {
        const val ACTION_AUTO_PLAY = "fm.bubatz.player.AUTO_PLAY"
        const val ACTION_PLAY_PAUSE = "fm.bubatz.player.PLAY_PAUSE"
        const val ACTION_NEXT = "fm.bubatz.player.NEXT"
        const val ACTION_PREVIOUS = "fm.bubatz.player.PREVIOUS"
        const val ACTION_SEEK = "fm.bubatz.player.SEEK"
        const val ACTION_AUDIO_ACTIVITY_PROBE = "fm.bubatz.player.AUDIO_ACTIVITY_PROBE"
        const val ACTION_AUDIO_PIPELINE_DIAGNOSTIC = "fm.bubatz.player.AUDIO_PIPELINE_DIAGNOSTIC"
        const val ACTION_TEST_RADIO_INSERT = "fm.bubatz.player.TEST_RADIO_INSERT"
        const val ACTION_REFRESH_PHONE_MONITOR = "fm.bubatz.player.REFRESH_PHONE_MONITOR"
        const val ACTION_PLAY_TRACK_ID = "fm.bubatz.player.PLAY_TRACK_ID"
        const val EXTRA_TRACK_ID = "track_id"
        const val EXTRA_SEEK_POSITION_MS = "seek_position_ms"

        private const val SESSION_COMMAND_PREVIOUS = "fm.bubatz.player.session.PREVIOUS"
        private const val SESSION_COMMAND_NEXT = "fm.bubatz.player.session.NEXT"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private lateinit var player: ExoPlayer
    private lateinit var standbyPlayer: ExoPlayer
    private lateinit var session: MediaSession
    private lateinit var bubatzNotificationProvider: BubatzMediaNotificationProvider
    private lateinit var activePlayerListener: Player.Listener
    private var omniaSpeedProbeSession: PlatformMediaSession? = null
    private var omniaAudioProbeTrack: AudioTrack? = null
    private var omniaAudioProbeJob: Job? = null
    private lateinit var shuffle: ShuffleManager
    private lateinit var diagnostics: CrashDiagnostics
    private lateinit var chargingIdleDiagnostics: ChargingIdleDiagnostics
    private var chargingIdleHeartbeatJob: Job? = null
    private lateinit var db: fm.bubatz.player.data.BubatzDatabase
    private lateinit var settings: AppSettings
    private lateinit var lastFmStore: LastFmSessionStore
    private lateinit var lastFmTracker: PlaybackScrobbleTracker
    private lateinit var lastFmSender: LastFmScrobbleSender
    private var lastFmEnabled = false
    private var scrobbleListenedMs = 0L
    private var lastScrobbleTickElapsed = 0L
    private var lastNowPlayingMediaId: String? = null
    private var lastFmFlushElapsed = 0L

    private var currentTrackId: Long? = null
    private var currentRadioClipId: Long? = null
    private var startedCurrentTrack = false
    private var startedCurrentRadio = false

    // v1.06: Radio inserts are scheduled by ACTUAL PLAYED MUSIC time. Pauses,
    // app downtime and inserts themselves do not advance the clock.
    private val radioScheduler = RadioScheduler()
    private lateinit var radioShuffleBag: RadioShuffleBag
    private val radioPrefs by lazy { getSharedPreferences("radio_schedule", MODE_PRIVATE) }
    private var radioEnabled = true
    private var radioMusicListenedMs = 0L
    private var radioTargetMusicMs = 0L
    private var radioDue = false

    // v1.37: While a radio insert is playing, queue the next music item in the
    // SAME ExoPlayer. Media3 can then advance without a stop/prepare gap and,
    // crucially, without publishing STATE_ENDED to Bluetooth between insert and music.
    private var pendingRadioSuccessorTrack: TrackEntity? = null

    // v0.94: one cursor-based history instead of separate back/forward stacks.
    // A → B → C, Previous => B, Next => C. Only at the end is a fresh
    // random title generated.
    private val navigationHistory = NavigationHistory()
    private val navigationPrefs by lazy { getSharedPreferences("navigation_history", MODE_PRIVATE) }

    private fun persistNavigationHistory() {
        val (items, index) = navigationHistory.snapshot()
        val historyCurrentId = items.getOrNull(index)

        // v0.97: this state is tiny but important. Use commit() so a user can
        // swipe the app away immediately after Previous/Next without losing the
        // just-written forward branch before Android kills the process.
        navigationPrefs.edit()
            .putString("items", items.joinToString(","))
            .putInt("index", index)
            .putLong("current_id", historyCurrentId ?: -1L)
            .commit()
    }

    private fun restoreNavigationHistory(currentId: Long?): Boolean {
        val raw = navigationPrefs.getString("items", null) ?: return false
        val items = raw.split(',').mapNotNull { it.toLongOrNull() }
        if (items.isEmpty()) return false

        val savedIndex = navigationPrefs.getInt("index", -1)
        val savedCurrentId = navigationPrefs.getLong("current_id", -1L)
            .takeIf { it >= 0L }

        // Normal path: playback-state and history were persisted in sync.
        if (navigationHistory.restore(items, savedIndex, currentId)) return true

        // v0.97 recovery path: the Room playback-state write can lag behind the
        // synchronous SharedPreferences history write during process shutdown.
        // If the restored current track exists in the saved history, restore the
        // cursor to that exact occurrence rather than discarding the whole branch.
        if (currentId != null) {
            val candidates = items.indices.filter { items[it] == currentId }
            if (candidates.isNotEmpty()) {
                val preferred = candidates.minByOrNull { kotlin.math.abs(it - savedIndex) } ?: candidates.last()
                if (navigationHistory.restore(items, preferred, currentId)) return true
            }
        }

        // Last fallback for an incomplete Room shutdown write: trust the
        // synchronously committed history cursor if it is internally consistent.
        if (savedCurrentId != null && savedIndex in items.indices && items[savedIndex] == savedCurrentId) {
            return navigationHistory.restore(items, savedIndex, savedCurrentId)
        }

        return false
    }


    private fun restoreRadioSchedule() {
        radioMusicListenedMs = radioPrefs.getLong("music_listened_ms", 0L).coerceAtLeast(0L)
        radioTargetMusicMs = radioPrefs.getLong("target_music_ms", 0L)
            .takeIf { it > 0L } ?: radioScheduler.nextMusicIntervalMs()
        radioDue = radioMusicListenedMs >= radioTargetMusicMs
        persistRadioSchedule()
    }

    private fun persistRadioSchedule() {
        radioPrefs.edit()
            .putLong("music_listened_ms", radioMusicListenedMs)
            .putLong("target_music_ms", radioTargetMusicMs)
            .apply()
    }

    private fun resetRadioScheduleAfterInsert() {
        radioMusicListenedMs = 0L
        radioTargetMusicMs = radioScheduler.nextMusicIntervalMs()
        radioDue = false
        persistRadioSchedule()
    }

    private var restoreJob: Job? = null
    private var positionPersistJob: Job? = null
    private var crossfadeMonitorJob: Job? = null
    private var crossfadeJob: Job? = null
    // v1.25: guards hard-cut boundaries (music↔radio) from publishing STATE_ENDED.
    private var radioHardcutJob: Job? = null
    // v1.00: invalidates stale fade coroutines after a manual transition/stop.
    // A cancelled old fade must never clear or overwrite state prepared for a newer track.
    private var crossfadeGeneration: Long = 0L
    private var settingsJob: Job? = null
    private var scrobbleProgressJob: Job? = null
    private var platformSessionSyncJob: Job? = null

    // v1.13: Phone-call interruption state. Notifications do not affect this path.
    private var doNotDisturbCalls = false
    private var phoneCallActive = false
    private var pausedByPhoneCall = false
    private var telephonyCallback: TelephonyCallback? = null
    @Suppress("DEPRECATION")
    private var legacyPhoneStateListener: PhoneStateListener? = null

    private var configuredCrossfadeMs = 5_000
    private var crossfadeInProgress = false
    private var pendingCrossfadeTrack: TrackEntity? = null
    private var pendingCrossfadeItem: MediaItem? = null

    // v1.35: conservative Auto-Cue. Tail analysis is advisory only: if analysis
    // fails or finds no meaningful trailing silence, all proven v1.34 transition
    // behaviour remains unchanged.
    private val tailSilenceAnalyzer by lazy { TailSilenceAnalyzer(this) }
    private var tailAnalysisJob: Job? = null
    private var tailAnalysisTrackId: Long? = null
    private var tailCueOutMs: Long? = null
    private var tailSilenceMs: Long = 0L

    private val previousSessionCommand =
        SessionCommand(SESSION_COMMAND_PREVIOUS, Bundle.EMPTY)
    private val nextSessionCommand =
        SessionCommand(SESSION_COMMAND_NEXT, Bundle.EMPTY)

    private val sessionCallback = object : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val defaultResult = super.onConnect(session, controller)
            val sessionCommands = defaultResult.availableSessionCommands
                .buildUpon()
                .add(previousSessionCommand)
                .add(nextSessionCommand)
                .build()

            // v0.89: the v0.88 ACTION-DIFF measured Bubatz at 0x6fffcd versus
            // Omnia at 0x0f37. Narrow the externally visible player commands to the
            // classic Omnia-like transport set. This does not touch the internal
            // queue, random/history, crossfade or playback implementation.
            val omniaLikePlayerCommands = defaultResult.availablePlayerCommands
                .buildUpon()
                .remove(Player.COMMAND_CHANGE_MEDIA_ITEMS)
                .remove(Player.COMMAND_SEEK_BACK)
                .remove(Player.COMMAND_SEEK_FORWARD)
                .remove(Player.COMMAND_SEEK_TO_MEDIA_ITEM)
                .remove(Player.COMMAND_PREPARE)
                .remove(Player.COMMAND_SET_REPEAT_MODE)
                .remove(Player.COMMAND_SET_SHUFFLE_MODE)
                .remove(Player.COMMAND_SET_SPEED_AND_PITCH)
                .add(Player.COMMAND_PLAY_PAUSE)
                .add(Player.COMMAND_SEEK_IN_CURRENT_MEDIA_ITEM)
                .add(Player.COMMAND_SEEK_TO_PREVIOUS)
                .add(Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM)
                .add(Player.COMMAND_SEEK_TO_NEXT)
                .add(Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM)
                .build()

            return MediaSession.ConnectionResult.accept(
                sessionCommands,
                omniaLikePlayerCommands
            )
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle
        ): ListenableFuture<SessionResult> {
            when (customCommand.customAction) {
                SESSION_COMMAND_PREVIOUS -> {
                    scope.launch {
                        restoreJob?.join()
                        playPreviousInternal()
                    }
                }

                SESSION_COMMAND_NEXT -> {
                    scope.launch {
                        restoreJob?.join()
                        playNextInternal()
                    }
                }

                else -> {
                    return super.onCustomCommand(
                        session,
                        controller,
                        customCommand,
                        args
                    )
                }
            }

            return Futures.immediateFuture(
                SessionResult(SessionResult.RESULT_SUCCESS)
            )
        }
    }

    private fun mediaButtonPreferences(): List<CommandButton> =
        listOf(
            CommandButton.Builder(CommandButton.ICON_PREVIOUS)
                .setDisplayName("Zurück")
                .setSessionCommand(previousSessionCommand)
                .setSlots(CommandButton.SLOT_BACK)
                .build(),
            CommandButton.Builder(CommandButton.ICON_NEXT)
                .setDisplayName("Weiter")
                .setSessionCommand(nextSessionCommand)
                .setSlots(CommandButton.SLOT_FORWARD)
                .build()
        )

    override fun onCreate() {
        super.onCreate()

        diagnostics = CrashDiagnostics(this)
        chargingIdleDiagnostics = ChargingIdleDiagnostics(this)
        db = (application as BubatzApplication).database
        shuffle = ShuffleManager(db, applicationContext)
        radioShuffleBag = RadioShuffleBag(this, db)
        settings = AppSettings(this)
        lastFmStore = LastFmSessionStore(this)
        lastFmTracker = PlaybackScrobbleTracker(db)
        lastFmSender = LastFmScrobbleSender(db, lastFmStore)
        restoreRadioSchedule()
        registerPhoneCallListenerIfPermitted()

        // Diagnostic only: persist the last playback/power/memory state once per minute.
        // No playback, shuffle, radio or Bubatz.IQ state is modified here.
        chargingIdleHeartbeatJob = scope.launch {
            while (true) {
                runCatching {
                    val item = if (::player.isInitialized) player.currentMediaItem else null
                    chargingIdleDiagnostics.record(
                        playbackActive = ::player.isInitialized && player.isPlaying,
                        mediaId = item?.mediaId,
                        title = item?.mediaMetadata?.title?.toString(),
                        positionMs = if (::player.isInitialized) player.currentPosition.coerceAtLeast(0L) else 0L,
                        durationMs = if (::player.isInitialized && player.duration > 0L) player.duration else 0L,
                        crossfadeActive = crossfadeInProgress,
                        radioInsertActive = item?.mediaId?.startsWith("radio:") == true
                    )
                }
                delay(60_000L)
            }
        }


        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                "bubatz_media_playback",
                "Bubatz FM Wiedergabe",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Laufende Medienwiedergabe"
                setSound(null, null)
                enableVibration(false)
                setShowBadge(false)
            }
            nm?.createNotificationChannel(channel)
        }

        // v0.82: Match the live Omnia MediaSession AudioAttributes exactly.
        // The comparison diagnosis reports Omnia as USAGE_MEDIA + CONTENT_TYPE_UNKNOWN (0).
        // Keep media usage, but remove Bubatz's explicit MUSIC classification for both
        // productive players so Samsung sees the same content type as Omnia.
        val omniaMatchedAudioAttributes = androidx.media3.common.AudioAttributes.Builder()
            .setUsage(androidx.media3.common.C.USAGE_MEDIA)
            .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_UNKNOWN)
            .build()

        // v0.57: One UI's compact live-media surface appears to use the actual
        // media-notification content title rather than MediaMetadata.displayTitle.
        // Supply "Titel – Interpret" directly through the Media3 provider.
        // v1.22 BOOMSTER diagnostic: both decks deliberately use the same audio-focus
        // policy. Previously the original primary deck requested/managed audio focus while
        // the standby deck did not. After a crossfade role swap this meant the audible
        // successor was the non-focus-owning ExoPlayer exactly when the old focus-owning
        // deck reached its boundary. Omnia uses one continuous player/focus owner. Remove
        // that asymmetry for this diagnostic before attempting a much more invasive custom
        // single-AudioTrack mixer. Phone-call handling remains Bubatz's explicit logic.
        // v1.47.3: ExternalStorageProvider can be restarted by Samsung's file browser
        // while enumerating the very large music folder. Route external-storage document
        // Uris through a detached-fd DataSource so active playback is not kept as a live
        // ContentProvider dependency (the crash signature was DEPENDENCY_DIED).
        val resilientDataSourceFactory = ResilientExternalStorageDataSourceFactory(this)
        val resilientMediaSourceFactory = DefaultMediaSourceFactory(resilientDataSourceFactory)

        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(resilientMediaSourceFactory)
            .build().apply {
            setAudioAttributes(omniaMatchedAudioAttributes, false)
        }
        standbyPlayer = ExoPlayer.Builder(this)
            .setMediaSourceFactory(resilientMediaSourceFactory)
            .build().apply {
            setAudioAttributes(omniaMatchedAudioAttributes, false)
            volume = 0f
            addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    diagnostics.save(
                        "v0.45: Standby STATE=$playbackState",
                        extra = "mediaId=${currentMediaItem?.mediaId}"
                    )
                }

                override fun onPlayerError(error: PlaybackException) {
                    diagnostics.save(
                        "v0.45 STANDBY EXOPLAYER ERROR",
                        error,
                        "mediaId=${currentMediaItem?.mediaId}\nuri=${currentMediaItem?.localConfiguration?.uri}"
                    )
                }
            })
        }

        activePlayerListener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                diagnostics.save(
                    "v0.45 EXOPLAYER ERROR",
                    error,
                    "mediaId=${player.currentMediaItem?.mediaId}\nuri=${player.currentMediaItem?.localConfiguration?.uri}"
                )
            }

            override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                diagnostics.save(
                    "v0.57: MediaSession-Metadaten",
                    extra = buildString {
                        append("mediaId=").append(player.currentMediaItem?.mediaId).append('\n')
                        append("title=").append(mediaMetadata.title).append('\n')
                        append("displayTitle=").append(mediaMetadata.displayTitle).append('\n')
                        append("artist=").append(mediaMetadata.artist).append('\n')
                        append("album=").append(mediaMetadata.albumTitle).append('\n')
                        append("artworkUri=").append(mediaMetadata.artworkUri)
                    }
                )
                updateOmniaSpeedProbe()
                if (::session.isInitialized && ::bubatzNotificationProvider.isInitialized) {
                    bubatzNotificationProvider.forceRefresh(session)
                }
                logSamsungLiveNotificationDiagnostics()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                updateOmniaSpeedProbe()
                if (isPlaying && phoneCallActive && !doNotDisturbCalls) {
                    // A controller tried to resume during a call. Keep the documented
                    // default behaviour: only the explicit "Bitte nicht stören!" switch
                    // may override an active phone call.
                    scope.launch { pauseForPhoneCall() }
                    return
                }
                scope.launch {
                    if (isPlaying) {
                        val mediaId = player.currentMediaItem?.mediaId.orEmpty()
                        if (mediaId.startsWith("track:") && !startedCurrentTrack) {
                            startedCurrentTrack = true
                            currentTrackId?.let { id ->
                                val item = player.currentMediaItem
                                withContext(Dispatchers.IO) {
                                    shuffle.markPlayed(id, System.currentTimeMillis())
                                    recordMusicHistory(id, item?.mediaMetadata?.title?.toString() ?: "Unbekannt")
                                }
                                startLastFmTracking(id)
                            }

                            // Never preload music→music when an insert is already due.
                            if (configuredCrossfadeMs > 0 && pendingCrossfadeTrack == null && !radioDue) {
                                prepareCrossfadeSuccessor()
                            }
                        } else if (mediaId.startsWith("radio:") && !startedCurrentRadio) {
                            startedCurrentRadio = true
                            currentRadioClipId?.let { id ->
                                val item = player.currentMediaItem
                                withContext(Dispatchers.IO) {
                                    db.clips().markPlayed(id, System.currentTimeMillis())
                                    radioShuffleBag.confirmPlayed(id)
                                    db.history().insert(
                                        PlayHistoryEntity(
                                            type = "RADIO",
                                            clipId = id,
                                            title = item?.mediaMetadata?.title?.toString() ?: "Bubatz FM Einspieler"
                                        )
                                    )
                                    db.history().trimTo(200)
                                }
                            }
                            // An insert consumes the pending radio slot.
                            resetRadioScheduleAfterInsert()
                            // v1.37: Pre-buffer the following music item in the active
                            // ExoPlayer playlist. This removes the prepare() pause after
                            // the insert while keeping the insert itself completely free
                            // of crossfade.
                            prepareRadioSuccessorGapless()
                        }
                    }
                    persistState()
                }
                lastScrobbleTickElapsed = android.os.SystemClock.elapsedRealtime()
                if (isPlaying) logSamsungLiveNotificationDiagnostics()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                updateOmniaSpeedProbe()
                scope.launch {
                    persistState()
                    if (playbackState == Player.STATE_ENDED && !crossfadeInProgress && radioHardcutJob?.isActive != true) {
                        val endedMediaId = player.currentMediaItem?.mediaId.orEmpty()
                        abortCrossfade()
                        when {
                            endedMediaId.startsWith("radio:") -> playNextInternal()
                            radioEnabled && radioDue -> playRadioInsert()
                            else -> playNextInternal()
                        }
                    }
                }
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                updateOmniaSpeedProbe()
            }

            override fun onIsLoadingChanged(isLoading: Boolean) {
                updateOmniaSpeedProbe()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                startedCurrentTrack = false
                lastFmTracker.reset()
                scrobbleListenedMs = 0L
                lastScrobbleTickElapsed = android.os.SystemClock.elapsedRealtime()
                lastNowPlayingMediaId = null
                val mediaId = mediaItem?.mediaId.orEmpty()
                startedCurrentRadio = false
                if (mediaId.startsWith("track:")) {
                    val transitionedTrackId = mediaId.removePrefix("track:").toLongOrNull()
                    val radioSuccessor = pendingRadioSuccessorTrack
                    var activatedGaplessRadioSuccessor = false
                    if (radioSuccessor != null && transitionedTrackId == radioSuccessor.id) {
                        val oldAnchor = currentTrackId
                        navigationHistory.ensureCurrent(oldAnchor)
                        val knownForwardId = navigationHistory.peekNext()
                        if (knownForwardId == radioSuccessor.id) {
                            navigationHistory.moveNext()
                        } else {
                            navigationHistory.appendNew(oldAnchor, radioSuccessor.id)
                        }
                        persistNavigationHistory()
                        pendingRadioSuccessorTrack = null
                        activatedGaplessRadioSuccessor = true
                        diagnostics.save(
                            "v1.37: Gapless Einspieler→Musik Übergang",
                            extra = "vonRadio=true\nzu=${radioSuccessor.title}"
                        )
                    }
                    currentTrackId = transitionedTrackId
                    currentRadioClipId = null
                    currentTrackId?.let { scheduleTailAnalysis(it) }

                    // v1.42: A seamless ExoPlayer playlist transition from a radio
                    // insert to its pre-buffered music successor does not toggle
                    // isPlaying. Therefore onIsPlayingChanged() never gets a chance to
                    // run the normal one-time music-start bookkeeping. Perform exactly
                    // that bookkeeping here, without touching the audio/gapless path.
                    if (activatedGaplessRadioSuccessor && transitionedTrackId != null) {
                        startedCurrentTrack = true
                        val activatedTrackId = transitionedTrackId
                        val activatedMediaId = mediaId
                        val activatedTitle = mediaItem?.mediaMetadata?.title?.toString()
                            ?: radioSuccessor?.title
                            ?: "Unbekannt"
                        scope.launch {
                            withContext(Dispatchers.IO) {
                                shuffle.markPlayed(activatedTrackId, System.currentTimeMillis())
                                recordMusicHistory(activatedTrackId, activatedTitle)
                            }

                            // Only start Last.fm / crossfade preparation if this track is
                            // still current. A very fast manual skip should not arm the
                            // tracker for an item that is already gone.
                            if (player.currentMediaItem?.mediaId == activatedMediaId) {
                                startLastFmTracking(activatedTrackId)
                                if (configuredCrossfadeMs > 0 && pendingCrossfadeTrack == null && !radioDue) {
                                    prepareCrossfadeSuccessor()
                                }
                            }
                            persistState()
                            diagnostics.save(
                                "v1.42: Einspieler→Musik Start registriert",
                                extra = "trackId=$activatedTrackId\ntitel=$activatedTitle\nhistory=true\nlastFm=${player.currentMediaItem?.mediaId == activatedMediaId}"
                            )
                        }
                    }
                } else if (mediaId.startsWith("radio:")) {
                    // Keep currentTrackId as the last music-history anchor while the
                    // insert is playing. The insert is not part of music navigation.
                    currentRadioClipId = mediaId.removePrefix("radio:").toLongOrNull()
                } else {
                    currentRadioClipId = null
                }
                updateOmniaSpeedProbe()
                if (::session.isInitialized && ::bubatzNotificationProvider.isInitialized) {
                    bubatzNotificationProvider.forceRefresh(session)
                }
                scope.launch { persistState() }
            }
        }
        player.addListener(activePlayerListener)


        // v0.92: the notification provider needs the classic platform token from
        // the start so Samsung sees the same MediaStyle→MediaSession relationship
        // that Omnia exposes.
        createOmniaSpeedProbe()

        bubatzNotificationProvider = BubatzMediaNotificationProvider(
            context = this,
            onMetadataSeen = { metadata ->
                diagnostics.save(
                    "v0.93: Native MediaStyle Notification / Plattform-Session",
                    extra = "title=${metadata.title}\nartist=${metadata.artist}\nalbum=${metadata.albumTitle}"
                )
            },
            platformSessionToken = { omniaSpeedProbeSession?.sessionToken }
        )
        setMediaNotificationProvider(bubatzNotificationProvider)
val sessionPlayer = BubatzSessionPlayer(
            player = player,
            onNext = { scope.launch { playNextInternal() } },
            onPrevious = { scope.launch { playPreviousInternal() } }
        )

        session = MediaSession.Builder(this, sessionPlayer)
            .setCallback(sessionCallback)
            .setMediaButtonPreferences(mediaButtonPreferences())
            .build()

        // Critical for MediaSessionService's own notification/foreground handling.
        // Our Activity drives playback via explicit service intents and therefore no
        // MediaController necessarily connects first. Register the session ourselves.
        addSession(session)
        updateOmniaSpeedProbe()
        logSamsungLiveNotificationDiagnostics()

        restoreJob = scope.launch {
            restorePersistedPlayback()
        }

        positionPersistJob = scope.launch {
            while (true) {
                delay(2_000L)
                if (player.currentMediaItem != null) {
                    persistState()
                    persistNavigationHistory()
                    updateOmniaSpeedProbe()
                }
            }
        }

        settingsJob = scope.launch {
            // v1.09: recover/mirror user settings before playback starts observing them.
            settings.ensureDurablePersistence()
            launch {
                settings.crossfadeMs.collectLatest { value ->
                    configuredCrossfadeMs = value.coerceIn(0, 15_000)
                }
            }
            launch {
                settings.radioEnabled.collectLatest { enabled ->
                    radioEnabled = enabled
                }
            }
            launch {
                settings.doNotDisturbCalls.collectLatest { enabled ->
                    val wasEnabled = doNotDisturbCalls
                    doNotDisturbCalls = enabled
                    if (phoneCallActive) {
                        if (enabled && pausedByPhoneCall) {
                            pausedByPhoneCall = false
                            player.play()
                        } else if (!enabled && wasEnabled && player.isPlaying) {
                            pauseForPhoneCall()
                        }
                    }
                }
            }
            launch {
                settings.lastFmEnabled.collectLatest { enabled ->
                    lastFmEnabled = enabled
                    if (!enabled) {
                        lastFmTracker.reset()
                        scrobbleListenedMs = 0L
                        lastNowPlayingMediaId = null
                    } else if (player.isPlaying && player.currentMediaItem?.mediaId?.startsWith("track:") == true) {
                        currentTrackId?.let { startLastFmTracking(it) }
                    }
                }
            }
        }

        scrobbleProgressJob = scope.launch {
            lastScrobbleTickElapsed = android.os.SystemClock.elapsedRealtime()
            while (true) {
                delay(1_000L)
                val now = android.os.SystemClock.elapsedRealtime()
                val delta = (now - lastScrobbleTickElapsed).coerceIn(0L, 2_500L)
                lastScrobbleTickElapsed = now

                val currentMediaId = player.currentMediaItem?.mediaId.orEmpty()
                if (radioEnabled && player.isPlaying && currentMediaId.startsWith("track:")) {
                    radioMusicListenedMs += delta
                    if (!radioDue && radioMusicListenedMs >= radioTargetMusicMs) {
                        radioDue = true
                        // A prepared music successor must not crossfade over the boundary
                        // where the insert belongs. Let the current song finish cleanly.
                        if (!crossfadeInProgress && pendingCrossfadeTrack != null) {
                            abortCrossfade()
                        }
                        diagnostics.save(
                            "v1.06: Radioeinspieler fällig",
                            extra = "musicMs=$radioMusicListenedMs\ntargetMs=$radioTargetMusicMs"
                        )
                    }
                    if ((radioMusicListenedMs / 1000L) % 5L == 0L) persistRadioSchedule()
                }

                if (lastFmEnabled && player.isPlaying && currentTrackId != null && currentMediaId.startsWith("track:")) {
                    scrobbleListenedMs += delta
                    val newlyQueued = runCatching {
                        lastFmTracker.onProgress(scrobbleListenedMs)
                    }.getOrDefault(false)
                    if (newlyQueued) flushLastFmPending()
                }

                if (lastFmEnabled && now - lastFmFlushElapsed >= 30_000L) {
                    lastFmFlushElapsed = now
                    flushLastFmPending()
                }
            }
        }

        // v1.02: Samsung can occasionally leave the compact media control in a
        // transient loading state even though ExoPlayer is already playing.  Keep the
        // classic platform MediaSession (the token used by our native MediaStyle
        // notification) explicitly synchronized.  We intentionally expose only
        // PLAYING/PAUSED here, matching the stable Omnia shape measured on-device.
        platformSessionSyncJob = scope.launch {
            while (true) {
                delay(500L)
                updateOmniaSpeedProbe()
            }
        }

        crossfadeMonitorJob = scope.launch {
            while (true) {
                delay(250L)
                monitorRadioHardcutBoundary()
                monitorAutomaticCrossfade()
            }
        }

        diagnostics.save("v1.10 Service erstellt – geglätteter Musik→Musik-Handoff + Radio-Hardcuts aktiv")
    }

    /**
     * v0.76 diagnostic-only MediaSession probe.
     *
     * Omnia exposes a platform MediaSession that reports STATE_PAUSED with speed=1.0.
     * Media3 reports speed=0.0 while paused. To test whether Samsung's compact media
     * surface keys off this unusual legacy shape, publish a SECOND platform session
     * with Bubatz metadata and the Omnia-like paused/speed combination. The real
     * Media3 session and ExoPlayer are not changed.
     */
    private fun createOmniaSpeedProbe() {
        if (omniaSpeedProbeSession != null) return
        omniaSpeedProbeSession = PlatformMediaSession(this, "BubatzOmniaSpeedProbe").apply {
            setFlags(
                PlatformMediaSession.FLAG_HANDLES_MEDIA_BUTTONS or
                    PlatformMediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS
            )
            setPlaybackToLocal(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_UNKNOWN)
                    .build()
            )
            setCallback(object : PlatformMediaSession.Callback() {
                override fun onPlay() { player.play() }
                override fun onPause() { player.pause() }
                override fun onSkipToNext() { scope.launch { playNextInternal() } }
                override fun onSkipToPrevious() { scope.launch { playPreviousInternal() } }
                override fun onSeekTo(pos: Long) { player.seekTo(pos.coerceAtLeast(0L)) }
            })
            isActive = true
        }
    }

    /**
     * v0.77 diagnostic-only audio activity probe.
     *
     * Samsung may rank compact media surfaces partly from real audio-pipeline activity
     * rather than only MediaSession/notification fields. This test starts a separate
     * local AudioTrack for about six seconds with media attributes and effectively
     * silent PCM. It does not request AudioFocus and does not touch the ExoPlayer,
     * crossfade, queue or productive Media3 session.
     */
    private fun startOmniaAudioActivityProbe() {
        if (omniaAudioProbeJob?.isActive == true) return

        omniaAudioProbeJob = scope.launch(Dispatchers.Default) {
            val sampleRate = 8_000
            val channelMask = AudioFormat.CHANNEL_OUT_MONO
            val encoding = AudioFormat.ENCODING_PCM_16BIT
            val minBuffer = AudioTrack.getMinBufferSize(sampleRate, channelMask, encoding)
                .coerceAtLeast(2_048)

            var track: AudioTrack? = null
            try {
                val createdTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(encoding)
                            .setSampleRate(sampleRate)
                            .setChannelMask(channelMask)
                            .build()
                    )
                    .setBufferSizeInBytes(minBuffer)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                track = createdTrack

                omniaAudioProbeTrack = createdTrack
                // Effectively inaudible, while still keeping a real media AudioTrack active.
                createdTrack.setVolume(0.0001f)
                createdTrack.play()

                val silence = ByteArray(minBuffer)
                val endAt = android.os.SystemClock.elapsedRealtime() + 6_000L
                while (android.os.SystemClock.elapsedRealtime() < endAt) {
                    val written = createdTrack.write(silence, 0, silence.size, AudioTrack.WRITE_BLOCKING)
                    if (written < 0) break
                }

                diagnostics.save(
                    "v0.77 Audio-Aktivitätsprobe beendet",
                    extra = "durationMs=6000\nusage=MEDIA\nfocusRequested=false"
                )
            } catch (t: Throwable) {
                diagnostics.save("v0.77 EXCEPTION Audio-Aktivitätsprobe", t)
            } finally {
                runCatching { track?.pause() }
                runCatching { track?.flush() }
                runCatching { track?.stop() }
                runCatching { track?.release() }
                if (omniaAudioProbeTrack === track) omniaAudioProbeTrack = null
            }
        }
    }


    /**
     * v0.80 compact diagnostic snapshot of Android's real audio pipeline.
     *
     * Public Android APIs do not expose the owning UID/PID/audio-session for
     * every AudioPlaybackConfiguration. For diagnosis only, we therefore pair
     * the public AudioAttributes with stable package UIDs and compare those
     * values against the framework configuration string. This never changes
     * playback or audio focus.
     */
    private fun saveAudioPipelineSnapshot() {
        val report = runCatching {
            val am = getSystemService(AudioManager::class.java)
            val configs = am?.activePlaybackConfigurations.orEmpty()
            val ownUid = applicationInfo.uid
            val omniaPackage = "com.rhmsoft.omnia"
            val omniaUid = runCatching {
                if (Build.VERSION.SDK_INT >= 33) {
                    packageManager.getApplicationInfo(
                        omniaPackage,
                        android.content.pm.PackageManager.ApplicationInfoFlags.of(0)
                    ).uid
                } else {
                    @Suppress("DEPRECATION")
                    packageManager.getApplicationInfo(omniaPackage, 0).uid
                }
            }.getOrNull()
            val mainSession = if (::player.isInitialized) player.audioSessionId else -1
            val standbySession = if (::standbyPlayer.isInitialized) standbyPlayer.audioSessionId else -1

            fun ownerHint(raw: String): String {
                val hints = mutableListOf<String>()
                if (raw.contains(ownUid.toString())) hints += "BUBATZ_UID"
                if (omniaUid != null && raw.contains(omniaUid.toString())) hints += "OMNIA_UID"
                if (mainSession > 0 && raw.contains(mainSession.toString())) hints += "BUBATZ_MAIN_SESSION"
                if (standbySession > 0 && raw.contains(standbySession.toString())) hints += "BUBATZ_STANDBY_SESSION"
                return hints.ifEmpty { listOf("nicht_eindeutig") }.joinToString(",")
            }

            buildString {
                append("v0.80: KOMPAKTER AUDIO-VERGLEICH\n")
                append("Bubatz uid=").append(ownUid)
                    .append(" mainSession=").append(mainSession)
                    .append(" standbySession=").append(standbySession).append('\n')
                append("Omnia package=").append(omniaPackage)
                    .append(" uid=").append(omniaUid ?: "nicht gefunden").append('\n')
                append("audioMode=").append(am?.mode)
                    .append(" musicActive=").append(am?.isMusicActive)
                    .append(" configs=").append(configs.size).append("\n\n")

                configs.forEachIndexed { index, cfg ->
                    val attrs = cfg.audioAttributes
                    val raw = cfg.toString().replace('\n', ' ')
                    append("AUDIO#").append(index + 1)
                        .append(" ownerHint=").append(ownerHint(raw)).append('\n')
                    append("  usage=").append(attrs.usage)
                        .append(" content=").append(attrs.contentType)
                        .append(" flags=0x").append(attrs.flags.toString(16))
                    if (Build.VERSION.SDK_INT >= 29) {
                        append(" capture=").append(attrs.allowedCapturePolicy)
                    }
                    append('\n')
                    append("  raw=").append(raw.take(420)).append('\n')
                }

                if (configs.isEmpty()) append("Keine aktive AudioPlaybackConfiguration sichtbar.\n")
                append("\nZIEL: Sind Omnia und Bubatz als getrennte reale Audio-Player sichtbar?\n")
                append("Hinweis: ownerHint nutzt nur Diagnose-Abgleich; keine Hidden-API wird aufgerufen.\n")
            }
        }.getOrElse {
            "v0.80 Audio-Pipeline-Diagnose fehlgeschlagen\n${it::class.java.simpleName}: ${it.message}"
        }
        diagnostics.saveLiveDiagnostic(report)
    }

    private fun updateOmniaSpeedProbe() {
        val probe = omniaSpeedProbeSession ?: return
        if (!::player.isInitialized) return
        val item = player.currentMediaItem ?: return
        // v1.33: Use the player's merged metadata, not only the metadata that was
        // attached to the MediaItem before playback. Media3 adds the embedded artwork
        // from the actual audio file to player.mediaMetadata after preparation.
        val md = player.mediaMetadata

        val plainTitle = md.title?.toString()?.trim().orEmpty().ifEmpty { "Bubatz FM" }
        val artistText = md.artist?.toString()?.trim().orEmpty()
        val platformMetadata = PlatformMediaMetadata.Builder()
            // Keep the large Samsung media card clean: TITLE stays just the song title.
            .putString(PlatformMediaMetadata.METADATA_KEY_TITLE, plainTitle)
            // v1.12: Omnia itself shows only the title in Samsung's compact chip.
            // Keep DISPLAY_TITLE title-only as well, otherwise Samsung can render
            // "Titel – Interpret" and then repeat the artist on the next line.
            .putString(PlatformMediaMetadata.METADATA_KEY_DISPLAY_TITLE, plainTitle)
            .putString(PlatformMediaMetadata.METADATA_KEY_ARTIST, artistText)
            .putString(PlatformMediaMetadata.METADATA_KEY_ALBUM, md.albumTitle?.toString() ?: "")
            .putLong(
                PlatformMediaMetadata.METADATA_KEY_DURATION,
                player.duration.takeIf { it > 0L } ?: 0L
            )

        // v1.33: Samsung's Live media card primarily takes its large background artwork
        // from the platform MediaSession. Until now this session never received artwork,
        // so Samsung could fall back to the notification's already-downscaled LargeIcon.
        // Publish the original embedded artwork here as well. Radio inserts deliberately
        // use the Bubatz artwork when their file contains no embedded picture.
        val platformArtwork = md.artworkData
            ?.takeIf { it.isNotEmpty() }
            ?.let { bytes -> runCatching { BitmapFactory.decodeByteArray(bytes, 0, bytes.size) }.getOrNull() }
            // v1.34: Match the app UI's fallback behavior for every item without
            // embedded artwork, not only radio inserts. This also covers ordinary
            // library tracks such as Julie London in the user's test case.
            ?: BitmapFactory.decodeResource(
                resources,
                fm.bubatz.player.R.drawable.bubatz_placeholder_cover
            )
        platformArtwork?.let {
            platformMetadata.putBitmap(PlatformMediaMetadata.METADATA_KEY_ALBUM_ART, it)
            platformMetadata.putBitmap(PlatformMediaMetadata.METADATA_KEY_ART, it)
        }

        probe.setMetadata(platformMetadata.build())

        probe.setPlaybackState(
            PlatformPlaybackState.Builder()
                // Exact action mask measured from Omnia on the target Samsung device.
                .setActions(0xF37L)
                .setState(
                    if (player.playWhenReady && player.currentMediaItem != null)
                        PlatformPlaybackState.STATE_PLAYING
                    else
                        PlatformPlaybackState.STATE_PAUSED,
                    player.currentPosition.coerceAtLeast(0L),
                    1.0f,
                    android.os.SystemClock.elapsedRealtime()
                )
                .build()
        )
        probe.isActive = true
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession = session

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // MediaSessionService marks this method @CallSuper. Calling it here allows
        // Media3 to process its own service/media-notification lifecycle correctly.
        super.onStartCommand(intent, flags, startId)

        when (intent?.action) {
            ACTION_AUTO_PLAY -> {
                scope.launch {
                    restoreJob?.join()
                    if (player.currentMediaItem == null) {
                        playNextInternal()
                    } else {
                        player.play()
                    }
                }
                return START_STICKY
            }

            ACTION_PLAY_PAUSE -> {
                scope.launch {
                    restoreJob?.join()
                    if (player.currentMediaItem == null) {
                        playNextInternal()
                    } else if (player.isPlaying) {
                        abortCrossfade()
                        player.pause()
                    } else {
                        player.play()
                    }
                }
                return START_STICKY
            }

            ACTION_NEXT -> {
                scope.launch {
                    restoreJob?.join()
                    playNextInternal()
                }
                return START_STICKY
            }

            ACTION_PREVIOUS -> {
                scope.launch {
                    restoreJob?.join()
                    playPreviousInternal()
                }
                return START_STICKY
            }

            ACTION_TEST_RADIO_INSERT -> {
                scope.launch {
                    restoreJob?.join()
                    playRadioInsert(force = true)
                }
                return START_STICKY
            }

            ACTION_REFRESH_PHONE_MONITOR -> {
                registerPhoneCallListenerIfPermitted()
                return START_STICKY
            }

            ACTION_PLAY_TRACK_ID -> {
                scope.launch {
                    restoreJob?.join()
                    val trackId = intent.getLongExtra(EXTRA_TRACK_ID, -1L)
                    if (trackId > 0L) playTrackByIdFromHistory(trackId)
                }
                return START_STICKY
            }

            ACTION_AUDIO_ACTIVITY_PROBE -> {
                updateOmniaSpeedProbe()
                startOmniaAudioActivityProbe()
                diagnostics.save(
                    "v0.77 Audio-Aktivitätsprobe gestartet",
                    extra = "durationMs=6000\nvolume=0.0001\nfocusRequested=false"
                )
                return START_STICKY
            }

            ACTION_AUDIO_PIPELINE_DIAGNOSTIC -> {
                saveAudioPipelineSnapshot()
                return START_STICKY
            }

            ACTION_SEEK -> {
                scope.launch {
                    restoreJob?.join()
                    val requested = intent.getLongExtra(EXTRA_SEEK_POSITION_MS, -1L)
                    if (requested >= 0L && player.currentMediaItem != null) {
                        abortCrossfade()
                        val duration = player.duration.takeIf { it > 0L }
                        val target = if (duration != null) {
                            requested.coerceIn(0L, duration)
                        } else {
                            requested.coerceAtLeast(0L)
                        }
                        player.seekTo(target)
                        persistState()
                        diagnostics.save(
                            "v0.45: Seek",
                            extra = "positionMs=$target"
                        )
                    }
                }
                return START_STICKY
            }
        }

        return START_STICKY
    }

    /**
     * v1.25: BOOMSTER-safe radio hard cuts.
     *
     * The Teufel BOOMSTER reacts to the outgoing ExoPlayer reaching STATE_ENDED
     * with a short transport interruption (and wakes its display). Music→music
     * was fixed in v1.24 by keeping the outgoing deck alive through the handoff.
     * Radio inserts intentionally do NOT crossfade, but they need the same
     * end-state protection. Shortly before the natural boundary we temporarily
     * repeat the outgoing item, then perform the normal hard transition at the
     * boundary. This preserves a true hard cut while preventing STATE_ENDED from
     * being published to the Bluetooth path.
     */
    private fun monitorRadioHardcutBoundary() {
        if (radioHardcutJob?.isActive == true) return
        if (crossfadeInProgress || !player.isPlaying) return
        val mediaId = player.currentMediaItem?.mediaId.orEmpty()
        val musicToRadio = mediaId.startsWith("track:") && radioEnabled && radioDue
        val radioToMusic = mediaId.startsWith("radio:")
        if (!musicToRadio && !radioToMusic) return

        // v1.32: Do not guess the end of a radio insert from currentPosition.
        // Radio -> music is now driven exclusively by ExoPlayer's real STATE_ENDED
        // callback in activePlayerListener. This removes the repeat/wrap loop that
        // caused the visible PLAY/PAUSE flutter and audible end stutter in v1.30/1.31.
        // The already stable music -> radio path deliberately keeps the v1.25
        // BOOMSTER protection unchanged.
        if (radioToMusic) return

        val duration = player.duration
        val position = player.currentPosition
        if (duration <= 0L || position < 0L) return

        // v1.35 Auto-Cue: when tail analysis found real trailing silence, switch
        // at the end of the last audible PCM instead of waiting through dead air.
        // We are still well before STATE_ENDED here, so no repeat guard is needed.
        val analysedCue = tailCueOutMs
            ?.takeIf { tailAnalysisTrackId == currentTrackId && it in 1 until duration }
        if (analysedCue != null) {
            val untilCue = analysedCue - position
            if (untilCue in -250L..750L) {
                radioHardcutJob = scope.launch {
                    try {
                        if (untilCue > 0L) delay(untilCue)
                        diagnostics.save(
                            "v1.35: Auto-Cue Musik→Einspieler",
                            extra = "cueOutMs=$analysedCue\ntrailingSilenceMs=$tailSilenceMs"
                        )
                        playRadioInsert()
                    } finally {
                        radioHardcutJob = null
                    }
                }
                return
            }
        }

        // No trustworthy cue point: keep the proven v1.32 END-safe path exactly.
        val remaining = duration - position
        if (remaining !in 1L..750L) return
        player.repeatMode = Player.REPEAT_MODE_ONE
        radioHardcutJob = scope.launch {
            try {
                delay(remaining.coerceAtLeast(1L))
                diagnostics.save(
                    "v1.35: Fallback Hardcut Musik→Einspieler",
                    extra = "remainingMs=$remaining"
                )
                playRadioInsert()
            } finally {
                player.repeatMode = Player.REPEAT_MODE_OFF
                radioHardcutJob = null
            }
        }
    }

    private suspend fun monitorAutomaticCrossfade() {
        if (configuredCrossfadeMs <= 0) return
        if (radioEnabled && radioDue) return
        if (player.currentMediaItem?.mediaId?.startsWith("radio:") == true) return
        if (crossfadeInProgress) return
        if (!player.isPlaying) return
        if (player.currentMediaItem == null) return

        val duration = player.duration
        val position = player.currentPosition
        if (duration <= 0L || position < 0L) return

        val remaining = duration - position
        val fadeMs = configuredCrossfadeMs.toLong()
        if (remaining <= 0L) return

        // Retry preparation if the early preload was not available yet.
        if (pendingCrossfadeTrack == null && remaining <= 30_000L) {
            prepareCrossfadeSuccessor()
        }

        // v1.08: A prepared standby deck may still be BUFFERING when the fade
        // window begins (especially with large libraries / slower SD cards).
        // Do not silently miss the whole transition. The monitor keeps the
        // successor prepared and starts the fade on the first READY tick while
        // there is still music left. Radio boundaries remain hard cuts.
        if (pendingCrossfadeItem != null &&
            remaining <= fadeMs &&
            standbyPlayer.playbackState == Player.STATE_BUFFERING
        ) {
            diagnostics.save(
                "v1.08: Crossfade wartet auf Standby",
                extra = "remainingMs=$remaining\nfadeMs=$fadeMs"
            )
        }

        val analysedCue = tailCueOutMs
            ?.takeIf { tailAnalysisTrackId == currentTrackId && it in 1 until duration }

        // v1.36: Auto-Cue may MOVE the configured crossfade window, but it must
        // never SHORTEN it. When a trustworthy trailing-silence cue is known,
        // the full configured fade ends at that cue point instead of at the
        // physical file end. This removes dead air while preserving the exact
        // crossfade duration selected by the user.
        val adaptiveStartMs = if (analysedCue != null) {
            (analysedCue - fadeMs).coerceAtLeast(0L)
        } else {
            duration - fadeMs
        }
        val effectiveFadeMs = fadeMs.coerceAtMost((duration - adaptiveStartMs).coerceAtLeast(1L))

        if (
            pendingCrossfadeItem != null &&
            position >= adaptiveStartMs &&
            remaining > 0L &&
            standbyPlayer.playbackState == Player.STATE_READY
        ) {
            diagnostics.save(
                if (analysedCue != null) "v1.36: Auto-Cue Crossfade volle Dauer" else "v1.36: Klassischer Crossfade-Fallback",
                extra = "remainingMs=$remaining\neffectiveFadeMs=$effectiveFadeMs\ncueOutMs=$analysedCue\ntrailingSilenceMs=$tailSilenceMs"
            )
            startAutomaticCrossfade(effectiveFadeMs)
        }
    }

    private fun scheduleTailAnalysis(trackId: Long) {
        if (tailAnalysisTrackId == trackId && (tailAnalysisJob?.isActive == true || tailCueOutMs != null)) return

        tailAnalysisJob?.cancel()
        tailAnalysisTrackId = trackId
        tailCueOutMs = null
        tailSilenceMs = 0L

        tailAnalysisJob = scope.launch {
            // Give productive playback time to settle first. The analyser decodes only
            // the final 12 seconds and runs off the main thread.
            delay(2_000L)
            val track = withContext(Dispatchers.IO) { db.tracks().byIdEnabled(trackId) } ?: return@launch
            val result = withContext(Dispatchers.IO) {
                tailSilenceAnalyzer.analyze(Uri.parse(track.uri), track.durationMs)
            }
            if (tailAnalysisTrackId != trackId) return@launch

            tailCueOutMs = result?.cueOutMs
            tailSilenceMs = result?.trailingSilenceMs ?: 0L
            diagnostics.save(
                if (result != null) "v1.35: Auto-Cue Tail erkannt" else "v1.35: Kein sicherer Auto-Cue Tail",
                extra = "trackId=$trackId\ncueOutMs=${result?.cueOutMs}\ntrailingSilenceMs=${result?.trailingSilenceMs}"
            )
        }
    }

    private suspend fun prepareCrossfadeSuccessor() {
        if (pendingCrossfadeTrack != null || crossfadeInProgress) return
        if (radioEnabled && radioDue) return
        if (player.currentMediaItem?.mediaId?.startsWith("radio:") == true) return

        try {
            navigationHistory.ensureCurrent(currentTrackId)
            var knownForwardId = navigationHistory.peekNext()
            var next: TrackEntity? = null
            while (knownForwardId != null && next == null) {
                next = withContext(Dispatchers.IO) { db.tracks().byIdEnabled(knownForwardId) }
                if (next == null) {
                    navigationHistory.discardNext()
                    persistNavigationHistory()
                    knownForwardId = navigationHistory.peekNext()
                }
            }
            if (next == null) {
                next = withContext(Dispatchers.IO) { shuffle.nextTrack(currentTrackId) }
            }
            val resolvedNext = next ?: return

            val item = mediaItemForTrack(resolvedNext)

            standbyPlayer.stop()
            standbyPlayer.clearMediaItems()
            standbyPlayer.volume = 0f
            standbyPlayer.setMediaItem(item)
            standbyPlayer.prepare()
            standbyPlayer.playWhenReady = false

            pendingCrossfadeTrack = resolvedNext
            pendingCrossfadeItem = item

            diagnostics.save(
                "v0.45: Crossfade-Nachfolger vorbereitet",
                extra = "id=${next.id}\ntitel=${next.title}"
            )
        } catch (t: Throwable) {
            diagnostics.save("v0.45 EXCEPTION beim Crossfade-Preload", t)
            abortCrossfade()
        }
    }

    private fun startAutomaticCrossfade(requestedFadeMs: Long? = null) {
        if (crossfadeInProgress) return

        val nextTrack = pendingCrossfadeTrack ?: return
        val nextItem = pendingCrossfadeItem ?: return
        val oldTrackId = currentTrackId
        val fadeMs = (requestedFadeMs ?: configuredCrossfadeMs.toLong()).coerceAtLeast(1L)

        crossfadeInProgress = true
        crossfadeJob?.cancel()
        val generation = ++crossfadeGeneration
        crossfadeJob = scope.launch {
            try {
                standbyPlayer.volume = 0f
                standbyPlayer.play()

                // v1.24 production fix: during a normal music→music crossfade the outgoing
                // deck must not publish its natural STATE_ENDED boundary. Some Bluetooth
                // receivers (confirmed with the Teufel BOOMSTER) react to that boundary
                // with a brief transport interruption. Keep the outgoing deck alive by
                // repeating it only for the remainder of the fade. Its gain reaches zero
                // before the role swap, then the old deck is reset normally below. This
                // preserves one-shot semantics for the new active track and for all
                // non-crossfade paths (radio inserts, manual skips, etc.).
                player.repeatMode = Player.REPEAT_MODE_ONE

                diagnostics.save(
                    "v1.24: Crossfade gestartet (END-sicherer Handoff)",
                    extra = "dauerMs=$fadeMs\nvon=$oldTrackId\nzu=${nextTrack.id}"
                )

                val startedAt = android.os.SystemClock.elapsedRealtime()

                while (true) {
                    val elapsed =
                        android.os.SystemClock.elapsedRealtime() - startedAt
                    val progress =
                        (elapsed.toFloat() / fadeMs.toFloat()).coerceIn(0f, 1f)
                    val gains = FadeEnvelope.gains(progress)

                    player.volume = gains.outgoing
                    standbyPlayer.volume = gains.incoming

                    if (progress >= 1f) break
                    delay(50L)
                }

                // v1.11: Do not decode the successor a second time just to hand it
                // back to the old session-bound deck. That duplicate-decoder handoff was
                // the remaining source of sporadic audible micro-stutters. The deck that
                // is already playing the successor simply becomes the new primary deck.
                // Media3 explicitly supports changing a MediaSession's underlying Player
                // as long as both players use the same application looper (our two
                // ExoPlayers do). No seek, prepare or duplicate AudioTrack overlap occurs.
                navigationHistory.acceptSuccessor(oldTrackId, nextTrack.id)
                persistNavigationHistory()

                // Invalidate any stale bookkeeping before the role swap. The successor
                // has already been audible during the fade, so establish its tracking
                // state directly rather than waiting for an event that already happened.
                lastFmTracker.reset()
                scrobbleListenedMs = 0L
                lastScrobbleTickElapsed = android.os.SystemClock.elapsedRealtime()
                lastNowPlayingMediaId = null
                currentTrackId = nextTrack.id
                currentRadioClipId = null
                startedCurrentRadio = false
                scheduleTailAnalysis(nextTrack.id)

                val oldPrimary = player
                val newPrimary = standbyPlayer

                // Only the active deck owns the productive listener. Move it before
                // publishing the new player variable so subsequent callbacks refer to
                // the correct source.
                oldPrimary.removeListener(activePlayerListener)
                player = newPrimary
                standbyPlayer = oldPrimary
                player.addListener(activePlayerListener)

                // The successor must retain normal one-shot playback semantics.
                player.repeatMode = Player.REPEAT_MODE_OFF
                player.volume = 1f

                val swappedSessionPlayer = BubatzSessionPlayer(
                    player = player,
                    onNext = { scope.launch { playNextInternal() } },
                    onPrevious = { scope.launch { playPreviousInternal() } }
                )
                session.setPlayer(swappedSessionPlayer)

                // The old deck is now only the empty standby deck for the next fade.
                standbyPlayer.volume = 0f
                standbyPlayer.pause()
                standbyPlayer.repeatMode = Player.REPEAT_MODE_OFF
                standbyPlayer.stop()
                standbyPlayer.clearMediaItems()

                // The successor was already playing before the role swap, so manually
                // perform the one-time "track became active" bookkeeping that would
                // normally be triggered by onIsPlayingChanged/onMediaItemTransition.
                startedCurrentTrack = true
                withContext(Dispatchers.IO) {
                    shuffle.markPlayed(nextTrack.id, System.currentTimeMillis())
                    recordMusicHistory(nextTrack.id, nextItem.mediaMetadata.title?.toString() ?: nextTrack.title)
                }
                startLastFmTracking(nextTrack.id)
                persistState()
                updateOmniaSpeedProbe()
                if (::bubatzNotificationProvider.isInitialized) {
                    bubatzNotificationProvider.forceRefresh(session)
                }

                diagnostics.save(
                    "v1.11: Crossfade per Deck-Rollentausch abgeschlossen",
                    extra = "titel=${nextTrack.title}\npositionMs=${player.currentPosition}"
                )

                // Only the still-current fade generation may publish completion.
                // A manual skip/pause/seek can invalidate this coroutine while it is
                // suspended in prepare()/handoff delays.
                if (generation != crossfadeGeneration) return@launch

                pendingCrossfadeTrack = null
                pendingCrossfadeItem = null
                crossfadeInProgress = false
                crossfadeJob = null

                delay(500L)
                if (generation == crossfadeGeneration && configuredCrossfadeMs > 0 && !radioDue) {
                    prepareCrossfadeSuccessor()
                }
            } catch (cancelled: CancellationException) {
                // Expected for manual next/previous/pause/seek and Bluetooth/service stop.
                // Do not run the generic cleanup here: abortCrossfade() already owns the
                // new state and an old cancelled coroutine must not clear it again.
                throw cancelled
            } catch (t: Throwable) {
                diagnostics.save("v1.00 EXCEPTION im Crossfade", t)
                if (generation == crossfadeGeneration) {
                    abortCrossfade()
                }
            }
        }
    }

    private fun abortCrossfade() {
        // Invalidate first, before cancelling. This prevents the cancelled coroutine
        // from publishing stale handoff/cleanup state after a new title has started.
        crossfadeGeneration += 1L
        crossfadeJob?.cancel()
        crossfadeJob = null
        crossfadeInProgress = false
        pendingCrossfadeTrack = null
        pendingCrossfadeItem = null

        if (::player.isInitialized) {
            player.volume = 1f
        }
        if (::player.isInitialized) {
            runCatching { player.repeatMode = Player.REPEAT_MODE_OFF }
        }
        if (::standbyPlayer.isInitialized) {
            runCatching { standbyPlayer.repeatMode = Player.REPEAT_MODE_OFF }
            runCatching { standbyPlayer.pause() }
            runCatching { standbyPlayer.stop() }
            runCatching { standbyPlayer.clearMediaItems() }
            standbyPlayer.volume = 0f
        }
    }

    private fun logSamsungLiveNotificationDiagnostics() {
        runCatching {
            val nm = getSystemService(NotificationManager::class.java)

            val canPostPromoted = runCatching {
                val method = NotificationManager::class.java
                    .getMethod("canPostPromotedNotifications")
                method.invoke(nm) as? Boolean
            }.getOrNull()

            val notificationClass = android.app.Notification::class.java
            val builderClass = android.app.Notification.Builder::class.java

            val hasPromotableMethodPresent = notificationClass.methods.any {
                it.name == "hasPromotableCharacteristics" && it.parameterCount == 0
            }

            val requestPromotedMethodPresent = builderClass.methods.any {
                it.name == "setRequestPromotedOngoing" && it.parameterTypes.size == 1
            }

            val promotedFlagValue = runCatching {
                notificationClass.getField("FLAG_PROMOTED_ONGOING").getInt(null)
            }.getOrNull()

            val active = if (Build.VERSION.SDK_INT >= 23) {
                nm?.activeNotifications?.joinToString(separator = "\n") { sbn ->
                    val n = sbn.notification

                    val promotedFlagSet = promotedFlagValue?.let { flag ->
                        (n.flags and flag) != 0
                    }

                    val promotable = runCatching {
                        val method = notificationClass
                            .getMethod("hasPromotableCharacteristics")
                        method.invoke(n) as? Boolean
                    }.getOrNull()

                    buildString {
                        append("id=").append(sbn.id)
                        append(",ongoing=").append(
                            (n.flags and android.app.Notification.FLAG_ONGOING_EVENT) != 0
                        )
                        append(",flags=0x").append(n.flags.toString(16))
                        append(",noClear=").append(
                            (n.flags and android.app.Notification.FLAG_NO_CLEAR) != 0
                        )
                        append(",onlyAlertOnce=").append(
                            (n.flags and android.app.Notification.FLAG_ONLY_ALERT_ONCE) != 0
                        )
                        append(",foregroundService=").append(
                            (n.flags and android.app.Notification.FLAG_FOREGROUND_SERVICE) != 0
                        )
                        append(",promotedFlag=").append(promotedFlagSet)
                        append(",promotable=").append(promotable)
                        append(",category=").append(n.category)
                        append(",group=").append(n.group)
                        append(",channel=").append(
                            if (Build.VERSION.SDK_INT >= 26) n.channelId else "n/a"
                        )
                        append(",style=").append(n.extras?.getString("android.template"))
                        append(",title=").append(n.extras?.getCharSequence("android.title"))
                        append(",text=").append(n.extras?.getCharSequence("android.text"))
                        append(",mediaSession=").append(
                            n.extras?.containsKey("android.mediaSession")
                        )
                    }
                }
            } else {
                "activeNotifications unsupported"
            }

            val channelInfo = if (Build.VERSION.SDK_INT >= 26) {
                nm?.notificationChannels?.joinToString(separator = "\n") { ch ->
                    "channel=${ch.id},name=${ch.name},importance=${ch.importance},badge=${ch.canShowBadge()},sound=${ch.sound}"
                }
            } else {
                "channels unsupported"
            }

            val liveReport = buildString {
                    append("v0.77: Samsung-/Android-16-Live-Diagnose").append('\n')
                    append("sdk=").append(Build.VERSION.SDK_INT).append('\n')
                    append("manufacturer=").append(Build.MANUFACTURER).append('\n')
                    append("model=").append(Build.MODEL).append('\n')
                    append("notificationsEnabled=").append(nm?.areNotificationsEnabled()).append('\n')
                    append("sessionActive=").append(::session.isInitialized && session.player.currentMediaItem != null).append('\n')
                    append("playerIsPlaying=").append(::player.isInitialized && player.isPlaying).append('\n')
                    append("playerState=").append(if (::player.isInitialized) player.playbackState else -1).append('\n')
                    append("mediaId=").append(if (::player.isInitialized) player.currentMediaItem?.mediaId else null).append('\n')

                    val sessionTokenText = runCatching {
                        if (::session.isInitialized) {
                            val token = session.token
                            "package=${token.packageName},uid=${token.uid},type=${token.type},serviceName=${token.serviceName}"
                        } else {
                            "session-not-initialized"
                        }
                    }.getOrElse { "error:${it::class.java.simpleName}:${it.message}" }

                    val availableCommandsText = runCatching {
                        if (::session.isInitialized) {
                            session.player.availableCommands.toString()
                        } else "session-not-initialized"
                    }.getOrElse { "error:${it::class.java.simpleName}:${it.message}" }

                    val serviceInfoText = runCatching {
                        val component = android.content.ComponentName(this@PlaybackService, PlaybackService::class.java)
                        val info = if (Build.VERSION.SDK_INT >= 33) {
                            packageManager.getServiceInfo(
                                component,
                                android.content.pm.PackageManager.ComponentInfoFlags.of(
                                    android.content.pm.PackageManager.GET_META_DATA.toLong()
                                )
                            )
                        } else {
                            @Suppress("DEPRECATION")
                            packageManager.getServiceInfo(component, android.content.pm.PackageManager.GET_META_DATA)
                        }
                        buildString {
                            append("name=").append(info.name)
                            append(",permission=").append(info.permission)
                            if (Build.VERSION.SDK_INT >= 29) {
                                append(",foregroundServiceType=").append(info.foregroundServiceType)
                            }
                            append(",exported=").append(info.exported)
                            append(",enabled=").append(info.enabled)
                        }
                    }.getOrElse { "error:${it::class.java.simpleName}:${it.message}" }

                    append("sessionToken=").append(sessionTokenText).append('\n')
                    append("availableCommands=").append(availableCommandsText).append('\n')
                    append("playbackSuppressionReason=").append(
                        if (::player.isInitialized) player.playbackSuppressionReason else -1
                    ).append('\n')
                    append("repeatMode=").append(if (::player.isInitialized) player.repeatMode else -1).append('\n')
                    append("shuffleModeEnabled=").append(
                        if (::player.isInitialized) player.shuffleModeEnabled else false
                    ).append('\n')
                    append("serviceInfo=").append(serviceInfoText).append('\n')
                    append("canPostPromotedNotifications=").append(canPostPromoted).append('\n')
                    append("hasPromotableCharacteristicsApi=").append(hasPromotableMethodPresent).append('\n')
                    append("setRequestPromotedOngoingApi=").append(requestPromotedMethodPresent).append('\n')
                    append("FLAG_PROMOTED_ONGOING=").append(promotedFlagValue).append('\n')
                    append("activeNotifications:\n").append(active).append('\n')
                    append("channels:\n").append(channelInfo)
                }
            diagnostics.saveLiveDiagnostic(liveReport)
        }.onFailure {
            diagnostics.saveLiveDiagnostic(
                "v0.72 LIVE-DIAGNOSE-FEHLER\n${it::class.java.simpleName}: ${it.message}"
            )
        }
    }

    private suspend fun restorePersistedPlayback() {
        try {
            val state = withContext(Dispatchers.IO) { db.state().get() }
            val trackId = state?.currentTrackId ?: return
            val track = withContext(Dispatchers.IO) { db.tracks().byIdEnabled(trackId) }

            if (track == null) {
                diagnostics.save(
                    "v0.45: gespeicherter Titel nicht mehr vorhanden",
                    extra = "trackId=$trackId"
                )
                return
            }

            val item = mediaItemForTrack(track)
            val savedPosition = state.currentPositionMs
                .coerceAtLeast(0L)
                .let { pos ->
                    val knownDuration = track.durationMs.takeIf { it > 0L }
                        ?: state.currentDurationMs.takeIf { it > 0L }
                    if (knownDuration != null && pos >= knownDuration) 0L else pos
                }

            currentTrackId = track.id
            startedCurrentTrack = false
            if (!restoreNavigationHistory(track.id)) {
                navigationHistory.reset(track.id)
                persistNavigationHistory()
            }

            player.setMediaItem(item, savedPosition)
            player.prepare()
            // Deliberately do not autoplay on ordinary app/service startup.
            player.playWhenReady = false

            diagnostics.save(
                "v0.45: letzter Titel wiederhergestellt",
                extra = "id=${track.id}\ntitel=${item.mediaMetadata.title}\npositionMs=$savedPosition"
            )
        } catch (t: Throwable) {
            diagnostics.save("v0.45 EXCEPTION bei Wiederherstellung", t)
        }
    }

    private suspend fun playNextInternal() {
        try {
            abortCrossfade()
            val oldCurrent = currentTrackId
            navigationHistory.ensureCurrent(oldCurrent)

            var knownForwardId = navigationHistory.peekNext()
            var next: TrackEntity? = null
            while (knownForwardId != null && next == null) {
                next = withContext(Dispatchers.IO) { db.tracks().byIdEnabled(knownForwardId) }
                if (next == null) {
                    navigationHistory.discardNext()
                    persistNavigationHistory()
                    knownForwardId = navigationHistory.peekNext()
                }
            }
            if (next == null) {
                next = withContext(Dispatchers.IO) { shuffle.nextTrack(currentTrackId) }
            }

            if (next == null) {
                diagnostics.save("v0.94 FEHLER: kein nächster Titel gefunden")
                return
            }

            val usingForwardHistory = knownForwardId != null && next.id == knownForwardId
            if (usingForwardHistory) {
                navigationHistory.moveNext()
            } else {
                navigationHistory.appendNew(oldCurrent, next.id)
            }
            persistNavigationHistory()

            val item = mediaItemForTrack(next)
            currentTrackId = next.id
            startedCurrentTrack = false

            diagnostics.save(
                "v0.94: nächster Titel gestartet",
                extra = "id=${next.id}\ntitel=${next.title}\nforwardHistory=$usingForwardHistory\nhistoryPos=${navigationHistory.position()}\nhistorySize=${navigationHistory.size()}"
            )

            player.setMediaItem(item)
            player.prepare()
            player.play()

            scope.launch {
                delay(500L)
                if (configuredCrossfadeMs > 0 && pendingCrossfadeTrack == null) {
                    prepareCrossfadeSuccessor()
                }
            }

        } catch (t: Throwable) {
            diagnostics.save("v0.94 EXCEPTION bei Next", t)
        }
    }

    private suspend fun playPreviousInternal() {
        try {
            abortCrossfade()
            val currentId = currentTrackId
            navigationHistory.ensureCurrent(currentId)

            var previousId = navigationHistory.movePrevious()
            var previous: TrackEntity? = null
            while (previousId != null && previous == null) {
                persistNavigationHistory()
                previous = withContext(Dispatchers.IO) {
                    db.tracks().byIdEnabled(previousId)
                }
                if (previous == null) {
                    diagnostics.save("v1.07: Previous überspringt entfernten History-Titel", extra = "trackId=$previousId")
                    previousId = navigationHistory.movePrevious()
                }
            }
            if (previous == null) {
                if (player.currentMediaItem != null) {
                    player.seekTo(0L)
                    if (!player.isPlaying) player.play()
                }
                diagnostics.save("v1.07: Previous → kein vorhandener älterer History-Titel")
                return
            }

            val item = mediaItemForTrack(previous)
            currentTrackId = previous.id
            startedCurrentTrack = false

            player.setMediaItem(item)
            player.prepare()
            player.play()

            scope.launch {
                delay(500L)
                if (configuredCrossfadeMs > 0 && pendingCrossfadeTrack == null) {
                    prepareCrossfadeSuccessor()
                }
            }

            diagnostics.save(
                "v0.94: vorheriger Titel gestartet",
                extra = "id=${previous.id}\ntitel=${previous.title}\nhistoryPos=${navigationHistory.position()}\nhistorySize=${navigationHistory.size()}"
            )
        } catch (t: Throwable) {
            diagnostics.save("v0.94 EXCEPTION bei Previous", t)
        }
    }

    /**
     * v1.45: A pause/resume must not create another "Zuletzt gehört" row for
     * the same music selection. Radio inserts do not break this comparison. A
     * track may appear again normally after another music track was selected.
     */
    private suspend fun recordMusicHistory(trackId: Long, title: String) {
        val history = db.history()
        if (history.latestMusicTrackId() == trackId) return
        history.insert(
            PlayHistoryEntity(
                type = "MUSIC",
                trackId = trackId,
                title = title
            )
        )
        history.trimTo(200)
    }

    private suspend fun playTrackByIdFromHistory(trackId: Long) {
        try {
            abortCrossfade()
            val track = withContext(Dispatchers.IO) { db.tracks().byIdEnabled(trackId) } ?: return
            val oldCurrent = currentTrackId
            navigationHistory.ensureCurrent(oldCurrent)
            if (oldCurrent != track.id) {
                navigationHistory.appendNew(oldCurrent, track.id)
                persistNavigationHistory()
            }
            currentTrackId = track.id
            startedCurrentTrack = false
            currentRadioClipId = null
            startedCurrentRadio = false
            player.setMediaItem(mediaItemForTrack(track))
            player.prepare()
            player.play()
            diagnostics.save("v1.16: Titel aus Zuletzt-gehört gestartet", extra = "trackId=${track.id}\ntitel=${track.title}")
        } catch (t: Throwable) {
            diagnostics.save("v1.16 EXCEPTION beim Start aus Zuletzt-gehört", t)
        }
    }

    private suspend fun prepareRadioSuccessorGapless() {
        if (!player.currentMediaItem?.mediaId.orEmpty().startsWith("radio:")) return
        if (pendingRadioSuccessorTrack != null || player.mediaItemCount > 1) return

        try {
            navigationHistory.ensureCurrent(currentTrackId)
            var knownForwardId = navigationHistory.peekNext()
            var next: TrackEntity? = null
            while (knownForwardId != null && next == null) {
                next = withContext(Dispatchers.IO) { db.tracks().byIdEnabled(knownForwardId) }
                if (next == null) {
                    navigationHistory.discardNext()
                    persistNavigationHistory()
                    knownForwardId = navigationHistory.peekNext()
                }
            }
            if (next == null) {
                next = withContext(Dispatchers.IO) { shuffle.nextTrack(currentTrackId) }
            }
            val resolvedNext = next ?: return

            // Do not call prepare()/play() again. Adding the already-known successor to
            // the active playlist lets ExoPlayer buffer it and perform its native
            // seamless media-item transition when the radio clip reaches its real end.
            player.addMediaItem(mediaItemForTrack(resolvedNext))
            pendingRadioSuccessorTrack = resolvedNext
            diagnostics.save(
                "v1.37: Musik nach Einspieler gapless vorgepuffert",
                extra = "id=${resolvedNext.id}\ntitel=${resolvedNext.title}"
            )
        } catch (t: Throwable) {
            pendingRadioSuccessorTrack = null
            diagnostics.save("v1.37 EXCEPTION beim Gapless-Preload nach Einspieler", t)
        }
    }

    private suspend fun playRadioInsert(force: Boolean = false) {
        if (!force && (!radioEnabled || !radioDue)) return
        val clip = withContext(Dispatchers.IO) { radioShuffleBag.nextClip() }
        if (clip == null) {
            diagnostics.save("v1.06: Kein Radioeinspieler importiert")
            // Avoid retrying at every song boundary when the clip library is empty.
            resetRadioScheduleAfterInsert()
            return
        }

        abortCrossfade()
        val item = mediaItemForRadioClip(clip)
        currentRadioClipId = clip.id
        pendingRadioSuccessorTrack = null
        startedCurrentRadio = false
        startedCurrentTrack = false
        lastFmTracker.reset()
        scrobbleListenedMs = 0L
        lastNowPlayingMediaId = null

        diagnostics.save(
            "v1.06: Radioeinspieler gestartet",
            extra = "id=${clip.id}\nname=${clip.name}\nforce=$force"
        )

        player.setMediaItem(item)
        player.prepare()
        player.play()
    }

    private fun mediaItemForRadioClip(clip: RadioClipEntity): MediaItem =
        MediaItem.Builder()
            .setUri(Uri.parse(clip.uri))
            .setMediaId("radio:${clip.id}")
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(clip.name)
                    .setDisplayTitle(clip.name)
                    .setArtist("Bubatz FM")
                    .setAlbumTitle("RADIOEINSPIELER")
                    .setArtworkData(
                        resources.openRawResource(fm.bubatz.player.R.drawable.bubatz_placeholder_cover).use { it.readBytes() },
                        MediaMetadata.PICTURE_TYPE_FRONT_COVER
                    )
                    .build()
            )
            .build()

    private data class ResolvedTrack(
        val title: String,
        val artist: String?,
        val album: String?,
        val albumArtist: String?,
        val isCompilation: Boolean,
        val durationMs: Long
    )

    private suspend fun mediaItemForTrack(track: fm.bubatz.player.data.TrackEntity): MediaItem {
        val resolved = if (
            !track.artist.isNullOrBlank() &&
            !track.album.isNullOrBlank() &&
            track.durationMs > 0L &&
            track.isCompilation != null
        ) {
            ResolvedTrack(track.title, track.artist, track.album, track.albumArtist, track.isCompilation == true, track.durationMs)
        } else {
            resolveTrackMetadata(track)
        }

        return MediaItem.Builder()
            .setUri(Uri.parse(track.uri))
            .setMediaId("track:${track.id}")
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(resolved.title)
                    .setDisplayTitle(resolved.title)
                    .setArtist(resolved.artist)
                    .setAlbumTitle(resolved.album)
                    .build()
            )
            .build()
    }

    private suspend fun resolveTrackMetadata(
        track: fm.bubatz.player.data.TrackEntity
    ): ResolvedTrack = withContext(Dispatchers.IO) {
        val fallback = ResolvedTrack(
            title = track.title,
            artist = track.artist,
            album = track.album,
            albumArtist = track.albumArtist,
            isCompilation = track.isCompilation == true,
            durationMs = track.durationMs
        )

        val resolved = runCatching {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(this@PlaybackService, Uri.parse(track.uri))

                val title = retriever
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                    ?.takeIf { it.isNotBlank() }
                    ?: track.title

                val artist = retriever
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                    ?.takeIf { it.isNotBlank() }
                    ?: track.artist

                val album = retriever
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
                    ?.takeIf { it.isNotBlank() }
                    ?: track.album

                val albumArtist = retriever
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST)
                    ?.takeIf { it.isNotBlank() }
                    ?: track.albumArtist

                val compilationTag = retriever
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_COMPILATION)
                    ?.trim()
                    ?.lowercase()
                val compilationFlag = compilationTag == "1" || compilationTag == "true" ||
                    compilationTag == "yes" || compilationTag == "y"
                val normalizedAlbumArtist = albumArtist?.trim()?.lowercase().orEmpty()
                val variousArtists = normalizedAlbumArtist == "various artists" ||
                    normalizedAlbumArtist == "various" || normalizedAlbumArtist == "va" ||
                    normalizedAlbumArtist == "v.a."

                val duration = retriever
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull()
                    ?.takeIf { it > 0L }
                    ?: track.durationMs

                ResolvedTrack(title, artist, album, albumArtist, compilationFlag || variousArtists, duration)
            } finally {
                retriever.release()
            }
        }.getOrElse {
            diagnostics.save(
                "v0.45: Metadaten-Fallback",
                throwable = it,
                extra = "trackId=${track.id}\nuri=${track.uri}"
            )
            fallback
        }

        if (
            resolved.title != track.title ||
            resolved.artist != track.artist ||
            resolved.album != track.album ||
            resolved.albumArtist != track.albumArtist ||
            resolved.isCompilation != track.isCompilation ||
            resolved.durationMs != track.durationMs
        ) {
            runCatching {
                db.tracks().updateMetadata(
                    id = track.id,
                    title = resolved.title,
                    artist = resolved.artist,
                    album = resolved.album,
                    albumArtist = resolved.albumArtist,
                    isCompilation = resolved.isCompilation,
                    durationMs = resolved.durationMs
                )
            }
        }

        resolved
    }

    /** v1.01: Last.fm is fully optional and tied to the currently authorized account. */
    private suspend fun startLastFmTracking(trackId: Long) {
        if (!lastFmEnabled) return
        val sessionKey = lastFmStore.sessionKey ?: return
        val apiKey = lastFmStore.apiKey ?: return
        val sharedSecret = lastFmStore.sharedSecret ?: return
        val track = withContext(Dispatchers.IO) { db.tracks().byIdEnabled(trackId) } ?: return
        if (track.artist.isNullOrBlank() || track.title.isBlank()) return

        val mediaId = "track:${track.id}"
        if (lastNowPlayingMediaId == mediaId) return

        scrobbleListenedMs = 0L
        lastScrobbleTickElapsed = android.os.SystemClock.elapsedRealtime()
        lastFmTracker.onItemStarted(
            mediaId = mediaId,
            durationMs = track.durationMs,
            nowSeconds = System.currentTimeMillis() / 1000L
        )
        lastNowPlayingMediaId = mediaId

        withContext(Dispatchers.IO) {
            val result = runCatching {
                LastFmApi(apiKey, sharedSecret).updateNowPlaying(
                    sessionKey = sessionKey,
                    artist = track.artist.orEmpty(),
                    track = track.title,
                    album = track.album,
                    durationSeconds = track.durationMs.takeIf { it > 0L }?.div(1000L)
                )
            }.getOrNull()

            if (result?.errorCode == 9) {
                lastFmStore.clearSession()
            }
        }
    }

    private suspend fun flushLastFmPending() {
        if (!lastFmEnabled || lastFmStore.sessionKey.isNullOrBlank()) return
        when (val result = runCatching { lastFmSender.flush() }.getOrNull()) {
            is FlushResult.ReauthenticationRequired -> {
                diagnostics.save("v1.01 Last.fm: erneute Anmeldung erforderlich")
            }
            is FlushResult.RetryLater -> {
                diagnostics.save("v1.01 Last.fm: später erneut senden", extra = result.message.orEmpty())
            }
            else -> Unit
        }
    }

    private fun registerPhoneCallListenerIfPermitted() {
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            diagnostics.save("v1.13 Telefon: READ_PHONE_STATE fehlt")
            return
        }
        val tm = getSystemService(TelephonyManager::class.java) ?: return

        if (Build.VERSION.SDK_INT >= 31) {
            if (telephonyCallback != null) return
            val callback = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                override fun onCallStateChanged(state: Int) {
                    handlePhoneCallState(state)
                }
            }
            telephonyCallback = callback
            tm.registerTelephonyCallback(mainExecutor, callback)
        } else {
            @Suppress("DEPRECATION")
            if (legacyPhoneStateListener == null) {
                @Suppress("DEPRECATION")
                val listener = object : PhoneStateListener() {
                    @Deprecated("Deprecated in Android 12; used only on API 28-30")
                    override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                        handlePhoneCallState(state)
                    }
                }
                legacyPhoneStateListener = listener
                @Suppress("DEPRECATION")
                tm.listen(listener, PhoneStateListener.LISTEN_CALL_STATE)
            }
        }
    }

    private fun handlePhoneCallState(state: Int) {
        when (state) {
            TelephonyManager.CALL_STATE_RINGING,
            TelephonyManager.CALL_STATE_OFFHOOK -> {
                phoneCallActive = true
                if (!doNotDisturbCalls) {
                    scope.launch { pauseForPhoneCall() }
                }
            }
            TelephonyManager.CALL_STATE_IDLE -> {
                val shouldResume = pausedByPhoneCall && !doNotDisturbCalls
                phoneCallActive = false
                pausedByPhoneCall = false
                if (shouldResume && player.currentMediaItem != null) {
                    player.play()
                }
            }
        }
    }

    private suspend fun pauseForPhoneCall() {
        if (doNotDisturbCalls || !phoneCallActive) return
        val wasActuallyPlaying = player.isPlaying || standbyPlayer.isPlaying || crossfadeInProgress
        if (wasActuallyPlaying) {
            // Cancel/flatten an in-flight fade before pausing both decks, otherwise the
            // standby deck could continue underneath the ringtone/call.
            abortCrossfade()
            runCatching { player.pause() }
            runCatching { standbyPlayer.pause() }
            pausedByPhoneCall = true
            persistState()
            updateOmniaSpeedProbe()
            if (::bubatzNotificationProvider.isInitialized) {
                bubatzNotificationProvider.forceRefresh(session)
            }
        }
    }

    private suspend fun persistState() {
        val item = player.currentMediaItem
        val state = PlaybackStateEntity(
            currentTrackId = currentTrackId,
            currentMediaId = item?.mediaId,
            upcomingMediaId = null,
            currentPositionMs = player.currentPosition.coerceAtLeast(0L),
            currentDurationMs = if (player.duration > 0L) player.duration else 0L,
            currentTitle = item?.mediaMetadata?.title?.toString(),
            currentArtist = item?.mediaMetadata?.artist?.toString(),
            currentAlbum = item?.mediaMetadata?.albumTitle?.toString(),
            isPlaying = player.isPlaying,
            nextRadioAtMs = 0L
        )
        withContext(Dispatchers.IO) {
            db.state().put(state)
        }
        // Keep the home-screen widget in sync with actual playback state.
        // This is display-only and does not participate in shuffle/IQ/radio decisions.
        fm.bubatz.player.BubatzWidgetProvider.refreshAll(applicationContext)
    }

    override fun onDestroy() {
        chargingIdleHeartbeatJob?.cancel()
        tailAnalysisJob?.cancel()
        omniaAudioProbeJob?.cancel()
        omniaAudioProbeJob = null
        runCatching { omniaAudioProbeTrack?.pause() }
        runCatching { omniaAudioProbeTrack?.flush() }
        runCatching { omniaAudioProbeTrack?.stop() }
        runCatching { omniaAudioProbeTrack?.release() }
        omniaAudioProbeTrack = null
        omniaSpeedProbeSession?.isActive = false
        omniaSpeedProbeSession?.release()
        omniaSpeedProbeSession = null
        if (::player.isInitialized && player.currentMediaItem != null) {
            persistNavigationHistory()
            persistRadioSchedule()
            scope.launch { persistState() }
        }
        positionPersistJob?.cancel()
        restoreJob?.cancel()
        crossfadeMonitorJob?.cancel()
        crossfadeJob?.cancel()
        radioHardcutJob?.cancel()
        settingsJob?.cancel()
        scrobbleProgressJob?.cancel()
        platformSessionSyncJob?.cancel()
        runCatching {
            val tm = getSystemService(TelephonyManager::class.java)
            if (Build.VERSION.SDK_INT >= 31) {
                telephonyCallback?.let { tm?.unregisterTelephonyCallback(it) }
            } else {
                @Suppress("DEPRECATION")
                legacyPhoneStateListener?.let { tm?.listen(it, PhoneStateListener.LISTEN_NONE) }
            }
        }
        telephonyCallback = null
        legacyPhoneStateListener = null
        runCatching { session.release() }
        runCatching { player.release() }
        runCatching { standbyPlayer.release() }
        scope.cancel()
        super.onDestroy()
    }
}
