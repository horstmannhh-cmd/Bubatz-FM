package fm.bubatz.player

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.io.StringWriter
import java.text.DateFormat
import java.util.Date

class CrashDiagnostics(private val context: Context) {
    private val prefs = context.getSharedPreferences("crash_diagnostics", Context.MODE_PRIVATE)

    fun save(label: String, throwable: Throwable? = null, extra: String? = null) {
        val body = buildString {
            append(label)
            extra?.let { append("\n").append(it) }
            throwable?.let {
                append("\n\n")
                val sw = StringWriter()
                it.printStackTrace(PrintWriter(sw))
                append(sw.toString())
            }
        }
        prefs.edit().putString("last_error", body.take(12000)).apply()
    }


    fun saveLiveDiagnostic(text: String) {
        prefs.edit().putString("live_diagnostic", text.take(12000)).apply()
    }

    fun readLiveDiagnostic(): String =
        prefs.getString("live_diagnostic", "Noch keine Live-Diagnose protokolliert.")
            ?: "Noch keine Live-Diagnose protokolliert."

    fun clearLiveDiagnostic() {
        prefs.edit().remove("live_diagnostic").apply()
    }

    fun read(): String =
        prefs.getString("last_error", "Noch kein interner Wiedergabefehler protokolliert.")
            ?: "Noch kein interner Wiedergabefehler protokolliert."

    fun clear() {
        prefs.edit().remove("last_error").apply()
    }

    /**
     * Reads Android's own record of recent process deaths.
     * This survives a crash and is useful even when our own uncaught-exception
     * handler was never reached (native crash, ANR, OS kill, service timeout).
     */
    fun readSystemExitInfo(): String {
        if (Build.VERSION.SDK_INT < 30) {
            return "System-Exit-Diagnose benötigt Android 11 oder neuer."
        }

        return runCatching {
            val am = context.getSystemService(ActivityManager::class.java)
            val exits = am.getHistoricalProcessExitReasons(context.packageName, 0, 8)
            if (exits.isEmpty()) return@runCatching "Keine historischen Prozessabbrüche gefunden."

            buildString {
                exits.take(5).forEachIndexed { index, info ->
                    if (index > 0) append("\n\n────────────\n\n")
                    append("#${index + 1}\n")
                    append("Zeit: ")
                    append(DateFormat.getDateTimeInstance().format(Date(info.timestamp)))
                    append("\nGrund: ${reasonName(info.reason)} (${info.reason})")
                    append("\nStatus: ${info.status}")
                    append("\nBeschreibung: ${info.description ?: "(keine)"}")
                    append("\nWichtigkeit: ${info.importance}")
                    append("\nPSS: ${info.pss / 1024} MB")
                    append("\nRSS: ${info.rss / 1024} MB")

                    val trace = runCatching {
                        info.traceInputStream?.use { input ->
                            BufferedReader(InputStreamReader(input)).use { reader ->
                                val text = StringBuilder()
                                var line: String?
                                var count = 0
                                while (reader.readLine().also { line = it } != null && count < 120) {
                                    text.append(line).append('\n')
                                    count++
                                }
                                text.toString()
                            }
                        }
                    }.getOrNull()

                    if (!trace.isNullOrBlank()) {
                        append("\n\nSystem-Trace:\n")
                        append(trace.take(10000))
                    }
                }
            }
        }.getOrElse {
            "System-Exit-Diagnose fehlgeschlagen: ${it::class.java.simpleName}: ${it.message}"
        }
    }

    private fun reasonName(reason: Int): String = when (reason) {
        0 -> "UNKNOWN"
        1 -> "EXIT_SELF"
        2 -> "SIGNALED"
        3 -> "LOW_MEMORY"
        4 -> "CRASH"
        5 -> "CRASH_NATIVE"
        6 -> "ANR"
        7 -> "INITIALIZATION_FAILURE"
        8 -> "PERMISSION_CHANGE"
        9 -> "EXCESSIVE_RESOURCE_USAGE"
        10 -> "USER_REQUESTED"
        11 -> "USER_STOPPED"
        12 -> "DEPENDENCY_DIED"
        13 -> "OTHER"
        14 -> "FREEZER"
        15 -> "PACKAGE_STATE_CHANGE"
        16 -> "PACKAGE_UPDATED"
        else -> "REASON_$reason"
    }
}
