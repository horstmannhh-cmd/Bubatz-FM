Bubatz.FM v1.43.0 / Code 145

Änderung: Bubatz Flow behandelt Multi-Artist-Compilations nicht mehr wie normale Alben. Normale Albumgewichtung verwendet jetzt Artist+Album als Schlüssel.

Sanity-Check: OK.
Lokaler Android/Gradle-Compile: nicht ausgeführt (kein gradlew-Skript im Projektpaket); finaler Compile über GitHub Actions.

