package fm.bubatz.player.playback

import android.content.Context

/** Persistent generation counter for Bubatz Flow. Real play counts/history stay untouched. */
class FlowCycleStore(context: Context) {
    private val prefs = context.getSharedPreferences("bubatz_flow", Context.MODE_PRIVATE)

    fun current(): Long {
        val value = prefs.getLong(KEY_CYCLE, 1L)
        if (value > 0L) return value
        prefs.edit().putLong(KEY_CYCLE, 1L).apply()
        return 1L
    }

    fun newCycle(): Long {
        val next = current() + 1L
        prefs.edit().putLong(KEY_CYCLE, next).commit()
        return next
    }

    private companion object { const val KEY_CYCLE = "cycle" }
}
