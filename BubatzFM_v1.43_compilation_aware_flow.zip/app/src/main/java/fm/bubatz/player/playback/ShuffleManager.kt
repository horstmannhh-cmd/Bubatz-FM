package fm.bubatz.player.playback

import android.content.Context
import fm.bubatz.player.data.BubatzDatabase
import fm.bubatz.player.data.RadioClipEntity
import fm.bubatz.player.data.TrackEntity
import kotlin.math.max
import kotlin.random.Random

/** Bubatz Flow: persistent cycles plus artist/album-aware weighted shuffle. */
class ShuffleManager(private val db: BubatzDatabase, context: Context) {
    private val cycles = FlowCycleStore(context)

    // v1.43: compilation-aware album handling. The library can contain very large
    // multi-artist compilation series, so a plain album-title penalty is actively
    // counterproductive there. Refresh occasionally because metadata is resolved
    // lazily while tracks are played.
    private var compilationAlbums: Set<String> = emptySet()
    private var compilationRefreshCountdown = 0

    suspend fun nextTrack(excludeId: Long? = null): TrackEntity? {
        var cycle = cycles.current()
        var candidates = db.tracks().flowCycleCandidates(cycle, excludeId, 64)
        // A fully heard Flow automatically opens a fresh pot. Manual reset uses the
        // same generation mechanism, so real play counts/history are never erased.
        if (candidates.isEmpty() && db.tracks().remainingInFlowCycle(cycle) == 0) {
            cycle = cycles.newCycle()
            candidates = db.tracks().flowCycleCandidates(cycle, excludeId, 64)
        }
        if (candidates.isEmpty()) return null
        if (candidates.size == 1) return candidates.first()

        if (compilationRefreshCountdown <= 0) {
            compilationAlbums = db.tracks().compilationLikeAlbums().toSet()
            compilationRefreshCountdown = 25
        } else {
            compilationRefreshCountdown--
        }

        val recent = db.tracks().recentlyPlayed(120)
        val artistRank = mutableMapOf<String, Int>()
        val albumRank = mutableMapOf<String, Int>()
        recent.forEachIndexed { index, track ->
            track.artist?.normalized()?.takeIf { it.isNotEmpty() }?.let { artistRank.putIfAbsent(it, index) }
            albumKey(track)?.let { albumRank.putIfAbsent(it, index) }
        }

        val weighted = candidates.map { track ->
            var weight = 1.0
            track.artist?.normalized()?.let { key ->
                artistRank[key]?.let { rank ->
                    weight *= when {
                        rank == 0 -> 0.005
                        rank < 3 -> 0.02
                        rank < 8 -> 0.07
                        rank < 15 -> 0.18
                        rank < 25 -> 0.38
                        rank < 35 -> 0.62
                        else -> 0.85
                    }
                }
            }

            // v1.43: album weighting only applies to normal artist albums.
            // Multi-artist compilations are deliberately exempt: hearing one Café del
            // Mar / Ultra-Lounge / sampler track must not suppress unrelated artists
            // that merely share that compilation album. For normal albums the key also
            // contains the artist, preventing generic titles such as "Greatest Hits"
            // from being treated as a single album across different performers.
            albumKey(track)?.let { key ->
                albumRank[key]?.let { rank ->
                    weight *= when {
                        rank < 3 -> 0.20
                        rank < 10 -> 0.45
                        else -> 0.80
                    }
                }
            }
            track to max(weight, 0.0001)
        }

        val total = weighted.sumOf { it.second }
        var pick = Random.nextDouble(total)
        for ((track, weight) in weighted) {
            pick -= weight
            if (pick <= 0.0) return track
        }
        return weighted.last().first
    }

    suspend fun markPlayed(id: Long, playedAt: Long) =
        db.tracks().markPlayed(id, playedAt, cycles.current())

    fun startNewCycle(): Long = cycles.newCycle()

    suspend fun nextRadioClip(excludeId: Long? = null): RadioClipEntity? =
        db.clips().randomLeastPlayed(excludeId)

    private fun albumKey(track: TrackEntity): String? {
        val album = track.album?.normalized()?.takeIf { it.isNotEmpty() } ?: return null
        if (album in compilationAlbums) return null
        val artist = track.artist?.normalized()?.takeIf { it.isNotEmpty() } ?: return null
        return "$artist\u0000$album"
    }

    private fun String.normalized(): String = trim().lowercase()
}
