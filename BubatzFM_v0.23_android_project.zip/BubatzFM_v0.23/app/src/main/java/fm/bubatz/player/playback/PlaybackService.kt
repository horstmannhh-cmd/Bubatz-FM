
package fm.bubatz.player.playback

import android.content.Intent
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.PlaybackException
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import fm.bubatz.player.BubatzApplication
import fm.bubatz.player.CrashDiagnostics
import fm.bubatz.player.data.PlayHistoryEntity
import fm.bubatz.player.data.PlaybackStateEntity
import fm.bubatz.player.playback.dual.DualDeckPlayer
import fm.bubatz.player.playback.dual.PlaybackCoordinator
import fm.bubatz.player.playback.session.BubatzSessionPlayer
import fm.bubatz.player.radio.RadioScheduler
import fm.bubatz.player.scrobble.PlaybackScrobbleTracker
import fm.bubatz.player.scrobble.LastFmApi
import fm.bubatz.player.scrobble.LastFmConfig
import fm.bubatz.player.scrobble.LastFmScrobbleSender
import fm.bubatz.player.scrobble.LastFmSessionStore
import fm.bubatz.player.settings.AppSettings
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

class PlaybackService : MediaSessionService() {
    companion object {
        const val ACTION_AUTO_PLAY = "fm.bubatz.player.AUTO_PLAY"
        const val ACTION_PLAY_PAUSE = "fm.bubatz.player.PLAY_PAUSE"
        const val ACTION_NEXT = "fm.bubatz.player.NEXT"
        const val ACTION_PREVIOUS = "fm.bubatz.player.PREVIOUS"
    }

    private lateinit var session: MediaSession
    private lateinit var dualDeck: DualDeckPlayer
    private val coordinator = PlaybackCoordinator()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private lateinit var shuffle: ShuffleManager
    private lateinit var scrobbleTracker: PlaybackScrobbleTracker
    private lateinit var settings: AppSettings
    private lateinit var lastFmStore: LastFmSessionStore
    private lateinit var lastFmSender: LastFmScrobbleSender
    private lateinit var crashDiagnostics: CrashDiagnostics
    private val lastFmApi = LastFmApi()

    private val radioScheduler = RadioScheduler()
    private var radioRemainingMusicMs = 0L
    private var lastRadioTickRealtimeMs = 0L
    private var currentStartedRealtimeMs: Long = 0L
    private var lastStartedMediaId: String? = null
    private var pendingStartedItem: MediaItem? = null
    private var activePlayer: Player? = null
    private var sessionPlayer: BubatzSessionPlayer? = null
    private var initializationJob: Job? = null
    private val sessionCallback = object : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .build()
        }
    }

    private var suppressHistoryForRestoredMediaId: String? = null
    private val externallyObservedPlayers = mutableSetOf<Int>()

    override fun onCreate() {
        super.onCreate()
        val db = (application as BubatzApplication).database
        shuffle = ShuffleManager(db)
        scrobbleTracker = PlaybackScrobbleTracker(db)
        settings = AppSettings(this)
        lastFmStore = LastFmSessionStore(this)
        lastFmSender = LastFmScrobbleSender(db, lastFmStore, lastFmApi)
        crashDiagnostics = CrashDiagnostics(this)

        dualDeck = DualDeckPlayer(
            context = this,
            scope = scope,
            crossfadeMsProvider = { settings.crossfadeMs.first() },
            onActiveDeckChanged = { player ->
                activePlayer = player
                rebuildMediaSession(player)
            },
            onMediaStarted = { item -> pendingStartedItem = item }
        )

        // A MediaSession must exist before a controller can bind, even while
        // the database-backed resume state is still loading.
        activePlayer = dualDeck.activePlayer
        rebuildMediaSession(dualDeck.activePlayer)

        initializationJob = scope.launch {
            val state = withContext(Dispatchers.IO) { db.state().get() }
            radioRemainingMusicMs = state?.nextRadioAtMs
                ?.takeIf { it in 1L..3_600_000L }
                ?: radioScheduler.nextMusicIntervalMs()
            lastRadioTickRealtimeMs = android.os.SystemClock.elapsedRealtime()

            // v0.23 recovery mode:
            // Never restore a media item automatically after a crash. A bad/unsupported
            // URI in persisted playback_state would otherwise crash the app again as soon
            // as MediaSessionService is created.
            if (state != null && (state.currentMediaId != null || state.upcomingMediaId != null)) {
                withContext(Dispatchers.IO) {
                    db.state().put(
                        state.copy(
                            currentTrackId = null,
                            currentMediaId = null,
                            upcomingMediaId = null,
                            currentPositionMs = 0L,
                            currentDurationMs = 0L,
                            currentTitle = null,
                            currentArtist = null,
                            currentAlbum = null,
                            isPlaying = false
                        )
                    )
                }
                crashDiagnostics.save("RECOVERY: alten Wiedergabestatus entfernt – Bibliothek bleibt erhalten")
            }
        }

        scope.launch {
            while (isActive) {
                delay(1_000)
                val player = activePlayer ?: continue

                val nowRealtime = android.os.SystemClock.elapsedRealtime()
                val tickDelta = if (lastRadioTickRealtimeMs > 0L) {
                    (nowRealtime - lastRadioTickRealtimeMs).coerceIn(0L, 5_000L)
                } else 0L
                lastRadioTickRealtimeMs = nowRealtime

                val currentId = player.currentMediaItem?.mediaId.orEmpty()
                if (player.isPlaying && currentId.startsWith("track:") && radioRemainingMusicMs > 0L) {
                    radioRemainingMusicMs = (radioRemainingMusicMs - tickDelta).coerceAtLeast(0L)
                    if (radioRemainingMusicMs == 0L) {
                        ensureRadioReservedIfDue()
                    }
                }

                val listenedMs = if (currentStartedRealtimeMs > 0L) {
                    android.os.SystemClock.elapsedRealtime() - currentStartedRealtimeMs
                } else 0L
                scrobbleTracker.onProgress(listenedMs)
                if (listenedMs > 0L && listenedMs % 60_000L < 1_000L && LastFmConfig.configured) {
                    scope.launch { lastFmSender.flush() }
                }

                if (player.currentPosition % 5_000L < 1_000L) persistPosition()
            }
        }
    }

    private fun attachExternalControlListener(player: Player) {
        val identity = System.identityHashCode(player)
        if (!externallyObservedPlayers.add(identity)) return
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                if (mediaItem != null) pendingStartedItem = mediaItem
            }

            override fun onPlayerError(error: PlaybackException) {
                crashDiagnostics.save(
                    label = "EXOPLAYER ERROR",
                    throwable = error,
                    extra = "mediaId=${player.currentMediaItem?.mediaId}\nuri=${player.currentMediaItem?.localConfiguration?.uri}"
                )
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) {
                    val item = player.currentMediaItem ?: pendingStartedItem
                    if (item != null && item.mediaId != lastStartedMediaId) {
                        scope.launch { handleMediaStarted(item) }
                    }
                }
                scope.launch { persistPosition() }
            }
        })
    }

    private fun rebuildMediaSession(player: Player) {
        val facade = BubatzSessionPlayer(
            player = player,
            onNext = { scope.launch { skipNext() } },
            onPrevious = { scope.launch { handlePreviousRequest() } }
        )
        sessionPlayer = facade

        if (!::session.isInitialized) {
            session = MediaSession.Builder(this, facade)
                .setCallback(sessionCallback)
                .build()
        } else {
            session.setPlayer(facade)
        }
        attachExternalControlListener(player)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession = session

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_AUTO_PLAY -> scope.launch {
                // Bluetooth may arrive immediately after Android creates the service.
                // Wait until the persisted library/resume state has been restored
                // before trying to start playback.
                initializationJob?.join()
                startPlaybackIfIdle()
            }
            ACTION_PLAY_PAUSE -> {
                scope.launch {
                    initializationJob?.join()
                    val p = activePlayer
                    if (p == null || p.currentMediaItem == null) {
                        crashDiagnostics.save("PLAY: startPlaybackIfIdle beginnt")
                        startPlaybackIfIdle()
                    } else {
                        crashDiagnostics.save("PLAY: vorhandener Titel ${p.currentMediaItem?.mediaId}")
                        if (p.isPlaying) p.pause() else p.play()
                    }
                }
            }
            ACTION_NEXT -> scope.launch { skipNext() }
            ACTION_PREVIOUS -> scope.launch { handlePreviousRequest() }
        }
        return super.onStartCommand(intent, flags, startId)
    }

    private suspend fun handlePreviousRequest() {
        val p = activePlayer
        if (p != null && p.currentPosition > 5_000L) {
            dualDeck.seekTo(0L)
            persistPosition()
        } else {
            playPreviousFromHistory()
        }
    }

    private suspend fun startPlaybackIfIdle() {
        try {
            crashDiagnostics.clear()
            crashDiagnostics.save("PREFLIGHT: wähle Zufallstitel")

            val currentTrackId = activePlayer?.currentMediaItem?.mediaId
                ?.takeIf { it.startsWith("track:") }
                ?.removePrefix("track:")
                ?.toLongOrNull()

            val t = withContext(Dispatchers.IO) { shuffle.nextTrack(currentTrackId) }
            if (t == null) {
                crashDiagnostics.save("PREFLIGHT: kein Titel in Datenbank gefunden")
                return
            }

            val uri = Uri.parse(t.uri)
            val scheme = uri.scheme ?: "(kein Scheme)"
            val authority = uri.authority ?: "(keine Authority)"

            var descriptorOk = false
            var length = -1L
            var descriptorError: String? = null

            withContext(Dispatchers.IO) {
                try {
                    contentResolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                        descriptorOk = true
                        length = afd.length
                    }
                    if (!descriptorOk) {
                        contentResolver.openFileDescriptor(uri, "r")?.use {
                            descriptorOk = true
                        }
                    }
                } catch (t: Throwable) {
                    descriptorError = "${t::class.java.simpleName}: ${t.message}"
                }
            }

            crashDiagnostics.save(
                label = "PREFLIGHT FERTIG",
                extra = buildString {
                    append("Titel-ID: ${t.id}\n")
                    append("Titel: ${t.title}\n")
                    append("URI: ${t.uri}\n")
                    append("Scheme: $scheme\n")
                    append("Authority: $authority\n")
                    append("Dateizugriff: ${if (descriptorOk) "OK" else "FEHLER"}\n")
                    append("Länge: $length\n")
                    descriptorError?.let { append("Fehler: $it\n") }
                    append("\nNoch KEINE Wiedergabe gestartet. Das ist absichtlich v0.23 Diagnose.")
                }
            )
        } catch (t: Throwable) {
            crashDiagnostics.save("PREFLIGHT: Exception", t)
        }
    }

    private suspend fun skipNext() {
        val next = coordinator.peekNext() ?: nextPlayableItem()?.also { coordinator.setNext(it) } ?: return
        dualDeck.setInitial(next, 0L, playWhenReady = true)
    }

    private suspend fun playPreviousFromHistory() {
        val db = (application as BubatzApplication).database
        val current = activePlayer?.currentMediaItem?.mediaId
        val previous = withContext(Dispatchers.IO) {
            db.history().recent(20)
                .asSequence()
                .filter { it.type == "MUSIC" && it.trackId != null }
                .map { "track:${it.trackId}" }
                .firstOrNull { it != current }
        } ?: run {
            dualDeck.seekTo(0L)
            return
        }

        val item = mediaItemFromPersistentId(previous) ?: return
        coordinator.clear()
        dualDeck.setInitial(item, 0L, playWhenReady = true)
    }

    private suspend fun handleMediaStarted(item: MediaItem) {
        if (item.mediaId == lastStartedMediaId) return
        lastStartedMediaId = item.mediaId
        currentStartedRealtimeMs = android.os.SystemClock.elapsedRealtime()

        val duration = when {
            item.mediaId.startsWith("track:") -> {
                val id = item.mediaId.removePrefix("track:").toLongOrNull()
                id?.let { withContext(Dispatchers.IO) {
                    (application as BubatzApplication).database.tracks().byId(it)?.durationMs
                } } ?: 0L
            }
            item.mediaId.startsWith("radio:") -> {
                val id = item.mediaId.removePrefix("radio:").toLongOrNull()
                id?.let { withContext(Dispatchers.IO) {
                    (application as BubatzApplication).database.clips().byId(it)?.durationMs
                } } ?: 0L
            }
            else -> 0L
        }

        if (item.mediaId.startsWith("radio:")) {
            radioRemainingMusicMs = radioScheduler.nextMusicIntervalMs()
        }

        scrobbleTracker.onItemStarted(
            mediaId = item.mediaId,
            durationMs = duration,
            nowSeconds = System.currentTimeMillis() / 1000L
        )

        if (item.mediaId.startsWith("track:") && LastFmConfig.configured) {
            val key = lastFmStore.sessionKey
            val artist = item.mediaMetadata.artist?.toString().orEmpty()
            val title = item.mediaMetadata.title?.toString().orEmpty()
            if (key != null && artist.isNotBlank() && title.isNotBlank()) {
                scope.launch(Dispatchers.IO) {
                    runCatching {
                        lastFmApi.updateNowPlaying(
                            sessionKey = key,
                            artist = artist,
                            track = title,
                            album = item.mediaMetadata.albumTitle?.toString(),
                            durationSeconds = duration.takeIf { it > 0L }?.div(1000L)
                        )
                    }
                }
            }
        }

        if (suppressHistoryForRestoredMediaId == item.mediaId) {
            // Resuming the same partially-played item is not a new play.
            suppressHistoryForRestoredMediaId = null
        } else {
            recordStartedItem(item)
        }

        // The item that was scheduled has now become active.
        coordinator.consumeNext()
        persistPosition(currentMediaIdOverride = item.mediaId, upcomingMediaIdOverride = null)
        scheduleUpcoming()
    }

    private suspend fun scheduleUpcoming() {
        val next = nextPlayableItem() ?: return
        coordinator.setNext(next)
        persistPosition(upcomingMediaIdOverride = next.mediaId)
        dualDeck.scheduleNext(next)
    }

    /**
     * Radio scheduler is evaluated before selecting the next media item.
     * If due, exactly one radio insert is returned. The following item will
     * be music again because the deadline is immediately moved forward.
     */
    private suspend fun nextPlayableItem(): MediaItem? {
        val radioEnabled = settings.radioEnabled.first()
        if (radioEnabled && radioRemainingMusicMs <= 0L) {
            val radio = buildNextRadioItem()
            if (radio != null) return radio
        }

        val currentTrackId = activePlayer?.currentMediaItem?.mediaId
            ?.takeIf { it.startsWith("track:") }
            ?.removePrefix("track:")
            ?.toLongOrNull()
        val t = withContext(Dispatchers.IO) { shuffle.nextTrack(currentTrackId) } ?: return null
        return MediaItem.Builder()
            .setUri(t.uri)
            .setMediaId("track:${t.id}")
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(t.title)
                    .setArtist(t.artist)
                    .setAlbumTitle(t.album)
                    .build()
            )
            .build()
    }

    private suspend fun buildNextRadioItem(): MediaItem? {
        val clip = withContext(Dispatchers.IO) { shuffle.nextRadioClip() } ?: return null
        return MediaItem.Builder()
            .setUri(clip.uri)
            .setMediaId("radio:${clip.id}")
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(clip.name)
                    .setArtist("Bubatz FM")
                    .setAlbumTitle("Radioeinspieler")
                    .build()
            )
            .build()
    }

    private suspend fun ensureRadioReservedIfDue() {
        if (radioRemainingMusicMs > 0L) return
        if (!settings.radioEnabled.first()) return
        val existing = coordinator.peekNext()
        if (existing?.mediaId?.startsWith("radio:") == true) return

        val radio = buildNextRadioItem() ?: return
        coordinator.setNext(radio)
        persistPosition(upcomingMediaIdOverride = radio.mediaId)
        dualDeck.scheduleNext(radio)
    }

    private suspend fun mediaItemFromPersistentId(mediaId: String): MediaItem? {
        val db = (application as BubatzApplication).database
        return withContext(Dispatchers.IO) {
            when {
                mediaId.startsWith("track:") -> {
                    val id = mediaId.removePrefix("track:").toLongOrNull() ?: return@withContext null
                    val t = db.tracks().byId(id) ?: return@withContext null
                    MediaItem.Builder()
                        .setUri(t.uri)
                        .setMediaId("track:${t.id}")
                        .setMediaMetadata(
                            MediaMetadata.Builder()
                                .setTitle(t.title)
                                .setArtist(t.artist)
                                .setAlbumTitle(t.album)
                                .build()
                        )
                        .build()
                }
                mediaId.startsWith("radio:") -> {
                    val id = mediaId.removePrefix("radio:").toLongOrNull() ?: return@withContext null
                    val clip = db.clips().byId(id) ?: return@withContext null
                    MediaItem.Builder()
                        .setUri(clip.uri)
                        .setMediaId("radio:${clip.id}")
                        .setMediaMetadata(
                            MediaMetadata.Builder()
                                .setTitle(clip.name)
                                .setArtist("Bubatz FM")
                                .setAlbumTitle("Radioeinspieler")
                                .build()
                        )
                        .build()
                }
                else -> null
            }
        }
    }

    private suspend fun recordStartedItem(item: MediaItem) {
        val db = (application as BubatzApplication).database
        val now = System.currentTimeMillis()
        withContext(Dispatchers.IO) {
            when {
                item.mediaId.startsWith("track:") -> {
                    val id = item.mediaId.removePrefix("track:").toLongOrNull() ?: return@withContext
                    db.tracks().markPlayed(id, now)
                    db.history().insert(
                        PlayHistoryEntity(
                            type = "MUSIC",
                            trackId = id,
                            title = item.mediaMetadata.title?.toString() ?: "Unbekannter Titel"
                        )
                    )
                }
                item.mediaId.startsWith("radio:") -> {
                    val id = item.mediaId.removePrefix("radio:").toLongOrNull() ?: return@withContext
                    db.clips().markPlayed(id, now)
                    db.history().insert(
                        PlayHistoryEntity(
                            type = "RADIO",
                            clipId = id,
                            title = item.mediaMetadata.title?.toString()
                                ?: "Bubatz FM Einspieler"
                        )
                    )
                }
            }
        }
    }

    private suspend fun persistPosition(
        currentMediaIdOverride: String? = null,
        upcomingMediaIdOverride: String? = coordinator.peekNext()?.mediaId
    ) {
        val player = activePlayer ?: return
        val db = (application as BubatzApplication).database
        val currentMediaId = currentMediaIdOverride ?: player.currentMediaItem?.mediaId
        val currentTrackId = currentMediaId
            ?.takeIf { it.startsWith("track:") }
            ?.removePrefix("track:")
            ?.toLongOrNull()

        withContext(Dispatchers.IO) {
            val old = db.state().get() ?: PlaybackStateEntity()
            db.state().put(
                old.copy(
                    currentTrackId = currentTrackId,
                    currentMediaId = currentMediaId,
                    upcomingMediaId = upcomingMediaIdOverride,
                    currentPositionMs = player.currentPosition.coerceAtLeast(0L),
                    currentDurationMs = player.duration.coerceAtLeast(0L),
                    currentTitle = player.currentMediaItem?.mediaMetadata?.title?.toString(),
                    currentArtist = player.currentMediaItem?.mediaMetadata?.artist?.toString(),
                    currentAlbum = player.currentMediaItem?.mediaMetadata?.albumTitle?.toString(),
                    isPlaying = player.isPlaying,
                    nextRadioAtMs = radioRemainingMusicMs
                )
            )
        }
    }

    override fun onDestroy() {
        runBlocking(Dispatchers.IO) {
            persistPosition()
        }
        scope.cancel()
        if (::session.isInitialized) session.release()
        dualDeck.release()
        super.onDestroy()
    }
}
