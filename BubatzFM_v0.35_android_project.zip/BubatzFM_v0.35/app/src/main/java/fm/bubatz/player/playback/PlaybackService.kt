package fm.bubatz.player.playback

import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import fm.bubatz.player.BubatzApplication
import fm.bubatz.player.CrashDiagnostics
import fm.bubatz.player.data.PlaybackStateEntity
import fm.bubatz.player.data.PlayHistoryEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PlaybackService : MediaSessionService() {

    companion object {
        const val ACTION_AUTO_PLAY = "fm.bubatz.player.AUTO_PLAY"
        const val ACTION_PLAY_PAUSE = "fm.bubatz.player.PLAY_PAUSE"
        const val ACTION_NEXT = "fm.bubatz.player.NEXT"
        const val ACTION_PREVIOUS = "fm.bubatz.player.PREVIOUS"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private lateinit var player: ExoPlayer
    private lateinit var session: MediaSession
    private lateinit var shuffle: ShuffleManager
    private lateinit var diagnostics: CrashDiagnostics
    private lateinit var db: fm.bubatz.player.data.BubatzDatabase

    private var currentTrackId: Long? = null
    private var startedCurrentTrack = false

    // Navigation history for familiar Previous/Next behavior:
    // A → B → C, Previous => B, Next => C (not a fresh random title).
    private val backStack = ArrayDeque<Long>()
    private val forwardStack = ArrayDeque<Long>()

    override fun onCreate() {
        super.onCreate()

        diagnostics = CrashDiagnostics(this)
        db = (application as BubatzApplication).database
        shuffle = ShuffleManager(db)

        player = ExoPlayer.Builder(this).build()

        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                diagnostics.save(
                    "v0.35 EXOPLAYER ERROR",
                    error,
                    "mediaId=${player.currentMediaItem?.mediaId}\nuri=${player.currentMediaItem?.localConfiguration?.uri}"
                )
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                scope.launch {
                    if (isPlaying && !startedCurrentTrack) {
                        startedCurrentTrack = true
                        currentTrackId?.let { id ->
                            val item = player.currentMediaItem
                            withContext(Dispatchers.IO) {
                                db.tracks().markPlayed(id, System.currentTimeMillis())
                                db.history().insert(
                                    PlayHistoryEntity(
                                        type = "MUSIC",
                                        trackId = id,
                                        title = item?.mediaMetadata?.title?.toString() ?: "Unbekannt"
                                    )
                                )
                            }
                        }
                    }
                    persistState()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                scope.launch {
                    persistState()
                    if (playbackState == Player.STATE_ENDED) {
                        playNextInternal()
                    }
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                startedCurrentTrack = false
                currentTrackId = mediaItem?.mediaId
                    ?.takeIf { it.startsWith("track:") }
                    ?.removePrefix("track:")
                    ?.toLongOrNull()
                scope.launch { persistState() }
            }
        })

        session = MediaSession.Builder(this, player).build()

        diagnostics.save("v0.35 Service erstellt – Minimalplayer bereit")
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession = session

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_AUTO_PLAY -> {
                scope.launch {
                    if (player.currentMediaItem == null) {
                        playNextInternal()
                    } else {
                        player.play()
                    }
                }
                return START_STICKY
            }

            ACTION_PLAY_PAUSE -> {
                scope.launch {
                    if (player.currentMediaItem == null) {
                        playNextInternal()
                    } else if (player.isPlaying) {
                        player.pause()
                    } else {
                        player.play()
                    }
                }
                return START_STICKY
            }

            ACTION_NEXT -> {
                scope.launch { playNextInternal() }
                return START_STICKY
            }

            ACTION_PREVIOUS -> {
                scope.launch { playPreviousInternal() }
                return START_STICKY
            }
        }

        return super.onStartCommand(intent, flags, startId)
    }

    private suspend fun playNextInternal() {
        try {
            val oldCurrent = currentTrackId
            val usingForwardHistory = forwardStack.isNotEmpty()

            val next = if (usingForwardHistory) {
                val forwardId = forwardStack.removeLast()
                withContext(Dispatchers.IO) { db.tracks().byId(forwardId) }
            } else {
                withContext(Dispatchers.IO) {
                    shuffle.nextTrack(currentTrackId)
                }
            }

            if (next == null) {
                diagnostics.save("v0.35 FEHLER: kein nächster Titel gefunden")
                return
            }

            oldCurrent?.let { current ->
                if (current != next.id) {
                    backStack.addLast(current)
                }
            }

            // A genuinely new random branch discards old forward history.
            if (!usingForwardHistory) {
                forwardStack.clear()
            }

            val item = mediaItemForTrack(next)
            currentTrackId = next.id
            startedCurrentTrack = false

            diagnostics.save(
                "v0.35: nächster Titel gestartet",
                extra = "id=${next.id}\ntitel=${next.title}\nforwardHistory=$usingForwardHistory\nback=${backStack.size}\nforward=${forwardStack.size}"
            )

            player.setMediaItem(item)
            player.prepare()
            player.play()

        } catch (t: Throwable) {
            diagnostics.save("v0.35 EXCEPTION bei Next", t)
        }
    }

    private suspend fun playPreviousInternal() {
        try {
            // Standard player behavior: after 5 seconds, Previous restarts
            // the current title. Near the beginning it navigates backward.
            if (player.currentMediaItem != null && player.currentPosition > 5_000L) {
                player.seekTo(0L)
                if (!player.isPlaying) player.play()
                diagnostics.save("v0.35: Previous → aktueller Titel neu gestartet")
                return
            }

            val currentId = currentTrackId

            var previousId: Long? = if (backStack.isNotEmpty()) {
                backStack.removeLast()
            } else {
                // Fallback for the first navigation after a service restart:
                // recover the preceding title from persistent play history.
                withContext(Dispatchers.IO) {
                    db.history()
                        .recent(30)
                        .asSequence()
                        .filter { it.type == "MUSIC" && it.trackId != null }
                        .mapNotNull { it.trackId }
                        .firstOrNull { it != currentId }
                }
            }

            if (previousId == null) {
                if (player.currentMediaItem != null) {
                    player.seekTo(0L)
                    if (!player.isPlaying) player.play()
                }
                diagnostics.save("v0.35: Previous → kein vorheriger Titel vorhanden")
                return
            }

            val previous = withContext(Dispatchers.IO) {
                db.tracks().byId(previousId)
            }

            if (previous == null) {
                diagnostics.save("v0.35: Previous → History-Titel nicht mehr in DB")
                return
            }

            // Remember where we came from, so Next returns there.
            currentId?.let { current ->
                if (current != previous.id) {
                    forwardStack.addLast(current)
                }
            }

            val item = mediaItemForTrack(previous)
            currentTrackId = previous.id
            startedCurrentTrack = false

            player.setMediaItem(item)
            player.prepare()
            player.play()

            diagnostics.save(
                "v0.35: vorheriger Titel gestartet",
                extra = "id=${previous.id}\ntitel=${previous.title}\nback=${backStack.size}\nforward=${forwardStack.size}"
            )
        } catch (t: Throwable) {
            diagnostics.save("v0.35 EXCEPTION bei Previous", t)
        }
    }

    private data class ResolvedTrack(
        val title: String,
        val artist: String?,
        val album: String?,
        val durationMs: Long
    )

    private suspend fun mediaItemForTrack(track: fm.bubatz.player.data.TrackEntity): MediaItem {
        val resolved = if (
            !track.artist.isNullOrBlank() &&
            !track.album.isNullOrBlank() &&
            track.durationMs > 0L
        ) {
            ResolvedTrack(track.title, track.artist, track.album, track.durationMs)
        } else {
            resolveTrackMetadata(track)
        }

        return MediaItem.Builder()
            .setUri(Uri.parse(track.uri))
            .setMediaId("track:${track.id}")
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(resolved.title)
                    .setArtist(resolved.artist)
                    .setAlbumTitle(resolved.album)
                    .build()
            )
            .build()
    }

    private suspend fun resolveTrackMetadata(
        track: fm.bubatz.player.data.TrackEntity
    ): ResolvedTrack = withContext(Dispatchers.IO) {
        val fallback = ResolvedTrack(
            title = track.title,
            artist = track.artist,
            album = track.album,
            durationMs = track.durationMs
        )

        val resolved = runCatching {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(this@PlaybackService, Uri.parse(track.uri))

                val title = retriever
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                    ?.takeIf { it.isNotBlank() }
                    ?: track.title

                val artist = retriever
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                    ?.takeIf { it.isNotBlank() }
                    ?: track.artist

                val album = retriever
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
                    ?.takeIf { it.isNotBlank() }
                    ?: track.album

                val duration = retriever
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull()
                    ?.takeIf { it > 0L }
                    ?: track.durationMs

                ResolvedTrack(title, artist, album, duration)
            } finally {
                retriever.release()
            }
        }.getOrElse {
            diagnostics.save(
                "v0.35: Metadaten-Fallback",
                throwable = it,
                extra = "trackId=${track.id}\nuri=${track.uri}"
            )
            fallback
        }

        if (
            resolved.title != track.title ||
            resolved.artist != track.artist ||
            resolved.album != track.album ||
            resolved.durationMs != track.durationMs
        ) {
            runCatching {
                db.tracks().updateMetadata(
                    id = track.id,
                    title = resolved.title,
                    artist = resolved.artist,
                    album = resolved.album,
                    durationMs = resolved.durationMs
                )
            }
        }

        resolved
    }

    private suspend fun persistState() {
        val item = player.currentMediaItem
        val state = PlaybackStateEntity(
            currentTrackId = currentTrackId,
            currentMediaId = item?.mediaId,
            upcomingMediaId = null,
            currentPositionMs = player.currentPosition.coerceAtLeast(0L),
            currentDurationMs = if (player.duration > 0L) player.duration else 0L,
            currentTitle = item?.mediaMetadata?.title?.toString(),
            currentArtist = item?.mediaMetadata?.artist?.toString(),
            currentAlbum = item?.mediaMetadata?.albumTitle?.toString(),
            isPlaying = player.isPlaying,
            nextRadioAtMs = 0L
        )
        withContext(Dispatchers.IO) {
            db.state().put(state)
        }
    }

    override fun onDestroy() {
        runCatching { session.release() }
        runCatching { player.release() }
        scope.cancel()
        super.onDestroy()
    }
}
