package fm.bubatz.player

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.common.util.concurrent.ListenableFuture

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: TrackAdapter
    private lateinit var nowPlaying: TextView
    private lateinit var countText: TextView

    private var tracks: List<Track> = emptyList()
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
            if (grants.values.any { it }) {
                loadMusic()
            } else {
                Toast.makeText(this, "Musikzugriff wurde nicht erlaubt.", Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        nowPlaying = findViewById(R.id.nowPlaying)
        countText = findViewById(R.id.countText)

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        adapter = TrackAdapter(emptyList()) { index -> playTrack(index) }
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        findViewById<Button>(R.id.loadButton).setOnClickListener { ensurePermissionAndLoad() }
        findViewById<Button>(R.id.previousButton).setOnClickListener { controller?.seekToPreviousMediaItem() }
        findViewById<Button>(R.id.nextButton).setOnClickListener { controller?.seekToNextMediaItem() }
        findViewById<Button>(R.id.playPauseButton).setOnClickListener {
            controller?.let {
                if (it.isPlaying) it.pause() else it.play()
            }
        }

        connectToPlaybackService()
    }

    private fun connectToPlaybackService() {
        val token = SessionToken(this, android.content.ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener(
            {
                try {
                    controller = controllerFuture?.get()
                    controller?.addListener(object : Player.Listener {
                        override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                            val title = mediaMetadata.title?.toString().orEmpty()
                            val artist = mediaMetadata.artist?.toString().orEmpty()
                            nowPlaying.text = if (title.isBlank()) "Noch nichts läuft"
                            else if (artist.isBlank()) title else "$title · $artist"
                        }
                    })
                } catch (e: Exception) {
                    Toast.makeText(this, "Player konnte nicht gestartet werden.", Toast.LENGTH_LONG).show()
                }
            },
            ContextCompat.getMainExecutor(this)
        )
    }

    private fun requiredPermissions(): Array<String> {
        val list = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            list += Manifest.permission.READ_MEDIA_AUDIO
            list += Manifest.permission.POST_NOTIFICATIONS
        } else {
            list += Manifest.permission.READ_EXTERNAL_STORAGE
        }
        return list.toTypedArray()
    }

    private fun ensurePermissionAndLoad() {
        val missing = requiredPermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isEmpty()) {
            loadMusic()
        } else {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun loadMusic() {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"

        val result = mutableListOf<Track>()

        contentResolver.query(
            collection,
            projection,
            selection,
            null,
            sortOrder
        )?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idColumn)
                val title = cursor.getString(titleColumn) ?: "Unbekannter Titel"
                val artist = cursor.getString(artistColumn) ?: "Unbekannter Interpret"
                val uri = ContentUris.withAppendedId(collection, id)
                result += Track(id, title, artist, uri)
            }
        }

        tracks = result
        adapter.submitList(result)
        countText.text = "${result.size} Titel"

        if (result.isEmpty()) {
            Toast.makeText(this, "Keine Musikdateien gefunden.", Toast.LENGTH_LONG).show()
        }
    }

    private fun playTrack(index: Int) {
        val player = controller ?: run {
            Toast.makeText(this, "Player wird noch gestartet.", Toast.LENGTH_SHORT).show()
            return
        }
        if (tracks.isEmpty() || index !in tracks.indices) return

        val items = tracks.map { track ->
            MediaItem.Builder()
                .setUri(track.uri)
                .setMediaId(track.id.toString())
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(track.title)
                        .setArtist(track.artist)
                        .build()
                )
                .build()
        }

        player.setMediaItems(items, index, 0L)
        player.prepare()
        player.shuffleModeEnabled = true
        player.play()
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}
