# Bubatz FM

Erste installierbare Android-Basis für den geplanten Bubatz-FM-Musikplayer.

## Bereits enthalten
- Lokale Musikbibliothek über Android MediaStore
- Wiedergabe lokaler Titel
- Media3 / ExoPlayer
- MediaSessionService für Hintergrundwiedergabe und Android-Mediensteuerung
- Vor / Zurück / Play-Pause
- Shuffle wird beim Start einer Wiedergabe aktiviert
- Dunkle Bubatz-FM-Grundoptik
- Technische Basis für spätere Smartwatch-/Bluetooth-Mediensteuerung

## Für spätere Versionen vorgesehen
- echtes Bubatz-FM-Branding/Logo
- Crossfade
- Zufallslogik passend zur großen Bibliothek
- Last.fm Scrobbling
- Favoriten / Warteschlange
- Albumcover
- Einstellungen
- weitere Radio-ähnliche Bubatz-FM-Funktionen

## Hinweis
Dies ist bewusst eine erste, möglichst robuste Basis. Sie soll zunächst sauber als APK gebaut und auf dem Zielgerät installiert werden.
