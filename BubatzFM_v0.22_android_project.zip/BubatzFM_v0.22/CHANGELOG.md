# Bubatz FM v0.22 Diagnose

- Wiedergabestart protokolliert jeden kritischen Schritt dauerhaft.
- Unbehandelte Java/Kotlin-Abstürze werden dauerhaft gespeichert.
- ExoPlayer-Fehler werden mit mediaId und URI gespeichert.
- MediaMetadataRetriever wurde vollständig aus dem ersten Wiedergabeweg entfernt.
- Eingebettete Albumcover-Abfrage vorübergehend deaktiviert, um native Metadaten-Crashes auszuschließen.
- Play wartet jetzt sicher auf abgeschlossene Service-Initialisierung.
- Diagnose ist in Einstellungen → Wiedergabe-Diagnose sichtbar.
- Bestehende Bibliothek bleibt kompatibel; kein erneutes Einlesen nötig.

# Bubatz FM v0.21

- Wiedergabestart für sehr große Bibliotheken grundlegend entschärft.
- Kein Aufbau einer 40.000+-Zeilen-Shuffle-Queue mehr beim ersten Play.
- Persistentes Fair-Shuffle über playCount: jeder Titel kommt einmal dran, bevor Wiederholungen möglich werden.
- Frische Bibliothek wählt erst beim tatsächlichen Play-Befehl einen Titel, nicht beim Service-Start.
- Manuelle Player-Steuerung startet keinen unnötigen Foreground-Service vor der Wiedergabe.
- SAF-Metadatenzugriff vereinfacht.
- Audio-Datei-URI wird nicht mehr fälschlich als Artwork-URI an Media3 übergeben.
- Ein Titel gilt erst als gespielt, wenn die Wiedergabe tatsächlich startet, nicht schon beim Vorladen.
- Bestehende 40.836-Titel-Datenbank bleibt kompatibel; kein erneutes Einlesen nötig.

# Bubatz FM v0.20

- Bibliotheksimport für sehr große Sammlungen umgebaut: zuerst schnelle Dateierfassung und DB-Speicherung, keine 40.000 Metadaten-Lesevorgänge mehr vor dem ersten Datenbankeintrag.
- Metadaten werden bei Wiedergabe eines Titels bei Bedarf gelesen.
- DB-Import erfolgt in 1000er-Blöcken.
- Radioeinspieler-Timer zählt jetzt ausschließlich tatsächlich abgespielte MUSIK-Zeit.
- Pause, App-Schließzeit und Einspieler zählen nicht mit.
- Restzeit bis zum nächsten Einspieler wird persistent gespeichert.
- Nach jedem tatsächlich gestarteten Einspieler wird ein neuer Zufallswert von 25–35 Minuten gezogen.

# Bubatz FM v0.19 Diagnose persistent

- Diagnose wird jetzt dauerhaft in SharedPreferences gespeichert.
- Selbst nach Prozess-Neustart oder Absturz bleibt der letzte Scan-Zwischenstand sichtbar.
- Fortschritt wird bereits während Ordner-/Datei-Zählung und Metadatenphase gespeichert.
- Damit lässt sich unterscheiden: Prozessneustart, SAF-Query-Problem, Audio-Erkennung oder Metadatenphase.

# Bubatz FM v0.18 Diagnose

- Ordnerscanner auf direkte Android DocumentsContract-Abfragen umgestellt.
- Rekursive SD-Karten-Suche ohne DocumentFile.listFiles().
- Diagnoseanzeige: besuchte Ordner, Dateien, erkannte Audiodateien, Metadaten-Erfolge/-Fehler, Datenbank-Einfügungen und Query-Fehler.
- Ziel: den 0-Titel-Fehler auf dem realen Gerät eindeutig lokalisieren.

# Bubatz FM v0.17

- Fix: Musikdateien werden nicht mehr verworfen, wenn Android auf der SD-Karte keine Metadaten über MediaMetadataRetriever liefert.
- Metadatenlesung versucht zuerst einen FileDescriptor und fällt bei Bedarf auf die URI-Methode zurück.
- Audioerkennung nutzt zusätzlich den MIME-Type.
- Versionsanzeige auf 0.17 aktualisiert.

# Bubatz FM v0.16

- Fix: Kotlin-Kompilierfehler in `PlaybackService.kt` behoben.
- `dualDeck.activePlayer` ist eine Property und wird jetzt korrekt ohne `()` verwendet.
- Enthält weiterhin die v0.15/v0.14-Anpassungen (JVM 17, 5000 ms Crossfade-Referenz, Bibliotheks-Persistenz/Startlogik/Bluetooth-Autostart-Basis).

# v0.15

- Build-Fix: Java- und Kotlin-JVM-Target einheitlich auf 17 gesetzt.
- Dadurch wird der GitHub-Actions-Fehler bei `:app:kspDebugKotlin` behoben.

# Bubatz FM v0.14

- Bluetooth-Autostart wartet nun zuverlässig auf die Initialisierung des Players.
- Play aus komplettem Leerlauf kann selbst einen Titel aus der Bubatz-FM-Bibliothek auswählen.
- Standard-Crossfade auf 5000 ms gesetzt.
- Bibliothek bleibt in Room gespeichert; Musik wird weiterhin nur aus explizit ausgewählten Ordnern importiert.
- Versionsanzeige auf 0.14 aktualisiert.
