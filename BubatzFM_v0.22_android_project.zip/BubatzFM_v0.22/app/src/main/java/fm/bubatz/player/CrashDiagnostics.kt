package fm.bubatz.player

import android.content.Context
import java.io.PrintWriter
import java.io.StringWriter

class CrashDiagnostics(context: Context) {
    private val prefs = context.getSharedPreferences("crash_diagnostics", Context.MODE_PRIVATE)

    fun save(label: String, throwable: Throwable? = null, extra: String? = null) {
        val body = buildString {
            append(label)
            extra?.let { append("\n").append(it) }
            throwable?.let {
                append("\n\n")
                val sw = StringWriter()
                it.printStackTrace(PrintWriter(sw))
                append(sw.toString())
            }
        }
        prefs.edit().putString("last_error", body.take(12000)).apply()
    }

    fun read(): String = prefs.getString("last_error", "Noch kein Wiedergabefehler protokolliert.")
        ?: "Noch kein Wiedergabefehler protokolliert."

    fun clear() {
        prefs.edit().remove("last_error").apply()
    }
}
