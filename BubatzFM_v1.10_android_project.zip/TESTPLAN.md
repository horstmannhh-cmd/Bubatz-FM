# Bubatz.FM v1.09 Testplan

1. Vor dem Update einen gut erkennbaren Crossfade-Wert einstellen (z. B. 6,5 s), Radioeinspieler/Bluetooth/Last.fm-Schalter merken.
2. v1.09 über die bestehende App installieren und neu öffnen. Alle Einstellungen müssen unverändert sein.
3. Einen Musik→Musik-Crossfade abwarten. Während/nach dem Wechsel muss die normale Playeransicht denselben Titel/Interpreten zeigen wie die Samsung-Live-Benachrichtigung.
4. Noch 2–3 automatische Titelwechsel beobachten; die Live-Benachrichtigung darf keinen vorherigen Titel behalten.
5. App vollständig schließen und neu öffnen. Crossfade-Wert und übrige Einstellungen erneut prüfen.
6. Auf dem Homescreen/Launcher muss unter dem Icon exakt `Bubatz.FM` stehen.

## v1.10 Crossfade-Glättung
1. Crossfade auf den bevorzugten Wert stellen und mindestens 8–10 automatische Musik→Musik-Wechsel laufen lassen.
2. Besonders auf den Moment achten, an dem der alte Titel vollständig verschwunden ist und nur der neue Titel weiterläuft. Dort darf kein kurzer Haker/Flam/Pegelsprung hörbar sein.
3. Mindestens einen Einspieler abwarten oder per Testknopf auslösen: Musik→Einspieler und Einspieler→Musik bleiben harte Übergänge ohne Crossfade.
4. Danach muss Musik→Musik wieder normal crossfaden.
