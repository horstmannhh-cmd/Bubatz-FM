from pathlib import Path
import sys, xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]

# v0.32 is intentionally a minimal playback diagnostic build.
# Only validate the minimum project structure needed to compile/run this test.
required = [
    root / "app/src/main/AndroidManifest.xml",
    root / "app/src/main/java/fm/bubatz/player/MainActivity.kt",
    root / "app/src/main/java/fm/bubatz/player/playback/PlaybackService.kt",
    root / "app/src/main/java/fm/bubatz/player/data/Dao.kt",
]

errors = [f"Missing required file: {p.relative_to(root)}" for p in required if not p.exists()]

manifest = root / "app/src/main/AndroidManifest.xml"
if manifest.exists():
    try:
        ET.parse(manifest)
    except Exception as e:
        errors.append(f"AndroidManifest.xml invalid: {e}")

service = root / "app/src/main/java/fm/bubatz/player/playback/PlaybackService.kt"
if service.exists():
    text = service.read_text()
    if "MediaSession.Builder(this, player)" not in text:
        errors.append("Minimal MediaSession not found.")
    if "ExoPlayer.Builder(this).build()" not in text:
        errors.append("Minimal ExoPlayer not found.")

if errors:
    print("SANITY CHECK FAILED")
    for e in errors:
        print("-", e)
    sys.exit(1)

print("SANITY CHECK OK - v0.32 minimal playback diagnostic")
