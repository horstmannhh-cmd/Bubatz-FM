# Archiv / Metadaten – Zwischenstand 3 (NICHT INSTALLIEREN)

- Der Bibliotheksscan wird direkt nach der Ordnerauswahl als Android-Foreground-Service (dataSync) gestartet. Die App muss für die Metadatenphase nicht mehr geöffnet bleiben.
- Fortschritt und Fehlerzahl erscheinen in einer Benachrichtigung und in der gespeicherten Scandiagnose.
- Die geschützte Enumeration läuft vor dem DB-Abgleich; unvollständige Enumeration verändert die vorhandene Bibliothek nicht.
- Metadaten werden weiterhin pro Titel dauerhaft gespeichert, ohne Track-ID, Playcount oder IQ-Deck zu ändern.
- Versionskennung im Projekt auf 1.49.59 / 414 angehoben.

## Vor Installation offen
- Kein Android-Build und kein Gerätetest in dieser Umgebung bestätigt.
- Android 15+ begrenzt dataSync-Foreground-Services zeitlich (typisch 6 Stunden innerhalb von 24 Stunden); eine zusätzliche Fortsetzung/Timeout-Behandlung fehlt.
- Beim erneuten Komplettscan werden bisherige Metadaten nicht erneut ausgelesen; der separate Force-Refresh-Modus fehlt.
- Fehlende Tags können bei Folgescans erneut im Backlog erscheinen; Status pro Datei ist noch nicht persistent.
- Archivsuche mit mehreren Suchwörtern muss noch vollständig SQL-seitig gefiltert und gezählt werden.
- Nach einer Prozessbeendigung muss der Scan derzeit manuell erneut gestartet werden. Der DB-Abgleich ist transaktional, Metadaten sind einzeln gespeichert.
