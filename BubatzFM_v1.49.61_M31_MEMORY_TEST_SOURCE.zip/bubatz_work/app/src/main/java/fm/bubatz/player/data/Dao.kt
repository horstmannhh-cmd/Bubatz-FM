package fm.bubatz.player.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TrackDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(items: List<TrackEntity>): List<Long>

    @Query("SELECT COUNT(*) FROM tracks WHERE enabled = 1")
    fun observeCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM tracks WHERE enabled = 1")
    suspend fun count(): Int

    @Query("SELECT id FROM tracks WHERE enabled = 1 ORDER BY id")
    suspend fun allEnabledIds(): List<Long>

    @Query("SELECT * FROM tracks WHERE id = :id")
    suspend fun byId(id: Long): TrackEntity?

    @Query("SELECT * FROM tracks WHERE id = :id AND enabled = 1")
    suspend fun byIdEnabled(id: Long): TrackEntity?

    // Read-only browse source for the UI library. It does not update play/shuffle state.
    @Query("SELECT * FROM tracks WHERE enabled = 1 ORDER BY LOWER(COALESCE(artist, '')), LOWER(COALESCE(album, '')), LOWER(title), id")
    suspend fun allEnabledForLibrary(): List<TrackEntity>

    @Query("""
        SELECT * FROM tracks
        WHERE enabled = 1
          AND artist IS NOT NULL
          AND TRIM(artist) = TRIM(:artist) COLLATE NOCASE
        ORDER BY LOWER(COALESCE(album, '')), LOWER(title), id
    """)
    suspend fun tracksByArtist(artist: String): List<TrackEntity>

    @Query("""
        SELECT * FROM tracks
        WHERE enabled = 1
          AND album IS NOT NULL
          AND TRIM(album) = TRIM(:album) COLLATE NOCASE
        ORDER BY LOWER(COALESCE(artist, '')), LOWER(title), id
    """)
    suspend fun tracksByAlbum(album: String): List<TrackEntity>

    // Compact archive indexes: never materialize the entire library as TrackEntity objects.
    data class ArtistSummary(val name: String, val trackCount: Int)
    data class AlbumSummary(val name: String, val trackCount: Int, val coverUri: String?, val searchText: String)

    @Query("""
        SELECT TRIM(artist) AS name, COUNT(*) AS trackCount FROM tracks
        WHERE enabled = 1 AND artist IS NOT NULL AND TRIM(artist) != ''
        GROUP BY LOWER(TRIM(artist)) ORDER BY LOWER(TRIM(artist))
    """)
    suspend fun archiveArtists(): List<ArtistSummary>

    @Query("""
        SELECT TRIM(album) AS name, COUNT(*) AS trackCount,
               MIN(uri) AS coverUri,
               LOWER(TRIM(album) || ' ' || COALESCE(GROUP_CONCAT(DISTINCT artist), '') || ' ' ||
                     COALESCE(GROUP_CONCAT(DISTINCT albumArtist), '')) AS searchText
        FROM tracks WHERE enabled = 1 AND album IS NOT NULL AND TRIM(album) != ''
        GROUP BY LOWER(TRIM(album)) ORDER BY LOWER(TRIM(album))
    """)
    suspend fun archiveAlbums(): List<AlbumSummary>

    @Query("""
        SELECT * FROM tracks WHERE enabled = 1
        AND (:term = '' OR LOWER(title || ' ' || COALESCE(artist, '') || ' ' || COALESCE(album, '')) LIKE '%' || :term || '%')
        ORDER BY LOWER(title), id LIMIT :limit OFFSET :offset
    """)
    suspend fun archiveTitlePage(term: String, limit: Int, offset: Int): List<TrackEntity>

    @Query("""
        SELECT COUNT(*) FROM tracks WHERE enabled = 1
        AND (:term = '' OR LOWER(title || ' ' || COALESCE(artist, '') || ' ' || COALESCE(album, '')) LIKE '%' || :term || '%')
    """)
    suspend fun archiveTitleCount(term: String): Int

    // Dynamic, parameterized AND search: all words are matched in SQL before LIMIT.
    // This prevents multiword searches from appearing empty because matches fell
    // outside the first 100 rows of a broader one-word result.
    @RawQuery
    suspend fun archiveSearchTitlePage(query: androidx.sqlite.db.SupportSQLiteQuery): List<TrackEntity>

    @RawQuery
    suspend fun archiveSearchTitleCount(query: androidx.sqlite.db.SupportSQLiteQuery): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun markMetadataInspected(row: MetadataScanEntity)

    @Query("DELETE FROM metadata_scan WHERE status = 2")
    suspend fun retryFailedMetadata(): Int

    @Query("SELECT COUNT(*) FROM metadata_scan WHERE status = 2")
    suspend fun metadataFailures(): Int

    // Metadata backlog is fetched in small pages; no full TrackEntity library in RAM.
    @Query("""
        SELECT * FROM tracks WHERE enabled = 1
          AND (artist IS NULL OR TRIM(artist) = '' OR album IS NULL OR TRIM(album) = '' OR durationMs = 0)
          AND id NOT IN (SELECT trackId FROM metadata_scan)
          AND id > :afterId ORDER BY id LIMIT :limit
    """)
    suspend fun metadataBacklogPage(afterId: Long, limit: Int): List<TrackEntity>

    @Query("""
        SELECT COUNT(*) FROM tracks WHERE enabled = 1
          AND (artist IS NULL OR TRIM(artist) = '' OR album IS NULL OR TRIM(album) = '' OR durationMs = 0)
          AND id NOT IN (SELECT trackId FROM metadata_scan)
    """)
    suspend fun metadataBacklogCount(): Int

    @Query("UPDATE tracks SET enabled = 0")
    suspend fun disableAll()

    @Query("UPDATE tracks SET enabled = 1 WHERE uri IN (:uris)")
    suspend fun enableByUris(uris: List<String>)

    @Query("""
        SELECT * FROM tracks
        WHERE enabled = 1
          AND playCount = (SELECT MIN(playCount) FROM tracks WHERE enabled = 1)
          AND (:excludeId IS NULL OR id != :excludeId)
        ORDER BY RANDOM()
        LIMIT 1
    """)
    suspend fun randomLeastPlayed(excludeId: Long? = null): TrackEntity?

    @Query("""
        SELECT * FROM tracks
        WHERE enabled = 1
          AND playCount = (SELECT MIN(playCount) FROM tracks WHERE enabled = 1)
          AND (:excludeId IS NULL OR id != :excludeId)
        ORDER BY RANDOM()
        LIMIT :limit
    """)
    suspend fun leastPlayedCandidates(excludeId: Long? = null, limit: Int = 64): List<TrackEntity>

    @Query("""
        SELECT * FROM tracks
        WHERE enabled = 1 AND lastPlayed IS NOT NULL
        ORDER BY lastPlayed DESC
        LIMIT :limit
    """)
    suspend fun recentlyPlayed(limit: Int = 80): List<TrackEntity>

    @Query("UPDATE tracks SET lastPlayed=:playedAt, playCount=playCount+1, flowCycle=:flowCycle WHERE id=:id")
    suspend fun markPlayed(id: Long, playedAt: Long, flowCycle: Long)

    @Query("""
        SELECT * FROM tracks
        WHERE enabled = 1
          AND flowCycle != :flowCycle
          AND (:excludeId IS NULL OR id != :excludeId)
        ORDER BY RANDOM()
        LIMIT :limit
    """)
    suspend fun flowCycleCandidates(flowCycle: Long, excludeId: Long? = null, limit: Int = 64): List<TrackEntity>

    @Query("SELECT COUNT(*) FROM tracks WHERE enabled = 1 AND flowCycle != :flowCycle")
    suspend fun remainingInFlowCycle(flowCycle: Long): Int

    /**
     * Album titles that currently behave like compilations: at least three distinct
     * credited artists among enabled tracks. Using the normalized album title here
     * also neutralizes generic names such as "Greatest Hits" that occur across
     * unrelated artists and should never act like one giant album in Bubatz.IQ.
     */
    @Query("""
        SELECT LOWER(TRIM(album))
        FROM tracks
        WHERE enabled = 1
          AND album IS NOT NULL AND TRIM(album) != ''
          AND artist IS NOT NULL AND TRIM(artist) != ''
        GROUP BY LOWER(TRIM(album))
        HAVING COUNT(DISTINCT LOWER(TRIM(artist))) >= 3
    """)
    suspend fun compilationLikeAlbums(): List<String>

    @Query("""
        UPDATE tracks
        SET title = :title,
            artist = :artist,
            album = :album,
            albumArtist = :albumArtist,
            isCompilation = :isCompilation,
            durationMs = :durationMs
        WHERE id = :id
    """)
    suspend fun updateMetadata(
        id: Long,
        title: String,
        artist: String?,
        album: String?,
        albumArtist: String?,
        isCompilation: Boolean,
        durationMs: Long
    )
}

@Dao
interface RadioClipDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(items: List<RadioClipEntity>): List<Long>

    @Query("SELECT COUNT(*) FROM radio_clips WHERE enabled=1")
    fun observeCount(): Flow<Int>

    @Query("SELECT id FROM radio_clips WHERE enabled = 1 ORDER BY id")
    suspend fun allEnabledIds(): List<Long>

    @Query("SELECT * FROM radio_clips WHERE id=:id")
    suspend fun byId(id: Long): RadioClipEntity?

    @Query("SELECT * FROM radio_clips WHERE id=:id AND enabled = 1")
    suspend fun byIdEnabled(id: Long): RadioClipEntity?

    @Query("UPDATE radio_clips SET enabled = 0")
    suspend fun disableAll()

    @Query("UPDATE radio_clips SET enabled = 1 WHERE uri IN (:uris)")
    suspend fun enableByUris(uris: List<String>)

    @Query("""
        SELECT * FROM radio_clips
        WHERE enabled = 1
          AND playCount = (SELECT MIN(playCount) FROM radio_clips WHERE enabled = 1)
          AND (:excludeId IS NULL OR id != :excludeId)
        ORDER BY RANDOM()
        LIMIT 1
    """)
    suspend fun randomLeastPlayed(excludeId: Long? = null): RadioClipEntity?

    @Query("UPDATE radio_clips SET lastPlayed=:playedAt, playCount=playCount+1 WHERE id=:id")
    suspend fun markPlayed(id: Long, playedAt: Long)
}

@Dao
interface ShuffleDao {
    @Query("DELETE FROM shuffle_queue") suspend fun clearTracks()
    @Insert suspend fun insertTracks(items: List<ShuffleQueueEntity>)
    @Query("SELECT trackId FROM shuffle_queue WHERE cycle=:cycle AND position=:position LIMIT 1")
    suspend fun trackAt(cycle: Long, position: Int): Long?

    @Query("DELETE FROM radio_shuffle_queue") suspend fun clearClips()
    @Insert suspend fun insertClips(items: List<RadioShuffleQueueEntity>)
    @Query("SELECT clipId FROM radio_shuffle_queue WHERE cycle=:cycle AND position=:position LIMIT 1")
    suspend fun clipAt(cycle: Long, position: Int): Long?
}

@Dao
interface StateDao {
    @Query("SELECT * FROM playback_state WHERE `key`='main' LIMIT 1")
    suspend fun get(): PlaybackStateEntity?

    @Query("SELECT * FROM playback_state WHERE `key`='main' LIMIT 1")
    fun observe(): Flow<PlaybackStateEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(state: PlaybackStateEntity)
}



@Dao
interface ScrobbleQueueDao {
    @Insert
    suspend fun enqueue(item: ScrobbleQueueEntity): Long

    @Query("SELECT * FROM scrobble_queue WHERE submitted = 0 ORDER BY startedAtSeconds ASC LIMIT :limit")
    suspend fun pending(limit: Int = 100): List<ScrobbleQueueEntity>

    @Query("UPDATE scrobble_queue SET submitted = 1 WHERE id = :id")
    suspend fun markSubmitted(id: Long)

    @Query("UPDATE scrobble_queue SET attempts = attempts + 1 WHERE id = :id")
    suspend fun markAttempt(id: Long)

    @Query("SELECT COUNT(*) FROM scrobble_queue WHERE submitted = 0")
    suspend fun pendingCount(): Int
}

@Dao
interface HistoryDao {
    @Insert
    suspend fun insert(item: PlayHistoryEntity)

    @Query("SELECT * FROM play_history ORDER BY playedAt DESC LIMIT :limit")
    suspend fun recent(limit: Int = 100): List<PlayHistoryEntity>

    @Query("SELECT trackId FROM play_history WHERE type = 'MUSIC' AND trackId IS NOT NULL ORDER BY playedAt DESC LIMIT 1")
    suspend fun latestMusicTrackId(): Long?

    @Query("""
        SELECT h.id AS historyId, h.playedAt AS playedAt, t.id AS trackId,
               t.title AS title, t.artist AS artist, t.album AS album, t.uri AS uri
        FROM play_history h
        INNER JOIN tracks t ON t.id = h.trackId
        WHERE h.type = 'MUSIC' AND h.trackId IS NOT NULL
        ORDER BY h.playedAt DESC
        LIMIT :limit
    """)
    fun observeRecentMusic(limit: Int = 50): Flow<List<RecentMusicItem>>

    @Query("""
        DELETE FROM play_history
        WHERE id NOT IN (SELECT id FROM play_history ORDER BY playedAt DESC LIMIT :keep)
    """)
    suspend fun trimTo(keep: Int = 200)
}

@Database(
    entities = [
        TrackEntity::class, MetadataScanEntity::class, RadioClipEntity::class,
        ShuffleQueueEntity::class, RadioShuffleQueueEntity::class,
        PlaybackStateEntity::class, ScrobbleQueueEntity::class, PlayHistoryEntity::class
    ],
    version = 8,
    exportSchema = false
)
abstract class BubatzDatabase : RoomDatabase() {
    abstract fun tracks(): TrackDao
    abstract fun clips(): RadioClipDao
    abstract fun shuffle(): ShuffleDao
    abstract fun state(): StateDao
    abstract fun history(): HistoryDao
    abstract fun scrobbles(): ScrobbleQueueDao

    companion object {
        private val MIGRATION_7_8 = object : androidx.room.migration.Migration(7, 8) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS metadata_scan (trackId INTEGER NOT NULL PRIMARY KEY, status INTEGER NOT NULL, inspectedAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_metadata_scan_status ON metadata_scan (status)")
            }
        }

        private val MIGRATION_5_6 = object : androidx.room.migration.Migration(5, 6) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE tracks ADD COLUMN flowCycle INTEGER NOT NULL DEFAULT 0")
            }
        }

        private val MIGRATION_6_7 = object : androidx.room.migration.Migration(6, 7) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                // null means: not inspected yet. Existing libraries are enriched lazily
                // when tracks are prepared, avoiding a 40k-file metadata rescan.
                db.execSQL("ALTER TABLE tracks ADD COLUMN albumArtist TEXT")
                db.execSQL("ALTER TABLE tracks ADD COLUMN isCompilation INTEGER")
            }
        }

        private val MIGRATION_4_5 = object : androidx.room.migration.Migration(4, 5) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE playback_state ADD COLUMN currentTitle TEXT")
                db.execSQL("ALTER TABLE playback_state ADD COLUMN currentArtist TEXT")
                db.execSQL("ALTER TABLE playback_state ADD COLUMN currentAlbum TEXT")
            }
        }

        private val MIGRATION_3_4 = object : androidx.room.migration.Migration(3, 4) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE playback_state ADD COLUMN currentDurationMs INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE playback_state ADD COLUMN isPlaying INTEGER NOT NULL DEFAULT 0")
            }
        }

        private val MIGRATION_2_3 = object : androidx.room.migration.Migration(2, 3) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE playback_state ADD COLUMN currentMediaId TEXT")
                db.execSQL("ALTER TABLE playback_state ADD COLUMN upcomingMediaId TEXT")
            }
        }

        fun create(context: android.content.Context): BubatzDatabase =
            Room.databaseBuilder(context, BubatzDatabase::class.java, "bubatz-fm.db")
                .addMigrations(MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8)
                .fallbackToDestructiveMigrationOnDowngrade()
                .build()
    }
}
