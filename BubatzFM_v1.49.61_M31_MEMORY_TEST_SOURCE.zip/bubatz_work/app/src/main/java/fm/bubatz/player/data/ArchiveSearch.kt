package fm.bubatz.player.data

import androidx.sqlite.db.SimpleSQLiteQuery
import androidx.sqlite.db.SupportSQLiteQuery

/** Parameterized multiword AND search, executed before paging. */
object ArchiveSearch {
    fun titles(terms: List<String>, limit: Int, offset: Int): SupportSQLiteQuery =
        query(terms, count = false, limit = limit, offset = offset)

    fun count(terms: List<String>): SupportSQLiteQuery =
        query(terms, count = true, limit = 0, offset = 0)

    private fun query(terms: List<String>, count: Boolean, limit: Int, offset: Int): SupportSQLiteQuery {
        val searchable = "LOWER(COALESCE(title, '') || ' ' || COALESCE(artist, '') || ' ' || COALESCE(album, ''))"
        val sql = StringBuilder(if (count) "SELECT COUNT(*) FROM tracks WHERE enabled = 1" else "SELECT * FROM tracks WHERE enabled = 1")
        val args = mutableListOf<Any>()
        for (term in terms.filter { it.isNotBlank() }) {
            sql.append(" AND ").append(searchable).append(" LIKE ? ESCAPE '\\'")
            val escaped = term.lowercase().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            args.add("%$escaped%")
        }
        if (!count) {
            sql.append(" ORDER BY LOWER(title), id LIMIT ? OFFSET ?")
            args.add(limit.coerceIn(1, 200))
            args.add(offset.coerceAtLeast(0))
        }
        return SimpleSQLiteQuery(sql.toString(), args.toTypedArray())
    }
}
