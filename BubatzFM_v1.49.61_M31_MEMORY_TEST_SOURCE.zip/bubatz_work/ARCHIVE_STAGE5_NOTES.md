# Archiv / Metadaten – Zwischenstand 5 (NICHT INSTALLIEREN)

- Room-Schema 7 -> 8: separate, kleine `metadata_scan`-Tabelle (Track-ID, Ergebnis, Zeitstempel), ohne Änderungen an `tracks`, Deck oder Wiedergabehistorie.
- Erfolgreich inspizierte Dateien erhalten Status 1, auch wenn tatsächlich Künstler-/Album-Tags fehlen. Unlesbare Dateien erhalten Status 2. Beide werden beim nächsten normalen Scan nicht endlos erneut geöffnet.
- Backlog-Abfragen schließen bereits geprüfte IDs aus; ein nach Unterbrechung erneut gestarteter manueller Scan setzt den Metadatenlauf bei den noch nicht geprüften Titeln fort. Die sichere Verzeichnis-Enumeration wird weiterhin vollständig wiederholt.
- Noch offen: echte Benutzeroberfläche für Wiederaufnahme und gezielten erneuten Versuch fehlgeschlagener Dateien, robustere SQL-Mehrwortsuche, Foreground-Service-Laufzeitstrategie auf Android 15+, vollständiger Android-Build und Gerätetest.
- Keine Änderungen an Bubatz.IQ und Wiedergabe.
