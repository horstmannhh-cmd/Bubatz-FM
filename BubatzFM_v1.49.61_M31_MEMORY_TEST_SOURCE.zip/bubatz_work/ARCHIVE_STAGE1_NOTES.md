# Archiv-Umbau – Zwischenstand (nicht installieren)

- Künstler und Alben werden als kompakte SQL-Gruppierungen abgefragt.
- Titelliste wird über SQL in 100er-Seiten geladen; Suchanfrage filtert serverseitig zunächst den ersten Begriff, weitere Begriffe in der jeweiligen Seite.
- Bestehende Wiedergabe- und Bubatz.IQ-Logik unangetastet.
- Noch NICHT umgesetzt: vollständiger, unterbrechungssicherer Metadatenscan; daher bleiben bisher nicht erschlossene Künstler weiterhin unsichtbar.
- Noch NICHT gebaut oder auf Android getestet; nur Quellcode-Zwischenstand.
- Mehrwortsuche braucht noch vollständig datenbankseitige AND-Filterung und korrekte Trefferzählung.
