# Archiv – Entwicklungsstand 8 (NICHT INSTALLIEREN)

- Archiv beobachtet die Room-Tracks-Tabelle und aktualisiert Künstler-/Album-Gruppierungen nach einer entprellten Änderung (2,5 s).
- Titel-Suche wird bei Datenänderung erneut abgefragt und auf Seite 1 zurückgesetzt; verhindert veraltete Trefferlisten nach dem Metadatenscan.
- Bestehende SQL-Paginierung, Scan-Dienst, Persistenz und Bubatz.IQ unverändert.
- Kein vollständiger Android-Build oder Gerätetest; nicht installieren.
