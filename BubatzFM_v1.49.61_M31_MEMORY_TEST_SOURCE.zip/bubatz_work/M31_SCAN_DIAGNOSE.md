# M31 Musikscan – Diagnoseversion 1.49.60

- Verhindert einen als erfolgreich gemeldeten Musikscan mit null gefundenen Audiodateien.
- Bestehende Bibliothek bleibt bei leerer Enumeration unverändert.
- Diagnose meldet besuchte Ordner, Dateien, erkannte Audiodateien und Abfragefehler.
- Keine Änderung an Bubatz.IQ, Wiedergabe oder Einspielerscan.
- Die eigentliche Ursache des M31-Problems ist noch nicht nachgewiesen.
- Zuerst GitHub-Build; danach nur gezielter M31-Test.
