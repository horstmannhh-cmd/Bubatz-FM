# Archiv / Metadaten – Zwischenstand 2 (NICHT INSTALLIEREN)

- Nach einem erfolgreichen geschützten Ordnerabgleich werden fehlende Künstler-/Album-/Laufzeit-Tags in 50er-Seiten aus der Datenbank gelesen und je Titel dauerhaft aktualisiert.
- Künstler, Album, Albumkünstler, Compilation-Flag, Titel und Laufzeit werden per MediaMetadataRetriever gelesen.
- Bereits vollständige Datensätze werden übersprungen; bestehende Track-IDs, IQ-Deck und Playcounts werden nicht verändert.
- Fortschritt und Fehlerzähler erscheinen in den Einstellungen.
- Bekannte Grenzen: Noch kein Foreground-Service, kein zuverlässiger Scan bei gesperrtem Bildschirm; ein fehlender Tag kann erneut im Backlog landen; geänderte Tags bereits vollständig erschlossener Dateien werden noch nicht erneut gelesen; keine Build-/Geräteprüfung.
- Nächster Schritt vor installierbarem Update: unterbrechungssicherer Foreground-Service und vollständige Scanoption, danach Build und Geräteprüfung.
