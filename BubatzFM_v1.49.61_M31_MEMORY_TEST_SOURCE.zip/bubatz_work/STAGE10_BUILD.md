# Stage 10: GitHub-Buildvorbereitung (keine APK)

GitHub Actions Workflow hinzugefügt: `.github/workflows/android-build.yml`.
Baut mit JDK 17, Gradle 8.10.2, Android 35 / Build Tools 34.0.0.
Führt Sanity-Check und `:app:testDebugUnitTest` vor `:app:assembleDebug` aus.
Das APK-Artefakt heißt `BubatzFM-v1.49.59-debug-apk`.

Wichtig: GitHub Actions erwartet `app/`, `build.gradle.kts`, `.github/` etc.
im Repository-Stammverzeichnis. Beim Upload den INHALT von `bubatz_work/`
verwenden, nicht den äußeren Ordner als Unterordner ablegen.

Noch kein vollständiger Android-Build ausgeführt. Nicht installieren, bevor
GitHub Actions grün ist und APK geprüft wurde.
