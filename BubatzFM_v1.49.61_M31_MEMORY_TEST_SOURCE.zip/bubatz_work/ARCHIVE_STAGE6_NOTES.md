# Archiv / Metadaten – Zwischenstand 6 (NICHT INSTALLIEREN)

- Manuelles "Metadaten fortsetzen" in den Einstellungen nach abgebrochenem Metadatenlauf. Es wiederholt nicht den vollständigen Ordnerscan; zulässig nur nach vollständig abgeschlossenem Ordnerabgleich.
- Nach Zeitlimit wird unterschieden zwischen Unterbrechung während der Verzeichnissuche (Ordner erneut auswählen) und während des Metadatendurchlaufs (Metadaten fortsetzen).
- "Fehlerhafte Dateien erneut prüfen" nach vollständig abgeschlossenem Scan setzt ausschließlich Fehlerstatus 2 zurück und versucht diese Dateien erneut.
- Der Dienst führt beide Vorgänge im Vordergrund aus. Bestehende Track-IDs und IQ-/Wiedergabedaten bleiben unverändert.
- Nicht installiert/nicht Android-gebaut; UI-Status ist derzeit beim Öffnen der Einstellungen zu aktualisieren. Android-15-Laufzeitlimit für sehr lange Scans erfordert gegebenenfalls manuelles Fortsetzen. Archivsuche und Build stehen noch aus.
