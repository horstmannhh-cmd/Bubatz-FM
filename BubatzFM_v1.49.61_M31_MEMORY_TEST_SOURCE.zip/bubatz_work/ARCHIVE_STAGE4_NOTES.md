# Archiv / Metadaten – Zwischenstand 4 (NICHT INSTALLIEREN)

- Android-15+-Timeout-Callback für dataSync-Foreground-Service ergänzt. Bei Erreichen des Zeitbudgets wird der Dienst gestoppt statt von Android wegen Timeout abgewürgt.
- Scanphase und zuletzt gewählter Ordner werden persistent protokolliert; nach Unterbrechung bleiben bereits gespeicherte Metadaten erhalten.
- Automatische Fortsetzung ist **noch nicht implementiert**: ein erneuter manueller Scan führt die sichere Enumeration erneut aus, anschließend werden fehlende Metadaten ergänzt.
- Offene Punkte: persistenter Bearbeitungsstatus für Dateien ohne Tags, echte Resume-Steuerung, SQL-seitige Mehrwort-Archivsuche, Build und Gerätetest.
- Keine Änderungen an Bubatz.IQ oder Wiedergabe.
