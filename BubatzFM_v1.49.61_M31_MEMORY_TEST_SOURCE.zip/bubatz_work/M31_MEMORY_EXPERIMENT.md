# M31 memory experiment v1.49.61 (source-only)

Based on v1.49.60 M31_SCAN_DIAGNOSE_BUILD (versionCode 415), with the previous v1.49.59 M31 artwork optimizations selectively transferred. New versionCode 416. The v1.49.60 LibraryScanner and LibraryScanService remain untouched; Bubatz.IQ and Last.fm unchanged.

Changes: MainActivity compressed artwork cache capped at 4 MiB; UI cover decoding subsampled with RGB_565; PlaybackService platform media artwork subsampled with RGB_565.

Not built or tested. Before installation confirm signing matches installed app and actual installed versionCode is lower than 416. Do not uninstall or clear app data: preserve 30-hour M31 library scan. Build via existing GitHub/Windows workflow.
