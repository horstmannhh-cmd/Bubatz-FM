# Archiv – Entwicklungsstand 7 (NICHT INSTALLIEREN)

- Titelarchiv: Mehrwortsuche wird jetzt vollständig und parametrisiert in SQLite ausgeführt (AND-Verknüpfung aller Suchwörter), bevor die 100er-Paginierung greift.
- Trefferanzahl entspricht nun der gesamten SQL-Treffermenge, nicht bloß der geladenen ersten Seite.
- SQL-LIKE-Sonderzeichen `%`, `_` und `\\` werden als wörtliche Suchzeichen behandelt.
- Künstler-/Albumverzeichnisse und Metadaten-Langzeitscan bleiben gegenüber Stage 6 unverändert; Bubatz.IQ ebenfalls.
- Bekannte offene Punkte: Künstler-/Album-Suche weiter clientseitig auf kompakten Gruppierungen; automatische Aktualisierung nach Metadatenlauf noch prüfen. Android-Build und Gerätetest ausstehend.
