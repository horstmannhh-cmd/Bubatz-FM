package fm.bubatz.player.diagnostics

import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.PlaybackState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Process-local bridge to Omnia's real Android MediaSession.
 * The NotificationListenerService owns discovery; this object exposes a small,
 * stable state surface to Compose and forwards only standard transport controls.
 */
object OmniaBridge {
    data class State(
        val connected: Boolean = false,
        val packageName: String? = null,
        val title: String = "",
        val artist: String = "",
        val album: String = "",
        val isPlaying: Boolean = false,
        val playbackState: Int? = null,
        val actions: Long = 0L,
        val durationMs: Long = 0L,
        val positionMs: Long = 0L
    ) {
        val hasMetadata: Boolean
            get() = title.isNotBlank() || artist.isNotBlank() || album.isNotBlank()
    }

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    @Volatile
    private var controller: MediaController? = null

    fun attach(newController: MediaController?) {
        controller = newController
        refresh()
    }

    fun detach(controllerBeingRemoved: MediaController? = null) {
        if (controllerBeingRemoved == null || controller === controllerBeingRemoved) {
            controller = null
            _state.value = State()
        }
    }

    fun refresh() {
        val c = controller
        if (c == null) {
            _state.value = State()
            return
        }
        val metadata = c.metadata
        val playback = c.playbackState
        _state.value = State(
            connected = true,
            packageName = c.packageName,
            title = metadata.text(MediaMetadata.METADATA_KEY_TITLE),
            artist = metadata.text(MediaMetadata.METADATA_KEY_ARTIST),
            album = metadata.text(MediaMetadata.METADATA_KEY_ALBUM),
            isPlaying = playback?.state == PlaybackState.STATE_PLAYING ||
                playback?.state == PlaybackState.STATE_BUFFERING,
            playbackState = playback?.state,
            actions = playback?.actions ?: 0L,
            durationMs = metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L,
            positionMs = playback?.position?.coerceAtLeast(0L) ?: 0L
        )
    }

    fun playPause() {
        val c = controller ?: return
        val state = c.playbackState?.state
        if (state == PlaybackState.STATE_PLAYING || state == PlaybackState.STATE_BUFFERING) {
            c.transportControls.pause()
        } else {
            c.transportControls.play()
        }
    }

    fun next() {
        controller?.transportControls?.skipToNext()
    }

    fun previous() {
        controller?.transportControls?.skipToPrevious()
    }

    fun seekTo(positionMs: Long) {
        controller?.transportControls?.seekTo(positionMs.coerceAtLeast(0L))
    }

    private fun MediaMetadata?.text(key: String): String =
        this?.getText(key)?.toString().orEmpty()
}
