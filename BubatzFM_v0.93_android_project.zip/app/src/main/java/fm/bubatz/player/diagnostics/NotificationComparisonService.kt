package fm.bubatz.player.diagnostics

import android.app.Notification
import android.app.NotificationManager
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.content.ComponentName
import android.os.Handler
import android.os.Looper
import fm.bubatz.player.CrashDiagnostics

class NotificationComparisonService : NotificationListenerService() {
    private var omniaController: MediaController? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val omniaCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: android.media.MediaMetadata?) {
            OmniaBridge.refresh()
        }

        override fun onPlaybackStateChanged(state: PlaybackState?) {
            OmniaBridge.refresh()
        }

        override fun onSessionDestroyed() {
            detachOmniaController()
            attachOmniaController()
        }
    }

    override fun onListenerConnected() {
        attachOmniaController()
        saveComparison()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        attachOmniaController()
        OmniaBridge.refresh()
        saveComparison()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        attachOmniaController()
        OmniaBridge.refresh()
        saveComparison()
    }

    override fun onListenerDisconnected() {
        detachOmniaController()
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        detachOmniaController()
        super.onDestroy()
    }

    private fun attachOmniaController() {
        val manager = getSystemService(MediaSessionManager::class.java) ?: return
        val component = ComponentName(this, NotificationComparisonService::class.java)
        val found = runCatching {
            manager.getActiveSessions(component)
                .firstOrNull { it.packageName.contains("omnia", ignoreCase = true) }
        }.getOrNull()

        if (found === omniaController) {
            OmniaBridge.attach(found)
            return
        }

        detachOmniaController()
        omniaController = found
        found?.registerCallback(omniaCallback, mainHandler)
        OmniaBridge.attach(found)
    }

    private fun detachOmniaController() {
        omniaController?.let { controller ->
            runCatching { controller.unregisterCallback(omniaCallback) }
            OmniaBridge.detach(controller)
        }
        omniaController = null
    }

    private fun saveComparison() {
        runCatching {
            val notifications = activeNotifications ?: emptyArray()
            val rankingMap = currentRanking
            val interesting = notifications.filter { sbn ->
                sbn.packageName == packageName ||
                    sbn.packageName.contains("omnia", ignoreCase = true) ||
                    sbn.notification.extras?.getCharSequence(Notification.EXTRA_TITLE)
                        ?.toString()?.contains("Omnia", true) == true
            }

            val report = buildString {
                append("v0.91: Omnia ↔ Bubatz FM Player-Integration\n")
                append("listenerConnected=true\n")
                append("aktive Benachrichtigungen=${notifications.size}\n")
                append("Treffer=${interesting.size}\n")
                append("Hinweis: v0.69 zeigte Bubatz ongoing=true/flags=0x62, Omnia ongoing=false/flags=0x60.\n\n")

                if (interesting.isEmpty()) {
                    append("Keine Bubatz-/Omnia-Benachrichtigung gefunden. Omnia und Bubatz FM gleichzeitig abspielen bzw. geöffnet lassen und erneut aktualisieren.\n")
                }

                interesting.forEachIndexed { i, sbn ->
                    if (i > 0) append("\n────────────\n")
                    append(describe(sbn, rankingMap))
                }

                append("\n\n════════════════════\n")
                append("ANDROID MEDIASESSION STACK\n")
                append("════════════════════\n")
                append(describeActiveMediaSessions())
            }
            CrashDiagnostics(this).saveNotificationComparison(report)
        }.onFailure {
            CrashDiagnostics(this).saveNotificationComparison(
                "v0.70 VERGLEICHSFEHLER\n${it::class.java.simpleName}: ${it.message}"
            )
        }
    }

    private fun describe(
        sbn: StatusBarNotification,
        rankingMap: RankingMap?
    ): String {
        val n = sbn.notification
        val nm = getSystemService(NotificationManager::class.java)
        val channel = if (Build.VERSION.SDK_INT >= 26) {
            n.channelId?.let { nm?.getNotificationChannel(it) }
        } else null

        val promotedFlag = runCatching {
            Notification::class.java.getField("FLAG_PROMOTED_ONGOING").getInt(null)
        }.getOrNull()
        val promotable = runCatching {
            Notification::class.java.getMethod("hasPromotableCharacteristics")
                .invoke(n) as? Boolean
        }.getOrNull()

        val ranking = Ranking()
        val rankingFound = runCatching {
            rankingMap?.getRanking(sbn.key, ranking) == true
        }.getOrDefault(false)

        return buildString {
            append("package=").append(sbn.packageName).append('\n')
            append("key=").append(sbn.key).append('\n')
            append("id=").append(sbn.id).append('\n')
            append("ongoing=").append((n.flags and Notification.FLAG_ONGOING_EVENT) != 0).append('\n')
            append("promotedFlag=").append(promotedFlag?.let { (n.flags and it) != 0 }).append('\n')
            append("promotable=").append(promotable).append('\n')
            append("category=").append(n.category).append('\n')
            append("group=").append(n.group).append('\n')
            append("channel=").append(if (Build.VERSION.SDK_INT >= 26) n.channelId else "n/a").append('\n')
            append("channelImportance=").append(channel?.importance).append('\n')
            append("channelName=").append(channel?.name).append('\n')
            append("channelSound=").append(channel?.sound).append('\n')
            append("channelBadge=").append(channel?.canShowBadge()).append('\n')
            append("style=").append(n.extras?.getString("android.template")).append('\n')
            append("title=").append(n.extras?.getCharSequence(Notification.EXTRA_TITLE)).append('\n')
            append("text=").append(n.extras?.getCharSequence(Notification.EXTRA_TEXT)).append('\n')
            append("subText=").append(n.extras?.getCharSequence(Notification.EXTRA_SUB_TEXT)).append('\n')
            append("mediaSession=").append(n.extras?.containsKey("android.mediaSession")).append('\n')
            append("flags=0x").append(n.flags.toString(16)).append('\n')
            append("visibility=").append(n.visibility).append('\n')
            append("priority=").append(n.priority).append('\n')
            append("hasSmallIcon=").append(n.smallIcon != null).append('\n')
            append("hasLargeIcon=").append(n.getLargeIcon() != null).append('\n')

            append("rankingFound=").append(rankingFound).append('\n')
            if (rankingFound) {
                append("rankingRank=").append(ranking.rank).append('\n')
                append("rankingImportance=").append(ranking.importance).append('\n')
                append("rankingChannel=").append(ranking.channel?.id).append('\n')
                append("rankingCanBubble=").append(ranking.canBubble()).append('\n')
                if (Build.VERSION.SDK_INT >= 30) {
                    append("rankingIsConversation=").append(ranking.isConversation).append('\n')
                }
                append("rankingSuspended=").append(ranking.isSuspended).append('\n')
                append("rankingAmbient=").append(ranking.isAmbient).append('\n')
            }
        }
    }
    private fun describeActiveMediaSessions(): String {
        return runCatching {
            val manager = getSystemService(MediaSessionManager::class.java)
            val listenerComponent = ComponentName(this, NotificationComparisonService::class.java)
            val controllers = manager?.getActiveSessions(listenerComponent).orEmpty()

            buildString {
                append("aktiveSessions=").append(controllers.size).append('\n')
                val interestingControllers = controllers.filter {
                    it.packageName == packageName ||
                        it.packageName.contains("omnia", ignoreCase = true)
                }
                append("TrefferSessions=").append(interestingControllers.size).append('\n')

                if (interestingControllers.isEmpty()) {
                    append("Keine Bubatz-/Omnia-MediaSession im Android-Session-Stack gefunden.\n")
                }

                interestingControllers.forEachIndexed { index, c ->
                    if (index > 0) append("\n──────── SESSION ────────\n")
                    append(describeController(c))
                }

                val bubatzActions = interestingControllers
                    .firstOrNull { it.packageName == packageName }
                    ?.playbackState?.actions
                val omniaActions = interestingControllers
                    .firstOrNull { it.packageName.contains("omnia", ignoreCase = true) }
                    ?.playbackState?.actions
                if (bubatzActions != null && omniaActions != null) {
                    append("\n════════ ACTION-DIFF ════════\n")
                    append("bubatzMask=0x").append(bubatzActions.toString(16)).append('\n')
                    append("omniaMask=0x").append(omniaActions.toString(16)).append('\n')
                    appendActionDiff("onlyBubatz", bubatzActions and omniaActions.inv())
                    appendActionDiff("onlyOmnia", omniaActions and bubatzActions.inv())
                    appendActionDiff("common", bubatzActions and omniaActions)
                }
            }
        }.getOrElse {
            "MediaSessionManager-Fehler=${it::class.java.simpleName}:${it.message}\n"
        }
    }

    private fun describeController(c: MediaController): String {
        val state = c.playbackState
        val metadata = c.metadata
        val playbackInfo = c.playbackInfo
        val audioAttributes = playbackInfo?.audioAttributes
        return buildString {
            append("sessionPackage=").append(c.packageName).append('\n')
            append("sessionTag=").append(runCatching { c.tag }.getOrNull()).append('\n')
            append("sessionFlags=").append(c.flags).append('\n')
            append("sessionFlagHandlesMediaButtons=")
                .append((c.flags and android.media.session.MediaSession.FLAG_HANDLES_MEDIA_BUTTONS.toLong()) != 0L).append('\n')
            append("sessionFlagHandlesTransportControls=")
                .append((c.flags and android.media.session.MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS.toLong()) != 0L).append('\n')
            append("sessionRatingType=").append(c.ratingType).append('\n')
            append("sessionActivity=").append(c.sessionActivity).append('\n')
            append("sessionPlaybackType=").append(playbackInfo?.playbackType).append('\n')
            append("sessionVolumeControl=").append(playbackInfo?.volumeControl).append('\n')
            append("sessionCurrentVolume=").append(playbackInfo?.currentVolume).append('\n')
            append("sessionMaxVolume=").append(playbackInfo?.maxVolume).append('\n')
            append("sessionAudioUsage=").append(audioAttributes?.usage).append('\n')
            append("sessionAudioContentType=").append(audioAttributes?.contentType).append('\n')
            append("sessionAudioFlags=0x").append(audioAttributes?.flags?.toString(16)).append('\n')
            append("playbackState=").append(state?.state).append('\n')
            append("playbackPosition=").append(state?.position).append('\n')
            append("playbackSpeed=").append(state?.playbackSpeed).append('\n')
            append("playbackActions=0x").append(state?.actions?.toString(16)).append('\n')
            if (state != null) {
                append(describePlaybackActions(state.actions))
            }
            append("activeQueueItemId=").append(state?.activeQueueItemId).append('\n')
            append("bufferedPosition=").append(state?.bufferedPosition).append('\n')
            append("errorMessage=").append(state?.errorMessage).append('\n')
            append("metadataTitle=").append(
                metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE)
            ).append('\n')
            append("metadataArtist=").append(
                metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST)
            ).append('\n')
            append("metadataAlbum=").append(
                metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ALBUM)
            ).append('\n')
            append("metadataDuration=").append(
                metadata?.getLong(android.media.MediaMetadata.METADATA_KEY_DURATION)
            ).append('\n')
            append("queueSize=").append(c.queue?.size).append('\n')
            append("queueTitle=").append(c.queueTitle).append('\n')
            append("extras=").append(c.extras).append('\n')
            append("diagnosticIsPaused=").append(state?.state == android.media.session.PlaybackState.STATE_PAUSED).append("\n")
            append("diagnosticReportsMotion=").append((state?.playbackSpeed ?: 0f) != 0f).append("\n")
        }
    }

    private fun StringBuilder.appendActionDiff(label: String, mask: Long) {
        val names = PLAYBACK_ACTIONS.filter { (_, bit) -> mask and bit != 0L }.map { it.first }
        append(label).append("Mask=0x").append(mask.toString(16)).append('\n')
        append(label).append("=").append(if (names.isEmpty()) "none" else names.joinToString(",")).append('\n')
    }

    private fun describePlaybackActions(actions: Long): String = buildString {
        append("playbackActionsDecoded=")
        val enabled = PLAYBACK_ACTIONS.filter { (_, bit) -> actions and bit != 0L }
        append(if (enabled.isEmpty()) "none" else enabled.joinToString(",") { it.first })
        append('\n')
        PLAYBACK_ACTIONS.forEach { (name, bit) ->
            append("action.").append(name).append('=')
                .append(actions and bit != 0L)
                .append(" (0x").append(bit.toString(16)).append(")\n")
        }
        val knownMask = PLAYBACK_ACTIONS.fold(0L) { mask, (_, bit) -> mask or bit }
        append("playbackActionsUnknownMask=0x")
            .append((actions and knownMask.inv()).toString(16)).append('\n')
    }

    companion object {
        private val PLAYBACK_ACTIONS = listOf(
            "STOP" to PlaybackState.ACTION_STOP,
            "PAUSE" to PlaybackState.ACTION_PAUSE,
            "PLAY" to PlaybackState.ACTION_PLAY,
            "REWIND" to PlaybackState.ACTION_REWIND,
            "SKIP_TO_PREVIOUS" to PlaybackState.ACTION_SKIP_TO_PREVIOUS,
            "SKIP_TO_NEXT" to PlaybackState.ACTION_SKIP_TO_NEXT,
            "FAST_FORWARD" to PlaybackState.ACTION_FAST_FORWARD,
            "SET_RATING" to PlaybackState.ACTION_SET_RATING,
            "SEEK_TO" to PlaybackState.ACTION_SEEK_TO,
            "PLAY_PAUSE" to PlaybackState.ACTION_PLAY_PAUSE,
            "PLAY_FROM_MEDIA_ID" to PlaybackState.ACTION_PLAY_FROM_MEDIA_ID,
            "PLAY_FROM_SEARCH" to PlaybackState.ACTION_PLAY_FROM_SEARCH,
            "SKIP_TO_QUEUE_ITEM" to PlaybackState.ACTION_SKIP_TO_QUEUE_ITEM,
            "PLAY_FROM_URI" to PlaybackState.ACTION_PLAY_FROM_URI,
            "PREPARE" to PlaybackState.ACTION_PREPARE,
            "PREPARE_FROM_MEDIA_ID" to PlaybackState.ACTION_PREPARE_FROM_MEDIA_ID,
            "PREPARE_FROM_SEARCH" to PlaybackState.ACTION_PREPARE_FROM_SEARCH,
            "PREPARE_FROM_URI" to PlaybackState.ACTION_PREPARE_FROM_URI,
            "SET_REPEAT_MODE" to 262144L,
            "SET_SHUFFLE_MODE_ENABLED" to 524288L,
            "SET_CAPTIONING_ENABLED" to 1048576L,
            "SET_SHUFFLE_MODE" to 2097152L,
            "SET_PLAYBACK_SPEED" to PlaybackState.ACTION_SET_PLAYBACK_SPEED
        )
    }

}
