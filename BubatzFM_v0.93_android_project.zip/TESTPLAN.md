# Bubatz FM v0.92 – Laufschrift-Test

1. v0.92 über die vorhandene Version installieren.
2. Omnia vollständig schließen bzw. dort keine Musik laufen lassen.
3. Nur in Bubatz FM einen Titel starten.
4. Bubatz im Vordergrund kurz spielen lassen und anschließend auf den Homescreen wechseln.
5. Oben links neben der Uhr prüfen, ob Samsungs kleine Titel-Laufschrift/der rote Medien-Chip nun den Bubatz-Titel zeigt.
6. Falls ja: einen Titel weiter springen und prüfen, ob sich der Text aktualisiert.
7. Falls nein: ein Screenshot der Statusleiste reicht.

Für diesen Test muss die Omnia-Bridge nicht geöffnet werden.
