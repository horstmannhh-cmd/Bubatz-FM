# v1.11 Crossfade-Glättung: Test

1. Crossfade auf den gewohnten Wert stellen und 8–10 automatische **Musik → Musik** Übergänge komplett laufen lassen.
2. Besonders am Ende der Überblendung auf den früher sporadischen Mikro-Stolperer achten. Erwartung: kein hörbarer Haker am internen Trackwechsel.
3. Während eines Crossfades einmal **Weiter** und einmal **Zurück** testen. Es darf weiterhin nur ein sauberer Titelwechsel stattfinden.
4. Falls ein Radioeinspieler fällig wird: Musik → Einspieler und Einspieler → Musik bleiben ohne Crossfade; danach muss Musik → Musik wieder crossfaden.
5. Stichprobe: Live-Benachrichtigung/Statusleisten-Laufschrift und Last.fm müssen nach dem automatischen Decktausch weiterhin den tatsächlich laufenden Titel zeigen.

# Bubatz.FM v1.09 Testplan

1. Vor dem Update einen gut erkennbaren Crossfade-Wert einstellen (z. B. 6,5 s), Radioeinspieler/Bluetooth/Last.fm-Schalter merken.
2. v1.09 über die bestehende App installieren und neu öffnen. Alle Einstellungen müssen unverändert sein.
3. Einen Musik→Musik-Crossfade abwarten. Während/nach dem Wechsel muss die normale Playeransicht denselben Titel/Interpreten zeigen wie die Samsung-Live-Benachrichtigung.
4. Noch 2–3 automatische Titelwechsel beobachten; die Live-Benachrichtigung darf keinen vorherigen Titel behalten.
5. App vollständig schließen und neu öffnen. Crossfade-Wert und übrige Einstellungen erneut prüfen.
6. Auf dem Homescreen/Launcher muss unter dem Icon exakt `Bubatz.FM` stehen.

## v1.10 Crossfade-Glättung
1. Crossfade auf den bevorzugten Wert stellen und mindestens 8–10 automatische Musik→Musik-Wechsel laufen lassen.
2. Besonders auf den Moment achten, an dem der alte Titel vollständig verschwunden ist und nur der neue Titel weiterläuft. Dort darf kein kurzer Haker/Flam/Pegelsprung hörbar sein.
3. Mindestens einen Einspieler abwarten oder per Testknopf auslösen: Musik→Einspieler und Einspieler→Musik bleiben harte Übergänge ohne Crossfade.
4. Danach muss Musik→Musik wieder normal crossfaden.

## v1.12 – Einspieler-Shuffle-Bag / Live-Benachrichtigung
1. Mehrere Einspieler importieren und automatische Einspieler oder "Einspieler jetzt testen" verwenden.
2. Prüfen, dass innerhalb eines vollständigen Durchlaufs kein Einspieler zweimal kommt, bevor alle anderen einmal gelaufen sind.
3. App/Service zwischen zwei Einspielern vollständig beenden und neu öffnen: der laufende Bag muss fortgesetzt werden, nicht neu beginnen.
4. Nach vollständigem Durchlauf beginnt eine neu gemischte Reihenfolge; der letzte Einspieler des alten Durchlaufs darf nicht direkt wiederholt werden (bei >1 Einspieler).
5. Während eines laufenden Durchlaufs einen Einspieler löschen und einen neuen hinzufügen, Bibliothek abgleichen: gelöschter Clip darf nicht mehr kommen, neuer Clip muss in den noch offenen Teil des Durchlaufs aufgenommen werden.
6. Normale Musik abspielen: Live-Benachrichtigung zeigt Titel einmal und Interpret einmal darunter; keine Form "Titel – Interpret" plus erneutem Interpret.
7. Crossfade Musik→Musik, Radio-Hardcuts und Last.fm stichprobenartig unverändert prüfen.
