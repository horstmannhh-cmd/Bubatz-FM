package fm.bubatz.player.settings

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "bubatz_settings")

class AppSettings(private val context: Context) {
    companion object {
        val AUTO_BLUETOOTH = booleanPreferencesKey("auto_bluetooth")
        val AUTO_BLUETOOTH_ALL_DEVICES = booleanPreferencesKey("auto_bluetooth_all_devices")
        val AUTO_BLUETOOTH_DEVICE_ADDRESSES = stringSetPreferencesKey("auto_bluetooth_device_addresses")
        val AUTO_BLUETOOTH_SKIP_ONCE = booleanPreferencesKey("auto_bluetooth_skip_once")
        val AUTO_BLUETOOTH_LAST_DEVICE = stringPreferencesKey("auto_bluetooth_last_device")
        val AUTO_BLUETOOTH_LAST_TRIGGER_MS = longPreferencesKey("auto_bluetooth_last_trigger_ms")

        val RADIO_ENABLED = booleanPreferencesKey("radio_enabled")
        val CROSSFADE_MS = intPreferencesKey("crossfade_ms")
        val LASTFM_ENABLED = booleanPreferencesKey("lastfm_enabled")

        private const val BACKUP_PREFS = "bubatz_settings_backup_v109"
        private const val B_AUTO_BT = "auto_bluetooth"
        private const val B_AUTO_BT_ALL = "auto_bluetooth_all_devices"
        private const val B_AUTO_BT_ADDR = "auto_bluetooth_device_addresses"
        private const val B_RADIO = "radio_enabled"
        private const val B_CROSSFADE = "crossfade_ms"
        private const val B_LASTFM = "lastfm_enabled"
    }

    private val backup = context.getSharedPreferences(BACKUP_PREFS, Context.MODE_PRIVATE)

    val autoBluetooth: Flow<Boolean> =
        context.dataStore.data.map { it[AUTO_BLUETOOTH] ?: true }

    val autoBluetoothAllDevices: Flow<Boolean> =
        context.dataStore.data.map { it[AUTO_BLUETOOTH_ALL_DEVICES] ?: true }

    val autoBluetoothDeviceAddresses: Flow<Set<String>> =
        context.dataStore.data.map { it[AUTO_BLUETOOTH_DEVICE_ADDRESSES] ?: emptySet() }

    val autoBluetoothSkipOnce: Flow<Boolean> =
        context.dataStore.data.map { it[AUTO_BLUETOOTH_SKIP_ONCE] ?: false }

    val radioEnabled: Flow<Boolean> =
        context.dataStore.data.map { it[RADIO_ENABLED] ?: true }

    val crossfadeMs: Flow<Int> =
        context.dataStore.data.map { it[CROSSFADE_MS] ?: 5000 }

    val lastFmEnabled: Flow<Boolean> =
        context.dataStore.data.map { it[LASTFM_ENABLED] ?: false }

    /**
     * v1.09: User-visible settings are durable state, not version defaults.
     * DataStore already survives normal APK updates. This second tiny mirror gives
     * us a recovery source if a future migration accidentally drops a key. Missing
     * keys are restored, existing DataStore values always win.
     */
    suspend fun ensureDurablePersistence() {
        val current = context.dataStore.data.first()

        val autoBt = current[AUTO_BLUETOOTH]
            ?: if (backup.contains(B_AUTO_BT)) backup.getBoolean(B_AUTO_BT, true) else true
        val autoBtAll = current[AUTO_BLUETOOTH_ALL_DEVICES]
            ?: if (backup.contains(B_AUTO_BT_ALL)) backup.getBoolean(B_AUTO_BT_ALL, true) else true
        val addresses = current[AUTO_BLUETOOTH_DEVICE_ADDRESSES]
            ?: backup.getStringSet(B_AUTO_BT_ADDR, emptySet())?.toSet().orEmpty()
        val radio = current[RADIO_ENABLED]
            ?: if (backup.contains(B_RADIO)) backup.getBoolean(B_RADIO, true) else true
        val crossfade = (current[CROSSFADE_MS]
            ?: if (backup.contains(B_CROSSFADE)) backup.getInt(B_CROSSFADE, 5000) else 5000)
            .coerceIn(0, 15000)
        val lastFm = current[LASTFM_ENABLED]
            ?: if (backup.contains(B_LASTFM)) backup.getBoolean(B_LASTFM, false) else false

        context.dataStore.edit { prefs ->
            if (prefs[AUTO_BLUETOOTH] == null) prefs[AUTO_BLUETOOTH] = autoBt
            if (prefs[AUTO_BLUETOOTH_ALL_DEVICES] == null) prefs[AUTO_BLUETOOTH_ALL_DEVICES] = autoBtAll
            if (prefs[AUTO_BLUETOOTH_DEVICE_ADDRESSES] == null) prefs[AUTO_BLUETOOTH_DEVICE_ADDRESSES] = addresses
            if (prefs[RADIO_ENABLED] == null) prefs[RADIO_ENABLED] = radio
            if (prefs[CROSSFADE_MS] == null) prefs[CROSSFADE_MS] = crossfade
            if (prefs[LASTFM_ENABLED] == null) prefs[LASTFM_ENABLED] = lastFm
        }

        backup.edit()
            .putBoolean(B_AUTO_BT, autoBt)
            .putBoolean(B_AUTO_BT_ALL, autoBtAll)
            .putStringSet(B_AUTO_BT_ADDR, addresses)
            .putBoolean(B_RADIO, radio)
            .putInt(B_CROSSFADE, crossfade)
            .putBoolean(B_LASTFM, lastFm)
            .commit()
    }

    suspend fun setAutoBluetooth(value: Boolean) {
        context.dataStore.edit { it[AUTO_BLUETOOTH] = value }
        backup.edit().putBoolean(B_AUTO_BT, value).commit()
    }

    suspend fun setAutoBluetoothAllDevices(value: Boolean) {
        context.dataStore.edit { it[AUTO_BLUETOOTH_ALL_DEVICES] = value }
        backup.edit().putBoolean(B_AUTO_BT_ALL, value).commit()
    }

    suspend fun setAutoBluetoothDeviceEnabled(address: String, enabled: Boolean) {
        var result: Set<String> = emptySet()
        context.dataStore.edit { prefs ->
            val current = prefs[AUTO_BLUETOOTH_DEVICE_ADDRESSES]?.toMutableSet() ?: mutableSetOf()
            if (enabled) current += address else current -= address
            result = current.toSet()
            prefs[AUTO_BLUETOOTH_DEVICE_ADDRESSES] = result
        }
        backup.edit().putStringSet(B_AUTO_BT_ADDR, result).commit()
    }

    suspend fun suppressNextBluetoothAutoStart() =
        context.dataStore.edit { it[AUTO_BLUETOOTH_SKIP_ONCE] = true }

    suspend fun clearBluetoothSuppression() =
        context.dataStore.edit { it[AUTO_BLUETOOTH_SKIP_ONCE] = false }

    /**
     * v0.99: A2DP disconnect ends the current auto-start cycle. Clearing the
     * remembered trigger prevents the reconnect from being swallowed by the
     * short duplicate-event debounce window.
     */
    suspend fun rearmBluetoothAutoStart(address: String?) {
        context.dataStore.edit { prefs ->
            val remembered = prefs[AUTO_BLUETOOTH_LAST_DEVICE]
            if (address == null || remembered == null || remembered == address) {
                prefs.remove(AUTO_BLUETOOTH_LAST_DEVICE)
                prefs.remove(AUTO_BLUETOOTH_LAST_TRIGGER_MS)
            } else {
                prefs.remove(AUTO_BLUETOOTH_LAST_TRIGGER_MS)
            }
        }
    }

    suspend fun setRadioEnabled(value: Boolean) {
        context.dataStore.edit { it[RADIO_ENABLED] = value }
        backup.edit().putBoolean(B_RADIO, value).commit()
    }

    suspend fun setCrossfadeMs(value: Int) {
        val normalized = value.coerceIn(0, 15000)
        context.dataStore.edit { it[CROSSFADE_MS] = normalized }
        backup.edit().putInt(B_CROSSFADE, normalized).commit()
    }

    suspend fun setLastFmEnabled(value: Boolean) {
        context.dataStore.edit { it[LASTFM_ENABLED] = value }
        backup.edit().putBoolean(B_LASTFM, value).commit()
    }

    /**
     * One atomic-ish policy evaluation for a Bluetooth connect event.
     * Empty whitelist only means "none" when all-devices mode is OFF.
     */
    suspend fun shouldAutoStartFor(address: String?, nowMs: Long = System.currentTimeMillis()): Boolean {
        val prefs = context.dataStore.data.first()
        if (!(prefs[AUTO_BLUETOOTH] ?: true)) return false

        if (prefs[AUTO_BLUETOOTH_SKIP_ONCE] == true) {
            context.dataStore.edit { it[AUTO_BLUETOOTH_SKIP_ONCE] = false }
            return false
        }

        val allDevices = prefs[AUTO_BLUETOOTH_ALL_DEVICES] ?: true
        if (!allDevices) {
            val allowed = prefs[AUTO_BLUETOOTH_DEVICE_ADDRESSES] ?: emptySet()
            if (address == null || address !in allowed) return false
        }

        val lastDevice = prefs[AUTO_BLUETOOTH_LAST_DEVICE]
        val lastAt = prefs[AUTO_BLUETOOTH_LAST_TRIGGER_MS] ?: 0L
        if (address != null && address == lastDevice && nowMs - lastAt < 10_000L) {
            return false
        }

        context.dataStore.edit {
            if (address != null) it[AUTO_BLUETOOTH_LAST_DEVICE] = address
            it[AUTO_BLUETOOTH_LAST_TRIGGER_MS] = nowMs
        }
        return true
    }
}
