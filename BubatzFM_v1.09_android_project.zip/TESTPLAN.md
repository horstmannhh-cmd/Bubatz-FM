# Bubatz.FM v1.09 Testplan

1. Vor dem Update einen gut erkennbaren Crossfade-Wert einstellen (z. B. 6,5 s), Radioeinspieler/Bluetooth/Last.fm-Schalter merken.
2. v1.09 über die bestehende App installieren und neu öffnen. Alle Einstellungen müssen unverändert sein.
3. Einen Musik→Musik-Crossfade abwarten. Während/nach dem Wechsel muss die normale Playeransicht denselben Titel/Interpreten zeigen wie die Samsung-Live-Benachrichtigung.
4. Noch 2–3 automatische Titelwechsel beobachten; die Live-Benachrichtigung darf keinen vorherigen Titel behalten.
5. App vollständig schließen und neu öffnen. Crossfade-Wert und übrige Einstellungen erneut prüfen.
6. Auf dem Homescreen/Launcher muss unter dem Icon exakt `Bubatz.FM` stehen.
