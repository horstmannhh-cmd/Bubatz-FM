
# Bubatz FM v0.10 – Testplan

## Bluetooth / Lockscreen
1. Play/Pause steuert den aktiven Deck.
2. NEXT startet den reservierten Shuffle-Folgetitel.
3. PREVIOUS nach >5 s startet den aktuellen Titel neu.
4. PREVIOUS am Titelanfang holt den vorherigen Musiktitel aus der History.
5. Nach Crossfade A→B bleiben diese Befehle funktionsfähig.

## Radio
1. EIN: Einspieler ungefähr alle 25–35 Minuten.
2. AUS: keine Einspieler.
3. Jede Transition mit Radio: harter Übergang.
4. Radio: kein Last.fm.

## Crossfade
- lange Titel: konfigurierte Dauer
- kurze Titel: Fade maximal Titeldauer
- manuelles NEXT: alter Übergangsjob wird abgebrochen

## Statische Prüfung
`python tools/sanity_check.py` → `SANITY CHECK OK`.


## v0.78 Samsung-Audio-Pipeline-Diagnose
1. Omnia und Bubatz FM parallel mit Musik laufen lassen.
2. Einstellungen > Wiedergabe-Diagnose öffnen.
3. „Audio-System prüfen“ antippen.
4. Den vollständigen v0.78-Block fotografieren/screenshotten.
5. Danach unter „Omnia-Vergleichsdiagnose“ „Vergleich laden“ antippen und dort die Session-Audio-Werte beider Player sichern.

Der Test verändert die eigentliche Wiedergabe nicht.
