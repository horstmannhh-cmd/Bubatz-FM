
# Bubatz FM v0.11 – Buildstatus

Der direkte SDK-Download in der Chat-Laufzeit wurde versucht, scheiterte aber an der
Netzwerkisolation des Containers (`Could not resolve host: dl.google.com`).

Deshalb enthält v0.11 einen automatisierten lokalen Buildweg.

Technische Basis:
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- compileSdk / targetSdk: 35
- Android Build Tools: 34.0.0
- minSdk: 28
- JDK: 17 oder höher

Das Windows-Skript:
1. findet bevorzugt das JDK aus Android Studio,
2. lädt die offiziellen Android Command Line Tools,
3. zeigt den SDK-Lizenzdialog,
4. installiert Plattform/Build Tools,
5. lädt Gradle 8.9,
6. führt Tests aus,
7. baut `assembleDebug`,
8. kopiert die APK in einen leicht auffindbaren Ordner.
