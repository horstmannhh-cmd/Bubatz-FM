
package fm.bubatz.player.scrobble

import fm.bubatz.player.data.BubatzDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

sealed interface FlushResult {
    data class Sent(val count: Int) : FlushResult
    data object NothingToDo : FlushResult
    data object NotAuthenticated : FlushResult
    data object ReauthenticationRequired : FlushResult
    data class RetryLater(val message: String?) : FlushResult
    data class PermanentFailure(val message: String?) : FlushResult
}

class LastFmScrobbleSender(
    private val db: BubatzDatabase,
    private val store: LastFmSessionStore,
    private val api: LastFmApi = LastFmApi()
) {
    suspend fun flush(): FlushResult = withContext(Dispatchers.IO) {
        val key = store.sessionKey ?: return@withContext FlushResult.NotAuthenticated
        val pending = db.scrobbles().pending(50)
        if (pending.isEmpty()) return@withContext FlushResult.NothingToDo

        val payloads = pending.mapNotNull { q ->
            val t = db.tracks().byId(q.trackId) ?: return@mapNotNull null
            val artist = t.artist?.trim().orEmpty()
            val title = t.title?.trim().orEmpty()
            if (artist.isBlank() || title.isBlank()) return@mapNotNull null
            ScrobblePayload(
                queueId = q.id,
                artist = artist,
                track = title,
                album = t.album,
                timestampSeconds = q.startedAtSeconds
            )
        }
        if (payloads.isEmpty()) return@withContext FlushResult.PermanentFailure("Missing track metadata")

        payloads.forEach { db.scrobbles().markAttempt(it.queueId) }

        val result = runCatching { api.scrobbleBatch(key, payloads) }
            .getOrElse { return@withContext FlushResult.RetryLater(it.message) }

        if (result.ok) {
            payloads.forEach { db.scrobbles().markSubmitted(it.queueId) }
            return@withContext FlushResult.Sent(payloads.size)
        }

        return@withContext when (result.errorCode) {
            9 -> {
                store.clear()
                FlushResult.ReauthenticationRequired
            }
            11, 16, 29 -> FlushResult.RetryLater(result.message)
            else -> FlushResult.PermanentFailure(result.message)
        }
    }
}
