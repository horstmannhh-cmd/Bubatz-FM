
package fm.bubatz.player.playback.dual

import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import fm.bubatz.player.playback.crossfade.CrossfadeDecision
import fm.bubatz.player.playback.crossfade.FadeEnvelope
import fm.bubatz.player.playback.crossfade.TransitionDecision
import kotlinx.coroutines.*
import kotlin.math.max

/**
 * Two-deck playback core for Bubatz FM.
 *
 * Deck A and Deck B alternate roles. Only MUSIC -> MUSIC is allowed to overlap.
 * Any transition involving a radio insert is a hard handoff.
 */
class DualDeckPlayer(
    context: Context,
    private val scope: CoroutineScope,
    private val crossfadeMsProvider: suspend () -> Int,
    private val onActiveDeckChanged: (Player) -> Unit,
    private val onMediaStarted: suspend (MediaItem) -> Unit
) {
    private val deckA = ExoPlayer.Builder(context).build()
    private val deckB = ExoPlayer.Builder(context).build()

    private var active = deckA
    private var standby = deckB
    private var transitionJob: Job? = null
    private var scheduledForMediaId: String? = null

    val activePlayer: Player get() = active

    init {
        deckA.volume = 1f
        deckB.volume = 1f

        val listener = object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                mediaItem ?: return
                if (active.currentMediaItem == mediaItem) {
                    scope.launch { onMediaStarted(mediaItem) }
                }
            }
        }
        deckA.addListener(listener)
        deckB.addListener(listener)
    }

    fun setInitial(item: MediaItem, startPositionMs: Long = 0L, playWhenReady: Boolean = false) {
        transitionJob?.cancel()
        transitionJob = null
        active.playWhenReady = false
        standby.playWhenReady = false
        active.stop()
        standby.stop()
        active.clearMediaItems()
        standby.clearMediaItems()
        active.volume = 1f
        standby.volume = 1f
        active.setMediaItem(item, startPositionMs)
        active.prepare()
        active.playWhenReady = playWhenReady
        scheduledForMediaId = null
        onActiveDeckChanged(active)
    }

    fun play() = active.play()
    fun pause() = active.pause()
    fun seekTo(positionMs: Long) = active.seekTo(positionMs)

    /**
     * Schedules the next item. For crossfade transitions, standby starts
     * before active reaches the end. For radio-related transitions, standby
     * remains silent until active ends completely.
     */
    suspend fun scheduleNext(next: MediaItem) {
        transitionJob?.cancel()
        scheduledForMediaId = next.mediaId

        val current = active.currentMediaItem
        val configuredMs = crossfadeMsProvider()
        when (val decision = CrossfadeDecision.decide(
            current?.mediaId,
            next.mediaId,
            configuredMs
        )) {
            is TransitionDecision.Crossfade -> scheduleCrossfade(next, decision.durationMs)
            TransitionDecision.HardTransition -> scheduleHardTransition(next)
        }
    }

    private fun scheduleCrossfade(next: MediaItem, durationMs: Int) {
        standby.stop()
        standby.clearMediaItems()
        standby.volume = 0f
        standby.setMediaItem(next)
        standby.prepare()

        transitionJob = scope.launch(Dispatchers.Main.immediate) {
            while (isActive) {
                delay(100)
                val duration = active.duration
                val pos = active.currentPosition
                if (duration <= 0L) continue

                val remaining = duration - pos
                val effectiveFadeMs = minOf(durationMs.toLong(), duration).coerceAtLeast(1L).toInt()
                if (remaining <= effectiveFadeMs) {
                    standby.play()
                    runFade(effectiveFadeMs)
                    completeSwap()
                    break
                }
            }
        }
    }

    private fun scheduleHardTransition(next: MediaItem) {
        standby.stop()
        standby.clearMediaItems()
        standby.volume = 1f
        standby.setMediaItem(next)
        standby.prepare()

        transitionJob = scope.launch(Dispatchers.Main.immediate) {
            while (isActive) {
                delay(100)
                if (active.playbackState == Player.STATE_ENDED) {
                    standby.play()
                    completeSwap()
                    break
                }
            }
        }
    }

    private suspend fun runFade(durationMs: Int) {
        val start = android.os.SystemClock.elapsedRealtime()
        while (true) {
            val elapsed = android.os.SystemClock.elapsedRealtime() - start
            val progress = (elapsed.toFloat() / max(1, durationMs).toFloat()).coerceIn(0f, 1f)
            val gains = FadeEnvelope.gains(progress)
            active.volume = gains.outgoing
            standby.volume = gains.incoming
            if (progress >= 1f) break
            delay(30)
        }
    }

    private fun completeSwap() {
        val old = active
        active = standby
        standby = old

        standby.stop()
        standby.clearMediaItems()
        standby.volume = 1f
        active.volume = 1f
        scheduledForMediaId = null
        onActiveDeckChanged(active)

        active.currentMediaItem?.let { item ->
            scope.launch { onMediaStarted(item) }
        }
    }

    fun release() {
        transitionJob?.cancel()
        deckA.release()
        deckB.release()
    }
}
