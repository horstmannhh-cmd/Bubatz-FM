package fm.bubatz.player.scrobble

import fm.bubatz.player.data.TrackEntity

/**
 * Integrationsgrenze für Last.fm.
 * In v0.1 wird bewusst noch kein API-Schlüssel im Quellcode eingebettet.
 * Die Playback-Engine kann ab hier Now Playing, Offline Queue und Scrobble auslösen.
 */
interface LastFmScrobbler {
    suspend fun nowPlaying(track: TrackEntity)
    suspend fun scrobble(track: TrackEntity, startedAtSeconds: Long)
    suspend fun flushPending()
}

class NoOpLastFmScrobbler : LastFmScrobbler {
    override suspend fun nowPlaying(track: TrackEntity) = Unit
    override suspend fun scrobble(track: TrackEntity, startedAtSeconds: Long) = Unit
    override suspend fun flushPending() = Unit
}
