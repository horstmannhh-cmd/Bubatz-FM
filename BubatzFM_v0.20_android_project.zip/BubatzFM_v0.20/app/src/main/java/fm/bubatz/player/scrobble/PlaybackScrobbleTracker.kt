
package fm.bubatz.player.scrobble

import fm.bubatz.player.data.BubatzDatabase
import fm.bubatz.player.data.ScrobbleQueueEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Tracks one currently-playing item. It writes to the offline queue exactly
 * once when the listening threshold is reached.
 */
class PlaybackScrobbleTracker(private val db: BubatzDatabase) {
    private var mediaId: String? = null
    private var trackId: Long? = null
    private var durationMs: Long = 0L
    private var startedAtSeconds: Long = 0L
    private var queued = false

    fun onItemStarted(mediaId: String?, durationMs: Long, nowSeconds: Long) {
        this.mediaId = mediaId
        this.durationMs = durationMs
        this.startedAtSeconds = nowSeconds
        this.trackId = mediaId
            ?.takeIf { it.startsWith("track:") }
            ?.removePrefix("track:")
            ?.toLongOrNull()
        this.queued = false
    }

    suspend fun onProgress(listenedMs: Long) {
        val id = trackId ?: return
        if (queued) return
        if (!ScrobbleRules.isEligible(mediaId, durationMs, listenedMs)) return

        withContext(Dispatchers.IO) {
            db.scrobbles().enqueue(
                ScrobbleQueueEntity(
                    trackId = id,
                    startedAtSeconds = startedAtSeconds
                )
            )
        }
        queued = true
    }

    fun reset() {
        mediaId = null
        trackId = null
        durationMs = 0L
        startedAtSeconds = 0L
        queued = false
    }
}
