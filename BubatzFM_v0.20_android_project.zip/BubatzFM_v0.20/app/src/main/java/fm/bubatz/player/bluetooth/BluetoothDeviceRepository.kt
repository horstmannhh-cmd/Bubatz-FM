
package fm.bubatz.player.bluetooth

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

data class PairedAudioDevice(
    val name: String,
    val address: String
)

class BluetoothDeviceRepository(private val context: Context) {
    fun pairedAudioDevices(): List<PairedAudioDevice> {
        if (android.os.Build.VERSION.SDK_INT >= 31 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED
        ) return emptyList()

        val manager = context.getSystemService(BluetoothManager::class.java)
        val adapter: BluetoothAdapter = manager?.adapter ?: return emptyList()

        return runCatching {
            adapter.bondedDevices
                .filter { device ->
                    val major = device.bluetoothClass?.majorDeviceClass
                    major == BluetoothClass.Device.Major.AUDIO_VIDEO || major == null
                }
                .map { device ->
                    PairedAudioDevice(
                        name = device.name ?: "Bluetooth-Gerät",
                        address = device.address
                    )
                }
                .sortedBy { it.name.lowercase() }
        }.getOrDefault(emptyList())
    }
}
