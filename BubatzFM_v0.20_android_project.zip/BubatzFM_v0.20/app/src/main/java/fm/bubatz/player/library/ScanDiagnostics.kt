package fm.bubatz.player.library

import android.content.Context

class ScanDiagnostics(context: Context) {
    private val prefs = context.getSharedPreferences("scan_diagnostics", Context.MODE_PRIVATE)

    fun save(text: String) {
        prefs.edit()
            .putString("last_scan", text)
            .putLong("last_scan_time", System.currentTimeMillis())
            .apply()
    }

    fun read(): String = prefs.getString("last_scan", "Noch kein Diagnose-Scan") ?: "Noch kein Diagnose-Scan"
}
