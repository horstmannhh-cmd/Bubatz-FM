
package fm.bubatz.player.scrobble

import android.content.Context
import android.content.Intent
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LastFmAuthCoordinator(
    private val context: Context,
    private val store: LastFmSessionStore = LastFmSessionStore(context),
    private val api: LastFmApi = LastFmApi()
) {

    suspend fun beginAuthorization(): String = withContext(Dispatchers.IO) {
        check(LastFmConfig.configured) { "Last.fm API key/secret fehlen." }
        val token = api.getToken()
        store.pendingToken = token
        api.authorizationUrl(token)
    }

    fun openAuthorization(url: String) {
        context.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse(url))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    suspend fun finishAuthorization(): LastFmSession = withContext(Dispatchers.IO) {
        val token = store.pendingToken ?: error("Keine laufende Last.fm-Anmeldung.")
        val session = api.getSession(token)
        store.username = session.username
        store.sessionKey = session.key
        store.pendingToken = null
        session
    }

    fun disconnect() = store.clear()
}
