package fm.bubatz.player.radio

import kotlin.random.Random

/**
 * Produces a random amount of ACTUAL PLAYED MUSIC time before the next
 * radio insert. Pauses, app downtime and radio inserts themselves do not count.
 */
class RadioScheduler(
    private val minMinutes: Int = 25,
    private val maxMinutes: Int = 35
) {
    fun nextMusicIntervalMs(): Long {
        val minutes = Random.nextInt(minMinutes, maxMinutes + 1)
        return minutes * 60_000L
    }
}
