package fm.bubatz.player

import android.app.Application
import fm.bubatz.player.data.BubatzDatabase

class BubatzApplication : Application() {
    val database: BubatzDatabase by lazy { BubatzDatabase.create(this) }
}
