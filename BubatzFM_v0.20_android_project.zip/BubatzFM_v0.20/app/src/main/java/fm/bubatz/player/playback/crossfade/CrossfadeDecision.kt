
package fm.bubatz.player.playback.crossfade

sealed interface TransitionDecision {
    data class Crossfade(val durationMs: Int) : TransitionDecision
    data object HardTransition : TransitionDecision
}

object CrossfadeDecision {
    fun decide(fromId: String?, toId: String?, configuredMs: Int): TransitionDecision =
        if (CrossfadePolicy.shouldCrossfade(fromId, toId, configuredMs)) {
            TransitionDecision.Crossfade(CrossfadePolicy.durationMs(configuredMs))
        } else {
            TransitionDecision.HardTransition
        }
}
