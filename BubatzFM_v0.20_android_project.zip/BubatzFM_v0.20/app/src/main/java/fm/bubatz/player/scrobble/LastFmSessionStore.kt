
package fm.bubatz.player.scrobble

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class LastFmSessionStore(context: Context) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "lastfm_secure",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    var sessionKey: String?
        get() = prefs.getString("session_key", null)
        set(value) = prefs.edit().apply {
            if (value == null) remove("session_key") else putString("session_key", value)
        }.apply()

    var pendingToken: String?
        get() = prefs.getString("pending_token", null)
        set(value) = prefs.edit().apply {
            if (value == null) remove("pending_token") else putString("pending_token", value)
        }.apply()

    var username: String?
        get() = prefs.getString("username", null)
        set(value) = prefs.edit().apply {
            if (value == null) remove("username") else putString("username", value)
        }.apply()

    fun clear() {
        prefs.edit().clear().apply()
    }
}
