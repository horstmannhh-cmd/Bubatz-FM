
package fm.bubatz.player.playback

import androidx.room.withTransaction
import fm.bubatz.player.data.*
import kotlin.random.Random

class ShuffleManager(private val db: BubatzDatabase) {
    suspend fun nextTrack(): TrackEntity? = db.withTransaction {
        var state = db.state().get() ?: PlaybackStateEntity()
        var id = db.shuffle().trackAt(state.shuffleCycle, state.shufflePosition)
        if (id == null) {
            val ids = db.tracks().allEnabledIds()
            if (ids.isEmpty()) return@withTransaction null
            val cycle = state.shuffleCycle + 1
            val shuffled = ids.shuffled(Random.Default)
            db.shuffle().clearTracks()
            db.shuffle().insertTracks(shuffled.mapIndexed { pos, trackId ->
                ShuffleQueueEntity(pos, trackId, cycle)
            })
            state = state.copy(shuffleCycle = cycle, shufflePosition = 0)
            db.state().put(state)
            id = shuffled.first()
        }
        val track = db.tracks().byId(id!!)
        db.state().put(state.copy(shufflePosition = state.shufflePosition + 1))
        track
    }

    suspend fun nextRadioClip(): RadioClipEntity? = db.withTransaction {
        var state = db.state().get() ?: PlaybackStateEntity()
        var id = db.shuffle().clipAt(state.radioCycle, state.radioPosition)
        if (id == null) {
            val ids = db.clips().allEnabledIds()
            if (ids.isEmpty()) return@withTransaction null
            val cycle = state.radioCycle + 1
            val shuffled = ids.shuffled(Random.Default)
            db.shuffle().clearClips()
            db.shuffle().insertClips(shuffled.mapIndexed { pos, clipId ->
                RadioShuffleQueueEntity(pos, clipId, cycle)
            })
            state = state.copy(radioCycle = cycle, radioPosition = 0)
            db.state().put(state)
            id = shuffled.first()
        }
        val clip = db.clips().byId(id!!)
        db.state().put(state.copy(radioPosition = state.radioPosition + 1))
        clip
    }
}
