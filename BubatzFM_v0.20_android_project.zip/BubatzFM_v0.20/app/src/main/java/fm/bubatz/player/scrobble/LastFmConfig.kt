
package fm.bubatz.player.scrobble

/**
 * Personal Last.fm API credentials belong here at build time.
 * Do NOT commit real credentials into a public repository.
 *
 * A Last.fm API account supplies API_KEY and SHARED_SECRET.
 */
object LastFmConfig {
    const val API_KEY = ""
    const val SHARED_SECRET = ""
    const val API_ROOT = "https://ws.audioscrobbler.com/2.0/"
    const val AUTH_ROOT = "https://www.last.fm/api/auth/"
    val configured: Boolean
        get() = API_KEY.isNotBlank() && SHARED_SECRET.isNotBlank()
}
