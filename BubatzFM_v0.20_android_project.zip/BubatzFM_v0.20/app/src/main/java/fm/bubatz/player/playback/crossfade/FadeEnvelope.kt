
package fm.bubatz.player.playback.crossfade

import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.PI

/**
 * Equal-power crossfade curve. This avoids the obvious volume dip of a
 * simple linear fade around the middle of the transition.
 */
object FadeEnvelope {
    data class Gains(val outgoing: Float, val incoming: Float)

    fun gains(progress: Float): Gains {
        val p = progress.coerceIn(0f, 1f)
        val angle = p * (PI.toFloat() / 2f)
        return Gains(
            outgoing = cos(angle),
            incoming = sin(angle)
        )
    }
}
