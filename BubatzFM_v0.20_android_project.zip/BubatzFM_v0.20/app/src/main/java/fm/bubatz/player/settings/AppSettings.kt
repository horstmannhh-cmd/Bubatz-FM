
package fm.bubatz.player.settings

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "bubatz_settings")

class AppSettings(private val context: Context) {
    companion object {
        val AUTO_BLUETOOTH = booleanPreferencesKey("auto_bluetooth")
        val AUTO_BLUETOOTH_ALL_DEVICES = booleanPreferencesKey("auto_bluetooth_all_devices")
        val AUTO_BLUETOOTH_DEVICE_ADDRESSES = stringSetPreferencesKey("auto_bluetooth_device_addresses")
        val AUTO_BLUETOOTH_SKIP_ONCE = booleanPreferencesKey("auto_bluetooth_skip_once")
        val AUTO_BLUETOOTH_LAST_DEVICE = stringPreferencesKey("auto_bluetooth_last_device")
        val AUTO_BLUETOOTH_LAST_TRIGGER_MS = longPreferencesKey("auto_bluetooth_last_trigger_ms")

        val RADIO_ENABLED = booleanPreferencesKey("radio_enabled")
        val CROSSFADE_MS = intPreferencesKey("crossfade_ms")
    }

    val autoBluetooth: Flow<Boolean> =
        context.dataStore.data.map { it[AUTO_BLUETOOTH] ?: true }

    val autoBluetoothAllDevices: Flow<Boolean> =
        context.dataStore.data.map { it[AUTO_BLUETOOTH_ALL_DEVICES] ?: true }

    val autoBluetoothDeviceAddresses: Flow<Set<String>> =
        context.dataStore.data.map { it[AUTO_BLUETOOTH_DEVICE_ADDRESSES] ?: emptySet() }

    val autoBluetoothSkipOnce: Flow<Boolean> =
        context.dataStore.data.map { it[AUTO_BLUETOOTH_SKIP_ONCE] ?: false }

    val radioEnabled: Flow<Boolean> =
        context.dataStore.data.map { it[RADIO_ENABLED] ?: true }

    val crossfadeMs: Flow<Int> =
        context.dataStore.data.map { it[CROSSFADE_MS] ?: 5000 }

    suspend fun setAutoBluetooth(value: Boolean) =
        context.dataStore.edit { it[AUTO_BLUETOOTH] = value }

    suspend fun setAutoBluetoothAllDevices(value: Boolean) =
        context.dataStore.edit { it[AUTO_BLUETOOTH_ALL_DEVICES] = value }

    suspend fun setAutoBluetoothDeviceEnabled(address: String, enabled: Boolean) {
        context.dataStore.edit { prefs ->
            val current = prefs[AUTO_BLUETOOTH_DEVICE_ADDRESSES]?.toMutableSet() ?: mutableSetOf()
            if (enabled) current += address else current -= address
            prefs[AUTO_BLUETOOTH_DEVICE_ADDRESSES] = current
        }
    }

    suspend fun suppressNextBluetoothAutoStart() =
        context.dataStore.edit { it[AUTO_BLUETOOTH_SKIP_ONCE] = true }

    suspend fun clearBluetoothSuppression() =
        context.dataStore.edit { it[AUTO_BLUETOOTH_SKIP_ONCE] = false }

    suspend fun setRadioEnabled(value: Boolean) =
        context.dataStore.edit { it[RADIO_ENABLED] = value }

    suspend fun setCrossfadeMs(value: Int) =
        context.dataStore.edit { it[CROSSFADE_MS] = value.coerceIn(0, 15000) }

    /**
     * One atomic-ish policy evaluation for a Bluetooth connect event.
     * Empty whitelist only means "none" when all-devices mode is OFF.
     */
    suspend fun shouldAutoStartFor(address: String?, nowMs: Long = System.currentTimeMillis()): Boolean {
        val prefs = context.dataStore.data.first()
        if (!(prefs[AUTO_BLUETOOTH] ?: true)) return false

        if (prefs[AUTO_BLUETOOTH_SKIP_ONCE] == true) {
            context.dataStore.edit { it[AUTO_BLUETOOTH_SKIP_ONCE] = false }
            return false
        }

        val allDevices = prefs[AUTO_BLUETOOTH_ALL_DEVICES] ?: true
        if (!allDevices) {
            val allowed = prefs[AUTO_BLUETOOTH_DEVICE_ADDRESSES] ?: emptySet()
            if (address == null || address !in allowed) return false
        }

        // ACL_CONNECTED and A2DP_CONNECTED can arrive for the same connection.
        val lastDevice = prefs[AUTO_BLUETOOTH_LAST_DEVICE]
        val lastAt = prefs[AUTO_BLUETOOTH_LAST_TRIGGER_MS] ?: 0L
        if (address != null && address == lastDevice && nowMs - lastAt < 10_000L) {
            return false
        }

        context.dataStore.edit {
            if (address != null) it[AUTO_BLUETOOTH_LAST_DEVICE] = address
            it[AUTO_BLUETOOTH_LAST_TRIGGER_MS] = nowMs
        }
        return true
    }
}
