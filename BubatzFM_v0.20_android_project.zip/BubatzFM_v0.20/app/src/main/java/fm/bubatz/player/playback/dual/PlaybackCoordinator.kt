
package fm.bubatz.player.playback.dual

import androidx.media3.common.MediaItem

/**
 * Holds just the upcoming item. The database-backed shuffle engine remains
 * the source of truth; we do not keep thousands of MediaItems in memory.
 */
class PlaybackCoordinator {
    private var next: MediaItem? = null

    fun setNext(item: MediaItem) { next = item }
    fun peekNext(): MediaItem? = next
    fun consumeNext(): MediaItem? = next.also { next = null }
    fun clear() { next = null }
}
