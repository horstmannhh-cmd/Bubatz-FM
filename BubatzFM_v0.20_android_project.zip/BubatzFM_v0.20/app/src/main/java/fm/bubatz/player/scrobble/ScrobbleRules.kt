
package fm.bubatz.player.scrobble

/**
 * Last.fm-compatible local eligibility check.
 *
 * We deliberately never scrobble radio inserts. A music track becomes
 * eligible after half its duration or 4 minutes, whichever comes first.
 * Very short files are ignored.
 */
object ScrobbleRules {
    private const val FOUR_MINUTES_MS = 4 * 60_000L
    private const val MIN_TRACK_MS = 30_000L

    fun thresholdMs(durationMs: Long): Long =
        minOf(durationMs / 2L, FOUR_MINUTES_MS)

    fun isEligible(
        mediaId: String?,
        durationMs: Long,
        listenedMs: Long
    ): Boolean {
        if (mediaId?.startsWith("track:") != true) return false
        if (durationMs < MIN_TRACK_MS) return false
        return listenedMs >= thresholdMs(durationMs)
    }
}
