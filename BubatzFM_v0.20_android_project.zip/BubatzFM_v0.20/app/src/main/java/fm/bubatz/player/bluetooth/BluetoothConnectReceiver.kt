
package fm.bubatz.player.bluetooth

import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import fm.bubatz.player.playback.PlaybackService
import fm.bubatz.player.settings.AppSettings
import kotlinx.coroutines.*

class BluetoothConnectReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val isAcl = intent.action == BluetoothDevice.ACTION_ACL_CONNECTED
        val isA2dp = intent.action == BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED &&
            intent.getIntExtra(BluetoothProfile.EXTRA_STATE, -1) == BluetoothProfile.STATE_CONNECTED

        if (!isAcl && !isA2dp) return

        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val device: BluetoothDevice? =
                    if (Build.VERSION.SDK_INT >= 33) {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    }

                // ACL is kept as an Omnia-like fallback. For it we only react to
                // audio/video-class devices. A2DP is already an audio connection.
                if (isAcl) {
                    val major = runCatching { device?.bluetoothClass?.majorDeviceClass }.getOrNull()
                    val looksLikeAudio =
                        major == BluetoothClass.Device.Major.AUDIO_VIDEO || major == null
                    if (!looksLikeAudio) return@launch
                }

                val address = runCatching { device?.address }.getOrNull()
                if (!AppSettings(context).shouldAutoStartFor(address)) return@launch

                val service = Intent(context, PlaybackService::class.java)
                    .setAction(PlaybackService.ACTION_AUTO_PLAY)
                ContextCompat.startForegroundService(context, service)
            } finally {
                pending.finish()
            }
        }
    }
}
