
package fm.bubatz.player.playback.crossfade

/**
 * Central transition policy for Bubatz FM.
 *
 * IMPORTANT:
 * Radio inserts must NEVER be crossfaded. They already contain their own
 * intro/outro timing and are treated as complete broadcast elements.
 */
object CrossfadePolicy {
    fun isMusic(mediaId: String?): Boolean = mediaId?.startsWith("track:") == true
    fun isRadio(mediaId: String?): Boolean = mediaId?.startsWith("radio:") == true

    fun shouldCrossfade(
        fromMediaId: String?,
        toMediaId: String?,
        configuredCrossfadeMs: Int
    ): Boolean {
        if (configuredCrossfadeMs <= 0) return false
        return isMusic(fromMediaId) && isMusic(toMediaId)
    }

    fun durationMs(configuredCrossfadeMs: Int): Int =
        configuredCrossfadeMs.coerceIn(0, 15_000)
}
