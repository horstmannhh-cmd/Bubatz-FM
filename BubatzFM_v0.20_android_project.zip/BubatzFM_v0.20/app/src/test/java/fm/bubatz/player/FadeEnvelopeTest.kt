
package fm.bubatz.player

import fm.bubatz.player.playback.crossfade.FadeEnvelope
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sqrt

class FadeEnvelopeTest {
    @Test fun endpointsAreCorrect() {
        val start = FadeEnvelope.gains(0f)
        val end = FadeEnvelope.gains(1f)
        assertEquals(1f, start.outgoing, 0.0001f)
        assertEquals(0f, start.incoming, 0.0001f)
        assertEquals(0f, end.outgoing, 0.0001f)
        assertEquals(1f, end.incoming, 0.0001f)
    }

    @Test fun midpointIsApproximatelyEqualPower() {
        val mid = FadeEnvelope.gains(0.5f)
        val expected = (1.0 / sqrt(2.0)).toFloat()
        assertTrue(kotlin.math.abs(mid.outgoing - expected) < 0.01f)
        assertTrue(kotlin.math.abs(mid.incoming - expected) < 0.01f)
    }
}
