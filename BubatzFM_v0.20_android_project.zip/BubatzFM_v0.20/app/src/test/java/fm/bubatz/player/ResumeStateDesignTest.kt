
package fm.bubatz.player

import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Documents the invariant behind v0.5 resume:
 * current + reserved upcoming are persisted separately so a process death
 * cannot silently skip the already-reserved shuffle item.
 */
class ResumeStateDesignTest {
    @Test fun mediaIdsAreTyped() {
        assertTrue("track:42".startsWith("track:"))
        assertTrue("radio:7".startsWith("radio:"))
    }
}
