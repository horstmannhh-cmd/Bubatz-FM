
package fm.bubatz.player

import fm.bubatz.player.playback.crossfade.CrossfadePolicy
import fm.bubatz.player.scrobble.ScrobbleRules
import org.junit.Assert.*
import org.junit.Test

class CrossfadePolicyTest {
    @Test fun musicToMusicCrossfades() {
        assertTrue(CrossfadePolicy.shouldCrossfade("track:1", "track:2", 6500))
    }

    @Test fun musicToRadioNeverCrossfades() {
        assertFalse(CrossfadePolicy.shouldCrossfade("track:1", "radio:2", 6500))
    }

    @Test fun radioToMusicNeverCrossfades() {
        assertFalse(CrossfadePolicy.shouldCrossfade("radio:1", "track:2", 6500))
    }

    @Test fun radioToRadioNeverCrossfades() {
        assertFalse(CrossfadePolicy.shouldCrossfade("radio:1", "radio:2", 6500))
    }

    @Test fun disabledCrossfadeStaysOff() {
        assertFalse(CrossfadePolicy.shouldCrossfade("track:1", "track:2", 0))
    }

    @Test fun radioNeverScrobbles() {
        assertFalse(ScrobbleRules.isEligible("radio:7", 60_000, 60_000))
    }
}
