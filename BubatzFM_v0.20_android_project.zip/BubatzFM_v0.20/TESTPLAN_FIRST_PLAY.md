# Test: erster Start über Play

1. App frisch öffnen.
2. Bibliothek laden.
3. „Noch nichts läuft“ muss sichtbar sein.
4. Keinen Titel aus der Liste antippen.
5. Nur den mittleren Play/Pause-Knopf drücken.
6. Erwartung: Ein Shuffle-Titel wird gewählt und startet.
7. Zweiter Druck pausiert.
8. Dritter Druck setzt fort.
