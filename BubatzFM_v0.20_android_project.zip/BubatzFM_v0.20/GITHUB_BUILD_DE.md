
# Bubatz FM per GitHub Actions als APK bauen

Das Repository enthält einen automatischen Android-Build unter:

`.github/workflows/android-build.yml`

Bei jedem Push auf `main` und bei manueller Ausführung erledigt GitHub automatisch:

1. Java 17 einrichten
2. Android SDK einrichten
3. Android Platform 35 + Build Tools 34.0.0 installieren
4. statischen Bubatz-FM-Sanity-Check ausführen
5. Unit-Tests starten
6. Debug-APK bauen
7. APK als GitHub-Actions-Artefakt bereitstellen

Die fertige Datei heißt:

`BubatzFM-v0.12-debug.apk`

## Auf dem Smartphone herunterladen

Im GitHub-Repository:

1. `Actions` öffnen
2. den Lauf `Build Bubatz FM APK` öffnen
3. nach unten zu `Artifacts` scrollen
4. `BubatzFM-v0.12-debug-apk` herunterladen
5. ZIP öffnen und `BubatzFM-v0.12-debug.apk` installieren

Beim ersten Installieren einer APK aus Browser/Dateimanager kann Android verlangen,
für diese App einmalig „Unbekannte Apps installieren“ zu erlauben.
