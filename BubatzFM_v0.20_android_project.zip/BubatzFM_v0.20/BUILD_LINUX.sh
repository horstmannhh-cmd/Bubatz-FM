#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
TOOLS="$ROOT/.build-tools"
SDK="$TOOLS/android-sdk"
GRADLE="$TOOLS/gradle-8.9"

mkdir -p "$TOOLS" "$SDK"

if ! command -v java >/dev/null 2>&1; then
  echo "Java fehlt. Bitte JDK 17 installieren."
  exit 1
fi

export JAVA_HOME="${JAVA_HOME:-$(dirname "$(dirname "$(readlink -f "$(command -v java)")")")}"
export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"

CMD="$SDK/cmdline-tools/latest/bin/sdkmanager"
if [ ! -x "$CMD" ]; then
  curl -L --fail -o "$TOOLS/commandlinetools.zip" \
    "https://dl.google.com/android/repository/commandlinetools-linux-15859902_latest.zip"
  rm -rf "$TOOLS/cmdline-extract"
  mkdir -p "$TOOLS/cmdline-extract" "$SDK/cmdline-tools/latest"
  unzip -q "$TOOLS/commandlinetools.zip" -d "$TOOLS/cmdline-extract"
  cp -a "$TOOLS/cmdline-extract/cmdline-tools/." "$SDK/cmdline-tools/latest/"
fi

export PATH="$SDK/platform-tools:$SDK/cmdline-tools/latest/bin:$PATH"

echo "Bitte die Android-SDK-Lizenzen lesen und bei Zustimmung mit y bestaetigen:"
"$CMD" --sdk_root="$SDK" --licenses
"$CMD" --sdk_root="$SDK" "platform-tools" "platforms;android-35" "build-tools;34.0.0"

if [ ! -x "$GRADLE/bin/gradle" ]; then
  curl -L --fail -o "$TOOLS/gradle-8.9-bin.zip" \
    "https://services.gradle.org/distributions/gradle-8.9-bin.zip"
  unzip -q "$TOOLS/gradle-8.9-bin.zip" -d "$TOOLS"
fi

printf 'sdk.dir=%s\n' "$SDK" > "$ROOT/local.properties"

cd "$ROOT"
"$GRADLE/bin/gradle" --no-daemon testDebugUnitTest
"$GRADLE/bin/gradle" --no-daemon assembleDebug

mkdir -p "$ROOT/FERTIGE_APK"
cp "$ROOT/app/build/outputs/apk/debug/app-debug.apk" \
   "$ROOT/FERTIGE_APK/BubatzFM-v0.11-debug.apk"

echo "Fertig: $ROOT/FERTIGE_APK/BubatzFM-v0.11-debug.apk"
