
from pathlib import Path
import sys, re, xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
errors = []

manifest_path = root/"app/src/main/AndroidManifest.xml"
ET.parse(manifest_path)
manifest = manifest_path.read_text()
application_match = re.search(r"<application\b(.*?)>", manifest, re.S)
if not application_match:
    errors.append("No <application> element.")
elif application_match.group(1).count("android:label=") != 1:
    errors.append("Application must contain exactly one android:label.")

dao = (root/"app/src/main/java/fm/bubatz/player/data/Dao.kt").read_text()
if "fun observe(): Flow<PlaybackStateEntity?>" not in dao:
    errors.append("StateDao.observe() missing.")

main = (root/"app/src/main/java/fm/bubatz/player/MainActivity.kt").read_text()
if "rememberSaveable" in main and "runtime.saveable.rememberSaveable" not in main:
    errors.append("rememberSaveable import missing.")
if "settings.setRadioEnabled" not in main:
    errors.append("Radio enable/disable UI missing.")

service = (root/"app/src/main/java/fm/bubatz/player/playback/PlaybackService.kt").read_text()
if "session.setPlayer(facade)" not in service:
    errors.append("MediaSession does not switch to session facade on deck handoff.")
if "settings.radioEnabled.first()" not in service:
    errors.append("Playback scheduler ignores radioEnabled setting.")
if "handlePreviousRequest()" not in service:
    errors.append("Unified previous handling missing.")

auth = (root/"app/src/main/java/fm/bubatz/player/scrobble/LastFmAuthCoordinator.kt").read_text()
if "store.pendingToken" not in auth:
    errors.append("Last.fm pending token is not persistent.")

session_player_path = root/"app/src/main/java/fm/bubatz/player/playback/session/BubatzSessionPlayer.kt"
if not session_player_path.exists():
    errors.append("BubatzSessionPlayer missing.")
else:
    sp = session_player_path.read_text()
    required = [
        "ForwardingPlayer",
        "COMMAND_SEEK_TO_NEXT",
        "COMMAND_SEEK_TO_PREVIOUS",
        "override fun seekToNext",
        "override fun seekToPrevious",
    ]
    for token in required:
        if token not in sp:
            errors.append(f"BubatzSessionPlayer missing {token}")

if errors:
    print("SANITY CHECK FAILED")
    for e in errors:
        print("-", e)
    sys.exit(1)

print("SANITY CHECK OK")
