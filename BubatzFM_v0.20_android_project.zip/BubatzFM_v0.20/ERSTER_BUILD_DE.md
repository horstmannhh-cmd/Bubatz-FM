
# Bubatz FM zum ersten Mal als APK bauen

## Windows – einfachste Variante

1. Entpacke den kompletten Ordner `BubatzFM_v0.11`.
2. Am besten ist **Android Studio bereits installiert**. Das Skript nutzt dann automatisch das darin enthaltene Java.
3. Doppelklicke auf:

   `BUBATZ_FM_BAUEN.bat`

4. Beim ersten Durchlauf werden die offiziellen Android-Buildwerkzeuge und Gradle heruntergeladen.
5. Google zeigt die Android-SDK-Lizenzen an. Lies sie und bestätige sie mit `y`, wenn du zustimmst.
6. Danach laufen Unit-Tests und der Debug-Build automatisch.
7. Bei Erfolg liegt die App hier:

   `FERTIGE_APK\BubatzFM-v0.11-debug.apk`

Du musst dafür weder Kotlin noch Gradle verstehen.

## Falls Windows das PowerShell-Skript blockiert

Die `.bat`-Datei startet PowerShell bereits mit einer Ausführungsfreigabe nur für diesen
einzelnen Prozess. An deinen dauerhaften PowerShell-Einstellungen wird nichts geändert.

## Was das Skript herunterlädt

Nur offizielle Build-Komponenten:
- Android Command Line Tools von `dl.google.com`
- Android Plattform API 35
- Android Build Tools 34.0.0
- Android Platform Tools
- Gradle 8.9 von `services.gradle.org`

Die gewählten Gradle-/Build-Tools-Versionen entsprechen der Kompatibilitätsbasis von
Android Gradle Plugin 8.7, das dieses Projekt verwendet.

## Wichtig

`BubatzFM-v0.11-debug.apk` ist zunächst eine **Debug-Version** für unseren privaten
Gerätetest. Sie ist nicht für den Play Store gedacht. Für deinen privaten Test ist das
genau die richtige Variante.
