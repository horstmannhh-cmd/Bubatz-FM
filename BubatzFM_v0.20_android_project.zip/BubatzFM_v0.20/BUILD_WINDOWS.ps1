
$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "========================================" -ForegroundColor DarkGreen
Write-Host "       BUBATZ FM - ANDROID BUILD" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor DarkGreen
Write-Host ""

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ToolsRoot = Join-Path $ProjectRoot ".build-tools"
$SdkRoot = Join-Path $ToolsRoot "android-sdk"
$GradleRoot = Join-Path $ToolsRoot "gradle-8.9"

New-Item -ItemType Directory -Force -Path $ToolsRoot | Out-Null
New-Item -ItemType Directory -Force -Path $SdkRoot | Out-Null

function Find-Java {
    $Candidates = @(
        "$env:ProgramFiles\Android\Android Studio\jbr\bin\java.exe",
        "$env:ProgramFiles\Android\Android Studio\jre\bin\java.exe"
    )
    foreach ($c in $Candidates) {
        if (Test-Path $c) { return $c }
    }
    $cmd = Get-Command java -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

$JavaExe = Find-Java
if (-not $JavaExe) {
    Write-Host "Java wurde nicht gefunden." -ForegroundColor Red
    Write-Host "Installiere bitte Android Studio oder JDK 17 und starte dieses Skript erneut."
    Read-Host "Enter zum Beenden"
    exit 1
}

$JavaVersionText = (& $JavaExe -version 2>&1 | Select-Object -First 1)
Write-Host "Java gefunden: $JavaVersionText"

# Prefer Android Studio JBR's JAVA_HOME if found there.
$JavaBin = Split-Path -Parent $JavaExe
$env:JAVA_HOME = Split-Path -Parent $JavaBin
$env:PATH = "$JavaBin;$env:PATH"

# Official Android command line tools version current when v0.11 was prepared.
$CmdToolsUrl = "https://dl.google.com/android/repository/commandlinetools-win-15859902_latest.zip"
$CmdZip = Join-Path $ToolsRoot "commandlinetools.zip"
$SdkManager = Join-Path $SdkRoot "cmdline-tools\latest\bin\sdkmanager.bat"

if (-not (Test-Path $SdkManager)) {
    Write-Host ""
    Write-Host "Lade Android Command Line Tools..." -ForegroundColor Cyan
    Invoke-WebRequest -Uri $CmdToolsUrl -OutFile $CmdZip

    $Extract = Join-Path $ToolsRoot "cmdline-extract"
    if (Test-Path $Extract) { Remove-Item $Extract -Recurse -Force }
    Expand-Archive -Path $CmdZip -DestinationPath $Extract -Force

    $Latest = Join-Path $SdkRoot "cmdline-tools\latest"
    New-Item -ItemType Directory -Force -Path $Latest | Out-Null
    Copy-Item (Join-Path $Extract "cmdline-tools\*") $Latest -Recurse -Force
}

$env:ANDROID_HOME = $SdkRoot
$env:ANDROID_SDK_ROOT = $SdkRoot
$env:PATH = "$(Join-Path $SdkRoot 'platform-tools');$(Join-Path $SdkRoot 'cmdline-tools\latest\bin');$env:PATH"

Write-Host ""
Write-Host "Android-SDK-Lizenzen:" -ForegroundColor Yellow
Write-Host "Google zeigt die Lizenzbedingungen im Terminal an."
Write-Host "Bitte mit 'y' bestaetigen, soweit du ihnen zustimmst."
Write-Host ""
& $SdkManager --sdk_root=$SdkRoot --licenses

Write-Host ""
Write-Host "Installiere benoetigte Android-SDK-Pakete..." -ForegroundColor Cyan
& $SdkManager --sdk_root=$SdkRoot "platform-tools" "platforms;android-35" "build-tools;34.0.0"

$GradleUrl = "https://services.gradle.org/distributions/gradle-8.9-bin.zip"
$GradleZip = Join-Path $ToolsRoot "gradle-8.9-bin.zip"

if (-not (Test-Path (Join-Path $GradleRoot "bin\gradle.bat"))) {
    Write-Host ""
    Write-Host "Lade Gradle 8.9..." -ForegroundColor Cyan
    Invoke-WebRequest -Uri $GradleUrl -OutFile $GradleZip
    Expand-Archive -Path $GradleZip -DestinationPath $ToolsRoot -Force
}

# local.properties tells Gradle where the SDK is.
$EscapedSdk = $SdkRoot.Replace("\", "\\")
"Sdk.dir=$EscapedSdk".Replace("Sdk.dir", "sdk.dir") | Set-Content -Encoding ASCII (Join-Path $ProjectRoot "local.properties")

Write-Host ""
Write-Host "Starte Unit-Tests..." -ForegroundColor Cyan
Push-Location $ProjectRoot
try {
    & (Join-Path $GradleRoot "bin\gradle.bat") --no-daemon testDebugUnitTest
    if ($LASTEXITCODE -ne 0) { throw "Unit-Tests fehlgeschlagen." }

    Write-Host ""
    Write-Host "Baue Debug-APK..." -ForegroundColor Cyan
    & (Join-Path $GradleRoot "bin\gradle.bat") --no-daemon assembleDebug
    if ($LASTEXITCODE -ne 0) { throw "Android-Build fehlgeschlagen." }
}
finally {
    Pop-Location
}

$Apk = Join-Path $ProjectRoot "app\build\outputs\apk\debug\app-debug.apk"
if (Test-Path $Apk) {
    $OutDir = Join-Path $ProjectRoot "FERTIGE_APK"
    New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
    $OutApk = Join-Path $OutDir "BubatzFM-v0.11-debug.apk"
    Copy-Item $Apk $OutApk -Force

    Write-Host ""
    Write-Host "========================================" -ForegroundColor DarkGreen
    Write-Host " BUILD ERFOLGREICH" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor DarkGreen
    Write-Host ""
    Write-Host "APK:" -ForegroundColor White
    Write-Host $OutApk -ForegroundColor Green
    Write-Host ""
    Write-Host "Diese Datei kannst du auf dein Android-Smartphone kopieren und installieren."
} else {
    Write-Host "Build lief durch, aber APK wurde nicht am erwarteten Ort gefunden." -ForegroundColor Red
}

Write-Host ""
Read-Host "Enter zum Beenden"
