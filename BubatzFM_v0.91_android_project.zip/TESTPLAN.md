# Bubatz FM v0.91 – kurzer Testplan

1. v0.91 über die bestehende Version installieren.
2. Omnia starten und einen gut erkennbaren Titel abspielen.
3. In Bubatz FM die eigene Wiedergabe pausieren.
4. Zur normalen Player-Seite wechseln.
5. Erwartung: Hinweis „OMNIA · EXTERNE WIEDERGABE“ sowie Omnias Titel, Interpret und Album.
6. In dieser Ansicht Zurück, Play/Pause und Weiter testen.
7. Danach Bubatz-eigene Wiedergabe starten.
8. Erwartung: Die Playeransicht wechselt wieder auf den Bubatz-Titel; die interne Wiedergabe hat Vorrang.

Für die Rückmeldung reichen zwei Screenshots: einmal Omnia-Modus im normalen Player und einmal Bubatz-Modus nach Wiederaufnahme.
