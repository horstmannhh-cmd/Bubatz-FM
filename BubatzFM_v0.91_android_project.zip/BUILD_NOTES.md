# Bubatz FM v0.91 – Build Notes

v0.91 integriert die in v0.90 verifizierte Omnia-MediaSession-Bridge erstmals in die normale Playeransicht.

Quellenregel für diesen Testbuild:
- Spielt Bubatz FM selbst, bleibt die Playeransicht vollständig bei Bubatz.
- Ist Bubatz pausiert/gestoppt und eine Omnia-MediaSession mit Metadaten verbunden, zeigt der Player Omnia als externe Quelle.
- Zurück, Play/Pause, Weiter und Seek werden in diesem Omnia-Modus an Omnia weitergereicht.

Die interne Bubatz-Wiedergabe, Random/History, Crossfade, Bibliothek und Last.fm-Logik wurden nicht verändert.
