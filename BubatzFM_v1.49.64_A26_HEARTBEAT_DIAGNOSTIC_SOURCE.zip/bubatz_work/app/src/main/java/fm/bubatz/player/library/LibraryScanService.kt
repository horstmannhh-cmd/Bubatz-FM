package fm.bubatz.player.library

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.room.withTransaction
import fm.bubatz.player.BubatzApplication
import fm.bubatz.player.R
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** User-initiated, visible library import. No playback or IQ state is modified. */
class LibraryScanService : Service() {
    companion object {
        const val ACTION_SCAN = "fm.bubatz.player.library.SCAN"
        const val ACTION_STOP = "fm.bubatz.player.library.STOP"
        const val ACTION_RESUME_METADATA = "fm.bubatz.player.library.RESUME_METADATA"
        const val ACTION_RETRY_FAILED = "fm.bubatz.player.library.RETRY_FAILED"
        const val EXTRA_TREE_URI = "tree_uri"
        private const val CHANNEL = "library_scan"
        private const val NOTIFICATION_ID = 2941
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private val diagnostics by lazy { ScanDiagnostics(this) }
    private val notificationManager by lazy { getSystemService(NotificationManager::class.java) }
    private val scanState by lazy { getSharedPreferences("library_scan_state", MODE_PRIVATE) }
    private var scanStartId: Int = 0
    private var stoppingForTimeout = false

    override fun onCreate() {
        super.onCreate()
        notificationManager.createNotificationChannel(
            NotificationChannel(CHANNEL, "Bibliothek einlesen", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            job?.cancel()
            diagnostics.save("Bibliotheksscan unterbrochen; bereits gespeicherte Metadaten bleiben erhalten.")
            stopSelf()
            return START_NOT_STICKY
        }
        if (job?.isActive == true) return START_NOT_STICKY
        scanStartId = startId
        stoppingForTimeout = false
        val uriString = intent?.getStringExtra(EXTRA_TREE_URI)
        if (intent == null) {
            stopSelf(startId)
            return START_NOT_STICKY
        }
        // Metadata-only resume is safe after successful enumeration/DB sync.
        // Never run a metadata-only resume if enumeration was interrupted.
        if (intent.action == ACTION_RESUME_METADATA || intent.action == ACTION_RETRY_FAILED) {
            val phase = scanState.getString("phase", "")
            val eligible = phase in setOf("metadata", "timed_out_metadata", "complete", "metadata_error")
            if (!eligible) {
                diagnostics.save("Fortsetzen nicht möglich: zuerst Musikordner vollständig einlesen.")
                stopSelf(startId)
                return START_NOT_STICKY
            }
            show("Metadaten werden vorbereitet …")
            job = scope.launch {
                try {
                    val dao = (application as BubatzApplication).database.tracks()
                    if (intent.action == ACTION_RETRY_FAILED) {
                        val count = dao.retryFailedMetadata()
                        diagnostics.save("Erneuter Versuch für $count fehlgeschlagene Dateien gestartet.")
                    }
                    scanState.edit().putString("phase", "metadata").apply()
                    runMetadataPass(dao)
                    scanState.edit().putString("phase", "complete").apply()
                    diagnostics.save("Metadaten vollständig bearbeitet; Fehler: ${dao.metadataFailures()}.")
                    show("Metadatenprüfung abgeschlossen")
                } catch (cancelled: CancellationException) {
                    diagnostics.save("Metadatenprüfung unterbrochen; Fortschritt gespeichert.")
                    throw cancelled
                } catch (t: Exception) {
                    scanState.edit().putString("phase", "metadata_error").apply()
                    diagnostics.save("Metadatenfehler: ${t::class.java.simpleName}: ${t.message}")
                    show("Metadatenprüfung fehlgeschlagen")
                } finally {
                    stopSelf(startId)
                }
            }
            return START_NOT_STICKY
        }
        if (intent.action != ACTION_SCAN || uriString.isNullOrBlank()) {
            stopSelf(startId)
            return START_NOT_STICKY
        }
        // Persist the selected tree for an explicit restart after interruption.
        // Do not auto-restart enumeration after process death: an incomplete tree
        // must never be mistaken for a complete snapshot.
        scanState.edit().putString("last_tree_uri", uriString).putString("phase", "enumerating").apply()
        show("Bibliotheksscan wird gestartet …")
        job = scope.launch {
            try {
                val db = (application as BubatzApplication).database
                val result = LibraryScanner(this@LibraryScanService)
                    .scanMusicDetailed(android.net.Uri.parse(uriString))
                if (result.error != null || result.stats.queryErrors > 0) {
                    val message = result.error ?: "Unvollständiger Ordnerscan"
                    diagnostics.save("Scan abgebrochen: $message. Bibliothek unverändert.")
                    show("Scanfehler – Bibliothek unverändert")
                    return@launch
                }
                var inserted = 0
                // Never disable the old library unless enumeration was complete.
                db.withTransaction {
                    db.tracks().disableAll()
                    result.tracks.chunked(500).forEachIndexed { index, chunk ->
                        inserted += db.tracks().insertAll(chunk).count { it != -1L }
                        db.tracks().enableByUris(chunk.map { it.uri })
                        if (index % 10 == 0) show("Abgleich: ${minOf((index + 1) * 500, result.tracks.size)}/${result.tracks.size}")
                    }
                }
                scanState.edit().putString("phase", "metadata").apply()
                diagnostics.save("Ordnerscan abgeschlossen: ${result.tracks.size} Titel, $inserted neu. Metadaten laufen …")
                runMetadataPass(db.tracks())
                scanState.edit().putString("phase", "complete").apply()
                diagnostics.save("Bibliotheksscan abgeschlossen. Aktive Titel: ${db.tracks().count()}; neu: $inserted.")
                show("Bibliotheksscan abgeschlossen")
            } catch (cancelled: CancellationException) {
                diagnostics.save("Scan unterbrochen; bereits gespeicherte Metadaten bleiben erhalten.")
                throw cancelled
            } catch (t: Exception) {
                diagnostics.save("Scanfehler: ${t::class.java.simpleName}: ${t.message}")
                show("Bibliotheksscan fehlgeschlagen")
            } finally {
                stopSelf(startId)
            }
        }
        // A killed service must not automatically restart an expensive full enumeration.
        return START_NOT_STICKY
    }

    private suspend fun runMetadataPass(dao: fm.bubatz.player.data.TrackDao) {
        LibraryScanner(this).fillMissingMetadata(dao) { done, total, failed ->
            if (done % 250 == 0 || done == total) {
                val message = "Metadaten: $done/$total · Fehler: $failed"
                diagnostics.save(message)
                show(message, done, total)
            }
        }
    }

    private fun show(message: String, progress: Int = 0, total: Int = 0) {
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Bubatz.FM · Bibliothek")
            .setContentText(message)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .apply { if (total > 0) setProgress(total, progress, false) else setProgress(0, 0, true) }
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    // Android 15 / target 35: dataSync FGS has a system-enforced time budget.
    // Stop promptly when it expires rather than waiting for a system crash.
    // Metadata updates already committed remain in Room; the next user scan
    // can pick up missing metadata. Enumeration must be run again for safety.
    override fun onTimeout(startId: Int, fgsType: Int) {
        if (Build.VERSION.SDK_INT >= 35) {
            stoppingForTimeout = true
            val previousPhase = scanState.getString("phase", "")
            scanState.edit().putString("phase", if (previousPhase == "metadata") "timed_out_metadata" else "timed_out_enumerating").apply()
            diagnostics.save("Android-Zeitlimit erreicht. Scan angehalten; gespeicherte Metadaten bleiben erhalten. Bibliotheksscan erneut starten.")
            job?.cancel()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(startId)
        }
    }

    override fun onDestroy() {
        job?.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
