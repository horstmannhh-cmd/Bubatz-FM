package fm.bubatz.player.library

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.DocumentsContract
import fm.bubatz.player.data.RadioClipEntity
import fm.bubatz.player.data.TrackEntity
import fm.bubatz.player.data.TrackDao
import fm.bubatz.player.data.MetadataScanEntity
import kotlinx.coroutines.ensureActive
import kotlin.coroutines.coroutineContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LibraryScanner(private val context: Context) {
    private val audioExt = setOf("mp3", "flac", "m4a", "aac", "ogg", "opus", "wav", "wma")
    private val diagnostics = ScanDiagnostics(context)

    data class ScanStats(
        var directoriesVisited: Int = 0,
        var filesVisited: Int = 0,
        var audioRecognized: Int = 0,
        var metadataRead: Int = 0,
        var metadataFailed: Int = 0,
        var queryErrors: Int = 0
    )

    data class MusicScanResult(
        val tracks: List<TrackEntity>,
        val stats: ScanStats,
        val error: String? = null
    )

    /**
     * Fast library import.
     *
     * Important: metadata is intentionally NOT extracted here. With libraries
     * around 40k tracks, doing MediaMetadataRetriever for every file before the
     * first DB insert can take long enough that Android kills the process.
     * We first persist every audio file, then metadata is resolved on demand
     * when a track is actually prepared for playback.
     */
    suspend fun scanMusicDetailed(treeUri: Uri): MusicScanResult = withContext(Dispatchers.IO) {
        val stats = ScanStats()
        val found = mutableListOf<Pair<Uri, String>>()

        diagnostics.save("START\nURI: $treeUri")

        val rootId = runCatching { DocumentsContract.getTreeDocumentId(treeUri) }
            .getOrElse {
                val msg = "FEHLER Tree-ID: ${it::class.java.simpleName}: ${it.message}"
                diagnostics.save(msg)
                return@withContext MusicScanResult(emptyList(), stats, msg)
            }

        val rootDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)

        try {
            enumerate(treeUri, rootDocUri, stats, found)
        } catch (t: Throwable) {
            val msg = "FEHLER Scan: ${t::class.java.simpleName}: ${t.message}"
            diagnostics.save(report(stats, found.size, msg))
            return@withContext MusicScanResult(emptyList(), stats, msg)
        }

        // A partially enumerated tree must never be used for a destructive sync.
        // enumerate() records inaccessible directories as queryErrors and continues
        // scanning siblings so diagnostics can still report the complete failure.
        if (stats.queryErrors > 0) {
            val msg = "Unvollständiger Scan: ${stats.queryErrors} Ordner konnten nicht gelesen werden. Bibliothek bleibt unverändert."
            diagnostics.save(report(stats, found.size, msg))
            return@withContext MusicScanResult(emptyList(), stats, msg)
        }

        val tracks = found.map { (uri, name) ->
            TrackEntity(
                uri = uri.toString(),
                title = name.substringBeforeLast('.').ifBlank { name },
                artist = null,
                album = null,
                durationMs = 0L
            )
        }

        diagnostics.save(report(stats, found.size, "Enumeration fertig – bereit für DB"))
        MusicScanResult(tracks, stats, null)
    }

    suspend fun scanMusic(treeUri: Uri): List<TrackEntity> =
        scanMusicDetailed(treeUri).tracks

    /**
     * Explicit metadata pass after a successful, non-destructive folder sync.
     * Existing row IDs and all IQ/playback columns are preserved by updateMetadata().
     * Each row is committed independently; interruption therefore retains progress.
     * This is deliberately not yet a foreground service: the UI must remain open.
     */
    suspend fun fillMissingMetadata(
        dao: TrackDao,
        onProgress: suspend (done: Int, total: Int, failed: Int) -> Unit
    ) = withContext(Dispatchers.IO) {
        val total = dao.metadataBacklogCount()
        var done = 0
        var failed = 0
        var afterId = 0L
        while (true) {
            coroutineContext.ensureActive()
            val page = dao.metadataBacklogPage(afterId, 50)
            if (page.isEmpty()) break
            for (track in page) {
                coroutineContext.ensureActive()
                afterId = track.id
                val meta = metadataOrNull(Uri.parse(track.uri))
                if (meta == null) {
                    failed++
                    dao.markMetadataInspected(MetadataScanEntity(track.id, 2))
                } else {
                    dao.updateMetadata(
                        id = track.id,
                        title = meta.title?.takeIf { it.isNotBlank() } ?: track.title,
                        artist = meta.artist?.takeIf { it.isNotBlank() } ?: track.artist,
                        album = meta.album?.takeIf { it.isNotBlank() } ?: track.album,
                        albumArtist = meta.albumArtist?.takeIf { it.isNotBlank() } ?: track.albumArtist,
                        isCompilation = meta.isCompilation ?: (track.isCompilation ?: false),
                        durationMs = meta.duration.takeIf { it > 0 } ?: track.durationMs
                    )
                    // An empty artist/album tag is a valid scan result, not a reason
                    // to reopen the same file on every subsequent library refresh.
                    dao.markMetadataInspected(MetadataScanEntity(track.id, 1))
                }
                done++
                if (done % 25 == 0 || done == total) onProgress(done, total, failed)
            }
        }
        onProgress(done, total, failed)
    }

    suspend fun scanRadio(treeUri: Uri): List<RadioClipEntity> = withContext(Dispatchers.IO) {
        val result = mutableListOf<RadioClipEntity>()
        val stats = ScanStats()
        val found = mutableListOf<Pair<Uri, String>>()
        val rootId = runCatching { DocumentsContract.getTreeDocumentId(treeUri) }.getOrNull()
            ?: return@withContext emptyList()
        val root = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)

        enumerate(treeUri, root, stats, found)

        // Radio inserts are a small collection, so metadata extraction here is fine.
        for ((uri, name) in found) {
            val meta = metadataOrNull(uri)
            result += RadioClipEntity(
                uri = uri.toString(),
                name = meta?.title ?: name.substringBeforeLast('.'),
                durationMs = meta?.duration ?: 0L
            )
        }
        result
    }

    private fun enumerate(
        treeUri: Uri,
        documentUri: Uri,
        stats: ScanStats,
        found: MutableList<Pair<Uri, String>>
    ) {
        stats.directoriesVisited++

        val documentId = DocumentsContract.getDocumentId(documentUri)
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, documentId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )

        val cursor = try {
            context.contentResolver.query(childrenUri, projection, null, null, null)
        } catch (_: Throwable) {
            stats.queryErrors++
            return
        }

        if (cursor == null) {
            stats.queryErrors++
            return
        }

        cursor.use { c ->
            val idIndex = c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameIndex = c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeIndex = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)

            while (c.moveToNext()) {
                val childId = if (idIndex >= 0) c.getString(idIndex) else null
                if (childId.isNullOrBlank()) continue

                val name = if (nameIndex >= 0) c.getString(nameIndex) ?: "Unbekannt" else "Unbekannt"
                val mime = if (mimeIndex >= 0) c.getString(mimeIndex) else null
                val childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childId)

                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    enumerate(treeUri, childUri, stats, found)
                } else {
                    stats.filesVisited++
                    val ext = name.substringAfterLast('.', "").lowercase()
                    if (ext in audioExt || mime?.startsWith("audio/") == true) {
                        stats.audioRecognized++
                        found += childUri to name
                    }
                    if (stats.filesVisited % 2000 == 0) {
                        diagnostics.save(report(stats, found.size, "Dateien werden erfasst"))
                    }
                }
            }
        }
    }

    private fun report(stats: ScanStats, found: Int, phase: String): String = buildString {
        append("$phase\n")
        append("Ordner: ${stats.directoriesVisited}\n")
        append("Dateien: ${stats.filesVisited}\n")
        append("Audio erkannt: ${stats.audioRecognized}\n")
        append("Audio gesammelt: $found\n")
        append("Query-Fehler: ${stats.queryErrors}")
    }

    private data class Meta(
        val title: String?,
        val artist: String?,
        val album: String?,
        val albumArtist: String?,
        val isCompilation: Boolean?,
        val duration: Long
    )

    private fun metadataOrNull(uri: Uri): Meta? = runCatching {
        val r = MediaMetadataRetriever()
        try {
            val opened = runCatching {
                context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                    r.setDataSource(pfd.fileDescriptor)
                    true
                } ?: false
            }.getOrDefault(false)
            if (!opened) r.setDataSource(context, uri)

            Meta(
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_COMPILATION)?.let { it == "1" },
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            )
        } finally {
            r.release()
        }
    }.getOrNull()
}
