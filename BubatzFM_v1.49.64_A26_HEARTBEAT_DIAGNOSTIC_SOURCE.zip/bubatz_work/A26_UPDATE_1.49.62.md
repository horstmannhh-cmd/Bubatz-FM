# Bubatz.FM 1.49.62 — A26

Basis: 1.49.61 Widget-Cover-Fix, abgeleitet aus 1.49.59 A26. Kein M31-Branch.

- Widget: quadratisches Cover-Bitmap mit zentriertem Zuschnitt (bereits in 1.49.61 enthalten).
- Statusleiste: weiße Brokkoli-Silhouette in vorhandener 96x96-Ressource vergrößert, ohne Funkwellen. Die endgültige Anzeigegröße wird durch Android/Samsung begrenzt.
- Programmzeiten: 00–03 Der Nachtbus, 03–06 Dunstabzug, 06–09 Zündfunk, 09–12 Aufglühen, 12–15 High Noon, 15–18 Blütezeit, 18–21 Drehmoment, 21–00 Sofaschwere.
- Bubatz.IQ, Shuffle und Playback nicht verändert.

Build/Installation auf A26 noch nicht durchgeführt.
