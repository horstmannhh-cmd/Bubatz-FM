# A26 diagnostic-only change 1.49.64

Based on the user-supplied A26 BUILD FIX archive (archive filename 1.49.63; internal Gradle version was 1.49.62 / 416).

- Persist last 90 one-minute Charging/Idle heartbeat samples in SharedPreferences using synchronous commit, keeping the existing last-heartbeat key and migrating its previous sample once.
- Add an on-demand, selectable Heartbeat-Verlauf section in Systemdiagnose (newest first).
- No changes to playback, Bubatz.IQ, scrobbling, shuffle, crossfade or the sampling cadence.
- This is a source ZIP for the existing GitHub build workflow; no APK was built in this environment.
- Earlier heartbeats already overwritten by the original app cannot be recovered.
