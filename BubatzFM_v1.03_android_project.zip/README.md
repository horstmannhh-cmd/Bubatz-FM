# Bubatz FM – Android Player v0.12

Persönlicher Android-Musikplayer mit Radio-Charakter. Diese erste Entwicklungsfassung legt die Architektur für sehr große lokale Bibliotheken und die Bubatz-FM-Sonderfunktionen fest.

## In v0.12 bereits umgesetzt

- Native Android-App in Kotlin + Jetpack Compose
- Storage Access Framework: Musik- und Einspielerordner frei wählbar, inklusive SD-Karte
- Persistente Room/SQLite-Datenbank statt 50.000+ Dateien dauerhaft im RAM
- Rekursiver Audio-Scan mit Metadaten
- Persistenter Shuffle-Zyklus: jeder Titel nur einmal pro Zyklus
- Queue wird nur wenige Titel voraus befüllt, nicht mit der kompletten Bibliothek
- Separater Shuffle-Pool für Radioeinspieler
- Radio-Scheduler-Grundlage mit 25–35 Minuten Streuung
- Media3/ExoPlayer + MediaSessionService für Hintergrundwiedergabe und Mediensteuerung
- Bluetooth-Autostart mit abschaltbarer Einstellung
- Last.fm-Integrationsgrenze und Scrobble-Queue-Datenmodell
- Bubatz-FM-Farben und bereitgestellte Designreferenz

## Bewusst noch nicht fertig in 0.2

- Dual-Player-Crossfade (in der Daten-/Einstellungsarchitektur vorbereitet)
- Einspieler tatsächlich in den laufenden Musikstrom einschieben
- direkte Last.fm-Authentifizierung/Übertragung
- gerätespezifische Bluetooth-Autostart-Härtung
- vollständige Now-Playing-UI, Coverextraktion, Suche, Historie
- inkrementeller Rescan mit Erkennung gelöschter/veränderter Dateien

Diese Punkte sind absichtlich getrennte Module. Dadurch lässt sich insbesondere Bluetooth und Crossfade früh auf echter Hardware testen, ohne später den ganzen Player neu zu bauen.

## Öffnen

Projektordner in Android Studio öffnen, Gradle synchronisieren und `app` auf einem Android-Gerät starten.

Minimum: Android 9 (API 28). Zielplattform: Android 15/API 35 in diesem Projektstand.


Siehe `CHANGELOG.md` für den aktuellen Entwicklungsstand.


## v0.12
Crossfade-Policy und Last.fm-Scrobble-Regeln sind jetzt als technische Guardrails implementiert. Radioeinspieler werden weder crossgefadet noch gescrobbelt.


## v0.12
Der Wiedergabekern verwendet jetzt zwei ExoPlayer-Decks für echten Musik-zu-Musik-Crossfade. Radioeinspieler bleiben technisch von jeder Überblendung ausgeschlossen.


## v0.12
Persistentes Resume speichert jetzt aktuellen und bereits reservierten nächsten Titel. Bluetooth-Autostart unterstützt alle oder ausgewählte gekoppelte Audiogeräte sowie eine einmalige Stille-Unterdrückung.


## v0.12
Last.fm Authentifizierung, Now Playing und persistenter Scrobble-Versand sind implementiert. Für die Nutzung werden einmalig eigene Last.fm API-Zugangsdaten benötigt; im Projekt sind bewusst keine fremden oder erfundenen Schlüssel enthalten.


## v0.12
Die App besitzt jetzt ihre erste echte Now-Playing-Oberfläche im Bubatz-FM-Branding mit Albumcover, Metadaten, Fortschritt, Transportsteuerung, Radio-ON-AIR-Ansicht und getrenntem Einstellungsbereich.


## v0.12
Launcher-/Adaptive-Icon, explizite MediaSession-Transportkommandos und persistente Lockscreen-Metadaten sind ergänzt. Die App ist damit funktional deutlich näher an einem echten installierbaren Alltagsplayer.


## v0.12
Stabilitätsdurchgang vor dem ersten echten Android-SDK-Build. Manifest, Room, Compose, MediaSession und Last.fm-Auth wurden an mehreren konkreten Stellen korrigiert; ein automatischer Sanity-Checker liegt bei.


## v0.12
System-NEXT/PREVIOUS werden über eine Media3-ForwardingPlayer-Fassade in Bubatz FMs eigenen Shuffle-/History-Kern geleitet. Der Radioeinspieler-Schalter wirkt nun tatsächlich auf die Wiedergabe.


## v0.12
Enthält jetzt einen weitgehend automatischen Windows-/Linux-Buildweg. Unter Windows genügt im Normalfall ein Doppelklick auf `BUBATZ_FM_BAUEN.bat`; die fertige Debug-APK wird bei erfolgreichem Build in `FERTIGE_APK` abgelegt.


## v0.12
GitHub Actions kann das Projekt jetzt vollständig in der Cloud testen und als Debug-APK bauen. Der fertige Build wird als herunterladbares Actions-Artefakt bereitgestellt.


## Last.fm (v1.01)
Last.fm ist vollständig optional. Bubatz speichert weder einen festen Benutzeraccount noch fest eingebaute API-Zugangsdaten. API-Key und Shared Secret werden einmalig in den Einstellungen eingegeben und verschlüsselt lokal gespeichert. Anschließend kann ein beliebiger Last.fm-Account über die Browser-Freigabe verbunden, getrennt oder gewechselt werden. Scrobbling kann unabhängig vom verbundenen Account jederzeit deaktiviert werden.
