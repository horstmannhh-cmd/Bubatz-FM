# v1.49.06 – WIDGET_RIGHT_PANEL_MINIMUM_TEST

- Rechte Programmsektion als eigener Test von 148dp auf 116dp verkleinert.
- Referenz sind die aktuellen längsten Namen „Morgenglühen“ und „Der Nachtbus“.
- Ziel: beide einzeilig mit sichtbarer Innenluft; danach wird diese Breite eingefroren.
- Keine Änderungen an Playback, Shuffle/IQ, Cover, Brokkoli oder Logik.
- versionCode 362 / versionName 1.49.06.

# v1.49.05 – WIDGET_RIGHT_PANEL_COMPACT

- Nur rechte Programmsektion geändert.
- Programmsektion: 126dp -> 148dp.
- Programmname, Brokkoli, Playback, Shuffle/IQ, Cover und Logik sonst unverändert.

# v1.49.04 – WIDGET_CONTROL_ROW_EXACT_FIT

- Neu auf dem vollständigen v1.49.00-Widget aufgebaut.
- Ursache der bisherigen Clipping-Versuche berücksichtigt: die untere Zeile hat keinen Platz für gleichzeitig vergrößerte Controls + Spacer + 78dp Bubatz.IQ.
- Keine vergrößerten Control-Views und kein gewichteter Spacer mehr.
- Exakte horizontale Belegung: 28dp Zurück + 8dp Abstand + 32dp Pause + 8dp Abstand + 28dp Weiter + 12dp Abstand + 78dp Bubatz.IQ = 194dp.
- Dadurch bleiben Zurück, Pause, Weiter sowie Shuffle + IQ vollständig innerhalb der verfügbaren Zeile.
- Bubatz.IQ sitzt durch den 12dp-Abstand klar getrennt vom Playback-Block und weiter rechts.
- Shuffle-Drawable und IQ-Optik gegenüber v1.49.00 unverändert.
- Cover-Rundung und rechte Programmseite unverändert.
- versionCode 360 / versionName 1.49.04.

# v1.48.99 – WIDGET_INFLATION_FIX_AND_ROUNDED_COVER

- Kritischen v1.48.98-Fehler behoben: der flexible `Space` im App-Widget wurde durch ein RemoteViews-kompatibles gewichtetes `LinearLayout` ersetzt. Das war die neue Layout-Komponente, die das Widget beim Hinzufügen scheitern lassen konnte.
- Die Entzerrung aus v1.48.98 bleibt erhalten: Playback links, Bubatz.IQ rechts vor der Trennlinie.
- Widget-Cover erhalten jetzt bewusst eine moderate Rundung (ca. 5,5 % der Coverkante), ausschließlich im Widget.
- Kein zusätzlicher Coverrahmen hinzugefügt; im Layout existiert auch kein expliziter Rahmen um `widget_cover`.
- Shuffle-Geometrie und Wiedergabe-/Bubatz.IQ-Logik unverändert.
- Rechte Programmseite unverändert.

# v1.48.98 – WIDGET_CONTROL_SPACING_IQ_FINISH

- Playback-Bedienung entzerrt: Zurück, Play/Pause und Weiter erhalten größere getrennte Touchflächen und mehr horizontalen Abstand.
- Bubatz.IQ wird durch einen flexiblen Spacer als geschlossene Statuskennung nach rechts zur vertikalen Trennlinie geschoben.
- Shuffle-Geometrie bleibt exakt auf dem funktionierenden Stand eingefroren.
- Shuffle und IQ verwenden jetzt denselben gedämpften Sage/Lime-Kern; deckungsgleicher enger Licht-Layer leicht verstärkt, ohne Button-Glow.
- Keine versetzten Reliefkopien, damit die Pfadtrennung der Shuffle-Geometrie nicht zugeschmiert wird.
- Rechte Widget-Seite unverändert.
- Playback-/Shuffle-/Bubatz.IQ-Logik unverändert.

# v1.48.97 – WIDGET_CONTROLS_AND_IQ_SEPARATION

- Korrekte Shuffle-Geometrie aus v1.48.95 bleibt unverändert.
- Versetzte Relief-Duplikate entfernt, die die getrennten Shuffle-Stränge optisch zu einer massiven Fläche verschmolzen haben.
- Nur noch deckungsgleicher, schwacher Licht-Layer unter dem scharfen Original: Kreuzung/Aussparungen bleiben lesbar.
- Bedienleiste entzerrt: Bubatz.IQ etwas kompakter, Abstand reduziert, Zurück/Weiter erhalten breitere sichere Renderboxen und weniger Innenpadding.
- Ziel: Zurück-Balken und Weiter-Balken vollständig sichtbar, symmetrischere Steuerleiste.
- Rechte Widget-Seite unverändert.
- Playback-/Shuffle-/Bubatz.IQ-Funktionalität unverändert.

# v1.48.96 – WIDGET_IQ_INSET_FINISH

- Die in v1.48.95 endlich korrekte Player-Shuffle-Geometrie ist unverändert eingefroren.
- Ausschließlich Material-/Relief-Finish ergänzt: dunkle versetzte Tiefenkante + sehr feine helle Gegenkante.
- Kernfarbe bleibt gedämpft Sage/Lime; kein flächiger Neon-Glow.
- IQ erhält passend dazu nur einen engen, dunklen Reliefschatten.
- Ziel: eingelassene, leicht hinterleuchtete Gerätekennzeichnung statt Bedienelement.
- Rechtes Widget-Panel und sämtliche Playback-/Shuffle-/Bubatz.IQ-Logik unverändert.

# v1.48.95 – WIDGET_IQ_REAL_PLAYER_SHUFFLE

- Der handgezeichnete/gerasterte Widget-Shuffle wurde vollständig entfernt.
- Das Widget verwendet jetzt direkt `ic_widget_iq_shuffle.xml` mit der 24×24-Material-Shuffle-Pfadgeometrie, passend zum `Icons.Default.Shuffle` des Hauptplayers.
- Shuffle und `IQ` werden separat nativ gerendert; dadurch bleiben die Pfeilspitzen beim Skalieren scharf.
- Keine neue Eigeninterpretation der Shuffle-Form.
- Zurückhaltende Sage-Farbe; kein zusätzlicher Neon-Glow.
- Rechtes Widget-Panel unverändert.
- Playback-/Shuffle-/Bubatz.IQ-Logik unverändert.

# v1.48.94 – WIDGET_IQ_PLAYER_GEOMETRY

- Bubatz.IQ-Shuffle im Widget an der Geometrie des Hauptplayers ausgerichtet.
- Die beiden rechten Ausgänge liegen jetzt deutlich auseinander; große Pfeilspitzen oben rechts und unten rechts bleiben auch nach Launcher-Skalierung erkennbar.
- Keine hakenförmigen Enden und kein kompaktes X mehr.
- Farbe, Größe, zurückhaltender Glow und IQ-Darstellung beibehalten.
- Rechtes Panel aus v1.48.92 unverändert.
- Playback-/Shuffle-/Bubatz.IQ-Logik unverändert.

# v1.48.93 – WIDGET_IQ_CLASSIC_SHUFFLE

- Ausschließlich die Shuffle-Silhouette von Bubatz.IQ im Widget neu aufgebaut.
- Zwei klar getrennte Eingänge links, längere Kreuzungswege und zwei große, voneinander getrennte, eindeutig nach rechts gerichtete Dreieckspfeile.
- Keine hakenartigen Enden und keine X-/Vierarm-Symmetrie.
- Farbe, zurückhaltender Glow, Relief und IQ-Darstellung beibehalten.
- Rechtes Widget-Panel aus v1.48.92 unverändert.
- Playback-, Shuffle- und Bubatz.IQ-Logik unverändert.

# v1.48.92 – WIDGET_RIGHT_PANEL_STABILIZE

- Ursache der scheinbar mitwandernden rechten Widget-Seite eingegrenzt: Zwischen v1.48.90 und v1.48.91 war der rechte Bereich im Quellcode identisch; die feste 62-dp-Höhe des Brokkoli-Bildes konnte jedoch je nach tatsächlich zugeteilter Widget-Höhe geclippt bzw. anders sichtbar werden.
- Rechtes Panel stabilisiert: Der Programmname behält seine natürliche Höhe, der Brokkoli nutzt ausschließlich die verbleibende Höhe per layout_weight.
- Zusätzliche interne Safe-Area am Brokkoli gegen Clipping.
- Bubatz.IQ-Grafik, Playback und gesamte Wiedergabe-/Shuffle-/IQ-Logik in diesem Build nicht verändert.

# v1.48.91 – WIDGET_IQ_SHUFFLE_GEOMETRY

- Nur die Shuffle-Geometrie des statischen Widget-Bubatz.IQ korrigiert.
- Zwei klar getrennte Eingänge links, zwei sich kreuzende Wege und zwei große, eindeutig nach rechts gerichtete Dreieck-Pfeilspitzen.
- Keine hakenförmigen Enden / keine vierarmige Symmetrie mehr.
- Zurückhaltende Farbe, enger Glow, Relief, IQ-Größe und rechte Widget-Seite aus v1.48.90 beibehalten.
- Playback-/Shuffle-/Bubatz.IQ-Logik unverändert.

# v1.48.90 – WIDGET_IQ_SUBTLE_INSET

- Bubatz.IQ im Standard-Widget visuell zurückgenommen: klare Konturen bleiben erhalten, aber geringere Leuchtdominanz.
- Enger, schwacher Lichtsaum statt großflächigem Glow.
- Dunkle Reliefkante und feine Lichtkante verstärken den Eindruck einer eingelassenen Gerätebeschriftung.
- Größenbalance bleibt bewusst gut lesbar; kein Zurückskalieren zum matschigen Frühzustand.
- Rechte Widget-Seite sowie Playback-/Shuffle-/Bubatz.IQ-Logik unverändert.

## v1.48.89 – WIDGET_IQ_FINETUNE
- Standard-Widget: Bubatz.IQ optisch feinpoliert.
- IQ moderat größer und kräftiger; Shuffle/IQ neu ausbalanciert.
- Kernfarbe frischer in Richtung Player-Lime, Glow eng und deutlich reduziert.
- Subtile dunkle/helle Reliefkante für eingelassene Armaturenwirkung.
- Rechte Programmfläche und Brokkoli unverändert.
- Keine Änderung an Playback-, Shuffle- oder Bubatz.IQ-Logik.

## v1.48.87 – WIDGET_PROGRAM_HERO
- Widget rechts: Variante A umgesetzt.
- Programmname oben, darunter deutlich größerer Brokkoli mit Radiowellen.
- Bubatz.FM-Wortmarke bleibt bewusst entfernt.
- Brokkoli näher an den Programmnamen gerückt; Safe-Area bleibt erhalten.
- Keine Änderung an Playback- oder Bubatz.IQ-Logik.

# v1.48.86 — WIDGET RIGHT PANEL + IQ POLISH

- Standard-Widget: rechter Bereich vereinfacht: Programmname + Brokkoli/Radiowellen-Signet, kompletter Bubatz.FM-Schriftzug entfernt.
- Brokkoli-Signet mit zusätzlichem Innenraum und fitCenter, damit Stumpf und linke Radiowellen nicht geclippt werden.
- Bubatz.IQ-Fläche leicht vergrößert, damit das lebende Signet mehr Safe-Area erhält.
- Playback-, Shuffle- und Bubatz.IQ-Logik unverändert.

## v1.48.26
- Titelinformationen: Teilen mit Auswahl zwischen Text und Audiodatei.
- Teilen ist sowohl beim aktuellen Titel als auch in „Zuletzt gehört“ verfügbar.
- Seekbar: weicher Glow um den 16-dp-Punkt wieder deutlicher sichtbar.
- Keine Änderungen an Bubatz.IQ oder Playback-Logik.

## v1.47.33
- JETZT-Symbol: Abstand zwischen kleinem Brokkoli und beiden Wellengruppen minimal reduziert.
- Größen, Symbolposition, Textlayout und Wiedergabelogik unverändert.

# v1.47.7

- Samsung Now Bar: ursprünglichen Brokkoli aus dem alten Stand vor den Wurst-Icon-Korrekturen wiederhergestellt.
- Das historische Symbol wurde inhaltlich nicht neu gezeichnet, sondern nur proportional verkleinert und zentriert, damit es nicht abgeschnitten wird.
- Keine Änderungen an Bubatz.IQ, Playback, Crossfade, Auto-Cue oder Storage-Fix.

# v1.47.3
- Stabilität: Wiedergabe von SAF-Dateien der SD-Karte nutzt für `com.android.externalstorage.documents` einen lokal abgelösten Dateideskriptor.
- Ziel: Ein Neustart/Absturz des Android ExternalStorageProvider beim Stöbern in sehr großen Ordnern soll die laufende Bubatz.FM-Wiedergabe nicht mehr via `DEPENDENCY_DIED` mitreißen.
- Bubatz.IQ-/Shuffle-Logik, Crossfade, Auto-Cue und UI unverändert.

## 1.46.9
- Wurst: Brokkoli wieder deutlich größer, monochrom und ohne Funkwellen.
- Eigenes Vektor-Small-Icon aus der ursprünglichen Bubatz-Brokkoli-Silhouette; Android/Samsung kann es passend zur Schrift einfärben.
- Sicherheitsrand rechts und leichte Linksverschiebung gegen Clipping beibehalten.
- Keine Änderungen an Bubatz.IQ, Shuffle oder Playback.

## v1.46.1
- Fix: BuildConfig generation enabled so automatic version display compiles.
- Keeps fixed broccoli zone and independent centered program text from v1.46.0.

# Bubatz.FM v1.45.7 – Diagnose-Build

- Sichtbarer roter Marker **DIAGNOSE 1.45.7** direkt unter dem Logo.
- Dient ausschließlich dazu, zweifelsfrei zu prüfen, ob GitHub und Android wirklich den aktuellen Quellstand bauen/installieren.
- Bubatz.IQ, Audio, Radio, Last.fm und History-Logik gegenüber v1.45.6 unverändert.
- GitHub-Workflow auf v1.45.7 aktualisiert und mit expliziter Build-Identitätsprüfung versehen.

## 1.46.8
- Samsung Now-Bar/"Wurst" icon: restored the detailed Bubatz broccoli artwork without radio waves.
- The notification bitmap now lives in `drawable-xxxhdpi` as a real 24dp-equivalent (96px) small icon instead of an oversized density-less drawable, preventing the right-side clipping seen with the prettier raster icon.
- Kept generous transparent safe margins and the slight left bias that worked in 1.46.6.
- No changes to Bubatz.IQ, shuffle, playback, crossfade or Auto-Cue logic.

## 1.47.8
- Build/Installations-Fix: Debug-Signing explizit an den Debug-Build gebunden.
- GitHub-Workflow von veralteten 1.45.7-Prüfungen bereinigt und auf 1.47.8 aktualisiert.
- CI prüft die erzeugte APK jetzt zusätzlich mit `apksigner` und `aapt`.
- Brokkoli-Icon aus 1.47.7 unverändert übernommen.

## v1.47.9
- Now-Bar/Notification-Brokkoli: restores the original v1.45.9 Media3 small icon artwork.
- The original glyph is only uniformly scaled down and centered to add Samsung safety margins; no redraw or silhouette changes.

## v1.47.29
- JETZT-Symbol: Brokkoli deutlich verkleinert; Radiowellen bleiben unverändert.
- Icon-Zone und Textlayout bleiben unverändert, damit sich die Schriftposition nicht verschiebt.
- Keine Änderungen an Bubatz.IQ oder Wiedergabelogik.

# v1.47.35 – Wurst-/Now-Bar-Diagnostik
- Erweitert die bestehende Omnia/Bubatz-Diagnose um Notification-SmallIcon, LargeIcon und App-/RoundIcon-Ressourcen.
- Zeigt Icon-Typ, Ressourcenpaket, Ressourcen-ID und Ressourcenname, soweit Android diese Informationen bereitstellt.
- Reine Diagnoseänderung: Wiedergabe, Bubatz.IQ, Shuffle, Crossfade, Last.fm und Artwork-Verhalten bleiben unverändert.
