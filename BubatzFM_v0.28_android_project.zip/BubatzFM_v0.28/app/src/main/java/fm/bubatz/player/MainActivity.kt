
package fm.bubatz.player

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import fm.bubatz.player.bluetooth.BluetoothDeviceRepository
import fm.bubatz.player.data.RadioClipEntity
import fm.bubatz.player.data.TrackEntity
import fm.bubatz.player.library.LibraryScanner
import fm.bubatz.player.library.ScanDiagnostics
import fm.bubatz.player.playback.PlaybackService
import fm.bubatz.player.scrobble.LastFmAuthCoordinator
import fm.bubatz.player.scrobble.LastFmConfig
import fm.bubatz.player.scrobble.LastFmSessionStore
import fm.bubatz.player.settings.AppSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val BubatzDark = Color(0xFF0F1A13)
private val BubatzGreen = Color(0xFF1F2E21)
private val BubatzMid = Color(0xFF375A36)
private val BubatzSage = Color(0xFF6A8A6A)
private val BubatzCream = Color(0xFFF2E9D2)
private val BubatzGold = Color(0xFFDCC9A1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 50)

        if (android.os.Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 51)

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = BubatzCream,
                    secondary = BubatzSage,
                    background = BubatzDark,
                    surface = BubatzGreen,
                    onPrimary = BubatzDark,
                    onBackground = BubatzCream,
                    onSurface = BubatzCream
                )
            ) {
                BubatzApp()
            }
        }
    }

    @Composable
    private fun BubatzApp() {
        var tab by rememberSaveable { mutableIntStateOf(0) }

        Scaffold(
            containerColor = BubatzDark,
            bottomBar = {
                NavigationBar(containerColor = BubatzGreen) {
                    NavigationBarItem(
                        selected = tab == 0,
                        onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.Radio, null) },
                        label = { Text("Player") }
                    )
                    NavigationBarItem(
                        selected = tab == 1,
                        onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.Settings, null) },
                        label = { Text("Einstellungen") }
                    )
                }
            }
        ) { padding ->
            Crossfade(targetState = tab, label = "main-tabs") { selected ->
                if (selected == 0) NowPlayingScreen(Modifier.padding(padding))
                else SettingsScreen(Modifier.padding(padding))
            }
        }
    }

    @Composable
    private fun NowPlayingScreen(modifier: Modifier = Modifier) {
        val db = (application as BubatzApplication).database
        val state by db.state().observe().collectAsState(initial = null)
        val scope = rememberCoroutineScope()

        var track by remember { mutableStateOf<TrackEntity?>(null) }
        var clip by remember { mutableStateOf<RadioClipEntity?>(null) }

        LaunchedEffect(state?.currentMediaId) {
            val mediaId = state?.currentMediaId
            track = null
            clip = null
            if (mediaId?.startsWith("track:") == true) {
                val id = mediaId.removePrefix("track:").toLongOrNull()
                track = id?.let { withContext(Dispatchers.IO) { db.tracks().byId(it) } }
            } else if (mediaId?.startsWith("radio:") == true) {
                val id = mediaId.removePrefix("radio:").toLongOrNull()
                clip = id?.let { withContext(Dispatchers.IO) { db.clips().byId(it) } }
            }
        }

        var visualPosition by remember(state?.currentPositionMs) {
            mutableLongStateOf(state?.currentPositionMs ?: 0L)
        }

        LaunchedEffect(state?.isPlaying, state?.currentPositionMs, state?.currentMediaId) {
            visualPosition = state?.currentPositionMs ?: 0L
            while (state?.isPlaying == true) {
                delay(500)
                visualPosition += 500
            }
        }

        val isRadio = clip != null
        val title = clip?.name ?: track?.title ?: "Bubatz FM"
        val artist = if (isRadio) "RADIOEINSPIELER" else track?.artist ?: "Bereit für Musik"
        val album = if (isRadio) "ON AIR" else track?.album.orEmpty()
        val duration = (state?.currentDurationMs ?: 0L).coerceAtLeast(track?.durationMs ?: clip?.durationMs ?: 0L)

        Column(
            modifier
                .fillMaxSize()
                .background(BubatzDark)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.bubatz_logo_horizontal),
                contentDescription = "Bubatz FM",
                modifier = Modifier.fillMaxWidth().height(72.dp),
                contentScale = ContentScale.Fit
            )

            Spacer(Modifier.height(18.dp))

            Surface(
                modifier = Modifier.fillMaxWidth().aspectRatio(1f),
                shape = RoundedCornerShape(26.dp),
                color = BubatzGreen,
                tonalElevation = 4.dp
            ) {
                if (isRadio) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Image(
                            painterResource(R.drawable.bubatz_logo_main_dark),
                            "Bubatz FM Einspieler",
                            Modifier.fillMaxSize().padding(28.dp),
                            contentScale = ContentScale.Fit
                        )
                    }
                } else {
                    AlbumArtwork(
                        uri = track?.uri,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            if (isRadio) {
                AssistChip(
                    onClick = {},
                    label = { Text("● ON AIR · BUBATZ FM") },
                    colors = AssistChipDefaults.assistChipColors(
                        labelColor = BubatzCream,
                        containerColor = BubatzMid
                    )
                )
                Spacer(Modifier.height(10.dp))
            }

            Text(
                text = title,
                color = BubatzCream,
                fontSize = 25.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 2
            )
            Spacer(Modifier.height(5.dp))
            Text(
                text = artist,
                color = if (isRadio) BubatzGold else BubatzSage,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
            if (album.isNotBlank()) {
                Text(
                    text = album,
                    color = BubatzSage.copy(alpha = 0.85f),
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
            }

            Spacer(Modifier.height(20.dp))

            val progress = if (duration > 0L) {
                (visualPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
            } else 0f

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(5.dp),
                color = BubatzGold,
                trackColor = BubatzMid
            )
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(visualPosition), color = BubatzSage, fontSize = 11.sp)
                Text(formatTime(duration), color = BubatzSage, fontSize = 11.sp)
            }

            Spacer(Modifier.height(14.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { sendPlaybackAction(PlaybackService.ACTION_PREVIOUS) }) {
                    Icon(Icons.Default.SkipPrevious, "Vorheriger Titel", tint = BubatzCream, modifier = Modifier.size(34.dp))
                }

                FilledIconButton(
                    onClick = { sendPlaybackAction(PlaybackService.ACTION_PLAY_PAUSE) },
                    modifier = Modifier.size(72.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = BubatzCream,
                        contentColor = BubatzDark
                    )
                ) {
                    Icon(
                        if (state?.isPlaying == true) Icons.Default.Pause else Icons.Default.PlayArrow,
                        if (state?.isPlaying == true) "Pause" else "Play",
                        modifier = Modifier.size(38.dp)
                    )
                }

                IconButton(onClick = { sendPlaybackAction(PlaybackService.ACTION_NEXT) }) {
                    Icon(Icons.Default.SkipNext, "Nächster Titel", tint = BubatzCream, modifier = Modifier.size(34.dp))
                }
            }

            Spacer(Modifier.height(10.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Shuffle, null, tint = BubatzSage, modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(6.dp))
                Text("RANDOM", color = BubatzSage, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(18.dp))
                Text("•", color = BubatzMid)
                Spacer(Modifier.width(18.dp))
                Text("BUBATZ.FM", color = BubatzGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(12.dp))
            Text(
                "Bluetooth- & Lockscreen-Steuerung aktiv",
                color = BubatzSage.copy(alpha = 0.75f),
                fontSize = 10.sp
            )

            Spacer(Modifier.height(24.dp))
        }
    }

    @Composable
    private fun AlbumArtwork(uri: String?, modifier: Modifier = Modifier) {
        // v0.22 diagnostics: do not parse embedded artwork until raw SAF playback
        // is proven stable. MediaMetadataRetriever can crash natively on malformed files.
        Box(modifier.background(BubatzGreen), contentAlignment = Alignment.Center) {
            Image(
                painterResource(R.drawable.bubatz_app_icon_dark),
                "Bubatz FM",
                Modifier.fillMaxSize().padding(52.dp),
                contentScale = ContentScale.Fit
            )
        }
    }

    @Composable
    private fun SettingsScreen(modifier: Modifier = Modifier) {
        val db = (application as BubatzApplication).database
        val scope = rememberCoroutineScope()
        val settings = remember { AppSettings(this) }

        val musicCount by db.tracks().observeCount().collectAsState(initial = 0)
        val clipCount by db.clips().observeCount().collectAsState(initial = 0)
        val autoBt by settings.autoBluetooth.collectAsState(initial = true)
        val autoBtAll by settings.autoBluetoothAllDevices.collectAsState(initial = true)
        val selectedBt by settings.autoBluetoothDeviceAddresses.collectAsState(initial = emptySet())
        val skipOnce by settings.autoBluetoothSkipOnce.collectAsState(initial = false)
        val crossfade by settings.crossfadeMs.collectAsState(initial = 6500)
        val radioEnabled by settings.radioEnabled.collectAsState(initial = true)

        val pairedDevices = remember { BluetoothDeviceRepository(this).pairedAudioDevices() }

        val lastFmStore = remember { LastFmSessionStore(this) }
        val lastFmAuth = remember { LastFmAuthCoordinator(this) }
        var lastFmUser by remember { mutableStateOf(lastFmStore.username) }
        var lastFmStatus by remember {
            mutableStateOf(if (lastFmUser != null) "Verbunden als $lastFmUser" else "Nicht verbunden")
        }

        var status by remember { mutableStateOf(ScanDiagnostics(this).read()) }

        val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            uri ?: return@rememberLauncherForActivityResult
            persist(uri)
            scope.launch {
                status = "Musik wird eingelesen …"
                val result = LibraryScanner(this@MainActivity).scanMusicDetailed(uri)
                var stored = 0
                result.tracks.chunked(1000).forEachIndexed { index, chunk ->
                    val inserted = db.tracks().insertAll(chunk)
                    stored += inserted.count { it != -1L }
                    status = "Bibliothek wird gespeichert … ${minOf((index + 1) * 1000, result.tracks.size)}/${result.tracks.size}"
                    ScanDiagnostics(this@MainActivity).save(status)
                }
                val s = result.stats
                status = buildString {
                    append("FERTIG / DB\n")
                    append("Ordner: ${s.directoriesVisited} · Dateien: ${s.filesVisited}\n")
                    append("Audio erkannt: ${s.audioRecognized}\n")
                    append("In Bibliothek neu: $stored\n")
                    append("Query-Fehler: ${s.queryErrors}")
                    result.error?.let { append("\nFehler: $it") }
                }
                ScanDiagnostics(this@MainActivity).save(status)
            }
        }

        val clipPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            uri ?: return@rememberLauncherForActivityResult
            persist(uri)
            scope.launch {
                status = "Einspieler werden eingelesen …"
                val items = LibraryScanner(this@MainActivity).scanRadio(uri)
                db.clips().insertAll(items)
                status = "${items.size} Einspieler geprüft"
            }
        }

        Column(
            modifier
                .fillMaxSize()
                .background(BubatzDark)
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            Image(
                painterResource(R.drawable.bubatz_logo_horizontal),
                "Bubatz FM",
                Modifier.fillMaxWidth().height(62.dp),
                contentScale = ContentScale.Fit
            )
            Spacer(Modifier.height(16.dp))

            SettingsCard("Bibliothek") {
                Text("$musicCount Musiktitel · $clipCount Einspieler", color = BubatzCream)
                Text(status, color = BubatzSage, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { musicPicker.launch(null) }) { Text("Musikordner") }
                    Button(onClick = { clipPicker.launch(null) }) { Text("Einspieler") }
                }
            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Wiedergabe-Diagnose") {
                var crashText by remember { mutableStateOf(CrashDiagnostics(this@MainActivity).read()) }
                Text(
                    "v0.28 testet den Start mit deaktiviertem Audio-Renderer. Nach einem Absturz hier auf „Aktualisieren“ tippen.",
                    color = BubatzCream,
                    fontSize = 11.sp
                )
                Spacer(Modifier.height(8.dp))
                Text(crashText, color = BubatzSage, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        crashText = CrashDiagnostics(this@MainActivity).read()
                    }) {
                        Text("Aktualisieren")
                    }
                    OutlinedButton(onClick = {
                        CrashDiagnostics(this@MainActivity).clear()
                        crashText = CrashDiagnostics(this@MainActivity).read()
                    }) {
                        Text("Löschen")
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Android-Absturzdiagnose") {
                var systemCrashText by remember {
                    mutableStateOf(CrashDiagnostics(this@MainActivity).readSystemExitInfo())
                }
                Text(
                    systemCrashText,
                    color = BubatzSage,
                    fontSize = 10.sp
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = {
                    systemCrashText = CrashDiagnostics(this@MainActivity).readSystemExitInfo()
                }) {
                    Text("Systemdiagnose aktualisieren")
                }
            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Radioeinspieler") {
                SettingSwitch(
                    "Automatische Einspieler aktiv",
                    radioEnabled
                ) { enabled ->
                    scope.launch { settings.setRadioEnabled(enabled) }
                }
                Text(
                    "Bei aktivierter Funktion ungefähr alle 25–35 Minuten. Einspieler werden nie überblendet und nie gescrobbelt.",
                    color = BubatzSage,
                    fontSize = 12.sp
                )
            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Crossfade") {
                Text("${crossfade / 1000.0} Sekunden · nur Musik → Musik", color = BubatzSage, fontSize = 12.sp)
                Slider(
                    value = crossfade.toFloat(),
                    onValueChange = { value -> scope.launch { settings.setCrossfadeMs(value.toInt()) } },
                    valueRange = 0f..15000f,
                    steps = 14
                )
                Text("Einspieler werden niemals überblendet.", color = BubatzGold, fontSize = 12.sp)
            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Bluetooth Auto-Start") {
                SettingSwitch(
                    "Automatisch bei Bluetooth-Audio starten",
                    autoBt
                ) { scope.launch { settings.setAutoBluetooth(it) } }

                if (autoBt) {
                    SettingSwitch("Alle Bluetooth-Audiogeräte", autoBtAll) {
                        scope.launch { settings.setAutoBluetoothAllDevices(it) }
                    }

                    if (!autoBtAll) {
                        pairedDevices.forEach { device ->
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = device.address in selectedBt,
                                    onCheckedChange = { enabled ->
                                        scope.launch {
                                            settings.setAutoBluetoothDeviceEnabled(device.address, enabled)
                                        }
                                    }
                                )
                                Text(device.name, color = BubatzCream)
                            }
                        }
                    }

                    OutlinedButton(
                        onClick = { scope.launch { settings.suppressNextBluetoothAutoStart() } },
                        enabled = !skipOnce
                    ) {
                        Text(
                            if (skipOnce) "Nächster Auto-Start wird übersprungen"
                            else "Beim nächsten Verbinden still bleiben"
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Last.fm") {
                Text(lastFmStatus, color = BubatzSage, fontSize = 12.sp)

                if (!LastFmConfig.configured) {
                    Text(
                        "API-Key und Shared Secret müssen einmalig in LastFmConfig.kt eingetragen werden.",
                        color = BubatzCream,
                        fontSize = 12.sp
                    )
                } else if (lastFmUser == null) {
                    Button(onClick = {
                        scope.launch {
                            runCatching {
                                val url = lastFmAuth.beginAuthorization()
                                lastFmAuth.openAuthorization(url)
                                lastFmStatus = "Im Browser freigeben, danach hier bestätigen."
                            }.onFailure {
                                lastFmStatus = it.message ?: "Last.fm-Anmeldung fehlgeschlagen"
                            }
                        }
                    }) { Text("Last.fm verbinden") }

                    OutlinedButton(onClick = {
                        scope.launch {
                            runCatching {
                                val session = lastFmAuth.finishAuthorization()
                                lastFmUser = session.username
                                lastFmStatus = "Verbunden als ${session.username}"
                            }.onFailure {
                                lastFmStatus = it.message ?: "Freigabe noch nicht abgeschlossen"
                            }
                        }
                    }) { Text("Freigabe abgeschlossen") }
                } else {
                    OutlinedButton(onClick = {
                        lastFmAuth.disconnect()
                        lastFmUser = null
                        lastFmStatus = "Nicht verbunden"
                    }) { Text("Last.fm trennen") }
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                "Bubatz FM · Version 0.28 Audio-Isolation",
                color = BubatzSage,
                fontSize = 11.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(24.dp))
        }
    }

    @Composable
    private fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
        Card(
            colors = CardDefaults.cardColors(containerColor = BubatzGreen),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(18.dp).fillMaxWidth()) {
                Text(title, color = BubatzCream, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                Spacer(Modifier.height(8.dp))
                content()
            }
        }
    }

    @Composable
    private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = BubatzCream, modifier = Modifier.weight(1f), fontSize = 13.sp)
            Switch(checked = checked, onCheckedChange = onChange)
        }
    }

    private fun sendPlaybackAction(action: String) {
        val i = Intent(this, PlaybackService::class.java).setAction(action)
        // The Activity is in the foreground, so a normal service start is enough.
        // Starting as a foreground service before a 40k-library initialization
        // finishes can trigger Android's foreground-service timeout.
        startService(i)
    }

    private fun persist(uri: Uri) {
        runCatching {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
    }

    private fun formatTime(ms: Long): String {
        if (ms <= 0) return "0:00"
        val total = ms / 1000
        val minutes = total / 60
        val seconds = total % 60
        return "$minutes:${seconds.toString().padStart(2, '0')}"
    }
}
