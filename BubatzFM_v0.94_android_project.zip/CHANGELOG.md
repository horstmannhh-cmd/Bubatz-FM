# Bubatz FM v0.94

- Random-/History-Navigation neu aufgebaut: eine eindeutige Verlaufsliste mit aktuellem Positionszeiger ersetzt die getrennten Back-/Forward-Stacks.
- Erwartetes Verhalten: A → B → C → Zurück B → Zurück A → Weiter B → Weiter C. Erst am Ende der bekannten History wird ein neuer Zufallstitel gewählt.
- Der Crossfade-Preloader respektiert jetzt ebenfalls vorhandene Vorwärts-History und würfelt nach einem Zurück nicht heimlich einen neuen Nachfolger aus.
- Previous springt innerhalb der vorhandenen History wirklich zum vorherigen Titel; am Anfang der History wird nur der aktuelle Titel neu gestartet.
- Die in v0.93 gelöste Samsung-Statusleisten-Laufschrift/MediaStyle-Notification bleibt unverändert.
- Keine Änderungen an Bibliothek, Last.fm, Omnia-Bridge oder Audio-/Crossfade-Engine außerhalb der History-Auswahl.

# Bubatz FM v0.93

- Isolierter Samsung-Statusleisten/Laufschrift-Test auf Basis von v0.92.
- Die Wiedergabe-Benachrichtigung wird nicht mehr aus Media3s erzeugter Notification rekonstruiert, sondern als saubere native Android `Notification.MediaStyle`-Benachrichtigung neu aufgebaut.
- Die native Benachrichtigung ist direkt mit der in v0.92 getesteten klassischen Plattform-MediaSession verbunden.
- Previous, Play/Pause und Next bleiben direkt mit dem echten Bubatz-Player verdrahtet.
- Ziel: ausschließen, dass Media3-spezifische Notification-Extras Samsungs kleine Titel-Laufschrift verhindern.
- Bibliothek, Random/History, Crossfade, Last.fm und Omnia-Bridge bleiben unverändert.

# Bubatz FM v0.92

- Gezielter Samsung-Statusleisten/Laufschrift-Test, keine neue Omnia-Bridge-Funktion.
- Bubatz' MediaStyle-Benachrichtigung wird mit einer klassischen Android-MediaSession verknüpft.
- Diese Plattform-Session meldet exakt das auf dem Zielgerät gemessene Omnia-Action-Profil `0xF37`.
- PlaybackState folgt nun der echten Bubatz-Wiedergabe (PLAYING/PAUSED), Geschwindigkeit bleibt Omnia-typisch bei `1.0`.
- AudioAttributes der Plattform-Session: `USAGE_MEDIA` + `CONTENT_TYPE_UNKNOWN`, passend zum gemessenen Omnia-Profil.
- Play/Pause, Previous, Next und Seek der Plattform-Session werden an den echten Bubatz-Player weitergereicht.
- Ziel: prüfen, ob Samsungs kleine Titel-Laufschrift oben neben der Uhr erscheint.
- Bibliothek, Random/History, Crossfade, Last.fm und Omnia-Bridge bleiben unverändert.

# Bubatz FM v0.91

- Omnia ist erstmals in die normale Playeransicht integriert.
- Solange Bubatz selbst spielt, bleibt Bubatz die sichtbare und steuerbare Quelle.
- Ist Bubatz pausiert/gestoppt und Omnia verbunden, zeigt der Player Omnias Titel, Interpret und Album.
- Zurück, Play/Pause, Weiter und Seek werden in diesem Modus an Omnia weitergereicht.
- Deutlicher OMNIA-Hinweis im Player, damit die aktive Quelle nicht verwechselt wird.
- Diagnose bleibt als Rückfallebene erhalten.

# v0.90

- Erste echte Omnia-MediaSession-Bridge auf Basis der in v0.88/v0.89 gemessenen Android-Sessions.
- Erkennt `com.rhmsoft.omnia` direkt im aktiven MediaSession-Stack.
- Zeigt Omnia-Titel, Interpret und Album in Bubatz FM an.
- Reagiert über MediaController-Callbacks unmittelbar auf Titel- und Playback-Änderungen.
- Play/Pause, Vor und Zurück werden direkt an Omnias echte MediaSession weitergereicht.
- Bestehende Bubatz-Wiedergabe, Bibliothek, Random/History, Crossfade und Last.fm bleiben unverändert.
- Bisherige Vergleichsdiagnose bleibt als Rückfallebene erhalten.

# Bubatz FM – Changelog

## v0.89.0 – Omnia-like TransportAction surface

- Based directly on the v0.88 device diagnostic.
- Narrows MediaSession-facing player commands that produced Bubatz `0x6fffcd` while Omnia exposed `0x0f37`.
- Removes externally advertised seek-back/seek-forward, queue-item seek, prepare, repeat, shuffle and playback-speed capabilities.
- Keeps play/pause, seek-in-track, previous and next available to Android.
- Internal playback, random/history, queue handling, crossfade, library and Last.fm scrobbling are unchanged.
- Diagnostic goal: check whether Samsung now ranks/displays Bubatz like Omnia and whether the legacy action mask moves substantially toward `0x0f37`.

# v0.88

- Gezielter TransportAction-Test nach dem v0.87-Bitvergleich.
- Externen Media3-Controllern werden PLAY/PAUSE sowie Previous/Next ausdrücklich als verfügbare Player-Kommandos angeboten.
- Playlist-Mutation bleibt weiterhin gesperrt; interne Zufalls-/History-/Crossfade-Logik bleibt unverändert.
- Diagnosebeschriftungen auf v0.88 aktualisiert.

# v0.86
- MediaSession verwendet nun einen BubatzSessionPlayer-Wrapper statt den ExoPlayer direkt.
- Der Session-facing Player entfernt COMMAND_CHANGE_MEDIA_ITEMS global, damit Media3 den Legacy-Queue-Command-Bit nicht mehr publiziert.
- Interne Queue-, Crossfade- und Zufallslogik arbeitet weiterhin direkt mit dem echten ExoPlayer.
- Diagnosehinweise auf v0.86 aktualisiert.

# v0.85

- Korrigiert die beiden MediaSession-Flag-Prüfungen in `NotificationComparisonService.kt`: `MediaController.flags` ist `Long`, die Android-Konstanten sind `Int`. Die Konstanten werden nun explizit mit `.toLong()` verglichen und gegen `0L` geprüft.
- Behebt damit die Kotlin-Compilerfehler in Zeile 158 und 160 aus dem GitHub-Actions-Build von v0.84.

# v0.84

- Build-Fix für die v0.83-MediaSession-Flag-Diagnose.
- Legacy-`MediaController.flags` werden korrekt als `Int` statt `Long` ausgewertet.
- Der nicht vorhandene Android-Framework-Schalter `FLAG_HANDLES_QUEUE_COMMANDS` wurde aus der Diagnose entfernt.
- Der eigentliche v0.83-A/B-Test bleibt unverändert: externe Media3-Controller erhalten weiterhin kein `COMMAND_CHANGE_MEDIA_ITEMS`.

# v0.83

- Nächster isolierter Omnia-Abgleich: Externe Media3-Controller erhalten kein `COMMAND_CHANGE_MEDIA_ITEMS` mehr.
- Ziel: Prüfen, ob dadurch Androids Legacy-`sessionFlags` von Bubatz von 7 auf Omnia-ähnliche 3 fallen.
- Diagnose zeigt die drei relevanten Legacy-Session-Flags jetzt einzeln an.
- Interne Queue, Zufallswiedergabe, Crossfade sowie die eigenen Previous/Next-Kommandos bleiben unverändert.
- AudioAttributes aus v0.82 bleiben unverändert (`USAGE_MEDIA` + `CONTENT_TYPE_UNKNOWN`).

# v0.82

- Produktiver Haupt- und Standby-Player verwenden jetzt `USAGE_MEDIA` + `AUDIO_CONTENT_TYPE_UNKNOWN`, passend zum aktuell gemessenen Omnia-MediaSession-Wert `sessionAudioContentType=0`.
- Diagnosebeschriftungen auf v0.82 aktualisiert.
- Diagnose-Probes bleiben unverändert, damit nur die produktive Media3-Klassifizierung isoliert getestet wird.

# v0.81

- Gezielter Omnia-Abgleich der produktiven Media3-AudioAttributes.
- Hauptplayer und Standby-Player verwenden nun explizit `USAGE_MEDIA` + `AUDIO_CONTENT_TYPE_MUSIC`.
- Hintergrund: v0.80 zeigte bei Omnia `sessionAudioContentType=2` (Music), bei Bubatz dagegen `0` (Unknown).
- Es werden ausschließlich öffentliche Media3-/Android-APIs verwendet.
- Keine Änderung an Crossfade, History, Resume, Seeking, Skip-Logik oder Benachrichtigungsaufbau.

# v0.80

- Kompakte Android-Audio-Pipeline-Diagnose auf Basis von v0.79.
- Zeigt Bubatz-UID, Omnia-UID sowie die Audio-Session-IDs von Haupt- und Standby-Player.
- Jede aktive `AudioPlaybackConfiguration` wird kurz mit Usage, Content-Type, Flags und einem Diagnose-Owner-Hinweis ausgegeben.
- Keine Hidden-API-Aufrufe; keine Änderung an Audio-Focus oder Wiedergabe.
- Player, Crossfade, History, Resume, Seeking, Skip-Logik und Benachrichtigung bleiben unangetastet.

# v0.79

- Build-Fix für Android-Audio-Pipeline-Diagnose: nur öffentliche `AudioPlaybackConfiguration`-APIs werden direkt verwendet.
- Diagnose protokolliert weiterhin AudioAttributes, Konfigurations-String und (API 31–35) AudioDeviceInfo.
- Keine Änderung an der eigentlichen Wiedergabe.

# v0.78

- Neuer kontrollierter Samsung-/Omnia-A/B-Test für echte Audio-Pipeline-Aktivität.
- Die bestehende native Diagnose-MediaSession `BubatzOmniaSpeedProbe` bleibt erhalten und meldet weiterhin Omnias beobachtete Legacy-Werte.
- Neu: manueller Button `Audio-Probe starten (6 s)` in der Omnia-Vergleichsdiagnose.
- Die Probe startet für sechs Sekunden einen separaten lokalen `AudioTrack` mit `USAGE_MEDIA` / `CONTENT_TYPE_MUSIC` und praktisch unhörbarem PCM (`volume=0.0001`).
- Es wird bewusst **kein** AudioFocus angefordert, damit weder Omnia noch der produktive Bubatz-Player pausiert oder geduckt werden.
- Die Probe-Session deklariert zusätzlich lokales Media-Playback über `setPlaybackToLocal(...)`.
- Produktiver Media3-Player, ExoPlayer, Crossfade, Cover-Handoff, Queue, Resume, History, Seeking und Skip-Logik bleiben unverändert.
- Testziel: Prüfen, ob Samsungs kompakte Medienanzeige reale Audio-Aktivität bzw. Audio-Historie des App-UIDs berücksichtigt.

# v0.76

- Kontrollierter Samsung-/Omnia-Test ohne Änderung des eigentlichen Players.
- Erstellt zusätzlich eine native Android-MediaSession `BubatzOmniaSpeedProbe`.
- Die Probe spiegelt die aktuellen Bubatz-Metadaten, meldet aber bewusst Omnias auffällige Kombination `STATE_PAUSED` + `playbackSpeed=1.0`.
- Für die Probe werden außerdem die bei Omnia beobachteten Legacy-Actions `0xF37` und Plattform-Session-Flags `3` gesetzt.
- Die produktive Media3-Session, ExoPlayer, Crossfade, Cover-Handoff, Resume, History, Seeking und Skip-Logik bleiben unverändert.
- Erwartung: Wenn Samsung jetzt Bubatz in der kompakten Now-Bar zeigt, liegt die Klassifizierung im Plattform-MediaSession-Pfad.

# v0.75

- MediaSession-Diagnose erweitert, ohne Wiedergabeverhalten zu verändern.
- Markiert `STATE_PAUSED` und eine gleichzeitig gemeldete von 0 abweichende `playbackSpeed`.
- Beobachtung auf Samsung/Android 16: Omnia meldet bei `playbackState=2` `playbackSpeed=1.0`,
  Bubatz FM dagegen `playbackSpeed=0.0`.
- Noch keine Änderung am Player. Dieser Unterschied wird zuerst isoliert geprüft.

# v0.74

- Behebt den Kotlin-Compilefehler aus v0.73:
  - `android.media.session.PlaybackState` besitzt auf der verwendeten API keinen `errorCode`-Accessor.
  - Diagnose verwendet stattdessen den kompatiblen `errorMessage`-Wert.
- Der neue Android-MediaSession-Stack-Vergleich bleibt vollständig erhalten.
- Notification-Verhalten unverändert gegenüber v0.72:
  - `ongoing=false`
  - `flags=0x60`
  - `priority=1`
- Keine Änderung an Wiedergabe, Crossfade, Cover-Handoff, Resume, History, Seeking oder Skip-Logik.

# v0.73

- Reine Tiefendiagnose nach dem negativen `priority=1`-Test aus v0.72.
- Notification-Verhalten bleibt unverändert:
  - `ongoing=false`
  - `flags=0x60`
  - `priority=1`
- Neu: direkter Vergleich des Android-`MediaSessionManager`-Stacks für Omnia und Bubatz FM.
- Pro aktiver Session werden protokolliert:
  - Package, Tag, Flags, RatingType, SessionActivity
  - PlaybackState, Position, Speed
  - verfügbare Playback-Actions
  - ActiveQueueItemId, BufferedPosition, ErrorCode
  - Titel, Interpret, Album, Dauer
  - Queue-Größe, Queue-Titel und Extras
- Ziel: prüfen, ob Samsung seine Statusleisten-/Now-Bar-Anzeige nicht aus der Notification, sondern aus dem System-MediaSession-Stack ableitet.
- Keine Änderung an Wiedergabe, Crossfade, Cover-Handoff, Resume, History, Seeking oder Skip-Logik.

# v0.72

- Einzeltest für Samsungs Now-Bar-Erkennung.
- Einzige relevante Änderung gegenüber v0.71:
  - `Notification.priority` von `0` auf `1` (`PRIORITY_HIGH`) wie bei Omnia.
- `ongoing=false` bleibt unverändert.
- `flags=0x60` bleibt unverändert.
- `category=transport`, `group=null`, MediaStyle, MediaSession, Channel und Metadatenlayout bleiben unverändert.
- Keine Änderung an Wiedergabe, Crossfade, Cover-Handoff, Resume, History, Seeking oder Skip-Logik.

Erwartung in der Vergleichsdiagnose:
- Bubatz FM: `ongoing=false`
- Bubatz FM: `flags=0x60`
- Bubatz FM: `priority=1`

Danach prüfen, ob Samsungs kleine Titelanzeige / Now Bar erscheint.

# v0.71

- Einzeltest für Samsungs Now-Bar-Erkennung.
- Einzige relevante Verhaltensänderung: Media-Notification nun `ongoing=false`, wie bei Omnia.
- `FLAG_ONGOING_EVENT (0x02)` wird ausdrücklich entfernt.
- `FLAG_NO_CLEAR`, `FOREGROUND_SERVICE`, `category=transport`, `group=null`, MediaStyle, MediaSession und Metadatenlayout bleiben unverändert.
- `priority` bleibt bewusst unverändert, damit nur eine Variable getestet wird.
- Keine Änderung an Wiedergabe, Crossfade, Cover-Handoff, Resume, History, Seeking oder Skip-Logik.

Erwartung in der Diagnose:
- Bubatz FM: `ongoing=false`
- Bubatz FM: `flags=0x60`
Danach prüfen, ob Samsungs kleine Titelanzeige / Now Bar erscheint.

# v0.70

- Letzte Diagnose-Runde: Omnia ↔ Bubatz FM Systemvergleich.
- Der NotificationListener liest nun `currentRanking` direkt als `RankingMap` aus.
- Pro Notification werden zusätzlich ausgegeben:
  - Ranking gefunden / Rank / Importance / Ranking-Channel
  - Bubble-/Conversation-/Suspended-/Ambient-Status
  - Channel-Name, -Importance, -Sound und Badge
  - Visibility, Priority, Small-/Large-Icon
- Der in v0.69 festgestellte Unterschied wird im Bericht festgehalten:
  - Bubatz FM: `ongoing=true`, `flags=0x62`
  - Omnia: `ongoing=false`, `flags=0x60`
- Keine Änderung an Wiedergabe, Crossfade, Cover-Handoff, Resume, History oder Notification-Verhalten.

# v0.69

- Reine Tiefendiagnose auf Basis des stabilen v0.68-Notification-Standes.
- Keine Änderung an Player, Crossfade, Cover-Handoff, History, Resume, Seeking oder Skip-Logik.
- Live-Diagnose erweitert um:
  - MediaSession-Token (Package, UID, Typ, ServiceName)
  - verfügbare Player-Kommandos
  - Playback-Suppression-Reason
  - Repeat-/Shuffle-Status
  - deklarierte PlaybackService-Eigenschaften inkl. Foreground-Service-Typ
- Omnia-Vergleich erweitert um:
  - Notification-Ranking
  - Ranking-Importance / Rank / Channel
  - Visibility / Priority
  - Large-/Small-Icon-Präsenz
  - zusätzliche Notification-Merkmale
- Ziel: den nächsten messbaren Unterschied zwischen Omnia und Bubatz FM finden, nachdem v0.68 bereits `flags=0x62`, `ongoing=true`, `group=null`, `category=transport` erreicht.

# v0.68

- Gleicher Notification-Flag-Satz wie Omnia:
  - Omnia: `flags=0x62`
  - Bubatz v0.67: `flags=0x6a`
- Der einzige zusätzliche Bubatz-Flag war `FLAG_ONLY_ALERT_ONCE` (`0x08`).
- v0.68 entfernt diesen Flag nach der Media3-Erstellung, sodass der Zielwert `0x62` erreicht werden soll.
- Diagnose zeigt zusätzlich `onlyAlertOnce=true/false`.
- `ongoing=true`, `group=null`, `category=transport`, `FOREGROUND_SERVICE` und `NO_CLEAR` bleiben erhalten.
- Player, Crossfade, Cover-Handoff, History, Resume, Seeking und Skip-Logik bleiben unangetastet.

# v0.67

- Nächste gezielte Omnia-Angleichung nach erfolgreichem v0.66-Build.
- Ergänzt `FLAG_NO_CLEAR`, weil Omnia in der Vergleichsdiagnose `flags=0x62` verwendet.
- Metadata-Layout nun wie bei Omnia: `title=Titel`, `text=Interpret`, `subText=Album`.
- Diagnose zeigt jetzt die exakten Notification-Flags sowie `noClear` und `foregroundService`.
- `ongoing=true`, `group=null`, `category=transport` und Kanal `bubatz_media_playback` bleiben erhalten.
- Player, Crossfade, Cover-Handoff, History, Resume, Seeking und Skip-Logik bleiben unangetastet.

# v0.66

- Behebt die drei konkreten Kotlin-Compilefehler aus v0.65.
- Entfernt `getNotificationChannelInfo()`: Diese API gehört in der verwendeten Media3-Version nicht zum `MediaNotification.Provider`-Interface.
- Entfernt `setSmallIcon()` aus `PlaybackService`: Der Wrapper stellt diese Methode nicht bereit; das interne `DefaultMediaNotificationProvider` setzt das Icon bereits selbst.
- Die Omnia-Angleichung bleibt unverändert: `ongoing=true`, `group=null`, `category=transport`, eigener Kanal `bubatz_media_playback`, Titel `Titel – Interpret`.
- Player, Crossfade, Cover-Handoff, History, Resume, Seeking und Skip-Logik bleiben unangetastet.

# v0.65

- Behebt den Kotlin-Syntaxfehler aus v0.64 in `getNotificationChannelInfo()`.
- Die eigentliche Omnia-Angleichung bleibt unverändert:
  - `ongoing=true`
  - `group=null`
  - `category=transport`
  - eigener Kanal `bubatz_media_playback`
  - Titel `Titel – Interpret`
- Player, Crossfade, Cover-Handoff, History, Resume, Seeking und Skip-Logik bleiben unangetastet.

# v0.64

- Behebt den v0.63-Buildfehler: `DefaultMediaNotificationProvider.createNotification()` ist final und kann nicht überschrieben werden.
- BubatzMediaNotificationProvider implementiert deshalb `MediaNotification.Provider` und delegiert die Standardarbeit an Media3.
- Die von Media3 erzeugte Notification wird **vor dem Posten** auf die Omnia-Werte angepasst: `ongoing=true`, `group=null`, `category=transport`.
- Auch asynchrone Notification-Updates laufen durch denselben Wrapper.
- Der eigene Kanal `bubatz_media_playback` bleibt erhalten.
- Player, Crossfade, Cover-Handoff, History, Resume, Seeking und Skip-Logik bleiben unangetastet.

# v0.61

- Behebt ausschließlich den Kotlin-Compilefehler aus v0.60.
- Ursache: ungültige Zeichenliterale `\\n` in der neuen Omnia-Notification-Diagnose.
- Die eigentliche v0.60-Logik bleibt unverändert: `ongoing=true`, `group=null`, `category=transport` und Bubatz-Notification-Provider.
- Player, Crossfade, Cover-Handoff, History, Resume, Seeking und Skip-Logik bleiben unangetastet.

# v0.60

- Omnia-Vergleich umgesetzt: Media-Notification wird nach Media3-Erstellung auf `ongoing=true`, `group=null` und `category=transport` angeglichen.
- BubatzMediaNotificationProvider wieder aktiv: Notification-Titel liefert `Titel – Interpret`.
- Media3 1.6.0 → 1.6.1 (enthält einen Fix rund um `setMediaNotificationProvider`).
- Zusätzliche Diagnose `v0.60: Omnia-Notification-Angleichung`.

Testziel: Während ein Titel läuft, Einstellungen → Wiedergabe-Diagnose → Vergleich laden. Bei Bubatz FM sollen insbesondere `ongoing=true` und `group=null` erscheinen. Danach prüfen, ob oben neben der Uhrzeit die Liveanzeige erscheint.

# v0.59
- Omnia-Vergleichsdiagnose via NotificationListenerService
- Direkter Vergleich aktiver Media-Benachrichtigungen (Paket, ongoing, promoted/promotable, Channel/Importance, MediaStyle/MediaSession, Titel/Text, Flags)
- Schaltfläche zum Android-Benachrichtigungszugriff
- v0.58 Cover-Handoff-Fix unverändert beibehalten

# Bubatz FM v0.58

- Behebt die eigentliche Ursache des kurz aufblitzenden Brokkoli-Platzhalters.
- Beim automatischen Musik→Musik-Wechsel wird der bisherige Track nicht mehr vor dem Datenbank-Lookup auf null gesetzt.
- Altes Cover/Titelobjekt bleibt sichtbar, bis der neue Track vollständig aus der Bibliothek geladen wurde.
- AlbumArtwork behält zusätzlich weiterhin das alte Bitmap, bis das neue eingebettete Cover geladen ist.
- Keine Änderung an Wiedergabe, Crossfade, MediaSession, History, Resume, Seeking oder Skip-Logik.
- Android-16-Live-Diagnose bleibt erhalten.

# Bubatz FM v0.57

- Live-/Samsung-Diagnose bekommt einen eigenen Speicherplatz und wird nicht mehr von normalen Playback-/Crossfade-Logs überschrieben.
- Einstellungen lesen gezielt diesen Live-Diagnosebericht.
- Albumcover-Flicker behoben: Beim automatischen Titelwechsel bleibt das bisherige Cover sichtbar, bis das neue eingebettete Cover fertig geladen ist.
- Nur wenn der neue Titel tatsächlich kein Cover besitzt, erscheint anschließend der Brokkoli-Platzhalter.
- Wiedergabe, Crossfade, History, Resume, Seeking, Skip-Logik und MediaSession bleiben unverändert.

# Bubatz FM v0.56

- Behebt die v0.55-Diagnose, deren Android-16-Live-Werte im UI nicht sichtbar wurden.
- Samsung- und Android-16-Live-Diagnose werden jetzt in einem einzigen Bericht gespeichert.
- Sichtbar werden insbesondere canPostPromotedNotifications, hasPromotableCharacteristicsApi, setRequestPromotedOngoingApi und FLAG_PROMOTED_ONGOING.
- Keine Änderung an Wiedergabe, Crossfade, History, Resume, Seeking, Skip-Logik oder MediaSession.

# Bubatz FM v0.55

- Reiner Diagnose-Build für Android 16 / Samsung One UI Live-/Promoted-Notification-Fähigkeiten.
- Prüft per Reflection, ob canPostPromotedNotifications(), hasPromotableCharacteristics() und setRequestPromotedOngoing() auf dem Gerät vorhanden sind.
- Prüft zusätzlich, ob FLAG_PROMOTED_ONGOING existiert und bei der aktiven Medienbenachrichtigung gesetzt ist.
- Keine Änderung an Player, Crossfade, History, Resume, Seeking, Skip-Logik oder MediaSession.
- Compile-SDK und Build-Workflow bleiben unverändert.

# Bubatz FM v0.54

- Behebt ausschließlich den Compile-Fehler aus v0.53.
- Fehlender Import für android.app.NotificationChannel ergänzt.
- Der eigentliche v0.53-Test bleibt unverändert: eigener stiller Medienkanal + standardmäßiger Media3-Provider.
- Keine Änderung an Player, Crossfade, History, Resume, Seeking oder Skip-Logik.

# Bubatz FM v0.53

- Gezielter Samsung-/One-UI-Test auf Basis der v0.52-Diagnose.
- Eigener Notification-Kanal „bubatz_media_playback“ mit IMPORTANCE_LOW, ohne Ton, ohne Vibration und ohne Badge.
- Standardmäßiger Media3-Notification-Provider bleibt zuständig; kein eigener Notification-Renderer.
- MediaSession, Crossfade, History, Resume, Seeking und Skip-Logik bleiben unverändert.
- Ziel: prüfen, ob die aktive Medienbenachrichtigung nun als ongoing eingestuft wird und One UI daraufhin die kompakte Live-Anzeige neben der Uhr aktiviert.

# Bubatz FM v0.52

- Reiner Samsung-/One-UI-Diagnose-Build.
- Protokolliert die aktive Medienbenachrichtigung inklusive Ongoing-Flag, Kategorie, Notification-Style, Kanal und MediaSession-Extra.
- Protokolliert zusätzlich Android-Version, Hersteller, Modell sowie den aktuellen MediaSession-/Player-Zustand.
- Keine Änderung an Wiedergabe, Crossfade, Historie, Resume, Seeking oder Skip-Logik.
- Ziel: herausfinden, ob Bubatz FM von One UI anders klassifiziert wird als Omnia und welche Notification-/Session-Eigenschaft für die kompakte Live-Anzeige fehlt.

# Bubatz FM v0.51

- Nach v0.50 ist bestätigt: title, displayTitle, artist und album kommen korrekt bei Media3 an.
- Der v0.49-Ansatz über einen eigenen Notification-Provider wird für Android 13+ verworfen.
- v0.51 konzentriert sich wieder auf den standardkonformen MediaSession/SystemUI-Pfad.
- Wiedergabe, Crossfade, Historie, Resume, Seeking und Skip-Logik bleiben unangetastet.
- Ziel des Tests: prüfen, ob One UI Bubatz FM als echte Media-Ongoing-Activity/Live-Medienoberfläche behandelt, wenn nur der standardmäßige Media3-SystemUI-Pfad aktiv ist.

# Bubatz FM v0.50

- Reiner Diagnose-Build für Samsungs kompakte Live-Medienanzeige.
- Protokolliert die MediaMetadata des sessiongebundenen Hauptplayers nach ID3/Media3-Verarbeitung.
- Protokolliert separat die MediaMetadata, die der Media3-Notification-Provider erhält.
- Keine Änderung an Crossfade, Wiedergabe, History, Resume, Seeking oder Systemsteuerung.

# Bubatz FM v0.49

- Zweiter gezielter Versuch für die One-UI-Live-Medienanzeige neben der Uhr.
- Statt nur MediaMetadata.displayTitle zu setzen, verwendet Bubatz FM nun einen eigenen DefaultMediaNotificationProvider.
- Der echte Notification-Titel lautet „Titel – Interpret“.
- Kleines Benachrichtigungssymbol bleibt der Brokkoli.
- Hauptplayer, Crossfade, History, Resume, Seeking und Systemsteuerung bleiben unverändert.
- Ob One UI den Text scrollt bzw. wie breit der Chip wird, entscheidet weiterhin die Samsung-Systemoberfläche.

# Bubatz FM v0.48

- Stabiler v0.47-Crossfade bleibt unverändert.
- MediaMetadata.displayTitle enthält jetzt „Titel – Interpret“ für kompakte System-/Live-Medienflächen.
- Kanonische Felder title und artist bleiben getrennt, damit Player, Last.fm und Datenbank sauber bleiben.
- Media3-Standard-Benachrichtigungssymbol wird durch einen kleinen monochromen Brokkoli ersetzt.
- Kein eigenes Widget und keine kosmetische Player-Umgestaltung in diesem Build.
- Ob One UI den langen Display-Titel als Laufschrift animiert, entscheidet die Systemoberfläche selbst.

# Bubatz FM v0.47

- Feinschliff des bereits funktionierenden Crossfades.
- Standby bleibt nach der Musiküberblendung bei voller Lautstärke, bis der Hauptplayer nachweislich isPlaying ist und seine Position fortschreitet.
- Erst danach beginnt der interne Deck-Handoff.
- Zusätzliche 60 ms Pufferzeit stabilisiert den Audio-Sink vor dem Handoff.
- Interner Handoff leicht auf 220 ms verlängert, um Restdips zu vermeiden.
- Der eigentliche eingestellte Musik-Crossfade bleibt unverändert.

# Bubatz FM v0.46

- Korrigiert ausschließlich den veralteten Sanity-Check des v0.45-Builds.
- Der eigentliche Crossfade-/Handoff-Code aus v0.45 bleibt unverändert.
- Der Prüfer akzeptiert jetzt die neue Handoff-Variable firstHandoffPosition.

# Bubatz FM v0.45

- Behebt die kurze hörbare Unterbrechung am Ende des v0.44-Crossfades.
- Das Standby-Deck spielt weiter, während der Hauptplayer denselben Folgetitel stumm vorbereitet.
- Direkt vor dem Handoff wird der Hauptplayer auf die aktuelle Standby-Position synchronisiert.
- Danach erfolgt ein nur 180 ms langer interner Deck-Handoff ohne Stille.
- MediaSession bleibt weiterhin dauerhaft am stabilen Hauptplayer.
- Der einmal vorbereitete Folgetitel bleibt für den laufenden Übergang fest gewählt.
- Bei einem komplett neuen Testlauf desselben Ausgangstitels darf wegen Random-Wiedergabe weiterhin ein anderer Folgetitel gewählt werden.

# Bubatz FM v0.44

- Behebt den in v0.43 ausbleibenden Crossfade, ohne den stabilen Hauptplayer umzubauen.
- Nächster Titel wird jetzt unmittelbar nach Wiedergabestart des aktuellen Titels im Standby-Player vorbereitet.
- Dadurch hat SAF/SD-Karten-Zugriff nicht nur wenige Sekunden Zeit zum Prepare.
- 20 Sekunden vor Titelende wird notfalls erneut ein Preload versucht.
- Zusätzliche Diagnose protokolliert Standby-READY und Erreichen der Fade-Schwelle.
- Fade-Dauer bleibt über die bestehende Crossfade-Einstellung steuerbar (Standard 5 s).
- Manuelles Vor/Zurück bleibt weiterhin harter Wechsel; Radioeinspieler bleiben ausgeschlossen.

# Bubatz FM v0.43

- Erster neuer Musik→Musik-Crossfade auf Basis des stabilen v0.42-Players.
- Ein zweiter ExoPlayer wird ausschließlich als kurzlebiges Standby-Deck benutzt.
- MediaSession bleibt dauerhaft am stabilen Hauptplayer; kein Session-Player-Wechsel und damit kein Rückfall in den früheren Crash-Pfad.
- Equal-Power-Fade über die bereits vorhandene Crossfade-Einstellung (Standard 5 Sekunden).
- Nächster Titel wird ca. 3 Sekunden vor Beginn der Fade-Zone vorbereitet.
- Nach der Überblendung übernimmt der Hauptplayer denselben Titel an der bereits erreichten Position.
- In v0.43 crossfaden nur automatische Musik→Musik-Übergänge. Manuelles Vor/Zurück bleibt absichtlich ein harter Wechsel.
- Pause oder Seek während eines vorbereiteten/aktiven Crossfades bricht den Fade sauber ab.
- Radioeinspieler bleiben weiterhin vollständig aus dem Crossfade-Pfad heraus.

# Bubatz FM v0.42

- Live-/Medienbenachrichtigung aus v0.41 bleibt erhalten.
- Eigene MediaSession-Kommandos für Zurück und Weiter ergänzt.
- Android-Systemsteuerung bekommt bevorzugte Zurück-/Weiter-Buttons in den vorgesehenen Slots.
- Zurück verwendet exakt dieselbe Bubatz-FM-History wie der Hauptplayer.
- Weiter verwendet exakt dieselbe Forward-History bzw. Random-Logik wie der Hauptplayer.
- Play/Pause bleibt der Standard-Media3-Befehl.
- Hauptplayer-Layout bleibt absichtlich unverändert; Hamburger-Menü/untere Leiste stehen weiter auf der kosmetischen To-do-Liste.

# Bubatz FM v0.41

- Stabile v0.40-Wiedergabe bleibt unverändert.
- MediaSession wird nun explizit mit addSession(session) beim MediaSessionService registriert.
- PlaybackService ruft in onStartCommand jetzt immer die MediaSessionService-Superklasse auf (@CallSuper).
- Damit kann Media3 die Session beobachten und seine automatische Medien-/Foreground-Benachrichtigung erzeugen.
- Seek, Resume, History, Tags, Cover und Hintergrundwiedergabe bleiben unverändert.
- Falls die Benachrichtigung nun erscheint, werden ihre Bedienelemente anschließend separat getestet.

# Bubatz FM v0.40

- Funktionierende Seek-Logik aus v0.39 bleibt unverändert.
- Material-Standard-Slider durch einen kompakten Bubatz-FM-Regler ersetzt.
- Dünner durchgehender Balken, kleiner runder Griffpunkt, beige gespielter und grüner verbleibender Bereich.
- Antippen und Ziehen auf der gesamten unsichtbar größeren Touch-Fläche bleibt bequem möglich.
- Resume, History, Tags, Cover und Hintergrundwiedergabe unverändert.
- Medienbenachrichtigung bleibt separat auf der To-do-Liste.

# Bubatz FM v0.39

- Fortschrittsbalken im Player durch einen verschiebbaren Slider ersetzt.
- Der Regler zeigt beim Ziehen sofort die Zielzeit an.
- Beim Loslassen springt ExoPlayer exakt an die gewählte Position.
- Die neue Position wird direkt persistent gespeichert und damit auch für Resume verwendet.
- Bei Radioeinspielern bleibt Seeking vorerst deaktiviert.
- Stabiler v0.38-Unterbau, Bibliothek, Tags, Cover und Vor-/Zurück-Navigation bleiben unverändert.

# Bubatz FM v0.38

- Letzter Titel wird beim Service-/App-Neustart wieder als aktiver Titel geladen.
- Wiedergabeposition wird ungefähr alle 2 Sekunden persistent gespeichert.
- Play nach einem Neustart setzt denselben Titel an der gespeicherten Position fort, statt einen neuen Random-Titel zu wählen.
- Ein normales App-Update behält denselben Wiedergabestatus ebenfalls bei.
- Kein automatisches Losspielen beim normalen App-Start; dafür bleibt später Bluetooth-Autostart separat steuerbar.
- Bibliothek, Tags, Cover und Vor-/Zurück-Navigation bleiben unverändert.
- Medienbenachrichtigung bleibt weiterhin separat auf der To-do-Liste.

# Bubatz FM v0.37

- Behebt das Rückwärts-Kreisen der Navigation.
- Beispiel: A → B → Zurück = A; nochmal Zurück bleibt bei A/Anfang statt wieder zu B zu springen.
- Vorwärts-Historie bleibt erhalten: nach Zurück führt Vor weiterhin zurück zu B.
- Persistente DB-History wird nicht mehr als Fallback für wiederholtes Zurück innerhalb der laufenden Session benutzt.
- Die fehlende Medienbenachrichtigung ist bewusst noch nicht weiter verändert worden, um den stabilen Player nicht unnötig anzufassen.

# Bubatz FM v0.36

- Stabile v0.35-Wiedergabe und Navigation bleiben unverändert.
- PlaybackService im Manifest jetzt vollständig als MediaSessionService + mediaPlayback-Foreground-Service deklariert.
- FOREGROUND_SERVICE und FOREGROUND_SERVICE_MEDIA_PLAYBACK ergänzt.
- POST_NOTIFICATIONS ergänzt und auf Android 13+ beim Start angefragt.
- Media3 darf damit wieder seinen offiziellen automatischen MediaStyle-Benachrichtigungspfad verwenden.
- Titel/Interpret kommen aus den bereits funktionierenden MediaItem-Metadaten.
- Noch kein Crossfade/Radio/BT-Autostart in diesem Build.

# Bubatz FM v0.35

- Behebt Vor/Zurück-Navigation.
- Beispiel: A → B → C → Zurück ergibt B; danach Vor ergibt wieder C statt eines neuen Random-Titels.
- Mehrfaches Zurück/Vor funktioniert über getrennte Back-/Forward-Stacks.
- Nach mehr als 5 Sekunden startet Zurück weiterhin zunächst den aktuellen Titel neu.
- Persistente DB-History bleibt als Fallback nach einem Service-Neustart erhalten.
- Tags, Cover und der stabile v0.34-Minimalplayer bleiben unverändert.

# Bubatz FM v0.34

- Stabiler v0.33-Player bleibt die Basis.
- ID3/M4A-Metadaten werden nur für den gerade benötigten Titel gelesen, nicht mehr für 40.000 Dateien auf einmal.
- Titel, Interpret, Album und Laufzeit werden nach erfolgreichem Lesen in der bestehenden Datenbank nachgetragen.
- Der Dateiname bleibt nur Fallback, falls ein Tag fehlt.
- Eingebettetes Cover wird für den aktuell angezeigten Titel wieder im Player dargestellt.
- Noch keine Änderung an Crossfade, Radioeinspielern oder Bluetooth.

# Bubatz FM v0.33

- Stabiler v0.32-Minimalplayer bleibt die Basis.
- Echte Wiedergabe-History ergänzt.
- „Zurück“: nach mehr als 5 Sekunden wird der aktuelle Titel neu gestartet; nahe am Titelanfang wird der vorherige Titel geladen.
- History wird erst geschrieben, wenn ein Titel tatsächlich zu spielen beginnt.
- Play/Pause, Next und Hintergrundwiedergabe bleiben unverändert.
- Noch kein Crossfade und noch keine Radioeinspieler in diesem Build.

# Bubatz FM v0.32

- Behebt die Auswahl des Diagnosebuilds durch den GitHub-Workflow: jetzt wieder rein numerische Versionsnummer.
- Sanity-Check ist für den Minimalplayer explizit auf die tatsächlich benötigten Komponenten reduziert.
- Der Minimalplayer selbst bleibt gegenüber v0.31 unverändert.

# Bubatz FM v0.31b

- Korrigiert ausschließlich die Build-Pipeline des Minimalplayer-Diagnosebuilds.
- Die drei alten Architekturprüfungen für DualDeck/Radio/Previous werden für diesen Diagnosebuild bewusst übersprungen.
- Der eigentliche Minimalplayer-Code aus v0.31 bleibt unverändert.

# Bubatz FM v0.31 Minimalplayer

- PlaybackService vollständig neu und minimal aufgebaut.
- Nur EIN ExoPlayer und EINE MediaSession.
- DualDeck, Crossfade, Radioeinspieler, Last.fm, History-Wrapper und Session-Fassade sind aus dem Wiedergabepfad entfernt.
- Play/Pause/Next funktionieren direkt über den neuen Minimalplayer.
- Titelwahl bleibt fair-random über playCount.
- Aktueller Titel und Wiedergabestatus werden weiter in der bestehenden Datenbank gespeichert.
- Bibliothek bleibt vollständig erhalten; kein erneutes Einlesen nötig.
- Ziel dieses Builds: erstmals echte hörbare Wiedergabe über den Service stabil herstellen.

# Bubatz FM v0.30 Activity-Isolation

- Play-Taste startet für diesen Test keinen PlaybackService.
- Ein zufälliger Titel wird in den App-Cache kopiert und direkt von einem ExoPlayer in MainActivity verarbeitet.
- MediaSessionService, DualDeck und Foreground-Service sind vollständig aus dem Testpfad entfernt.
- Wiedergabe bleibt stumm und läuft 3 Sekunden.
- Wenn v0.30 stabil ist, liegt die Crash-Ursache eindeutig im Service/MediaSession-Lebenszyklus.
- Bibliothek bleibt unverändert erhalten.

# Bubatz FM v0.29 Local-File-Isolation

- Prüft, ob der Crash vom SAF/content://-Datenpfad stammt.
- Ein zufälliger Titel wird zunächst über ContentResolver in den App-Cache kopiert.
- ExoPlayer erhält danach ausschließlich eine lokale file://-URI.
- Wiedergabe bleibt stumm; der Test läuft 3 Sekunden.
- Wenn v0.29 stabil bleibt, liegt die Ursache sehr wahrscheinlich im direkten content://-Playback.
- Bibliothek bleibt unverändert erhalten.

# Bubatz FM v0.28 Audio-Isolation

- Isoliert den Absturz direkt nach playWhenReady=true.
- Der Audio-Renderer wird vor dem Aktivieren der Wiedergabe vollständig deaktiviert.
- Wenn der Prozess damit stabil bleibt, liegt der Crash sehr wahrscheinlich im Audio-Renderer/Decoder/AudioSink/Audio-Fokus-Pfad.
- ExoPlayer-Fehler und Playback-State-Änderungen werden zusätzlich persistent protokolliert.
- Noch keine hörbare Wiedergabe; Bibliothek bleibt unverändert erhalten.

# Bubatz FM v0.27 Post-prepare-Diagnose

- Testet ausschließlich die Schritte nach erfolgreichem prepare().
- Prüft volume=0, playWhenReady=true, 1,5 s aktiven Zustand, play(), erneut 1,5 s, pause() und release().
- Audio bleibt stumm, damit wir nur den technischen Wiedergabestart untersuchen.
- Jede Stufe wird persistent protokolliert.
- Bibliothek bleibt erhalten; kein erneutes Einlesen nötig.

# Bubatz FM v0.26 Stufendiagnose

- Wiedergabestart in klar getrennte Diagnose-Stufen zerlegt.
- Jede erreichte Stufe wird dauerhaft gespeichert, bevor die nächste beginnt.
- Geprüft werden: Service-Befehl, Initialisierung, Zufallstitel, URI, Dateizugriff, ExoPlayer-Erzeugung, MediaItem-Erzeugung, setMediaItem() und prepare().
- In v0.26 wird absichtlich noch KEIN play() aufgerufen.
- Ziel: exakt feststellen, welche einzelne Media3-Operation den Prozess beendet.
- Bibliothek bleibt vollständig erhalten; kein erneutes Einlesen nötig.

# Bubatz FM v0.25 Systemdiagnose

- Liest Androids eigene `ApplicationExitInfo`-Historie aus.
- Zeigt, ob der letzte Prozessabbruch ein Java-Crash, Native-Crash, ANR, Service-/Initialisierungsfehler, OS-Kill oder anderer Grund war.
- Liest vorhandene System-Traces aus, wenn Android sie bereitstellt.
- Für diesen Test muss Play NICHT erneut gedrückt werden: zuerst den bereits aufgezeichneten Absturz aus v0.24 auslesen.
- Bibliothek bleibt unverändert erhalten.

# Bubatz FM v0.24 Service-Fix

- Wichtiger Fix im MediaSessionService-Lebenszyklus.
- Eigene Bubatz-FM-Intents (Play/Pause/Next/Previous/Bluetooth-Autostart) werden nicht mehr an `MediaSessionService.super.onStartCommand()` weitergereicht.
- Hintergrund: v0.23 zeigte, dass der URI-Preflight vollständig erfolgreich war und der Prozess erst danach abstürzte. Damit liegt der Verdacht stark auf der Weitergabe des benutzerdefinierten Intent an MediaSessionService.
- v0.24 bleibt zunächst Preflight-only: Play prüft die Datei, startet aber noch keine Audioausgabe.
- Bibliothek bleibt vollständig erhalten; kein erneutes Einlesen nötig.

# Bubatz FM v0.23 URI-Preflight

- Crash-Schleife behoben: gespeicherter Wiedergabestatus wird beim Start sicher zurückgesetzt, Bibliothek bleibt erhalten.
- Play startet in dieser Diagnoseversion absichtlich noch keine Audioausgabe.
- Stattdessen wird ein Zufallstitel gewählt und sein SAF-/Content-URI direkt auf Lesbarkeit geprüft.
- Diagnose zeigt Titel-ID, URI, Scheme, Authority, Dateizugriff und Dateilänge.
- Damit lässt sich eindeutig feststellen, ob der Absturz vor ExoPlayer an einem ungültigen/unerreichbaren Dokument-URI liegt.
- Bibliothek muss nicht neu eingelesen werden.

# Bubatz FM v0.22 Diagnose

- Wiedergabestart protokolliert jeden kritischen Schritt dauerhaft.
- Unbehandelte Java/Kotlin-Abstürze werden dauerhaft gespeichert.
- ExoPlayer-Fehler werden mit mediaId und URI gespeichert.
- MediaMetadataRetriever wurde vollständig aus dem ersten Wiedergabeweg entfernt.
- Eingebettete Albumcover-Abfrage vorübergehend deaktiviert, um native Metadaten-Crashes auszuschließen.
- Play wartet jetzt sicher auf abgeschlossene Service-Initialisierung.
- Diagnose ist in Einstellungen → Wiedergabe-Diagnose sichtbar.
- Bestehende Bibliothek bleibt kompatibel; kein erneutes Einlesen nötig.

# Bubatz FM v0.21

- Wiedergabestart für sehr große Bibliotheken grundlegend entschärft.
- Kein Aufbau einer 40.000+-Zeilen-Shuffle-Queue mehr beim ersten Play.
- Persistentes Fair-Shuffle über playCount: jeder Titel kommt einmal dran, bevor Wiederholungen möglich werden.
- Frische Bibliothek wählt erst beim tatsächlichen Play-Befehl einen Titel, nicht beim Service-Start.
- Manuelle Player-Steuerung startet keinen unnötigen Foreground-Service vor der Wiedergabe.
- SAF-Metadatenzugriff vereinfacht.
- Audio-Datei-URI wird nicht mehr fälschlich als Artwork-URI an Media3 übergeben.
- Ein Titel gilt erst als gespielt, wenn die Wiedergabe tatsächlich startet, nicht schon beim Vorladen.
- Bestehende 40.836-Titel-Datenbank bleibt kompatibel; kein erneutes Einlesen nötig.

# Bubatz FM v0.20

- Bibliotheksimport für sehr große Sammlungen umgebaut: zuerst schnelle Dateierfassung und DB-Speicherung, keine 40.000 Metadaten-Lesevorgänge mehr vor dem ersten Datenbankeintrag.
- Metadaten werden bei Wiedergabe eines Titels bei Bedarf gelesen.
- DB-Import erfolgt in 1000er-Blöcken.
- Radioeinspieler-Timer zählt jetzt ausschließlich tatsächlich abgespielte MUSIK-Zeit.
- Pause, App-Schließzeit und Einspieler zählen nicht mit.
- Restzeit bis zum nächsten Einspieler wird persistent gespeichert.
- Nach jedem tatsächlich gestarteten Einspieler wird ein neuer Zufallswert von 25–35 Minuten gezogen.

# Bubatz FM v0.19 Diagnose persistent

- Diagnose wird jetzt dauerhaft in SharedPreferences gespeichert.
- Selbst nach Prozess-Neustart oder Absturz bleibt der letzte Scan-Zwischenstand sichtbar.
- Fortschritt wird bereits während Ordner-/Datei-Zählung und Metadatenphase gespeichert.
- Damit lässt sich unterscheiden: Prozessneustart, SAF-Query-Problem, Audio-Erkennung oder Metadatenphase.

# Bubatz FM v0.18 Diagnose

- Ordnerscanner auf direkte Android DocumentsContract-Abfragen umgestellt.
- Rekursive SD-Karten-Suche ohne DocumentFile.listFiles().
- Diagnoseanzeige: besuchte Ordner, Dateien, erkannte Audiodateien, Metadaten-Erfolge/-Fehler, Datenbank-Einfügungen und Query-Fehler.
- Ziel: den 0-Titel-Fehler auf dem realen Gerät eindeutig lokalisieren.

# Bubatz FM v0.17

- Fix: Musikdateien werden nicht mehr verworfen, wenn Android auf der SD-Karte keine Metadaten über MediaMetadataRetriever liefert.
- Metadatenlesung versucht zuerst einen FileDescriptor und fällt bei Bedarf auf die URI-Methode zurück.
- Audioerkennung nutzt zusätzlich den MIME-Type.
- Versionsanzeige auf 0.17 aktualisiert.

# Bubatz FM v0.16

- Fix: Kotlin-Kompilierfehler in `PlaybackService.kt` behoben.
- `dualDeck.activePlayer` ist eine Property und wird jetzt korrekt ohne `()` verwendet.
- Enthält weiterhin die v0.15/v0.14-Anpassungen (JVM 17, 5000 ms Crossfade-Referenz, Bibliotheks-Persistenz/Startlogik/Bluetooth-Autostart-Basis).

# v0.15

- Build-Fix: Java- und Kotlin-JVM-Target einheitlich auf 17 gesetzt.
- Dadurch wird der GitHub-Actions-Fehler bei `:app:kspDebugKotlin` behoben.

# Bubatz FM v0.14

- Bluetooth-Autostart wartet nun zuverlässig auf die Initialisierung des Players.
- Play aus komplettem Leerlauf kann selbst einen Titel aus der Bubatz-FM-Bibliothek auswählen.
- Standard-Crossfade auf 5000 ms gesetzt.
- Bibliothek bleibt in Room gespeichert; Musik wird weiterhin nur aus explizit ausgewählten Ordnern importiert.
- Versionsanzeige auf 0.14 aktualisiert.
