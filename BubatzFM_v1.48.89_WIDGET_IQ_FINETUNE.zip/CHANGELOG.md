## v1.48.89 – WIDGET_IQ_FINETUNE
- Standard-Widget: Bubatz.IQ optisch feinpoliert.
- IQ moderat größer und kräftiger; Shuffle/IQ neu ausbalanciert.
- Kernfarbe frischer in Richtung Player-Lime, Glow eng und deutlich reduziert.
- Subtile dunkle/helle Reliefkante für eingelassene Armaturenwirkung.
- Rechte Programmfläche und Brokkoli unverändert.
- Keine Änderung an Playback-, Shuffle- oder Bubatz.IQ-Logik.

## v1.48.87 – WIDGET_PROGRAM_HERO
- Widget rechts: Variante A umgesetzt.
- Programmname oben, darunter deutlich größerer Brokkoli mit Radiowellen.
- Bubatz.FM-Wortmarke bleibt bewusst entfernt.
- Brokkoli näher an den Programmnamen gerückt; Safe-Area bleibt erhalten.
- Keine Änderung an Playback- oder Bubatz.IQ-Logik.

# v1.48.86 — WIDGET RIGHT PANEL + IQ POLISH

- Standard-Widget: rechter Bereich vereinfacht: Programmname + Brokkoli/Radiowellen-Signet, kompletter Bubatz.FM-Schriftzug entfernt.
- Brokkoli-Signet mit zusätzlichem Innenraum und fitCenter, damit Stumpf und linke Radiowellen nicht geclippt werden.
- Bubatz.IQ-Fläche leicht vergrößert, damit das lebende Signet mehr Safe-Area erhält.
- Playback-, Shuffle- und Bubatz.IQ-Logik unverändert.

## v1.48.26
- Titelinformationen: Teilen mit Auswahl zwischen Text und Audiodatei.
- Teilen ist sowohl beim aktuellen Titel als auch in „Zuletzt gehört“ verfügbar.
- Seekbar: weicher Glow um den 16-dp-Punkt wieder deutlicher sichtbar.
- Keine Änderungen an Bubatz.IQ oder Playback-Logik.

## v1.47.33
- JETZT-Symbol: Abstand zwischen kleinem Brokkoli und beiden Wellengruppen minimal reduziert.
- Größen, Symbolposition, Textlayout und Wiedergabelogik unverändert.

# v1.47.7

- Samsung Now Bar: ursprünglichen Brokkoli aus dem alten Stand vor den Wurst-Icon-Korrekturen wiederhergestellt.
- Das historische Symbol wurde inhaltlich nicht neu gezeichnet, sondern nur proportional verkleinert und zentriert, damit es nicht abgeschnitten wird.
- Keine Änderungen an Bubatz.IQ, Playback, Crossfade, Auto-Cue oder Storage-Fix.

# v1.47.3
- Stabilität: Wiedergabe von SAF-Dateien der SD-Karte nutzt für `com.android.externalstorage.documents` einen lokal abgelösten Dateideskriptor.
- Ziel: Ein Neustart/Absturz des Android ExternalStorageProvider beim Stöbern in sehr großen Ordnern soll die laufende Bubatz.FM-Wiedergabe nicht mehr via `DEPENDENCY_DIED` mitreißen.
- Bubatz.IQ-/Shuffle-Logik, Crossfade, Auto-Cue und UI unverändert.

## 1.46.9
- Wurst: Brokkoli wieder deutlich größer, monochrom und ohne Funkwellen.
- Eigenes Vektor-Small-Icon aus der ursprünglichen Bubatz-Brokkoli-Silhouette; Android/Samsung kann es passend zur Schrift einfärben.
- Sicherheitsrand rechts und leichte Linksverschiebung gegen Clipping beibehalten.
- Keine Änderungen an Bubatz.IQ, Shuffle oder Playback.

## v1.46.1
- Fix: BuildConfig generation enabled so automatic version display compiles.
- Keeps fixed broccoli zone and independent centered program text from v1.46.0.

# Bubatz.FM v1.45.7 – Diagnose-Build

- Sichtbarer roter Marker **DIAGNOSE 1.45.7** direkt unter dem Logo.
- Dient ausschließlich dazu, zweifelsfrei zu prüfen, ob GitHub und Android wirklich den aktuellen Quellstand bauen/installieren.
- Bubatz.IQ, Audio, Radio, Last.fm und History-Logik gegenüber v1.45.6 unverändert.
- GitHub-Workflow auf v1.45.7 aktualisiert und mit expliziter Build-Identitätsprüfung versehen.

## 1.46.8
- Samsung Now-Bar/"Wurst" icon: restored the detailed Bubatz broccoli artwork without radio waves.
- The notification bitmap now lives in `drawable-xxxhdpi` as a real 24dp-equivalent (96px) small icon instead of an oversized density-less drawable, preventing the right-side clipping seen with the prettier raster icon.
- Kept generous transparent safe margins and the slight left bias that worked in 1.46.6.
- No changes to Bubatz.IQ, shuffle, playback, crossfade or Auto-Cue logic.

## 1.47.8
- Build/Installations-Fix: Debug-Signing explizit an den Debug-Build gebunden.
- GitHub-Workflow von veralteten 1.45.7-Prüfungen bereinigt und auf 1.47.8 aktualisiert.
- CI prüft die erzeugte APK jetzt zusätzlich mit `apksigner` und `aapt`.
- Brokkoli-Icon aus 1.47.7 unverändert übernommen.

## v1.47.9
- Now-Bar/Notification-Brokkoli: restores the original v1.45.9 Media3 small icon artwork.
- The original glyph is only uniformly scaled down and centered to add Samsung safety margins; no redraw or silhouette changes.

## v1.47.29
- JETZT-Symbol: Brokkoli deutlich verkleinert; Radiowellen bleiben unverändert.
- Icon-Zone und Textlayout bleiben unverändert, damit sich die Schriftposition nicht verschiebt.
- Keine Änderungen an Bubatz.IQ oder Wiedergabelogik.

# v1.47.35 – Wurst-/Now-Bar-Diagnostik
- Erweitert die bestehende Omnia/Bubatz-Diagnose um Notification-SmallIcon, LargeIcon und App-/RoundIcon-Ressourcen.
- Zeigt Icon-Typ, Ressourcenpaket, Ressourcen-ID und Ressourcenname, soweit Android diese Informationen bereitstellt.
- Reine Diagnoseänderung: Wiedergabe, Bubatz.IQ, Shuffle, Crossfade, Last.fm und Artwork-Verhalten bleiben unverändert.
