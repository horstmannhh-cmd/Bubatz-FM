
package fm.bubatz.player

import androidx.room.withTransaction
import android.Manifest
import androidx.compose.ui.graphics.asImageBitmap
import android.media.MediaMetadataRetriever
import android.graphics.BitmapFactory
import android.content.Intent
import android.provider.Settings
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.zIndex
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import fm.bubatz.player.bluetooth.BluetoothDeviceRepository
import fm.bubatz.player.data.RadioClipEntity
import fm.bubatz.player.data.RecentMusicItem
import fm.bubatz.player.data.TrackEntity
import fm.bubatz.player.library.LibraryScanner
import fm.bubatz.player.library.ScanDiagnostics
import fm.bubatz.player.diagnostics.OmniaBridge
import fm.bubatz.player.playback.PlaybackService
import fm.bubatz.player.playback.FlowCycleStore
import fm.bubatz.player.scrobble.LastFmAuthCoordinator
import fm.bubatz.player.scrobble.LastFmSessionStore
import fm.bubatz.player.settings.AppSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalTime

private val BubatzDark = Color(0xFF0F1A13)
private val BubatzGreen = Color(0xFF1F2E21)
private val BubatzMid = Color(0xFF375A36)
private val BubatzSage = Color(0xFF6A8A6A)
private val BubatzCream = Color(0xFFF2E9D2)
private val BubatzGold = Color(0xFFDCC9A1)

private data class ProgramSlot(val name: String, val timeLabel: String, val endLabel: String)

private val BubatzDailyProgram = listOf(
    ProgramSlot("Der Nachtbus", "0–3 Uhr", "3 UHR"),
    ProgramSlot("Dunstabzug", "3–6 Uhr", "6 UHR"),
    ProgramSlot("Morgenglühen", "6–9 Uhr", "9 UHR"),
    ProgramSlot("Blütezeit", "9–12 Uhr", "12 UHR"),
    ProgramSlot("High Noon", "12–15 Uhr", "15 UHR"),
    ProgramSlot("Abgedreht am Nachmittag", "15–18 Uhr", "18 UHR"),
    ProgramSlot("Klangsog", "18–21 Uhr", "21 UHR"),
    ProgramSlot("Sofaschwere", "21–0 Uhr", "MITTERNACHT")
)

private fun currentProgramSlot(now: LocalTime = LocalTime.now()): ProgramSlot = when (now.hour) {
    in 0..2 -> BubatzDailyProgram[0]
    in 3..5 -> BubatzDailyProgram[1]
    in 6..8 -> BubatzDailyProgram[2]
    in 9..11 -> BubatzDailyProgram[3]
    in 12..14 -> BubatzDailyProgram[4]
    in 15..17 -> BubatzDailyProgram[5]
    in 18..20 -> BubatzDailyProgram[6]
    else -> BubatzDailyProgram[7]
}

@Composable
private fun MiniBroccoliRadio(modifier: Modifier = Modifier) {
    // Keep the three source elements independent: large original waves,
    // a deliberately tiny broccoli "station dot", and tight spacing.
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.bubatz_wave_left),
            contentDescription = null,
            modifier = Modifier.size(width = 18.dp, height = 38.dp),
            contentScale = ContentScale.Fit,
            colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(BubatzSage)
        )
        Spacer(Modifier.width(0.dp))
        Image(
            painter = painterResource(id = R.drawable.bubatz_broccoli_mini),
            contentDescription = null,
            modifier = Modifier.size(14.dp),
            contentScale = ContentScale.Fit,
            colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(BubatzSage)
        )
        Spacer(Modifier.width(0.dp))
        Image(
            painter = painterResource(id = R.drawable.bubatz_wave_right),
            contentDescription = null,
            modifier = Modifier.size(width = 18.dp, height = 38.dp),
            contentScale = ContentScale.Fit,
            colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(BubatzSage)
        )
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 50)

        if (android.os.Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 51)

        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE), 52)
        }

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = BubatzCream,
                    secondary = BubatzSage,
                    background = BubatzDark,
                    surface = BubatzGreen,
                    onPrimary = BubatzDark,
                    onBackground = BubatzCream,
                    onSurface = BubatzCream
                )
            ) {
                BubatzApp()
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 52 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startService(
                Intent(this, PlaybackService::class.java)
                    .setAction(PlaybackService.ACTION_REFRESH_PHONE_MONITOR)
            )
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun BubatzApp() {
        var tab by rememberSaveable { mutableIntStateOf(0) }
        var showProgram by rememberSaveable { mutableStateOf(false) }
        val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
        val scope = rememberCoroutineScope()

        fun navigateTo(target: Int) {
            tab = target
            scope.launch { drawerState.close() }
        }

        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(
                    drawerContainerColor = BubatzGreen,
                    drawerContentColor = BubatzCream
                ) {
                    Spacer(Modifier.height(28.dp))
                    Image(
                        painter = painterResource(R.drawable.bubatz_logo_horizontal),
                        contentDescription = "Bubatz FM",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(72.dp)
                            .padding(horizontal = 20.dp),
                        contentScale = ContentScale.Fit
                    )
                    Spacer(Modifier.height(18.dp))
                    NavigationDrawerItem(
                        label = { Text("Player") },
                        selected = tab == 0,
                        onClick = { navigateTo(0) },
                        icon = { Icon(Icons.Default.Radio, null) },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    NavigationDrawerItem(
                        label = { Text("Tagesprogramm") },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            showProgram = true
                        },
                        icon = { Icon(Icons.Default.Schedule, null) },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    NavigationDrawerItem(
                        label = { Text("Zuletzt gehört") },
                        selected = tab == 2,
                        onClick = { navigateTo(2) },
                        icon = { Icon(Icons.Default.History, null) },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    NavigationDrawerItem(
                        label = { Text("Einstellungen") },
                        selected = tab == 1,
                        onClick = { navigateTo(1) },
                        icon = { Icon(Icons.Default.Settings, null) },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }
            }
        ) {
            Scaffold(containerColor = BubatzDark) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    Crossfade(targetState = tab, label = "main-tabs") { selected ->
                        when (selected) {
                            0 -> NowPlayingScreen(
                                modifier = Modifier.fillMaxSize(),
                                onShowProgram = { showProgram = true }
                            )
                            1 -> SettingsScreen(Modifier.fillMaxSize())
                            else -> RecentHistoryScreen(Modifier.fillMaxSize())
                        }
                    }
                    if (tab == 0) {
                        IconButton(
                            onClick = { scope.launch { drawerState.open() } },
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .statusBarsPadding()
                                .padding(start = 8.dp, top = 4.dp)
                                .size(48.dp)
                                .background(
                                    color = BubatzGreen.copy(alpha = 0.94f),
                                    shape = RoundedCornerShape(14.dp)
                                )
                                .zIndex(10f)
                        ) {
                            Icon(
                                Icons.Default.Menu,
                                contentDescription = "Menü",
                                tint = BubatzSage
                            )
                        }
                    } else {
                        FloatingActionButton(
                            onClick = { navigateTo(0) },
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .navigationBarsPadding()
                                .padding(end = 18.dp, bottom = 18.dp)
                                .zIndex(10f),
                            containerColor = BubatzGreen.copy(alpha = 0.96f),
                            contentColor = BubatzCream,
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Icon(
                                Icons.Default.ArrowBack,
                                contentDescription = "Zurück zum Player"
                            )
                        }
                    }
                }
            }
        }

        if (showProgram) {
            ProgramScheduleSheet(onDismiss = { showProgram = false })
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun ProgramScheduleSheet(onDismiss: () -> Unit) {
        var programSlot by remember { mutableStateOf(currentProgramSlot()) }
        LaunchedEffect(Unit) {
            while (true) {
                programSlot = currentProgramSlot()
                delay(30_000L)
            }
        }
        ModalBottomSheet(
            onDismissRequest = onDismiss,
            containerColor = BubatzGreen,
            contentColor = BubatzCream,
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 22.dp, end = 22.dp, bottom = 28.dp)
                    .navigationBarsPadding()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Bubatz.FM · TAGESPROGRAMM",
                    color = BubatzCream,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 14.dp)
                )
                val currentIndex = BubatzDailyProgram.indexOfFirst { it.name == programSlot.name }.coerceAtLeast(0)
                val orderedProgram = BubatzDailyProgram.drop(currentIndex) + BubatzDailyProgram.take(currentIndex)
                orderedProgram.forEach { slot ->
                    val isCurrent = slot.name == programSlot.name
                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                        shape = RoundedCornerShape(14.dp),
                        color = if (isCurrent) BubatzMid.copy(alpha = 0.72f) else Color.Transparent
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 11.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = slot.timeLabel,
                                color = if (isCurrent) BubatzGold else BubatzSage,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.width(88.dp)
                            )
                            Text(
                                text = slot.name,
                                color = BubatzCream,
                                fontSize = 14.sp,
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                                modifier = Modifier.weight(1f)
                            )
                            if (isCurrent) {
                                Text(
                                    text = "JETZT",
                                    color = BubatzGold,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.8.sp
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(96.dp))
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun NowPlayingScreen(modifier: Modifier = Modifier, onShowProgram: () -> Unit) {
        val db = (application as BubatzApplication).database
        val state by db.state().observe().collectAsState(initial = null)
        val omniaState by OmniaBridge.state.collectAsState()
        val scope = rememberCoroutineScope()

        var track by remember { mutableStateOf<TrackEntity?>(null) }
        var clip by remember { mutableStateOf<RadioClipEntity?>(null) }

        // Bubatz.FM program schedule is purely visual: it follows the device clock
        // and never changes playback, Bubatz.IQ, radio scheduling or audio behavior.
        var programSlot by remember { mutableStateOf(currentProgramSlot()) }
        LaunchedEffect(Unit) {
            while (true) {
                programSlot = currentProgramSlot()
                delay(30_000L)
            }
        }

        LaunchedEffect(state?.currentMediaId) {
            val mediaId = state?.currentMediaId

            if (mediaId?.startsWith("track:") == true) {
                // Keep the previous track (and therefore its cover) visible until
                // the database lookup for the new track has completed.
                val id = mediaId.removePrefix("track:").toLongOrNull()
                val newTrack = id?.let {
                    withContext(Dispatchers.IO) { db.tracks().byId(it) }
                }
                if (newTrack != null) {
                    track = newTrack
                    clip = null
                }
            } else if (mediaId?.startsWith("radio:") == true) {
                val id = mediaId.removePrefix("radio:").toLongOrNull()
                val newClip = id?.let {
                    withContext(Dispatchers.IO) { db.clips().byId(it) }
                }
                if (newClip != null) {
                    clip = newClip
                    track = null
                }
            } else if (mediaId == null) {
                track = null
                clip = null
            }
        }

        var visualPosition by remember(state?.currentPositionMs) {
            mutableLongStateOf(state?.currentPositionMs ?: 0L)
        }
        var isSeeking by remember { mutableStateOf(false) }
        var seekPreviewPosition by remember { mutableLongStateOf(0L) }

        LaunchedEffect(state?.isPlaying, state?.currentPositionMs, state?.currentMediaId, isSeeking) {
            if (!isSeeking) {
                visualPosition = state?.currentPositionMs ?: 0L
                while (state?.isPlaying == true && !isSeeking) {
                    delay(500)
                    visualPosition += 500
                }
            }
        }

        // v0.91 source arbitration: never steal the UI from Bubatz while its own
        // playback is active. If Bubatz is paused/stopped and Omnia has a live
        // MediaSession, the normal player becomes an Omnia remote surface.
        val useOmnia = state?.isPlaying != true && omniaState.connected && omniaState.hasMetadata
        val isRadio = !useOmnia && clip != null
        val title = when {
            useOmnia -> omniaState.title.ifBlank { "Omnia" }
            isRadio -> clip?.name ?: "Bubatz FM"
            else -> track?.title ?: "Bubatz FM"
        }
        val artist = when {
            useOmnia -> omniaState.artist.ifBlank { "Omnia" }
            isRadio -> "RADIOEINSPIELER"
            else -> track?.artist ?: "Bereit für Musik"
        }
        val album = when {
            useOmnia -> omniaState.album
            isRadio -> "ON AIR"
            else -> track?.album.orEmpty()
        }
        val duration = if (useOmnia) {
            omniaState.durationMs
        } else {
            (state?.currentDurationMs ?: 0L).coerceAtLeast(track?.durationMs ?: clip?.durationMs ?: 0L)
        }

        Column(
            modifier
                .fillMaxSize()
                .background(BubatzDark)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.bubatz_logo_horizontal),
                contentDescription = "Bubatz FM",
                modifier = Modifier.fillMaxWidth().height(72.dp),
                contentScale = ContentScale.Fit
            )

            Spacer(Modifier.height(8.dp))


            // On-air badge: fixed icon zone + independent three-line text zone.
            // The broccoli never moves with the programme title. Long titles get
            // their own full middle line instead of colliding with the icon.
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.80f)
                    .height(60.dp)
                    .clickable { onShowProgram() },
                shape = RoundedCornerShape(14.dp),
                color = BubatzMid.copy(alpha = 0.45f)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .width(56.dp)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.Center
                    ) {
                        MiniBroccoliRadio(Modifier.size(width = 54.dp, height = 42.dp).offset(x = 3.dp))
                    }

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .padding(end = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "JETZT:",
                            color = BubatzSage.copy(alpha = 0.90f),
                            fontSize = 9.5.sp,
                            lineHeight = 10.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 0.7.sp,
                            textAlign = TextAlign.Center,
                            maxLines = 1
                        )
                        Text(
                            text = programSlot.name.uppercase(),
                            color = BubatzCream.copy(alpha = 0.96f),
                            fontSize = when {
                                programSlot.name.length > 22 -> 9.5.sp
                                programSlot.name.length > 17 -> 11.sp
                                else -> 13.5.sp
                            },
                            lineHeight = when {
                                programSlot.name.length > 22 -> 10.5.sp
                                programSlot.name.length > 17 -> 11.5.sp
                                else -> 14.sp
                            },
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            softWrap = false
                        )
                        Text(
                            text = "NOCH BIS ${programSlot.endLabel}",
                            color = BubatzSage.copy(alpha = 0.9f),
                            fontSize = 8.5.sp,
                            lineHeight = 9.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            Surface(
                modifier = Modifier.fillMaxWidth().aspectRatio(1f),
                shape = RoundedCornerShape(26.dp),
                color = BubatzGreen,
                tonalElevation = 4.dp
            ) {
                if (isRadio || useOmnia) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Image(
                            painterResource(if (useOmnia) R.drawable.bubatz_app_icon_dark else R.drawable.bubatz_logo_main_dark),
                            if (useOmnia) "Omnia über Bubatz FM" else "Bubatz FM Einspieler",
                            Modifier.fillMaxSize().padding(if (useOmnia) 52.dp else 28.dp),
                            contentScale = ContentScale.Fit
                        )
                    }
                } else {
                    AlbumArtwork(
                        uri = track?.uri,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            if (useOmnia) {
                AssistChip(
                    onClick = {},
                    label = { Text("OMNIA · EXTERNE WIEDERGABE") },
                    colors = AssistChipDefaults.assistChipColors(
                        labelColor = BubatzCream,
                        containerColor = BubatzMid
                    )
                )
                Spacer(Modifier.height(10.dp))
            }

            if (isRadio) {
                AssistChip(
                    onClick = {},
                    label = { Text("● ON AIR · BUBATZ FM") },
                    colors = AssistChipDefaults.assistChipColors(
                        labelColor = BubatzCream,
                        containerColor = BubatzMid
                    )
                )
                Spacer(Modifier.height(10.dp))
            }

            Text(
                text = title,
                color = BubatzCream,
                fontSize = 25.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 2
            )
            Spacer(Modifier.height(5.dp))
            Text(
                text = artist,
                color = if (isRadio) BubatzGold else BubatzSage,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
            if (album.isNotBlank()) {
                Text(
                    text = album,
                    color = BubatzSage.copy(alpha = 0.85f),
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
            }

            Spacer(Modifier.height(20.dp))

            val shownPosition = if (isSeeking) seekPreviewPosition else if (useOmnia) omniaState.positionMs else visualPosition
            val sliderValue = if (duration > 0L) {
                (shownPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
            } else 0f

            CompactSeekBar(
                value = sliderValue,
                enabled = duration > 0L && !isRadio,
                onValueChange = { value ->
                    if (duration > 0L) {
                        isSeeking = true
                        seekPreviewPosition = (duration * value.coerceIn(0f, 1f)).toLong()
                    }
                },
                onValueChangeFinished = {
                    if (isSeeking && duration > 0L) {
                        val target = seekPreviewPosition.coerceIn(0L, duration)
                        visualPosition = target
                        if (useOmnia) OmniaBridge.seekTo(target) else sendSeekAction(target)
                    }
                    isSeeking = false
                }
            )
            Spacer(Modifier.height(6.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(shownPosition), color = BubatzSage, fontSize = 11.sp)
                Text(formatTime(duration), color = BubatzSage, fontSize = 11.sp)
            }

            Spacer(Modifier.height(14.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { if (useOmnia) OmniaBridge.previous() else sendPlaybackAction(PlaybackService.ACTION_PREVIOUS) }) {
                    Icon(Icons.Default.SkipPrevious, "Vorheriger Titel", tint = BubatzCream, modifier = Modifier.size(34.dp))
                }

                FilledIconButton(
                    onClick = { if (useOmnia) OmniaBridge.playPause() else sendPlaybackAction(PlaybackService.ACTION_PLAY_PAUSE) },
                    modifier = Modifier.size(72.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = BubatzCream,
                        contentColor = BubatzDark
                    )
                ) {
                    Icon(
                        if ((useOmnia && omniaState.isPlaying) || (!useOmnia && state?.isPlaying == true)) Icons.Default.Pause else Icons.Default.PlayArrow,
                        if ((useOmnia && omniaState.isPlaying) || (!useOmnia && state?.isPlaying == true)) "Pause" else "Play",
                        modifier = Modifier.size(38.dp)
                    )
                }

                IconButton(onClick = { if (useOmnia) OmniaBridge.next() else sendPlaybackAction(PlaybackService.ACTION_NEXT) }) {
                    Icon(Icons.Default.SkipNext, "Nächster Titel", tint = BubatzCream, modifier = Modifier.size(34.dp))
                }
            }

            Spacer(Modifier.height(10.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Shuffle, null, tint = BubatzSage, modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(5.dp))
                Text("BUBATZ.IQ", color = BubatzSage, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(18.dp))
                Text("•", color = BubatzMid)
                Spacer(Modifier.width(18.dp))
                Text(if (useOmnia) "OMNIA BRIDGE" else "BUBATZ.FM", color = BubatzGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(12.dp))
            Text(
                "Bluetooth- & Lockscreen-Steuerung aktiv",
                color = BubatzSage.copy(alpha = 0.75f),
                fontSize = 10.sp
            )

            Spacer(Modifier.height(18.dp))
            Text(
                text = "Bubatz.FM · v${BuildConfig.VERSION_NAME}",
                color = BubatzSage.copy(alpha = 0.48f),
                fontSize = 9.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(12.dp))
        }


    }

    @Composable
    private fun AlbumArtwork(uri: String?, modifier: Modifier = Modifier) {
        // Keep the previous cover visible until the next embedded cover is ready.
        // This prevents the broccoli placeholder from flashing during normal transitions.
        var artworkBytes by remember { mutableStateOf<ByteArray?>(null) }

        LaunchedEffect(uri) {
            if (uri.isNullOrBlank()) {
                artworkBytes = null
                return@LaunchedEffect
            }

            val loadedArtwork = withContext(Dispatchers.IO) {
                runCatching {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(this@MainActivity, Uri.parse(uri))
                        retriever.embeddedPicture
                    } finally {
                        retriever.release()
                    }
                }.getOrNull()
            }

            artworkBytes = loadedArtwork
        }

        val bitmap = remember(artworkBytes) {
            artworkBytes?.let { bytes ->
                runCatching {
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
                }.getOrNull()
            }
        }

        Box(modifier.background(BubatzGreen), contentAlignment = Alignment.Center) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap,
                    contentDescription = "Albumcover",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Image(
                    painterResource(R.drawable.bubatz_app_icon_dark),
                    "Bubatz FM",
                    Modifier.fillMaxSize().padding(52.dp),
                    contentScale = ContentScale.Fit
                )
            }
        }
    }

    @Composable
    private fun CompactSeekBar(
        value: Float,
        enabled: Boolean,
        onValueChange: (Float) -> Unit,
        onValueChangeFinished: () -> Unit
    ) {
        val active = BubatzGold
        val inactive = BubatzMid
        val disabled = BubatzSage.copy(alpha = 0.45f)

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .height(24.dp)
                .then(
                    if (enabled) {
                        Modifier
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onTap = { offset ->
                                        val fraction = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                                        onValueChange(fraction)
                                        onValueChangeFinished()
                                    }
                                )
                            }
                            .pointerInput(Unit) {
                                detectHorizontalDragGestures(
                                    onDragStart = { offset ->
                                        val fraction = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                                        onValueChange(fraction)
                                    },
                                    onHorizontalDrag = { change, _ ->
                                        val fraction = (change.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                                        onValueChange(fraction)
                                        change.consume()
                                    },
                                    onDragEnd = onValueChangeFinished,
                                    onDragCancel = onValueChangeFinished
                                )
                            }
                    } else Modifier
                )
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val y = size.height / 2f
                val startX = 4.dp.toPx()
                val endX = size.width - 4.dp.toPx()
                val usable = (endX - startX).coerceAtLeast(0f)
                val thumbX = startX + usable * value.coerceIn(0f, 1f)
                val trackWidth = 4.dp.toPx()

                drawLine(
                    color = if (enabled) inactive else disabled,
                    start = Offset(startX, y),
                    end = Offset(endX, y),
                    strokeWidth = trackWidth,
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = if (enabled) active else disabled,
                    start = Offset(startX, y),
                    end = Offset(thumbX, y),
                    strokeWidth = trackWidth,
                    cap = StrokeCap.Round
                )
                drawCircle(
                    color = if (enabled) active else disabled,
                    radius = 6.dp.toPx(),
                    center = Offset(thumbX, y)
                )
            }
        }
    }

    @Composable
    private fun RecentHistoryScreen(modifier: Modifier = Modifier) {
        val db = (application as BubatzApplication).database
        val recent by db.history().observeRecentMusic(50).collectAsState(initial = emptyList())

        Column(
            modifier
                .fillMaxSize()
                .background(BubatzDark)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 18.dp)
        ) {
            Text("Wer war das gerade?", color = BubatzCream, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Die letzten 50 Musiktitel · Einspieler werden nicht aufgeführt", color = BubatzSage, fontSize = 13.sp)
            Spacer(Modifier.height(14.dp))

            if (recent.isEmpty()) {
                SettingsCard("Noch nichts gehört") {
                    Text("Sobald Bubatz.FM Musik abspielt, tauchen die zuletzt gehörten Titel hier auf.", color = BubatzSage, fontSize = 13.sp)
                }
            } else {
                recent.forEach { item ->
                    RecentHistoryRow(item)
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }

    @Composable
    private fun RecentHistoryRow(item: RecentMusicItem) {
        var artworkBytes by remember(item.trackId) { mutableStateOf<ByteArray?>(null) }
        LaunchedEffect(item.trackId, item.uri) {
            artworkBytes = withContext(Dispatchers.IO) {
                runCatching {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(this@MainActivity, Uri.parse(item.uri))
                        retriever.embeddedPicture
                    } finally {
                        retriever.release()
                    }
                }.getOrNull()
            }
        }
        val bitmap = remember(artworkBytes) {
            artworkBytes?.let { bytes ->
                runCatching { BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap() }.getOrNull()
            }
        }
        Card(
            onClick = { playTrackFromHistory(item.trackId) },
            colors = CardDefaults.cardColors(containerColor = BubatzGreen),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(58.dp),
                    shape = RoundedCornerShape(10.dp),
                    color = BubatzMid
                ) {
                    if (bitmap != null) {
                        Image(bitmap = bitmap, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    } else {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.MusicNote, null, tint = BubatzCream.copy(alpha = 0.8f))
                        }
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.title, color = BubatzCream, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
                    Text(item.artist ?: "Unbekannter Interpret", color = BubatzSage, fontSize = 13.sp, maxLines = 1)
                    Text(formatHistoryTime(item.playedAt), color = BubatzSage.copy(alpha = 0.8f), fontSize = 11.sp)
                }
                Icon(Icons.Default.PlayArrow, "Erneut abspielen", tint = BubatzGold)
            }
        }
    }

    @Composable
    private fun SettingsScreen(modifier: Modifier = Modifier) {
        val db = (application as BubatzApplication).database
        val scope = rememberCoroutineScope()
        val settings = remember { AppSettings(this) }
        LaunchedEffect(Unit) { settings.ensureDurablePersistence() }

        val musicCount by db.tracks().observeCount().collectAsState(initial = 0)
        val clipCount by db.clips().observeCount().collectAsState(initial = 0)
        val autoBt by settings.autoBluetooth.collectAsState(initial = true)
        val autoBtAll by settings.autoBluetoothAllDevices.collectAsState(initial = true)
        val selectedBt by settings.autoBluetoothDeviceAddresses.collectAsState(initial = emptySet())
        val skipOnce by settings.autoBluetoothSkipOnce.collectAsState(initial = false)
        val crossfade by settings.crossfadeMs.collectAsState(initial = 6500)
        val radioEnabled by settings.radioEnabled.collectAsState(initial = true)
        val lastFmEnabled by settings.lastFmEnabled.collectAsState(initial = false)
        val doNotDisturbCalls by settings.doNotDisturbCalls.collectAsState(initial = false)

        val pairedDevices = remember { BluetoothDeviceRepository(this).pairedAudioDevices() }

        val lastFmStore = remember { LastFmSessionStore(this) }
        val lastFmAuth = remember { LastFmAuthCoordinator(this) }
        var lastFmUser by remember { mutableStateOf(lastFmStore.username) }
        var lastFmStatus by remember {
            mutableStateOf(if (lastFmUser != null) "Verbunden als $lastFmUser" else "Nicht verbunden")
        }
        var lastFmApiKey by remember { mutableStateOf(lastFmStore.apiKey.orEmpty()) }
        var lastFmSecret by remember { mutableStateOf(lastFmStore.sharedSecret.orEmpty()) }
        var lastFmHasApiCredentials by remember { mutableStateOf(lastFmStore.hasApiCredentials) }

        var status by remember { mutableStateOf(ScanDiagnostics(this).read()) }

        val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            uri ?: return@rememberLauncherForActivityResult
            persist(uri)
            scope.launch {
                status = "Musik wird eingelesen …"
                val result = LibraryScanner(this@MainActivity).scanMusicDetailed(uri)
                var stored = 0
                if (result.error == null) {
                    db.withTransaction {
                        // v1.07: a scan is a real folder sync. Anything that no longer
                        // exists in the selected tree is disabled, while existing rows
                        // keep metadata/playCount/history identity. New files are inserted.
                        db.tracks().disableAll()
                        result.tracks.chunked(500).forEachIndexed { index, chunk ->
                            val inserted = db.tracks().insertAll(chunk)
                            stored += inserted.count { it != -1L }
                            db.tracks().enableByUris(chunk.map { it.uri })
                            status = "Bibliothek wird abgeglichen … ${minOf((index + 1) * 500, result.tracks.size)}/${result.tracks.size}"
                            ScanDiagnostics(this@MainActivity).save(status)
                        }
                    }
                }
                val activeAfter = db.tracks().count()
                val s = result.stats
                status = buildString {
                    append("FERTIG / SYNC\n")
                    append("Ordner: ${s.directoriesVisited} · Dateien: ${s.filesVisited}\n")
                    append("Audio erkannt: ${s.audioRecognized}\n")
                    append("Aktiv in Bibliothek: $activeAfter · Neu: $stored\n")
                    append("Query-Fehler: ${s.queryErrors}")
                    result.error?.let { append("\nFehler: $it – bestehende Bibliothek unverändert") }
                }
                ScanDiagnostics(this@MainActivity).save(status)
            }
        }

        val clipPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            uri ?: return@rememberLauncherForActivityResult
            persist(uri)
            scope.launch {
                status = "Einspieler werden eingelesen …"
                val items = LibraryScanner(this@MainActivity).scanRadio(uri)
                db.withTransaction {
                    db.clips().disableAll()
                    items.chunked(500).forEach { chunk ->
                        db.clips().insertAll(chunk)
                        db.clips().enableByUris(chunk.map { it.uri })
                    }
                }
                status = "${items.size} Einspieler aktiv · Ordner abgeglichen"
            }
        }

        Column(
            modifier
                .fillMaxSize()
                .background(BubatzDark)
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            Image(
                painterResource(R.drawable.bubatz_logo_horizontal),
                "Bubatz FM",
                Modifier.fillMaxWidth().height(62.dp),
                contentScale = ContentScale.Fit
            )
            Spacer(Modifier.height(16.dp))

            SettingsCard("Bitte nicht stören!") {
                SettingSwitch(
                    "Anrufe ignorieren und Musik weiterspielen",
                    doNotDisturbCalls
                ) { enabled ->
                    scope.launch { settings.setDoNotDisturbCalls(enabled) }
                }
                Text(
                    if (doNotDisturbCalls)
                        "Aktiv: Auch bei Telefonanrufen spielt Bubatz weiter."
                    else
                        "Standard: Eingehende und aktive Telefonanrufe pausieren Bubatz. Danach geht es nur weiter, wenn der Anruf die Pause ausgelöst hat. Benachrichtigungstöne bleiben ohne Einfluss.",
                    color = BubatzSage,
                    fontSize = 12.sp
                )
                if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                    Spacer(Modifier.height(8.dp))
                    Text("Telefonberechtigung fehlt – die Anrufpause kann sonst nicht funktionieren.", color = BubatzGold, fontSize = 11.sp)
                    OutlinedButton(onClick = {
                        requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE), 52)
                    }) { Text("Telefonberechtigung erlauben") }
                }
            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Bibliothek") {
                Text("$musicCount Musiktitel · $clipCount Einspieler", color = BubatzCream)
                Text(status, color = BubatzSage, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { musicPicker.launch(null) }) { Text("Musikordner") }
                    Button(onClick = { clipPicker.launch(null) }) { Text("Einspieler") }
                }
            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Omnia Bridge · v0.91") {
                val omniaState by OmniaBridge.state.collectAsState()
                val listenerEnabled = remember {
                    val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
                    enabled.contains(packageName)
                }

                Text(
                    when {
                        !listenerEnabled -> "Benachrichtigungszugriff fehlt"
                        omniaState.connected -> "Omnia verbunden"
                        else -> "Omnia noch nicht im MediaSession-Stack gefunden"
                    },
                    color = if (omniaState.connected) BubatzSage else BubatzCream,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(8.dp))

                if (omniaState.connected) {
                    Text(
                        omniaState.title.ifBlank { "Titel unbekannt" },
                        color = BubatzCream,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (omniaState.artist.isNotBlank()) {
                        Text(omniaState.artist, color = BubatzSage, fontSize = 13.sp)
                    }
                    if (omniaState.album.isNotBlank()) {
                        Text(omniaState.album, color = BubatzSage.copy(alpha = 0.85f), fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { OmniaBridge.previous() }) {
                            Icon(Icons.Default.SkipPrevious, "Omnia: vorheriger Titel", tint = BubatzCream)
                        }
                        FilledIconButton(onClick = { OmniaBridge.playPause() }) {
                            Icon(
                                if (omniaState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                "Omnia: Play/Pause"
                            )
                        }
                        IconButton(onClick = { OmniaBridge.next() }) {
                            Icon(Icons.Default.SkipNext, "Omnia: nächster Titel", tint = BubatzCream)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "MediaSession: ${omniaState.packageName} · Actions 0x${omniaState.actions.toString(16)}",
                        color = BubatzSage,
                        fontSize = 10.sp
                    )
                } else {
                    Text(
                        "Omnia starten und dort einen Titel abspielen. Bubatz übernimmt Metadaten und Standard-Steuerung direkt aus Omnias echter Android-MediaSession.",
                        color = BubatzSage,
                        fontSize = 11.sp
                    )
                }

                if (!listenerEnabled) {
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = {
                        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    }) { Text("Zugriff öffnen") }
                }
            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Wiedergabe-Diagnose") {
                var crashText by remember {
                    mutableStateOf(CrashDiagnostics(this@MainActivity).readLiveDiagnostic())
                }
                Text(
                    "v0.91 bindet Omnia erstmals in die normale Playeransicht ein. Bubatz behält Vorrang, solange die eigene Wiedergabe läuft; bei pausiertem Bubatz übernimmt eine verbundene Omnia-Session Anzeige und Transportsteuerung.",
                    color = BubatzCream,
                    fontSize = 11.sp
                )
                Spacer(Modifier.height(8.dp))
                Text(crashText, color = BubatzSage, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        crashText = CrashDiagnostics(this@MainActivity).readLiveDiagnostic()
                    }) {
                        Text("Aktualisieren")
                    }
                    OutlinedButton(onClick = {
                        CrashDiagnostics(this@MainActivity).clearLiveDiagnostic()
                        crashText = CrashDiagnostics(this@MainActivity).readLiveDiagnostic()
                    }) {
                        Text("Löschen")
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = {
                    sendPlaybackAction(PlaybackService.ACTION_AUDIO_PIPELINE_DIAGNOSTIC)
                    kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
                        kotlinx.coroutines.delay(250L)
                        crashText = CrashDiagnostics(this@MainActivity).readLiveDiagnostic()
                    }
                }) { Text("Audio-System prüfen") }
            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Omnia-Vergleichsdiagnose") {
                var comparisonText by remember {
                    mutableStateOf(CrashDiagnostics(this@MainActivity).readNotificationComparison())
                }
                val listenerEnabled = remember(comparisonText) {
                    val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
                    enabled.contains(packageName)
                }
                Text(
                    if (listenerEnabled) "Benachrichtigungszugriff: aktiv" else "Benachrichtigungszugriff: noch nicht aktiviert",
                    color = if (listenerEnabled) BubatzSage else BubatzCream, fontSize = 11.sp
                )
                Spacer(Modifier.height(6.dp))
                Text("v1.47.34 ergänzt den Omnia/Bubatz-Vergleich um ART/ALBUM_ART: Abmessungen, Speichergröße, Bitmap-Format und Artwork-URIs. Die Wiedergabe bleibt unverändert.", color = BubatzCream, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                Text(comparisonText, color = BubatzSage, fontSize = 10.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    }) { Text("Zugriff öffnen") }
                    OutlinedButton(onClick = {
                        comparisonText = CrashDiagnostics(this@MainActivity).readNotificationComparison()
                    }) { Text("Vergleich laden") }
                }

            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Android-Absturzdiagnose") {
                var systemCrashText by remember {
                    mutableStateOf(CrashDiagnostics(this@MainActivity).readSystemExitInfo())
                }
                Text(
                    systemCrashText,
                    color = BubatzSage,
                    fontSize = 10.sp
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = {
                    systemCrashText = CrashDiagnostics(this@MainActivity).readSystemExitInfo()
                }) {
                    Text("Systemdiagnose aktualisieren")
                }
            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Radioeinspieler") {
                SettingSwitch(
                    "Automatische Einspieler aktiv",
                    radioEnabled
                ) { enabled ->
                    scope.launch { settings.setRadioEnabled(enabled) }
                }
                Text(
                    "Bei aktivierter Funktion ungefähr alle 25–35 Minuten tatsächlich gehörter Musik. Pausen und Einspieler zählen nicht. Einspieler werden nie überblendet und nie gescrobbelt.",
                    color = BubatzSage,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { sendPlaybackAction(PlaybackService.ACTION_TEST_RADIO_INSERT) }) {
                    Text("Einspieler jetzt testen")
                }
            }

            Spacer(Modifier.height(12.dp))

            var showFlowResetDialog by remember { mutableStateOf(false) }
            SettingsCard("Bubatz.IQ") {
                Text(
                    "Abwechslungsreiche Wiedergabe mit stärkerer Künstlerdurchmischung und eigenem Bubatz.IQ-Zyklus.",
                    color = BubatzSage,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { showFlowResetDialog = true }) {
                    Text("Bubatz.IQ neu mischen")
                }
            }
            if (showFlowResetDialog) {
                AlertDialog(
                    onDismissRequest = { showFlowResetDialog = false },
                    title = { Text("Bubatz.IQ neu mischen?") },
                    text = { Text("Der aktuelle Bubatz.IQ-Zyklus beginnt von vorn. Hörhistorie, Playcounts und Last.fm bleiben vollständig erhalten.") },
                    confirmButton = {
                        TextButton(onClick = {
                            FlowCycleStore(this@MainActivity).newCycle()
                            showFlowResetDialog = false
                        }) { Text("Neu mischen") }
                    },
                    dismissButton = {
                        TextButton(onClick = { showFlowResetDialog = false }) { Text("Abbrechen") }
                    }
                )
            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Crossfade") {
                Text("${crossfade / 1000.0} Sekunden · nur Musik → Musik", color = BubatzSage, fontSize = 12.sp)
                Slider(
                    value = crossfade.toFloat(),
                    onValueChange = { value -> scope.launch { settings.setCrossfadeMs(value.toInt()) } },
                    valueRange = 0f..15000f,
                    steps = 14
                )
                Text("Einspieler werden niemals überblendet.", color = BubatzGold, fontSize = 12.sp)
            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Bluetooth Auto-Start") {
                SettingSwitch(
                    "Automatisch bei Bluetooth-Audio starten",
                    autoBt
                ) { scope.launch { settings.setAutoBluetooth(it) } }

                if (autoBt) {
                    SettingSwitch("Alle Bluetooth-Audiogeräte", autoBtAll) {
                        scope.launch { settings.setAutoBluetoothAllDevices(it) }
                    }

                    if (!autoBtAll) {
                        pairedDevices.forEach { device ->
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = device.address in selectedBt,
                                    onCheckedChange = { enabled ->
                                        scope.launch {
                                            settings.setAutoBluetoothDeviceEnabled(device.address, enabled)
                                        }
                                    }
                                )
                                Text(device.name, color = BubatzCream)
                            }
                        }
                    }

                    OutlinedButton(
                        onClick = { scope.launch { settings.suppressNextBluetoothAutoStart() } },
                        enabled = !skipOnce
                    ) {
                        Text(
                            if (skipOnce) "Nächster Auto-Start wird übersprungen"
                            else "Beim nächsten Verbinden still bleiben"
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            SettingsCard("Last.fm · v1.01") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Scrobbling", color = BubatzCream, fontWeight = FontWeight.SemiBold)
                        Text(
                            if (lastFmEnabled) "Aktiv" else "Ausgeschaltet",
                            color = BubatzSage,
                            fontSize = 12.sp
                        )
                    }
                    Switch(
                        checked = lastFmEnabled,
                        onCheckedChange = { enabled ->
                            scope.launch { settings.setLastFmEnabled(enabled) }
                        }
                    )
                }

                Spacer(Modifier.height(8.dp))
                Text(lastFmStatus, color = BubatzSage, fontSize = 12.sp)
                Text(
                    "Account und Scrobbling sind unabhängig: Du kannst den Account wechseln oder Scrobbling komplett abschalten.",
                    color = BubatzSage,
                    fontSize = 11.sp
                )

                if (!lastFmHasApiCredentials) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Für die Last.fm-API braucht Bubatz einmalig einen API-Key und Shared Secret. Sie werden verschlüsselt nur auf diesem Gerät gespeichert und nicht in das Projekt eingebaut.",
                        color = BubatzCream,
                        fontSize = 11.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = lastFmApiKey,
                        onValueChange = { lastFmApiKey = it },
                        label = { Text("Last.fm API-Key") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = lastFmSecret,
                        onValueChange = { lastFmSecret = it },
                        label = { Text("Shared Secret") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(
                        enabled = lastFmApiKey.isNotBlank() && lastFmSecret.isNotBlank(),
                        onClick = {
                            lastFmStore.saveApiCredentials(lastFmApiKey, lastFmSecret)
                            lastFmHasApiCredentials = true
                            lastFmStatus = "API-Zugang gespeichert · Account noch nicht verbunden"
                        }
                    ) { Text("API-Zugang speichern") }
                } else if (lastFmUser == null) {
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = {
                        scope.launch {
                            runCatching {
                                val url = lastFmAuth.beginAuthorization()
                                lastFmAuth.openAuthorization(url)
                                lastFmStatus = "Im Browser freigeben, danach hier bestätigen."
                            }.onFailure {
                                lastFmStatus = it.message ?: "Last.fm-Anmeldung fehlgeschlagen"
                            }
                        }
                    }) { Text("Last.fm Account verbinden") }

                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(onClick = {
                        scope.launch {
                            runCatching {
                                val session = lastFmAuth.finishAuthorization()
                                lastFmUser = session.username
                                lastFmStatus = "Verbunden als ${session.username}"
                            }.onFailure {
                                lastFmStatus = it.message ?: "Freigabe noch nicht abgeschlossen"
                            }
                        }
                    }) { Text("Freigabe abgeschlossen") }
                } else {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Verbunden als $lastFmUser",
                        color = BubatzCream,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(onClick = {
                        lastFmAuth.disconnect()
                        lastFmUser = null
                        lastFmStatus = "Nicht verbunden · API-Zugang bleibt gespeichert"
                    }) { Text("Account trennen / wechseln") }
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                "Bubatz.FM · v${BuildConfig.VERSION_NAME}",
                color = BubatzSage,
                fontSize = 11.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(24.dp))
        }
    }

    @Composable
    private fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
        Card(
            colors = CardDefaults.cardColors(containerColor = BubatzGreen),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(18.dp).fillMaxWidth()) {
                Text(title, color = BubatzCream, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                Spacer(Modifier.height(8.dp))
                content()
            }
        }
    }

    @Composable
    private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = BubatzCream, modifier = Modifier.weight(1f), fontSize = 13.sp)
            Switch(checked = checked, onCheckedChange = onChange)
        }
    }

    private fun sendPlaybackAction(action: String) {
        val i = Intent(this, PlaybackService::class.java).setAction(action)
        // The Activity is in the foreground, so a normal service start is enough.
        // Starting as a foreground service before a 40k-library initialization
        // finishes can trigger Android's foreground-service timeout.
        startService(i)
    }

    private fun sendSeekAction(positionMs: Long) {
        val i = Intent(this, PlaybackService::class.java)
            .setAction(PlaybackService.ACTION_SEEK)
            .putExtra(PlaybackService.EXTRA_SEEK_POSITION_MS, positionMs)
        startService(i)
    }

    private fun playTrackFromHistory(trackId: Long) {
        startService(
            Intent(this, PlaybackService::class.java)
                .setAction(PlaybackService.ACTION_PLAY_TRACK_ID)
                .putExtra(PlaybackService.EXTRA_TRACK_ID, trackId)
        )
    }

    private fun formatHistoryTime(timestamp: Long): String {
        val formatter = java.text.SimpleDateFormat("dd.MM. · HH:mm", java.util.Locale.getDefault())
        return formatter.format(java.util.Date(timestamp))
    }

    private fun persist(uri: Uri) {
        runCatching {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
    }

    private fun formatTime(ms: Long): String {
        if (ms <= 0) return "0:00"
        val total = ms / 1000
        val minutes = total / 60
        val seconds = total % 60
        return "$minutes:${seconds.toString().padStart(2, '0')}"
    }
}
